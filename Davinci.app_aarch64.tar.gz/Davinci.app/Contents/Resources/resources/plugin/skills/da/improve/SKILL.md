---
name: improve
description: Optimization, refactoring, and iterative improvement based on verification results
agent: davinci-iterator
agents: [senior-fullstack, senior-architect]
davinci-phase: act
allowed-tools: [Write, Edit, Read, Bash, Glob, Grep, Task]
next-skill: verify
skill-type: flexible
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 생성자: 자기 검증은 사전 점검일 뿐이다. 최종 판정은 독립 verify 노드가 낸다. 미완료 시 partial + remaining.

# /da:improve - Optimization & Improvement

## Purpose
Fix bugs, optimize performance, refactor code, and enhance quality based on verification results.
Close the DAVINCI loop by applying lessons learned.

## Workflow
1. **Bug Fixes** - Address verification issues by priority
2. **Performance Optimization** - Optimize bottlenecks, reduce bundle size
3. **Code Refactoring** - Improve structure, reduce duplication
4. **UX Enhancement** - Polish interactions, animations, responsiveness
5. **Re-verification** - Run targeted tests to confirm fixes

## Deliverables
- Fixed bugs with test coverage
- Performance report (before/after metrics)
- Refactored code with improved maintainability
- Updated documentation

## Node Contract (da:protocol §2 / §4.4)

da:improve는 verify → improve → verify 루프의 **NOT_MET 분기 노드**다.

**입력(필수)**: 오케스트레이터 또는 직전 da:verify handoff에서 다음을 받는다. 없으면 `docs/.da-*-checkpoint.json`의 `handoff_da:verify`를 읽어 채운다.
```json
{"attempt": 2, "max_attempts": 3,
 "previous_failure": {"verdict": "NOT_MET", "reason": "...", "next_action_hint": "...",
                      "items_failed": [{"name": "...", "detail": "..."}], "severity_max": "High"}}
```
- attempt ≥ 2인데 previous_failure가 없으면 **작업 시작 금지** → `status: blocked`, blockers: ["previous_failure missing"].
- 직전 시도와 같은 접근 금지. 시작 전에 1줄로 선언: "이전: X → 실패: Y → 이번에 다르게: Z".

**출력(필수)**: handoff JSON — `status`, `evidence[]`(재실행한 테스트/빌드 명령 + exit code), `remaining[]`(미해결 items), `approach_changed: true|false`.
- 수정 후 자기 재검증은 사전 점검이다. **passed 판정은 후속 da:verify 노드가 낸다** — 여기서 "verified/passed" 선언 금지.
- Critical/High 항목이 남았고 attempt == max_attempts → `status: blocked` (강제 진행 금지, §3.4).

## Iron Law

**NO FIX WITHOUT ROOT CAUSE INVESTIGATION FIRST.**

Fixing symptoms creates new bugs. Every fix must address the root cause.

## Three-Fix Architectural Escalation Rule
```
Fix #1 fails -> Re-analyze with new information.
Fix #2 fails -> Question your assumptions.
Fix #3 fails -> STOP. The architecture is wrong.
               Do NOT attempt fix #4.
               Escalate to /da:system for architectural review.
```

**Architectural problem indicators:**
- Each fix reveals new issues elsewhere
- Fixes require "massive refactoring"
- Same logical error manifests in different forms

## Anti-Rationalization Rules
- "One more fix should work" -- if 3 failed, the problem is structural.
- "I'm almost there" -- sunk cost fallacy. Step back.
- "Refactoring would take too long" -- repeated fixes take longer.
- Adjusting tests to match buggy output is NOT improvement.
- "I'll address architecture later" -- later never comes. Escalate now.

## Red Flags -- STOP AND REASSESS
- Applying the same fix type for the third time
- Each fix is getting larger and more complex
- Fix requires changes in 5+ files (wrong abstraction)
- Adding special cases, flags, or workarounds

## Defense-in-Depth Post-Fix Hardening
After EVERY successful fix, add validation at 4 layers:
1. **Entry point** - Input validation where bug could be caught earliest
2. **Business logic** - Precondition guards making bug structurally impossible
3. **Environment** - Dependency/state validation for environmental causes
4. **Instrumentation** - Logging/metrics to detect recurrence

## Self-Correction Integration
Before fixing: check reflexion.json for similar past failures.
If `recurrence_count > 2` -> trigger architectural escalation.
After fix: update reflexion.json with new learnings.

## Transition
- **Next**: /da:verify
- **Condition**: All critical bugs fixed, performance targets met
