# Anime.js V4 Text Animation Reference

> da:effect_text Layer 2 — 20-type text animations
> Dependencies: `animejs@^4.x`

## Core API: splitText + stagger + createTimeline

```tsx
import { animate, stagger, createTimeline } from "animejs"
import { splitText } from "animejs/text"
import { createScope } from "animejs/scope"
import { spring } from "animejs/easings/spring"
```

## React Integration Pattern

```tsx
"use client"
import { useEffect, useRef } from "react"
import { animate, stagger } from "animejs"
import { splitText } from "animejs/text"
import { createScope } from "animejs/scope"

interface TextAnimationProps {
  text: string
  animation: TextAnimationType
  staggerInterval?: number
  staggerFrom?: "first" | "center" | "last" | "random"
  className?: string
  onReady?: () => void
}

export function TextAnimation({ text, animation, staggerInterval = 30, staggerFrom = "first", className, onReady }: TextAnimationProps) {
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!ref.current) return
    const scope = createScope({ root: ref })

    scope.add(() => {
      const splitter = splitText(ref.current!, { chars: true, accessible: true })
      applyTextEffect(splitter.chars, animation, staggerInterval, staggerFrom)
      onReady?.()
    })

    return () => scope.revert()
  }, [text, animation])

  return <div ref={ref} className={className}>{text}</div>
}
```

## 20 Effect Implementations

### Basic (score 0-1)

| Effect | Score | Description |
|--------|-------|-------------|
| `split-fade` | 1 | Per-character opacity 0→1 + translateY fade |
| `split-slide` | 1 | Per-character translateX slide in |
| `horizontal-split` | 1 | Left/right halves separate then merge |
| `wavy` | 1 | Per-character translateY wave (stagger + sin) |
| `raining-letters` | 1 | Letters fall from above (randomized delay) |
| `subtle-highlight` | 1 | Sequential highlight (background-color sweep) |
| `spring` | 0 | Entire text appears with Motion spring |
| `typewriter` | 1 | Windups-based sequential typing (separate component) |
| `none` | 0 | Display immediately without animation |

### Advanced (score 2)

| Effect | Score | Description |
|--------|-------|-------------|
| `magnetic-assemble` | 2 | Gather from random positions like a magnetic field |
| `neon-flicker` | 2 | Neon sign flicker (textShadow + opacity) |
| `3d-rotate` | 2 | Per-character rotateY 3D rotation entrance |
| `explode` | 2 | Burst outward from center then reassemble |
| `glitch` | 2 | Digital glitch (clip-path + skew + color shift) |
| `scatter-reform` | 2 | Scatter then reassemble (not yet implemented — Phase 2) |

### Intermediate (score 1)

| Effect | Score | Description |
|--------|-------|-------------|
| `smoke-reveal` | 1 | Appear clearly from blur |
| `gravity-drop` | 1 | Fall from above with gravity + bounce |
| `perspective-flip` | 1 | rotateX 3D flip |
| `scramble-decode` | 1 | Random characters → decode to correct characters |
| `breathing` | 0 | Smooth scale pulse (infinite loop) |
| `grid-spawn` | 1 | Sequential generation from grid coordinates |
| `liquid-fill` | 1 | Bottom→top color fill animation |

## Next.js / React 19 Considerations

### Required Rules

1. **`"use client"` required** — `splitText`, `createScope` use DOM APIs and cannot run in server components
2. **`createScope` cleanup required** — React 18+ strict mode runs useEffect twice, so without `scope.revert()` cleanup, text gets double-split and disappears
3. **`splitText` import path** — must import from `"animejs"` or `"animejs/text"`. Other paths forbidden

### Forbidden Pattern — Manual innerHTML split

```tsx
// Absolutely forbidden — manual DOM split
// In React strict mode, useEffect runs twice causing innerHTML to be replaced twice, destroying text
useEffect(() => {
  if (!ref.current) return
  const text = ref.current.textContent || ""
  ref.current.innerHTML = text
    .split("")
    .map(c => `<span class="char">${c}</span>`)
    .join("")
  // No cleanup → cannot restore in strict mode
}, [])
```

```tsx
// Correct pattern — splitText + createScope
useEffect(() => {
  if (!ref.current) return
  const scope = createScope({ root: ref })

  scope.add(() => {
    const splitter = splitText(ref.current!, { chars: true, accessible: true })
    animate(splitter.chars, {
      opacity: [0, 1],
      translateY: [20, 0],
      delay: stagger(30),
      duration: 600,
      ease: "outExpo",
    })
  })

  return () => scope.revert()  // Strict mode safe: DOM restore + animation cleanup
}, [])
```

### Next.js Dynamic Import

When using with Vanta etc., ensure `splitText` does not execute on the server:

```tsx
// Safe usage in Next.js App Router
"use client"
import { useEffect, useRef } from "react"
// animejs is client-only, so "use client" declaration is sufficient
// dynamic import not needed (animejs natively supports ESM)
import { animate, stagger } from "animejs"
import { splitText } from "animejs/text"
import { createScope } from "animejs/scope"
```

> **Iron Rule**: Text splitting must use the `splitText` API.
> Manual `innerHTML`/`textContent` based split is forbidden under all circumstances.
> Wrap with `createScope` and call `scope.revert()` in cleanup.

## Anime.js V4 Core Patterns

### splitText + stagger
```typescript
const splitter = splitText(".title", { chars: true, accessible: true })
animate(splitter.chars, {
  opacity: [0, 1],
  translateY: [20, 0],
  delay: stagger(30, { from: "center" }),
  duration: 600,
  ease: "outExpo",
})
```

### createTimeline (multi-stage sequencing)
```typescript
const tl = createTimeline({ defaults: { duration: 400, ease: "outQuint" } })
tl.add(".title .char", { opacity: [0, 1], translateY: [30, 0], delay: stagger(25) })
  .add(".subtitle", { opacity: [0, 1], translateY: [15, 0] }, "-=200")
  .add(".cta-btn", { opacity: [0, 1], scale: [0.9, 1] }, "-=100")
```

### Scope (React cleanup safe)
```typescript
useEffect(() => {
  const scope = createScope({ root: containerRef })
  scope.add(() => { /* Call animate() here */ })
  return () => scope.revert()  // Clean up all animations
}, [])
```
