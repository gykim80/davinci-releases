---
description: "End active team collaboration session and clean up session state files."
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 유틸리티: 부작용(외부 API/배포/삭제) 전 §7 destructive/cost_gate 규칙을 확인한다.

## Tool Parameter Rules → See CLAUDE.md (ABSOLUTE)

# /da:cowork:cleanup - End Team Session

## Purpose
End an active team collaboration session, collect results, and clean up session state.

## Usage
```
/da:cowork:cleanup [--force]
```

## Behavioral Flow

### Phase 1: Finalize
- Collect remaining teammate outputs
- Merge results
- CTO final review

### Phase 2: Cleanup
- Remove session state file
- Archive session log
- Update DAVINCI status

### Phase 3: Report
- Team session summary
- Tasks completed/remaining
- Recommendations for follow-up
