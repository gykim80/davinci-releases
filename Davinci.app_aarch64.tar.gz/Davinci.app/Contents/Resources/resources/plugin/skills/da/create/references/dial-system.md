# 3-Dial Parameter System

## 개요

3-Dial 파라미터 시스템은 디자인 출력 강도를 세 가지 독립적인 축으로 제어한다.
각 Dial은 1-10 척도로 설정되며, Phase 1에서 결정된 값이 Creative Brief에 포함되어
Phase 3-4 구현 단계 전반에 걸쳐 참조된다.

---

## Dial 정의

### DESIGN_VARIANCE (1-10)
레이아웃 실험성 수준을 제어한다.

| 범위 | 레이아웃 유형 |
|------|-------------|
| 1-3  | 대칭 그리드, 중앙 정렬 구조 |
| 4-7  | 오프셋 배치, 요소 오버랩 |
| 8-10 | 메이슨리 레이아웃, 비대칭 자유 배치 |

### MOTION_INTENSITY (1-10)
애니메이션 강도 및 인터랙션 복잡도를 제어한다.

| 범위 | 애니메이션 유형 |
|------|--------------|
| 1-3  | 호버 상태 변화만 허용 |
| 4-7  | CSS transition 기반 전환 효과 |
| 8-10 | Spring Physics, Scroll-triggered 리빌 |

### VISUAL_DENSITY (1-10)
콘텐츠 밀도 및 정보 압축 수준을 제어한다.

| 범위 | 밀도 유형 |
|------|---------|
| 1-3  | 갤러리형 여백 중심 레이아웃 |
| 4-7  | 표준 애플리케이션 밀도 |
| 8-10 | 코크핏형 고밀도 데이터 인터페이스 |

---

## 페르소나 프리셋 매핑

| 페르소나 | VARIANCE | MOTION | DENSITY | 특성 |
|---------|----------|--------|---------|------|
| minimal | 3 | 2 | 3 | 깔끔하고 정돈된 인터페이스 |
| bold | 9 | 8 | 6 | 강렬하고 실험적인 레이아웃 |
| playful | 7 | 7 | 5 | 활기차고 인터랙티브한 디자인 |
| elegant | 5 | 4 | 3 | 절제되고 세련된 분위기 |
| terminal | 6 | 3 | 8 | 데이터 중심 고밀도 인터페이스 |

---

## Dial 레벨별 구현 규칙

### DESIGN_VARIANCE 규칙

```
variance > 4:
  - 중앙 정렬 Hero 섹션 금지
  - Split Screen 또는 Asymmetric 레이아웃 강제 적용

variance > 7:
  - Masonry 레이아웃 사용
  - 분수 단위 그리드 (fractional grid units) 적용
  - 의도적인 대형 여백 존 (massive empty zones) 배치
```

### MOTION_INTENSITY 규칙

```
motion > 5:
  - Spring Physics 활성화 (stiffness: 100, damping: 20)
  - 무한 마이크로 애니메이션 허용

motion > 7:
  - Scroll-triggered 리빌 적용
  - Parallax 효과 적용
  - IntersectionObserver 필수 사용 (addEventListener 방식 금지)
```

### VISUAL_DENSITY 규칙

```
density > 7:
  - 카드 컴포넌트 대신 border-top / divide-y 기반 리스트 구분
  - 숫자 표시는 Monospace 필수 (font-mono 클래스 적용)

density < 4:
  - 섹션 간격 py-24 ~ py-40 범위 적용
  - 여백 중심 generous whitespace 유지
```

---

## 모바일 오버라이드 규칙

variance 4-10 범위에서 비대칭/오프셋 레이아웃이 지정된 경우,
768px 미만(md: breakpoint 이하)에서는 다음 규칙을 강제 적용한다.

```css
/* 768px 미만 폴백: 단일 컬럼 */
width: 100%;       /* w-full */
padding-x: 1rem;   /* px-4 */
padding-y: 2rem;   /* py-8 */
```

- `md:` 이상에서 지정된 비대칭 레이아웃은 모바일에서 단일 컬럼으로 폴백
- 이 규칙은 DESIGN_VARIANCE와 무관하게 모바일 viewport에서 항상 우선 적용

---

## Dial 오버라이드 문법

개별 Dial 값을 덮어쓰려면 다음 문법을 사용한다.

```
--variance=9 --motion=3
--variance=7 --density=8
--motion=2
```

페르소나 프리셋 적용 후 특정 Dial만 조정할 때 사용한다.

---

## 파이프라인 통합

- **Phase 1 (Discovery)**: 페르소나 선택 또는 수동 Dial 값 설정
- **Creative Brief**: 결정된 Dial 값 세 개를 명시적으로 포함
- **Phase 3 (Design)**: Dial 규칙에 따른 레이아웃/타이포그래피/모션 결정
- **Phase 4 (Implementation)**: Dial 규칙에 따른 코드 구현 제약 적용

---

## Tier 및 로드 정책

- **Tier**: standard+
- **로드 정책**: 항상 로드 (조건 없이 모든 디자인 세션에서 참조)
