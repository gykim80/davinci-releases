---
name: save
description: "현재 작업 상태를 수동 세션 스냅샷으로 저장"
agent: pipeline-guide
agents: [pipeline-guide]
davinci-phase: null
allowed-tools: [Write, Read, Bash, Glob]
next-skill: null
skill-type: utility
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 유틸리티: 부작용(외부 API/배포/삭제) 전 §7 destructive/cost_gate 규칙을 확인한다.

# /da:save

현재 작업 상태를 수동 체크포인트로 저장합니다.
compact/stop 후에도 작업 맥락을 보존하기 위한 스냅샷입니다.

## Usage
```
/da:save                    # 현재 상태 자동 수집 + 저장
/da:save "VAD 로직 구현 중"  # 메모 추가하여 저장
```

## 동작 순서

1. **데이터 수집**
   - git status → 수정 중인 파일 목록
   - git diff --stat → 최근 변경 요약
   - 워크플로우 상태 (feature, phase, iteration, match_rate)
   - Claude가 현재 대화 맥락에서 task.description, next_steps, decisions 추론

2. **체크포인트 생성**
   ```python
   from davinci.session.checkpoint import save_checkpoint
   save_checkpoint(data, manual=True)
   ```
   저장 위치: `.claude/session/manual/{timestamp}.json`

3. **확인 메시지 출력**
   ```
   체크포인트 저장 완료: .claude/session/manual/2026-03-31T14-30-00+09-00.json
   - 파일 3개 수정 중
   - 다음: VAD 로직 구현 → PipelineMonitor 음성 상태 표시
   ```

## 체크포인트 포맷

```json
{
  "version": 1,
  "type": "manual",
  "timestamp": "2026-03-31T14:30:00+09:00",
  "task": {
    "description": "voice.rs WebSocket 연결 구현",
    "status": "in_progress",
    "progress": "3/5 단계 완료"
  },
  "context": {
    "current_files": ["src/hooks/useVoiceInput.ts"],
    "recent_changes": ["마이크 권한 체크 추가"],
    "next_steps": ["VAD 로직 구현"],
    "decisions": ["Web Speech API 대신 Whisper 채택"]
  },
  "workflow": {
    "feature": "voice-input",
    "phase": "act",
    "iteration": 2,
    "match_rate": 85.0
  }
}
```

## 제한

- 최대 5개 수동 체크포인트 (FIFO — 오래된 것 자동 삭제)
- 체크포인트 크기: 최대 10KB
- 7일 후 자동 만료

## 복원

저장된 체크포인트는 다음 방법으로 복원됩니다:
- **자동**: 세션 시작 시 `session_start` 훅이 최근 체크포인트를 컨텍스트에 주입
- **수동**: `/da:resume`으로 명시적 복원
