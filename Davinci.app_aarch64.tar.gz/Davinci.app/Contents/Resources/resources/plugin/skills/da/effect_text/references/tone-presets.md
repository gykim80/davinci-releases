# Text Effect Tone Presets

> da:effect_text — 8 tone presets mapping to text animation configurations
> Each preset defines: effect, stagger, easing, energy, timeline, and style overrides

## Preset Overview

| Tone | Effect | Stagger | Easing | Energy |
|------|--------|---------|--------|--------|
| dark | split-fade | 30ms from:first | outExpo | calm |
| neon | neon-flicker | 50ms from:random | inOutQuad | dynamic |
| minimal | spring | whole (no split) | spring(1,80,10) | calm |
| organic | wavy | 40ms from:center | outSine | calm |
| luxury | horizontal-split | 25ms from:center | outQuart | calm |
| corporate | split-slide | 30ms from:first | outQuint | calm |
| playful | explode | 20ms from:center | outBack | dynamic |
| cyber | scramble-decode | 15ms from:first | linear | moderate |

## Energy Levels

```yaml
calm:     duration 800-1200ms, no loop, subtle movement
moderate: duration 500-800ms,  optional loop, medium movement
dynamic:  duration 300-600ms,  loop allowed, large movement range
```

## Detailed Preset Configs

### dark
```yaml
effect: split-fade
stagger:
  interval: 30
  from: first
easing: outExpo
energy: calm
timeline:
  charDuration: 800
  totalEstimate: ~1200ms
style:
  color: "#e2e2e2"
  textShadow: "0 0 20px rgba(0,0,0,0.5)"
  fontWeight: 600
scroll: fade (threshold 0.3)
hover: null
```

### neon
```yaml
effect: neon-flicker
stagger:
  interval: 50
  from: random
easing: inOutQuad
energy: dynamic
timeline:
  charDuration: 400
  flickerRepeat: 3
  totalEstimate: ~1500ms
style:
  color: "#0ff"
  textShadow: |
    0 0 7px #0ff,
    0 0 10px #0ff,
    0 0 21px #0ff,
    0 0 42px #0ff
  fontWeight: 700
  fontFamily: monospace (fallback)
scroll: fade (threshold 0.2)
hover: null
```

### minimal
```yaml
effect: spring
stagger: null (whole text, no character split)
easing: spring(1, 80, 10)
energy: calm
timeline:
  duration: 1000
  totalEstimate: ~1000ms
style:
  color: inherit
  textShadow: none
  fontWeight: 400
scroll: fade (threshold 0.5)
hover: null
note: |
  spring effect animates the entire text block as one unit.
  No splitText call needed. Uses animate() on the container directly.
```

### organic
```yaml
effect: wavy
stagger:
  interval: 40
  from: center
easing: outSine
energy: calm
timeline:
  charDuration: 600
  waveAmplitude: 15
  totalEstimate: ~1400ms
style:
  color: "#4a5a3a"
  textShadow: "0 1px 2px rgba(0,0,0,0.1)"
  fontWeight: 400
  fontFamily: serif (fallback)
scroll: fade (threshold 0.3)
hover: null
```

### luxury
```yaml
effect: horizontal-split
stagger:
  interval: 25
  from: center
easing: outQuart
energy: calm
timeline:
  charDuration: 900
  splitGap: 40
  totalEstimate: ~1300ms
style:
  color: "#d4af37"
  textShadow: "0 2px 4px rgba(212,175,55,0.3)"
  fontWeight: 300
  letterSpacing: "0.05em"
  fontFamily: serif (fallback)
scroll: fade (threshold 0.4)
hover: 3d-tilt (subtle, maxRotate: 3deg)
```

### corporate
```yaml
effect: split-slide
stagger:
  interval: 30
  from: first
easing: outQuint
energy: calm
timeline:
  charDuration: 700
  slideDistance: 20
  totalEstimate: ~1100ms
style:
  color: "#1a1a2e"
  textShadow: none
  fontWeight: 500
  letterSpacing: "0.02em"
scroll: fade (threshold 0.3)
hover: null
```

### playful
```yaml
effect: explode
stagger:
  interval: 20
  from: center
easing: outBack
energy: dynamic
timeline:
  charDuration: 500
  explodeRadius: 80
  reassembleDuration: 400
  totalEstimate: ~1200ms
style:
  color: "#ff6b6b"
  textShadow: "2px 2px 0 #feca57, 4px 4px 0 #48dbfb"
  fontWeight: 800
scroll: fade (threshold 0.2)
hover: 3d-tilt (playful, maxRotate: 8deg)
```

### cyber
```yaml
effect: scramble-decode
stagger:
  interval: 15
  from: first
easing: linear
energy: moderate
timeline:
  charDuration: 600
  scrambleChars: "!@#$%^&*01"
  decodeIterations: 5
  totalEstimate: ~1400ms
style:
  color: "#00ff41"
  textShadow: "0 0 5px #00ff41, 0 0 10px rgba(0,255,65,0.3)"
  fontWeight: 400
  fontFamily: "'JetBrains Mono', 'Fira Code', monospace"
  letterSpacing: "0.03em"
scroll: fade (threshold 0.2)
hover: null
```

## Usage in Implementation

```tsx
// Example: applying a tone preset
const TONE_CONFIG = {
  dark: {
    effect: "split-fade",
    stagger: { interval: 30, from: "first" },
    easing: "outExpo",
    style: { color: "#e2e2e2", textShadow: "0 0 20px rgba(0,0,0,0.5)" },
  },
  // ... other tones
} as const

// In TextAnimation component:
const config = TONE_CONFIG[tone]
animate(splitter.chars, {
  opacity: [0, 1],
  translateY: [20, 0],
  delay: stagger(config.stagger.interval, { from: config.stagger.from }),
  duration: config.timeline.charDuration,
  ease: config.easing,
})
```

## Persona-to-Tone Mapping (da:design delegation)

```yaml
minimal  -> minimal
bold     -> dark
playful  -> playful
elegant  -> luxury
terminal -> cyber
```

When delegated from da:design, the persona determines the tone automatically.
No user confirmation needed in pipeline mode.
