---
name: git
description: Git operations with intelligent commit messages and workflow optimization
agent: starter-guide
agents: []
davinci-phase: null
allowed-tools: [Bash, Read, Grep, Glob]
next-skill: null
skill-type: rigid
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 유틸리티: 부작용(외부 API/배포/삭제) 전 §7 destructive/cost_gate 규칙을 확인한다.

## Tool Parameter Rules -> See CLAUDE.md (ABSOLUTE)
# /da:git - Intelligent Git Workflow

## Purpose
Git workflow automation with conventional commit messages, branch strategy, and safe operation guardrails.

## Usage
```
/da:git [commit|branch|pr|status] [--conventional] [--scope SCOPE]
```

## Behavioral Flow

### Phase 1: Analyze
```yaml
1. Repository_State:
   - git status (staged, unstaged, untracked)
   - git diff (changes summary)
   - git log (recent commit style)
   - Branch context and upstream status

2. Change_Classification:
   - feat: New feature
   - fix: Bug fix
   - refactor: Code restructuring
   - docs: Documentation
   - chore: Maintenance
   - test: Test additions
   - perf: Performance improvement
```

### Phase 2: Execute
```yaml
1. Smart_Commit:
   - Generate conventional commit message: type(scope): description
   - Stage relevant files (avoid secrets, large binaries)
   - Create commit

2. Branch_Management:
   - Feature branch naming: feature/description
   - Bugfix branch naming: fix/description
   - Branch cleanup suggestions

3. PR_Creation:
   - Title from commit history
   - Auto-generated description
   - Test plan checklist
```

## Safety Guardrails
- Never force push to main/master
- Never commit .env or credential files
- Warn on large binary files
- Require confirmation for destructive operations

### Push Impact Analysis (FR-08)
```yaml
trigger: git push 실행 전 반드시 수행
goal: push가 트리거하는 배포 범위를 사전에 파악

steps:
  1. git remote -v로 원격 저장소 확인
  2. PaaS CLI 존재 여부 체크:
     railway:
       - railway service list 실행
       - 같은 repo에 연결된 서비스 목록 출력
       - auto-deploy 설정된 서비스 강조
       - DB 서비스가 같은 repo에 연결되어 있으면 경고
     vercel:
       - vercel ls 실행
       - 배포 대상 프로젝트 확인
  3. 영향받는 서비스 목록을 사용자에게 보고
  4. 사용자 명시적 승인 후 push 실행

anti_pattern:
  - 서비스 목록 미확인 상태에서 git push
  - DB 서비스가 같은 repo에 연결된 상태에서 push
  - 환경변수 변경 후 원본 값 미기록 상태에서 push
```

## Boundaries

**Will:**
- Generate intelligent commit messages
- Manage branches safely
- Create well-structured PRs

**Will Not:**
- Force push without explicit request
- Commit secrets or credentials
- Run destructive git operations silently
