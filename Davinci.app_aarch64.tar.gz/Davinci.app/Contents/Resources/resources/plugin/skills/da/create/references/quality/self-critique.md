# Self-Critique Protocol (5-Dimensional Review)

> Phase 4.5: Auto-execute after Phase 4 Verification passes.
> Max 2 revision passes. Scoring happens in thinking only (never emit scores to chat).

---

## 5 Dimensions

### 1. Philosophy Consistency

Does the artifact commit to ONE design direction and sustain it across every micro-decision
(chrome, kicker, spacing, accent, tone of voice)?

**Evaluation criteria:**
- Is there a single declared direction, or multiple styles fighting?
- Do chrome/kicker vocabulary stay in one register throughout?
- Are accent/serif/mono used by the same rule on every screen?

**Scoring (1-5):**
- 1-2: Three styles fighting each other. No coherent thesis.
- 3: One direction but half the elements drift. Mixed signals.
- 4: Coherent, occasional drift on edge sections.
- 5: Every element argues for the same thesis.

**Action when < 3:** Identify the dominant direction. Remove or restyle all elements
that belong to a different direction. Unify chrome vocabulary.

---

### 2. Visual Hierarchy

Can a stranger figure out what to read first, second, third -- without being told?

**Evaluation criteria:**
- Is the largest type clearly the most important thing on each screen?
- Do mono/serif/sans roles match the information's role (meta/body/display)?
- Is there a clear primary + secondary + tertiary tier, or do loud elements compete?

**Scoring (1-5):**
- 1-2: Everything shouts. No clear reading order.
- 3: Hierarchy works on hero sections but breaks on body/detail screens.
- 4: Clear tiers, occasional collision between elements.
- 5: Eye moves through content with zero friction.

**Action when < 3:** Establish 3 explicit tiers (display/body/meta). Reduce competing
large elements. Ensure only ONE element per screen is the loudest.

---

### 3. Execution Quality

The 90/10 stuff -- alignment, leading, kerning at large sizes, image framing,
chrome polish, edge-case spacing.

**Evaluation criteria:**
- Stat/number elements: do they sit on a baseline or float?
- Column tops aligned in grid layouts?
- Placeholder image proportions consistent across sections?
- Mono labels: same letter-spacing and case rule everywhere?
- Any orphaned line breaks causing single-character lines?

**Scoring (1-5):**
- 1-2: Visible tape and string. Broken alignment throughout.
- 3: Most sections clean, 1-2 sections ragged.
- 4: Polished. Expert eye finds 2-3 minor misses.
- 5: Magazine-grade detail execution.

**Action when < 3:** Audit grid alignment section by section. Fix orphaned text,
inconsistent spacing, and mismatched label treatments.

---

### 4. Specificity

Does the artifact feel like it was made for THIS brief, or could it be any project
with the logo swapped?

**Evaluation criteria:**
- Does copy reference the actual product/domain, not generic filler?
- Are data points, metrics, and examples specific to the brief?
- Do section types and layout choices reflect the content's nature?
- Would swapping the brand name make the artifact feel wrong?

**Scoring (1-5):**
- 1-2: Generic template with logo swap. "Feature One / Feature Two" copy.
- 3: Some brief-specific elements, but structure is cookie-cutter.
- 4: Clearly made for this brief. Layout choices reflect content.
- 5: Inseparable from the brief. Every section earns its existence.

**Action when < 3:** Replace all generic copy with brief-derived content.
Restructure sections to match the actual information architecture.

---

### 5. Restraint

Does the artifact know when to stop? Or does it add decoration, animation,
and complexity beyond what the brief requires?

**Evaluation criteria:**
- Is every visual element earning its place, or decorating emptiness?
- Are animations functional (guide attention) or gratuitous?
- Is the color palette disciplined (1 accent, derived tones only)?
- Would removing any element make the design worse? (If no -> overdesigned)

**Scoring (1-5):**
- 1-2: Christmas tree. Gradients, shadows, animations, icons competing.
- 3: Some restraint, but 2-3 gratuitous decorative elements.
- 4: Clean. One intentional flourish, everything else serves function.
- 5: Nothing to remove. Every element is load-bearing.

**Action when < 3:** Remove all purely decorative elements. Reduce to
1 accent color, 1 animation type, 0 gratuitous shadows.

---

## Execution Rules

1. **Auto-execute** after Phase 4 Verification passes (never skip).
2. **Score in thinking only** -- do not emit numeric scores to the chat output.
3. **Max 2 revision passes** -- if any dimension scores < 3 after pass 1, fix and re-score.
   If still < 3 after pass 2, proceed and note the limitation in the handoff.
4. **Fix only failing dimensions** -- do not touch dimensions scoring >= 3.
5. **Evidence required** -- each score must cite specific elements, class names,
   or section labels. "Feels off" is not a valid score justification.
6. **Do not grade-inflate** -- a score of 4 means strong, not acceptable.
   If all 5 dimensions score 4+, verify you are being genuinely critical.
