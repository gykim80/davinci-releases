<!--
Source: op7418/guizang-ppt-skill (Apache-2.0)
Original: https://github.com/op7418/guizang-ppt-skill
Copyright (c) op7418. Licensed under Apache-2.0.
Modifications: Adapted for davinci-framework — Korean comments + PPTX Iron Law conflict notes.
-->

# 재사용 컴포넌트 가이드 (Reusable Components)

> 원본: op7418/guizang-ppt-skill `references/components.md`
> 모든 컴포넌트는 `template.html`의 CSS 클래스 기반.

---

## 슬라이드 구조 (Slide Structure)

```html
<section class="slide light">...</section>
<section class="slide dark">...</section>
<!-- ⚠️ PPTX: hero canvas 배경은 정적 이미지 우회 필수 -->
<section class="slide hero light">...</section>
<section class="slide hero dark">...</section>
```

---

## 타이포그래피 (Typography)

```html
<!-- 제목 계층 -->
<h1 class="h-hero">[최대 제목 — hero 전용, 5자 이하]</h1>
<h2 class="h-xl">[대형 섹션 제목]</h2>
<h3 class="h-sub">[서브타이틀]</h3>
<h4 class="h-md">[소제목]</h4>
<h2 class="h-xl h-xl-en">[English Serif Title]</h2>

<!-- 본문 계층 -->
<p class="lead">[리드 문장 — 첫 번째 대형 본문]</p>
<p class="body-zh">[일반 본문]</p>
<p class="body-serif">[세리프 본문 — 인문학적]</p>
<p class="kicker">[KICKER — 페이지 상단 짧은 레이블]</p>
<p class="meta">[메타 정보]</p>
<div class="meta-row">
  <span>[항목1]</span><span>·</span><span>[항목2]</span>
</div>
```
---

## 데이터 컴포넌트 (Data Components)

```html
<!-- stat-card: grid-6 / grid-4 / grid-3 내 사용 -->
<!-- ⚠️ PPTX: border-top 호환. gradient 배경 금지. -->
<div class="stat-card" data-anim>
  <p class="stat-label">[지표명]</p>
  <p class="stat-nb">[숫자]<span class="stat-unit">[단위]</span></p>
  <p class="stat-note">[설명 한 줄]</p>
</div>

<!-- plat: 플랫폼/제품 비교 -->
<div class="plat">
  <p class="name">[플랫폼명]</p>
  <p class="nb">[핵심 수치]</p>
  <p class="sub">[단위 / 기준]</p>
</div>

<!-- rowline: 키-값-메타 3열, 구분선 자동 -->
<div class="rowline">
  <span class="k">[키]</span>
  <span class="v">[값]</span>
  <span class="m">[메타]</span>
</div>
```
---

## 인용 & 강조 (Quote & Highlight)

```html
<!-- callout: 좌측 border-left + 배경 틴트 -->
<!-- ⚠️ PPTX: border-left 및 배경 호환 -->
<div class="callout">
  <p class="q-big">[인용 텍스트]</p>
  <span class="cite">— [출처]</span>
</div>

<!-- callout-src: 인용 출처 레이블 -->
<span class="callout-src">— [출처 / 작성자, 연도]</span>

<!-- hi: 하이라이트 언더라인 -->
<span class="hi">[강조 텍스트]</span>

<!-- tag: 박스 레이블 -->
<span class="tag">[LABEL]</span>

<!-- rule: 구분선 -->
<div class="rule"></div>
<!-- rule v: 수직 구분선 (Before/After용) -->
<div class="rule v" style="align-self:stretch;height:auto;margin:0"></div>
```
---

## 이미지 컴포넌트 (Image Components)

> ⚠️ PPTX Iron Law #4: CSS background-image 금지. `<img>` 태그 필수.
> ⚠️ PPTX Iron Law #6: SVG/canvas 금지.
> ⚠️ 그리드 내 이미지: `height:Nvh` 고정 필수 (aspect-ratio 금지).

```html
<!-- frame-img: 이미지 컨테이너 (그리드 내 high 고정) -->
<div class="frame-img" style="height:26vh">
  <img src="[경로]" alt="[설명]">
</div>

<!-- 비율 클래스 (단독 이미지용만) -->
<div class="frame-img r-16x9"><img src="[경로]" alt="[설명]"></div>
<div class="frame-img r-16x10"><img src="[경로]" alt="[설명]"></div>
<div class="frame-img r-4x3"><img src="[경로]" alt="[설명]"></div>
<div class="frame-img r-3x4"><img src="[경로]" alt="[설명]"></div>
<div class="frame-img r-1x1"><img src="[경로]" alt="[설명]"></div>

<!-- tile: 이미지 + 캡션 조합 -->
<figure class="tile">
  <div class="frame-img" style="height:26vh">
    <img src="[경로]" alt="[설명]">
  </div>
  <figcaption class="img-cap">[캡션]</figcaption>
</figure>
```
---

## 아이콘 (Icons — Lucide)

> ⚠️ PPTX Iron Law #6: SVG 금지. Lucide 아이콘은 web preview 전용.
> 이모지 사용 절대 금지 — Lucide 아이콘으로 대체.

```html
<i data-lucide="target" class="ico-lg"></i>
<i data-lucide="arrow-right" class="ico-md"></i>
<i data-lucide="check-circle" class="ico-sm"></i>
<script>lucide.createIcons();</script>
```

자주 쓰는 아이콘: `target` / `palette` / `search-check` / `compass` / `share-2` / `crown` / `check-circle` / `x-circle` / `plus` / `arrow-right` / `grid-2x2` / `network`
---

## 레이아웃 그리드 (Layout Grids)

```html
<div class="frame grid-6">...</div>    <!-- 3×2 stat-card -->
<div class="frame grid-4">...</div>    <!-- 2×2 -->
<div class="frame grid-3">...</div>    <!-- 1×3 -->
<div class="frame grid-3-3">...</div>  <!-- 3×N 이미지 그리드 -->
<div class="frame grid-2-7-5">...</div> <!-- 2열 7:5 -->
<div class="frame grid-2-6-6">...</div> <!-- 2열 6:6 Before/After -->
<div class="frame grid-2-8-4">...</div> <!-- 2열 8:4 Lead+Sidebar -->
```
---

## 크롬 & 푸터 (Chrome & Footer)

```html
<!-- 상단 크롬 -->
<div class="chrome">
  <span class="left">
    <span>[섹션 태그]</span><span class="sep"></span><span>[부제]</span>
  </span>
  <span class="right"><span>[번호] / [총수]</span></span>
</div>

<!-- 하단 푸터 -->
<div class="foot">
  <span class="title">[덱 제목]</span>
  <span>[번호] / [총수]</span>
</div>
```

> chrome = 여러 페이지 걸쳐 동일한 "잡지 헤더" (예: "Act II · Workflow")
> kicker = 이 페이지만의 고유 인트로 — chrome 번역/반복 금지
---

## 애니메이션 마커 (Animation Markers)

> ⚠️ PPTX: 애니메이션은 web preview 전용. PPTX export 시 전체 즉시 표시.

```html
<!-- cascade (기본) -->
<p data-anim>[텍스트]</p>

<!-- directional (Before/After) -->
<div data-anim="left">...</div>
<div data-anim="right">...</div>

<!-- quote (줄별 인용) -->
<span data-anim="line" style="display:block">[줄]</span>

<!-- pipeline (스텝) -->
<div data-anim="step">...</div>

<!-- 섹션 레시피 -->
<section data-animate="hero">...</section>
<section data-animate="quote">...</section>
<section data-animate="directional">...</section>
<section data-animate="pipeline">...</section>
```
