# Fidelity Score v4.2 — 24차원 채점 기준

Phase 5 검증 시 사용. 총점 0-100, 통과 기준 60점.
da:work Stage 2 Gate: ≥60, Stage 3.5 Review: ≥70.

## Design Fidelity (53%)

| # | Dimension | Weight | Scoring |
|---|-----------|--------|---------|
| 1 | Typography | 7% | 폰트 패밀리, 사이즈 스케일, letter-spacing, line-height |
| 2 | Colors | 9% | 팔레트 준수, 시맨틱 토큰 사용, tinted gray |
| 3 | Spacing | 7% | 일관된 간격 시스템, section/component 간격 |
| 4 | Layout | 6% | 그리드 시스템, 반응형 breakpoint, 비대칭 활용 |
| 5 | Motion | 5% | 애니메이션 프리셋 적용, 적절한 타이밍 |
| 6 | Components | 5% | shadcn/ui 패턴 준수, 컴포넌트 구조 |
| 7 | Background_Effects | 5% | 배경 효과, 노이즈 텍스처, 그라데이션 |
| 8 | Animation_Patterns | 4% | scroll-reveal, stagger, hover 패턴 |
| 9 | Visual_Coherence | 5% | 섹션 흐름, 색상 전환, 브랜드 인상 |

## Code Quality (32%)

| # | Dimension | Weight | Scoring |
|---|-----------|--------|---------|
| 10 | Transition_Specificity | 3% | transition-all 사용 0건이면 만점 |
| 11 | Spacing_Entropy | 3% | 다양한 간격값 사용 (3종 이상 만점) |
| 12 | Shadow_Complexity | 3% | multi-layer shadow 비율 (50%+ 만점) |
| 13 | Color_Variety | 3% | 시맨틱 토큰 비율 (80%+ 만점, gray-NNN 감점) |
| 14 | Typography_Range | 3% | fluid clamp() 사용 비율 (h1~h3에 50%+ 만점) |
| 15 | Animation_Presence | 2% | motion 라이브러리 사용 (scroll-reveal 1개+ 만점) |
| 16 | Modern_CSS | 2% | container query, :focus-visible, clamp() 등 |
| 17 | Font_Diversity | 4% | display+body+mono 3종=만점, 2종=반점, 1종=0점 |
| 18 | External_Effect_Usage | 3% | 외부 효과 라이브러리 2개+=만점, 1개=반점 |
| 19 | Section_Layout_Variety | 4% | 고유 레이아웃 4종+=만점, 3종=반점, 2종이하=0점 |
| 20 | Composition_Philosophy | 2% | Creative Brief Composition 규칙 준수 |

## Senior Quality (10%)

| # | Dimension | Weight | Scoring |
|---|-----------|--------|---------|
| 21 | Senior_Effect_Tier | 5% | S-Tier 1+개 AND A-Tier 2+개=만점. S0+A2 또는 S1+A1=반점. S0+A1이하=0점 |
| 22 | Editorial_Pattern_Usage | 5% | 수학적비율 1+ AND 편집패턴 2+ AND 그리드파괴 1+ AND 극단스케일=만점 |

## New Quality (5%)

| # | Dimension | Weight | Scoring |
|---|-----------|--------|---------|
| 23 | Composition_Quality | 3% | Composition Engine Plan 준수도. Full/Half/Zero |
| 24 | Registry_Utilization | 2% | Component Registry 활용도. 50%+=Full, 30-49%=Half |

## Optional Dimension

| Dimension | Weight | Condition |
|-----------|--------|-----------|
| Video_Background_Quality | 5% | Creative Brief Video 전략 활성 시에만. 기존 24차원을 95%로 스케일 |

## v4.1→v4.2 가중치 변경 내역
- Colors: 10%→9%, Animation_Patterns: 5%→4%, Animation_Presence: 3%→2%
- External_Effect_Usage: 4%→3%, Composition_Philosophy: 3%→2%
- 확보된 5%로 Composition_Quality(3%) + Registry_Utilization(2%) 신설
