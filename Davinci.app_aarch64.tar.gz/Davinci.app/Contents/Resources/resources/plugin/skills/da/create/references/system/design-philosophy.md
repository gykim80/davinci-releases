# Design Composition Philosophy Reference

> Referenced when selecting `Composition_Philosophy` in da:design Phase 2 Creative Brief.
> Each philosophy influences layout, typography, component structure, and interaction patterns.

---

## Philosophy Overview

| ID | Philosophy | Core Principle | Best For |
|----|-----------|---------------|----------|
| CP-01 | Brutalist | Raw, honest, anti-design | Portfolio, art, experimental |
| CP-02 | Minimalist | Less is more, whitespace | SaaS, tools, documentation |
| CP-03 | Glassmorphism | Frosted glass, depth layers | Dashboard, modern apps |
| CP-04 | Neomorphism | Soft shadows, tactile feel | Settings, controls UI |
| CP-05 | Material Design 3 | Google's design system | Android, cross-platform |
| CP-06 | Organic/Biomorphic | Natural curves, fluid shapes | Wellness, lifestyle, eco |
| CP-07 | Retro/Y2K | Nostalgia, bold colors, pixel | Gaming, entertainment |
| CP-08 | Swiss/International | Grid precision, Helvetica | Corporate, editorial |
| CP-09 | Maximalist | More is more, layered, bold | Fashion, media, creative |
| CP-10 | Kinetic/Motion-First | Animation drives layout | Landing pages, storytelling |

---

## CP-01: Brutalist

> "Don't hide the structure. Function is the aesthetic."

### Core Characteristics
- Raw HTML feel, intentional roughness
- System fonts or monospace emphasis
- High contrast (black & white base), neon accents
- Asymmetric layouts, overlapping allowed

### Tailwind Patterns
```css
/* Base setup */
font-family: 'Courier New', ui-monospace, monospace;
background: #000; color: #fff;
border: 3px solid #fff;

/* Layout */
.brutalist-grid { @apply grid grid-cols-[1fr_2fr] gap-0 border-2 border-white; }
.brutalist-card { @apply border-2 border-white p-4 hover:bg-white hover:text-black transition-none; }
```

### Component Principles
- No shadows, borders only (`border-2`, `border-4`)
- Hover: Color inversion, no transition or `transition-none`
- Images: Grayscale or high-contrast filter
- Buttons: Square, uppercase, thick borders

### Ideal Projects
Portfolios, art galleries, experimental projects, startup landing pages

---

## CP-02: Minimalist

> "Perfection is achieved when there is nothing left to remove."

### Core Characteristics
- Generous whitespace (section padding 80px+)
- Limited color palette (2-3 colors)
- Typography as the primary design element
- Clear visual hierarchy (1 focal point per view)

### Tailwind Patterns
```css
/* Spacing system */
.min-section { @apply py-20 md:py-32 px-6 max-w-4xl mx-auto; }
.min-heading { @apply text-4xl md:text-6xl font-light tracking-tight; }
.min-body { @apply text-lg text-muted-foreground leading-relaxed max-w-prose; }

/* Color constraints */
--primary: oklch(0.15 0 0);       /* near black */
--muted: oklch(0.55 0 0);         /* mid gray */
--background: oklch(0.98 0 0);    /* near white */
```

### Component Principles
- Cards: No border, subtle shadow or background difference only
- Buttons: Ghost/outline preferred, solid for single CTA only
- Icons: strokeWidth 1.5, unified 24px
- Images: Generous margins, unified aspect-ratio

### Ideal Projects
SaaS, productivity tools, documentation sites, corporate brands

---

## CP-03: Glassmorphism

> "Translucent layers create depth and hierarchy."

### Core Characteristics
- backdrop-blur + translucent backgrounds (bg-white/10)
- Subtle borders (border-white/20)
- Depth through multi-layer stacking
- Gradient backgrounds required (to showcase blur effects)

### Tailwind Patterns
```css
/* Glass card */
.glass-card {
  @apply bg-white/10 backdrop-blur-xl border border-white/20
         rounded-2xl shadow-lg shadow-black/5;
}
.glass-card-strong {
  @apply bg-white/20 backdrop-blur-2xl border border-white/30
         rounded-3xl;
}

/* Background gradient (required) */
.glass-bg {
  @apply bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500;
}
```

### Component Principles
- Cards: Translucent + blur, rounded-2xl minimum
- Navigation: Sticky + glass effect
- Modals: Glass overlay + glass content
- Dark mode: bg-black/20, border-white/10

### Ideal Projects
Dashboards, modern apps, iOS-style UI, creative agencies

---

## CP-04: Neomorphism

> "Soft light and shadows create a tactile experience."

### Core Characteristics
- Elements in same color as background (monochrome)
- Dual shadows (light side + dark side)
- Convex/concave effects for interaction states
- Low contrast, soft curves

### Tailwind Patterns
```css
/* Convex (default state) */
.neo-raised {
  @apply bg-gray-200 rounded-2xl;
  box-shadow: 8px 8px 16px #b8b8b8, -8px -8px 16px #ffffff;
}
/* Concave (pressed state) */
.neo-pressed {
  @apply bg-gray-200 rounded-2xl;
  box-shadow: inset 4px 4px 8px #b8b8b8, inset -4px -4px 8px #ffffff;
}
/* Dark mode */
.dark .neo-raised {
  @apply bg-gray-800;
  box-shadow: 8px 8px 16px #1a1a1a, -8px -8px 16px #3a3a3a;
}
```

### Component Principles
- Buttons: Raised → pressed (active state)
- Input fields: Pressed (concave inputs)
- Toggles/sliders: Emphasize tactile feedback
- Text: Mid-gray, avoid high contrast

### Ideal Projects
Settings screens, control panels, IoT dashboards, calculator apps

---

## CP-05: Material Design 3

> "Adaptive design — transforms to fit device and user."

### Core Characteristics
- Dynamic Color (auto-generated color themes)
- Elevation system (levels 0-5)
- Shape system (None/Extra Small/Small/Medium/Large/Extra Large/Full)
- Typography: Roboto → variable font system

### Tailwind Patterns
```css
/* Elevation system */
.m3-elevation-0 { @apply shadow-none; }
.m3-elevation-1 { @apply shadow-sm bg-primary/5; }
.m3-elevation-2 { @apply shadow-md bg-primary/8; }
.m3-elevation-3 { @apply shadow-lg bg-primary/11; }

/* Shape system */
.m3-shape-sm { @apply rounded-lg; }    /* 12px */
.m3-shape-md { @apply rounded-xl; }    /* 16px */
.m3-shape-lg { @apply rounded-2xl; }   /* 28px */
.m3-shape-full { @apply rounded-full; }

/* FAB (Floating Action Button) */
.m3-fab { @apply rounded-xl bg-primary-container text-on-primary-container
                 p-4 shadow-lg hover:shadow-xl transition-shadow; }
```

### Component Principles
- Buttons: Filled / Outlined / Text / Elevated / Tonal (5 types)
- Cards: Elevated / Filled / Outlined (3 types)
- Lists: 48px minimum height, leading/trailing icons
- Navigation: Bottom / Rail / Drawer (by screen size)

### Ideal Projects
Android apps, cross-platform, Google ecosystem, enterprise tools

---

## CP-06: Organic/Biomorphic

> "Nature's irregularity breathes life into digital."

### Core Characteristics
- Irregular curves (blob shapes, waves)
- Natural color palette (earth tones, pastel green)
- Soft gradients, organic transitions
- SVG illustration-centric

### Tailwind Patterns
```css
/* Natural palette */
--earth-brown: oklch(0.45 0.05 60);
--leaf-green: oklch(0.65 0.15 145);
--sky-soft: oklch(0.85 0.05 230);
--sand: oklch(0.88 0.03 80);

/* Blob container */
.organic-blob {
  border-radius: 30% 70% 70% 30% / 30% 30% 70% 70%;
  @apply bg-gradient-to-br from-leaf-green/20 to-sky-soft/20;
}

/* Wave divider (SVG) */
.organic-wave { @apply w-full h-16 fill-current text-sand; }
```

### Component Principles
- Cards: Large border-radius (rounded-3xl+), soft shadows
- Dividers: SVG waves, blob patterns (no straight lines)
- Icons: Hand-drawn style or rounded
- Spacing: Generous and uneven (asymmetric padding)

### Ideal Projects
Wellness, lifestyle, eco/green, education, children

---

## CP-07: Retro/Y2K

> "The future of the past — nostalgia becomes a trend."

### Core Characteristics
- Vivid colors (neon pink, cyber blue, lime)
- Pixel fonts or 90s digital fonts
- Excessive gradients (intentional)
- Window/dialog box UI patterns

### Tailwind Patterns
```css
/* Y2K palette */
--neon-pink: oklch(0.70 0.25 350);
--cyber-blue: oklch(0.65 0.20 250);
--lime: oklch(0.80 0.25 130);
--retro-purple: oklch(0.50 0.20 300);

/* Window UI */
.retro-window {
  @apply border-2 border-black bg-gray-200;
}
.retro-titlebar {
  @apply bg-gradient-to-r from-blue-800 to-blue-500
         text-white px-2 py-1 text-sm font-bold
         flex items-center justify-between;
}
.retro-btn {
  @apply border-2 border-t-white border-l-white
         border-b-gray-600 border-r-gray-600
         bg-gray-300 px-3 py-1 active:border-t-gray-600
         active:border-l-gray-600 active:border-b-white
         active:border-r-white;
}
```

### Component Principles
- Buttons: 3D beveled edge (press effect)
- Cursors: Custom cursor (pointer → crosshair)
- Text: Shadows, glitch effects, blinking
- Backgrounds: Star/grid patterns, animated gradients

### Ideal Projects
Gaming, entertainment, music, fashion, Gen Z targeting

---

## CP-08: Swiss/International

> "The grid is order, and typography is design."

### Core Characteristics
- Strict grid system (12-column baseline)
- Sans-serif (Helvetica, Inter, Suisse Int'l)
- Asymmetric but aligned layouts
- Limited colors + strong typographic hierarchy

### Tailwind Patterns
```css
/* Grid system */
.swiss-grid {
  @apply grid grid-cols-12 gap-4 md:gap-6;
}
.swiss-col-main { @apply col-span-8; }
.swiss-col-side { @apply col-span-4; }

/* Typographic hierarchy */
.swiss-display { @apply text-7xl font-bold tracking-tighter leading-none; }
.swiss-heading { @apply text-3xl font-semibold tracking-tight; }
.swiss-body { @apply text-base leading-relaxed tracking-normal; }
.swiss-caption { @apply text-xs uppercase tracking-widest text-muted-foreground; }
```

### Component Principles
- Layout: Grid-based, visible alignment lines
- Colors: Black & white + 1 accent (traditionally red)
- Images: Full-bleed or grid-aligned, captions required
- Spacing: Baseline grid adherence (8px multiples)

### Ideal Projects
Corporate sites, editorial, news, architecture/design portfolios

---

## CP-09: Maximalist

> "More is more. Not the aesthetics of emptiness, but of fullness."

### Core Characteristics
- Layering: Text + images + pattern overlap
- Bold typography mix (serif + sans + display)
- Rich color palette (5+ colors)
- Active use of patterns, textures, illustrations

### Tailwind Patterns
```css
/* Rich palette */
--max-coral: oklch(0.70 0.18 25);
--max-teal: oklch(0.65 0.12 190);
--max-gold: oklch(0.80 0.15 90);
--max-violet: oklch(0.55 0.22 300);
--max-cream: oklch(0.92 0.03 80);

/* Layered section */
.max-section {
  @apply relative overflow-hidden;
  background: repeating-linear-gradient(
    45deg, transparent, transparent 10px,
    oklch(0.95 0.02 80) 10px, oklch(0.95 0.02 80) 20px
  );
}
.max-overlay-text {
  @apply absolute inset-0 flex items-center justify-center
         text-8xl font-black opacity-10 pointer-events-none;
}
```

### Component Principles
- Cards: Mixed sizes, masonry layout
- Text: Large display text serves as decoration
- Images: Collage style, overlapping allowed
- Spacing: Dense but intentionally tight

### Ideal Projects
Fashion, media, creative agencies, magazines, events

---

## CP-10: Kinetic/Motion-First

> "There is no design at rest. Motion is the interface."

### Core Characteristics
- Scroll-driven animations
- Page transition animations (View Transitions API)
- Micro-interactions on every element
- Timing functions define brand identity

### Tailwind + Motion Patterns
```tsx
import { motion, useScroll, useTransform } from "motion/react"

// Transform based on scroll progress
function KineticHero() {
  const { scrollYProgress } = useScroll()
  const scale = useTransform(scrollYProgress, [0, 0.5], [1, 0.8])
  const opacity = useTransform(scrollYProgress, [0, 0.3], [1, 0])

  return (
    <motion.section style={{ scale, opacity }}
      className="h-screen flex items-center justify-center sticky top-0"
    >
      <motion.h1
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
        className="text-8xl font-bold"
      >
        Motion First
      </motion.h1>
    </motion.section>
  )
}

// Brand easing (unified across the project)
const BRAND_EASE = [0.16, 1, 0.3, 1]     // smooth decel
const BRAND_SPRING = { stiffness: 300, damping: 30 }
```

### Component Principles
- Entry: Entry animations on all elements (stagger)
- Hover: Scale, color shift, shadow changes
- Click: Haptic-like feedback (scale 0.95 → 1)
- Page transitions: View Transitions or shared layout animation
- Performance: Use `will-change` carefully, optimize GPU layers

### Ideal Projects
Landing pages, storytelling, product showcases, interactive portfolios

---

## Philosophy Combination Guide

Multiple philosophies can be combined. Recommended combinations:

| Combination | Description | Example |
|------|------|------|
| Minimalist + Kinetic | Clean layout with refined motion | Apple-style landing |
| Swiss + Glassmorphism | Grid precision + depth | Corporate dashboard |
| Brutalist + Maximalist | Extreme visual impact | Art/music sites |
| Organic + Minimalist | Natural curves + whitespace | Wellness apps |
| Material + Kinetic | Systematic framework + lively motion | Mobile apps |

### Not Recommended Combinations
| Combination | Reason |
|------|------|
| Neomorphism + Brutalist | Conflicting shadow philosophies |
| Swiss + Organic | Grid precision contradicts free-form curves |
| Retro + Material | Completely clashing era aesthetics |
