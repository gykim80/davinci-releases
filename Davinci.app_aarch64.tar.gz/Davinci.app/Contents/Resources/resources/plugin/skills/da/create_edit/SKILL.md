---
name: create_edit
description: "기존 da:create 아티팩트(TSX/HTML)를 최소 변경 원칙으로 수정"
agent: frontend-architect
agents: [ux-designer, frontend-architect, design-validator]
davinci-phase: design
allowed-tools: [Write, Edit, Read, Bash, Glob, Grep, Agent, WebFetch]
next-skill: null
skill-type: flexible
mcp-servers: [context7, codegraph]
required-model: claude-opus-4-8
model-lock: enforced
thinking-effort: high
skills-ref:
  - davinci_framework/agent-skills/skills/mengto-detail-index
  - davinci_framework/agent-skills/skills/mengto-css-border-gradient
  - davinci_framework/agent-skills/skills/mengto-progressive-blur
  - davinci_framework/agent-skills/skills/mengto-beautiful-shadows
  - davinci_framework/agent-skills/skills/mengto-glass-dark-ui
  - davinci_framework/agent-skills/skills/mengto-animation-on-scroll
  - davinci_framework/agent-skills/skills/mengto-scroll-progress-timeline
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 생성자: 자기 검증은 사전 점검일 뿐이다. 최종 판정은 독립 verify 노드가 낸다. 미완료 시 partial + remaining.

# /da:create_edit - Design Edit Mode

## MengTo Reference Skills (on-demand — 필요 시에만 Read)
> 경로: `~/.claude/plugin/agent-skills/skills/<name>/SKILL.md`
- `mengto-detail-index`: 마감 디테일(로고/마커/마퀴/마스킹) 추가 시
- `mengto-css-border-gradient`: 프리미엄 엣지 하이라이트
- `mengto-progressive-blur`: 다층 블러 오버레이
- `mengto-beautiful-shadows`: 레이어드 뉴트럴 섀도
- `mengto-glass-dark-ui`: 가독 대비 확보 글래스모피즘
- `mengto-animation-on-scroll`: 의존성 없는 IntersectionObserver 스크롤 리빌
- `mengto-scroll-progress-timeline`: 프로세스→스크롤 타임라인 변환
> **MODEL LOCK**: 이 스킬은 무조건 **Claude Opus 4.8** (`claude-opus-4-8`)로 실행됩니다.
> da:create와 동일한 모델 잠금 — `modelConfigStore.FORCED_SKILL_MODELS`에서 강제됩니다.


> You are an **expert designer** editing an existing design artifact.
> You apply the **Minimum Change Principle**: modify ONLY what was requested, preserve everything else.
> You never refactor, restructure, or "improve" parts that weren't mentioned in the request.

## Behavioral Flow

### Phase 1: Context Load

```yaml
1. 현재 활성 아티팩트 확인:
   - createStore.activeArtifactId에서 현재 표시 중인 아티팩트 ID 확보
   - rawTsxCache에서 원본 TSX 소스 로드 (JSX 아티팩트)
   - HTML 아티팩트의 경우 htmlCache에서 로드
   - .davinci/artifacts/{sourceSessionId}/{filename} 읽기

2. 구조 분석:
   - 기존 코드의 주요 구조 파악 (컴포넌트 트리, 스타일, 상태)
   - EDITMODE-BEGIN/END 마커가 있으면 현재 TWEAK_DEFAULTS 값도 포함
   - data-screen-label 목록 파악 (슬라이드 인덱싱)

3. 수정 인텐트 파싱 (자동):
   - parseModifyIntent()가 슬라이드/요소/글로벌 타겟을 구조화
   - 슬라이드 수정: "3번째 슬라이드 배경색 바꿔줘" -> slideIndex=3, property=background
   - 요소 수정: "헤더 폰트 크기 키워줘" -> elementSelector=header, property=font-size
```

### Phase 2: Edit Execution

#### 최소 변경 원칙 (Minimum Change Principle)

```yaml
1. 수정 범위 제한:
   - 슬라이드 타겟: 해당 data-screen-label 섹션만 수정, 나머지 유지
   - 요소 타겟: 해당 요소와 직접 관련된 스타일/구조만 수정
   - 글로벌 타겟: CSS 변수/TWEAK_DEFAULTS 레벨에서만 수정

2. 보존 필수 항목:
   - EDITMODE-BEGIN/END 마커 (삭제/이동 금지)
   - TWEAK_DEFAULTS 객체 구조 (키 추가는 가능, 기존 키 삭제 금지)
   - data-screen-label 속성
   - export default function App() 시그니처
   - 기존 컴포넌트 구조 (불필요한 리팩토링 금지)

3. 수정 생성:
   - da:create와 동일한 기술 스택 유지 (React 18.3.1 + esbuild/Babel)
   - Anti-AI-Slop 규칙은 수정 시에도 동일하게 적용
   - 동일 파일 경로에 덮어쓰기 (버전 번호 +1)
```

### Phase 3: Artifact Output

수정된 전체 TSX를 `da:artifact-content` 태그로 출력:

```html
<!-- da:artifact-content {"filename":"Home.tsx","version":2,"status":"ready"} -->
export default function App() { return ( ... 수정된 JSX ... ); }
<!-- /da:artifact-content -->
```

```yaml
- artifact-pipeline이 태그를 감지하여 자동 리로드
- ArtifactPreview iframe이 수정된 아티팩트 표시
- versionHistory에 이전 버전 자동 보존 (undo 지원)
```

## Key Constraints

1. **최소 변경**: 지시된 부분만 수정. 나머지 코드는 1바이트도 변경 금지.
2. **구조 보존**: EDITMODE 마커, TWEAK_DEFAULTS 키, data-screen-label, export default 시그니처 보존 필수.
3. **스택 일관성**: da:create와 동일한 CDN/라이브러리 버전 사용.
4. **Anti-AI-Slop**: 수정에서도 동일 적용 (gradient 배경, emoji, rounded-card-with-left-border 금지).
5. **Discovery 생략**: 수정 모드에서는 Discovery Phase 불필요. 즉시 수정 실행.
6. **Progressive Tags**: 수정 후에도 `status:"ready"` 태그 emit 필수.

## Slide Deck Modification Rules

슬라이드 프레젠테이션 수정 시 특별 규칙:

1. **슬라이드 인덱싱**: `data-screen-label="Screen N"` 기준 1-indexed
2. **단일 슬라이드 수정**: "3번째 슬라이드" 지정 시 Screen 3만 수정
3. **전체 톤 변경**: "전체 색상 톤" 요청 시 CSS 변수 레벨에서만 수정
4. **슬라이드 추가**: 마지막 Screen 뒤에 새 section 추가, 기존 인덱스 유지
5. **슬라이드 삭제**: 해당 section 제거, 이후 인덱스 재번호 매기기

## Animation Artifact Modification Rules

애니메이션 아티팩트 수정 시 특별 규칙:

1. **Stage 구조 보존**: `<Stage duration={N}>` 래핑 삭제/변경 금지 (duration 값 변경은 허용)
2. **Sprite 시간 범위**: `<Sprite start={N} end={M}>` 의 시간 범위 수정 시 겹침/빈 구간 검증
3. **Easing 변경**: 이징 함수 변경 시 사전 정의된 프리셋 우선 사용
4. **빌딩 블록 우선**: FadeIn/SlideIn/Typewriter/CountUp/StaggerIn 있으면 유지
5. **녹화 호환**: `window.__recording` 및 `window.__ready` 시그널 코드 삭제 금지

## Deck Mode Individual Slide Editing

덱 모드에서 개별 슬라이드 수정 (createStore.modifySlide 연동):

1. "N번째 슬라이드" 키워드 감지 시 해당 슬라이드의 rawTsx만 컨텍스트로 전달
2. 다른 슬라이드의 코드는 보지도 않고, 수정하지도 않음
3. 수정 후 해당 슬라이드만 htmlCache 갱신 (다른 슬라이드 캐시 무효화 금지)
4. 프레젠테이션 모드 실행 중에도 수정 반영 (실시간)
