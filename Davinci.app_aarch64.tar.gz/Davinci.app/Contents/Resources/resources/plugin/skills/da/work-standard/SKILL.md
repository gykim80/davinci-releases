---
name: work-standard
description: "da:work STANDARD MODE reference — Stages 1-4 (system → arch-verify loop → per-phase dev/verify loop → e2e) executed when pipeline_mode=standard. Loaded by da:work, not invoked directly."
skill-type: reference
davinci-phase: work
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 오케스트레이터: §4 그래프 ready-set 디스패치, §6 노드 단위 checkpoint, §7 interrupt 표 외 질문 금지.

## ── STANDARD MODE (Execute Stages 1-4 below when pipeline_mode="standard") ──

---

## Stage 1: System Architecture (da:system) — Task Delegation

```yaml
Checkpoint: {"current_stage":1, "last_skill":"da:system"}

# Load complexity from checkpoint (determined in Stage 0)
complexity = checkpoint.get("complexity", "MODERATE")

# Build handoff chain from previous skills (none for system)
previous_handoffs = ""  # da:system is first, no previous handoffs

# Get dynamic handoff schema for da:system
from davinci.workflow.handoff_schemas import get_skill_specific_schema_json
handoff_schema = get_skill_specific_schema_json("da:system")

Task(model="opus", prompt=f"
  Your task is to execute the /da:system skill.

  {COMMON_RULES}

  1. First Read ~/.claude/commands/da/system.md using the Read tool.
  2. That file's content is your operating protocol. Follow it exactly.
  3. ARGUMENTS: {plan_path} + Type: {project_type}
  4. AskUserQuestion call forbidden. Proceed with autonomous judgment.
  5. After completion, return a summary of what was done.

  IMPORTANT: Include this JSON handoff at the end of your response:
  ```json
  {handoff_schema}
  ```")

# Extract handoff from da:system output
from davinci.workflow.handoff import extract_handoff
system_handoff = extract_handoff(task_result, "da:system")

→ Bash: Update checkpoint with handoff_da:system = system_handoff
→ da:git("da:system complete — architecture design commit/push")
→ ZERO OUTPUT → Checkpoint: {"current_stage":2, "iterations":{"arch":0}, "handoff_da:system": system_handoff}
→ Skill("da:verify", "Verify ARCHITECTURE.md. Check completeness/consistency/gaps against plan.")
→ Continues to Stage 2 LOOP result_judgment
```

---

## Stage 2: Architecture Verification Loop

```yaml
# da:verify already called inline in Stage 1 → here starts from result_judgment
max_arch_iterations = 3

LOOP (da:protocol §4.4 conditional edge — verdict + items[] 기반, 텍스트 % 단독 추출 금지):
  verdict MET (≥90%, Critical/High 없음) → da:git("verification passed") → checkpoint Stage 3 → break
  verdict NOT_MET, attempts < max → da:improve("improve ARCHITECTURE.md — previous_failure: {reason}, 다른 접근: {next_action_hint}") → attempts++
    → da:verify("re-verify") → LOOP repeat
  attempts == max, Critical/High 잔존 → node blocked → §7 interrupt(blocked_decision) — Stage 3 진입 금지
  attempts == max, Medium/Low만 → node degraded → da:git → Stage 3 (리포트에 degraded 명시)
  verdict BLOCKED/IMPOSSIBLE → 즉시 §7 interrupt / 사용자 보고
  # 모든 전이 직후 checkpoint 저장 (§6.1)
```

---

## Stage 3: Phase Development Loop

```yaml
Checkpoint_Update: {"current_stage":3, "current_phase":1}

# ★ Phase data reload (for context compression recovery)
Phase_Data_Check:
  - Is phases array in current context?
  - If not → Read(docs/.da-work-checkpoint.json) → restore phases array
  - Also restore execution_mode, roadmap_file, ref_docs

for phase in phases:
  Checkpoint_Update: {"current_phase": N, "last_skill":"phase_start"}
  Output: "🔨 Phase {N}/{total}: {phase_summary} starting"

  # ═══════════════════════════════════════════════════
  # ROADMAP mode / PLAN mode common Task template
  # ═══════════════════════════════════════════════════
  # skill_name = GAME ? "da:game" : "da:dev"
  # skill_file = GAME ? "game.md" : "dev.md"

  if execution_mode == "roadmap":
    step_instructions = phase.steps format ("Step SNN: title / file / dependency / actions / verify")

    # Build handoff chain from previous skills
    from davinci.workflow.handoff import build_handoff_chain
    previous_handoffs = build_handoff_chain(checkpoint)

    # Get dynamic handoff schema
    from davinci.workflow.handoff_schemas import get_skill_specific_schema_json
    handoff_schema = get_skill_specific_schema_json(skill_name)

    Task(
      subagent_type="general-purpose", model="opus",
      prompt=f"
        Your task is to execute the /da:{skill_name} skill.

        {COMMON_RULES}

        {previous_handoffs}

        1. First Read ~/.claude/commands/da/{skill_file} using the Read tool.
        2. Plan: {plan_file} | Roadmap: {roadmap_file} | References: {ref_docs}
        3. Phase {N} Steps: {step_instructions}
        4. Check verify criteria for each Step. Respect blocked_by.
        5. AskUserQuestion forbidden. Return summary.

        IMPORTANT: Include this JSON handoff at the end of your response:
        ```json
        {handoff_schema}
        ```
      "
    )
    Momentum: "Phase {N} implementation complete → start da:verify immediately"

  elif execution_mode == "plan":
    # ── design_pregenerated branch (highest priority — skip all design skills) ──
    if design_pregenerated == true:
      # Design artifacts already generated in Stage 0.5 batch.
      # Skip da:create/da:design entirely → go straight to da:dev.
      # da:dev will auto-load artifacts via Phase 0.5 Design Artifact Loader.
      pass  # fall through to da:dev below (GAME or GENERAL)

    elif phase.design_needed:
      # ── da:work 내 디자인: da:design (community DS fast path) ──
      # da:work 에서는 da:create(풀 디자인 엔진) 대신 da:design 으로 접근.
      # community 디자인 시스템에서 사용자 의도에 가까운 DS를 기반으로 빠르게 디자인.
      # 디자인 완료 후 자동으로 da:dev 로 전환 (design_pregenerated 플래그 설정).
      # NOTE: 독립 디자인 세션의 da:create 는 영향 없음 (풀 엔진 그대로 유지).
      Task(subagent_type="general-purpose", model="opus",
        prompt="
          Your task is to execute the /da:design skill in FAST MODE for da:work orchestration.

          {COMMON_RULES}
          5. Return handoff JSON at end of response.

          FAST MODE RULES (da:work orchestration context):
          - Skip AskUserQuestion (Discovery). Use plan context as design brief directly.
          - Use community design system: pick the closest DS from dsRegistryStore seed systems
            matching the project's industry/style. Apply its DTCG tokens.
          - Skip effect pipeline (da:effect_bg, da:effect_text, da:effect_particle).
          - Focus on layout + component assembly + design tokens only.
          - Output design artifacts to .davinci/artifacts/ directory.
          - Generate design.tokens.json (DTCG) alongside HTML artifacts.

          1. First Read ~/.claude/commands/da/design.md using the Read tool.
          2. Phase {N} design. Pages: {design_pages} | Style: {auto_style} | Reference ARCHITECTURE.md.
          3. AskUserQuestion forbidden. Return summary + handoff JSON.
          4. Include in handoff: design_artifacts path + design_pregenerated=true.")
      Checkpoint_Update: {"last_skill":"da:design", "design_pregenerated": true, "design_artifact_session_id": "{current_session_id}"}

    # ★ Stage 3.3: GAME 프로젝트일 때 da:asset --game을 da:game과 병렬 실행
    if project_type == "GAME":
      # 두 Task를 동일 메시지에서 동시 호출 (병렬 실행)
      Task(subagent_type="general-purpose", model="opus",
        prompt="
          Your task is to execute the /da:asset skill with --game flag.

          {COMMON_RULES}
             {"skill": "da:asset", "status": "completed",
              "assets": {"generated": [...], "path": "public/assets/generated/"},
              "style_consistency": {"matched": true/false, "style": "..."}}

          1. Read ~/.claude/commands/da/asset.md → execute per protocol
          2. ARGUMENTS: --game flag. Generate ALL game assets. Art style: {auto_style}. Output: public/assets/generated/
          3. If no API key, generate color placeholders (graceful degradation).
          4. AskUserQuestion forbidden. Return summary + handoff JSON.")
      Task(subagent_type="general-purpose", model="opus",
        prompt="
          Your task is to execute the /da:game skill.
          ★ IMPORTANT: da:asset --game is running IN PARALLEL. Use placeholder asset keys in code.

          {COMMON_RULES}
          5. 완료 시 다음 JSON 포함하여 반환:

             {"skill": "da:game", "status": "completed", "phase": {N},
              "scenes": [...], "systems": [...],
              "assets": {"generated": [...], "path": "public/assets/generated/"},
              "config": {"physics": "...", "scale_mode": "...", "target_fps": 60}}

          1. Read ~/.claude/commands/da/game.md → execute per protocol
          2. {plan} Phase {N} tasks: {tasks}. Reference ARCHITECTURE.md.
          3. AskUserQuestion forbidden. Return summary + handoff JSON.")

    else:
      # GENERAL 프로젝트: 기존 da:dev 단독 실행
      # Build {design_artifacts} context injection
      design_artifacts = ""
      if design_pregenerated == true:
        design_artifacts = "Design artifacts pre-generated in .davinci/artifacts/{design_artifact_session_id}/. Files: {design_completed_pages[]}. Use Phase 0.5 Design Artifact Loader protocol to load and convert them."

      Task(subagent_type="general-purpose", model="opus",
        prompt="
          Your task is to execute the /da:dev skill.

          {COMMON_RULES}
          5. 완료 시 다음 JSON 포함하여 반환:

             {"skill": "da:dev", "status": "completed", "phase": {N},
              "implementation": {"files_created": [...], "files_modified": [...], "endpoints_added": [...], "tests_written": [...]},
              "metrics": {"loc_added": N, "test_coverage": "N%"}}

          1. First Read ~/.claude/commands/da/dev.md using the Read tool.
          2. {plan} Phase {N} tasks: {tasks}. Reference ARCHITECTURE.md.
          3. {design_artifacts}
          4. AskUserQuestion forbidden. Return summary + handoff JSON.")

  # Task return → ZERO OUTPUT → Verification Loop (max 5 rounds)
  Skill("da:verify", "Phase {N} implementation verification. Criteria: {verify_criteria}. Acceptance ledger: docs/.da-acceptance.json")
  LOOP (da:protocol §4.4 — Stage 2와 동일 전이표):
    MET → da:git → checkpoint 저장 → next ready Phase or Stage 4
    NOT_MET, attempts < max → da:improve(previous_failure + next_action_hint) → re-call da:verify
    attempts == max → Critical/High 잔존이면 blocked(다음 Phase 중 이 Phase에 의존하는 노드는 대기, 독립 노드만 계속)
                       Medium/Low만이면 degraded로 진행(리포트 명시)
    BLOCKED/IMPOSSIBLE → §7 interrupt

  # §8 Proactive Compact: 2 Phase마다 context 압축 (Standard Mode)
  if N % 2 == 0 and N < total_phases:
    /compact
```

**Proceed immediately to Stage 4 after all Phases complete. Tool calls only, no text output.**

---

## Stage 4: E2E Validation

```yaml
Checkpoint_Update: {"current_stage":4, "last_skill":"da:e2e"}

Task(model="opus",
  prompt="
    Your task is to execute the /da:e2e skill.

    {COMMON_RULES}
    5. 완료 시 다음 JSON 포함하여 반환:

       {"skill": "da:e2e", "status": "completed",
        "test_results": {"passed": N, "failed": N, "total": N},
        "failures": [{"test": "...", "reason": "...", "severity": "..."}]}

    1. First Read ~/.claude/commands/da/e2e.md using the Read tool.
    2. Playwright E2E test design+execution.
    3. AskUserQuestion forbidden. Return summary + handoff JSON.")

max_e2e_iterations = 3

if NOT e2e_issues → da:git commit → Stage 5

if e2e_issues:
  LOOP (max 3):
    Task(model="opus",
      prompt="
        Your task is to execute the /da:{skill_name} skill to fix E2E failures.

        {COMMON_RULES}

        1. First Read ~/.claude/commands/da/{skill_file}.md using the Read tool.
        2. Fix E2E failures: {e2e_issues}
        3. AskUserQuestion forbidden.")
    Skill("da:verify", "E2E issue fix verification")
    If needed Skill("da:improve", "additional improvement")
    Task(model="opus", prompt="
      Your task is to re-execute the /da:e2e skill.

      {COMMON_RULES}

      1. First Read ~/.claude/commands/da/e2e.md then execute.
      2. AskUserQuestion forbidden.")
    e2e_pass or max → da:git commit → Stage 5
```

---

