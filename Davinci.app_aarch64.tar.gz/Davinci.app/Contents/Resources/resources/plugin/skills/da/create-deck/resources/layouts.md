<!--
Source: op7418/guizang-ppt-skill (Apache-2.0)
Original: https://github.com/op7418/guizang-ppt-skill
Copyright (c) op7418. Licensed under Apache-2.0.
Modifications: Adapted for davinci-framework — Korean comments + PPTX Iron Law conflict notes.
-->

# 페이지 레이아웃 라이브러리 (Page Layout Library)

> 원본: op7418/guizang-ppt-skill `references/layouts.md`
>
> **클래스명 규칙**: 모든 클래스는 `template.html`의 `<style>` 블록에 정의된 것만 사용.
> 커스텀 클래스 추가 금지 — 필요 시 inline `style` 속성 사용.
>
> ⚠️ **PPTX Iron Law 주의**: gradient, SVG, canvas 요소는 PPTX export 금지.
> WebGL 배경(canvas#bg-dark, canvas#bg-light)은 web preview 전용.
> PPTX export 시 정적 이미지로 우회 필수.

---

## 주제 리듬 규칙 (Theme Rhythm Rules)

슬라이드는 반드시 `light`, `dark`, `hero light`, `hero dark` 중 하나를 지정해야 합니다.

- 연속 3페이지 동일 테마 금지
- 8페이지 이상: hero light 1개 + hero dark 1개 이상 필수
- 전체가 light만인 덱 금지 — dark 정문 페이지 반드시 1개 이상

---

## Layout 1 — 개장 봉투 (Opening Cover)

> 의식감, 여백 충분. hero dark 권장.

```html
<section class="slide hero dark" data-animate="hero">
  <div class="chrome">
    <span class="left">
      <span>[브랜드]</span><span class="sep"></span><span>[날짜]</span>
    </span>
    <span class="right"><span>[카테고리]</span></span>
  </div>
  <div class="fill center col">
    <p class="kicker" data-anim>[섹션 태그]</p>
    <h1 class="h-hero" data-anim>[덱 제목<br>두 줄 가능]</h1>
    <p class="lead" style="margin-top:4vh;max-width:38vw" data-anim>[부제목 또는 핵심 메시지]</p>
    <div class="meta-row" style="margin-top:5vh" data-anim>
      <span>[발표자]</span><span>·</span><span>[소속]</span><span>·</span><span>[날짜]</span>
    </div>
  </div>
  <div class="foot">
    <span class="title">[덱 제목 짧게]</span>
    <span>01 / [총 페이지]</span>
  </div>
</section>
```

---

## Layout 2 — 챕터 막 (Act Divider / Chapter Break)

> 극한 미니멀 제목 페이지. hero dark / hero light 교차.

```html
<section class="slide hero dark" data-animate="hero">
  <div class="chrome">
    <span class="left"><span>[Act II · 워크플로우]</span></span>
    <span class="right"><span>[번호] / [총수]</span></span>
  </div>
  <div class="fill center col">
    <p class="kicker" data-anim>ACT [번호]</p>
    <h2 class="h-xl" data-anim>[챕터 제목]</h2>
    <p class="lead" style="margin-top:3vh;opacity:.7" data-anim>[한 줄 요약]</p>
  </div>
  <div class="foot">
    <span></span>
    <span>[번호] / [총수]</span>
  </div>
</section>
```
---

## Layout 3 — 데이터 대자보 (Big Numbers / Stat Grid)

> 6개 데이터 카드 그리드. light 테마 권장.
> ⚠️ PPTX: stat-card border-top 호환. gradient 사용 금지.

```html
<section class="slide light">
  <div class="chrome">
    <span class="left"><span>[섹션]</span><span class="sep"></span><span>[부제]</span></span>
    <span class="right"><span>[번호] / [총수]</span></span>
  </div>
  <p class="kicker" style="margin-top:3vh" data-anim>[키워드]</p>
  <h2 class="h-xl" style="margin-top:1.5vh" data-anim>[숫자로 말하는 제목]</h2>
  <div class="frame grid-6" style="margin-top:4vh">
    <div class="stat-card" data-anim>
      <p class="stat-label">[지표명]</p>
      <p class="stat-nb">[숫자]<span class="stat-unit">[단위]</span></p>
      <p class="stat-note">[설명 한 줄]</p>
    </div>
    <!-- stat-card × 6 -->
  </div>
  <div class="foot"><span>[출처]</span><span>[번호] / [총수]</span></div>
</section>
```

---

## Layout 4 — 좌문우도 (Left Text + Right Image)

> 텍스트 7 : 이미지 5 분할. grid-2-7-5 사용.
> ⚠️ PPTX: align-self:end 사용 금지. frame-img height:Nvh 고정 사용.

```html
<section class="slide light">
  <div class="chrome">
    <span class="left"><span>[섹션]</span><span class="sep"></span><span>[주제]</span></span>
    <span class="right"><span>[번호] / [총수]</span></span>
  </div>
  <div class="frame grid-2-7-5" style="margin-top:3vh;align-items:start">
    <div class="col" style="justify-content:space-between;height:100%">
      <div>
        <p class="kicker" data-anim>[kicker]</p>
        <h2 class="h-xl" style="margin-top:2vh" data-anim>[메인 제목]</h2>
        <p class="body-zh" style="margin-top:3vh;max-width:36vw" data-anim>[본문 2-3줄]</p>
      </div>
      <div class="callout" style="margin-top:4vh" data-anim>
        <p class="q-big">[인용구]</p>
        <span class="cite">[출처]</span>
      </div>
    </div>
    <figure class="tile">
      <div class="frame-img" style="height:52vh" data-anim>
        <img src="[이미지]" alt="[설명]">
      </div>
      <figcaption class="img-cap">[캡션]</figcaption>
    </figure>
  </div>
  <div class="foot"><span>[출처]</span><span>[번호] / [총수]</span></div>
</section>
```
---

## Layout 5 — 이미지 그리드 (Image Grid)

> 다중 이미지 비교 (3×2 또는 3×1). height:Nvh 고정 필수.
> ⚠️ PPTX: aspect-ratio 대신 height:Nvh 사용 필수.

```html
<section class="slide light">
  <div class="chrome">
    <span class="left"><span>[섹션]</span><span class="sep"></span><span>[주제]</span></span>
    <span class="right"><span>[번호] / [총수]</span></span>
  </div>
  <p class="kicker" style="margin-top:3vh" data-anim>[kicker]</p>
  <h2 class="h-md" style="margin-top:1.5vh" data-anim>[그리드 제목]</h2>
  <div class="frame grid-3-3" style="margin-top:3vh">
    <figure class="tile" data-anim>
      <div class="frame-img" style="height:26vh"><img src="[경로1]" alt="[설명1]"></div>
      <figcaption class="img-cap">[캡션1]</figcaption>
    </figure>
    <figure class="tile" data-anim>
      <div class="frame-img" style="height:26vh"><img src="[경로2]" alt="[설명2]"></div>
      <figcaption class="img-cap">[캡션2]</figcaption>
    </figure>
    <figure class="tile" data-anim>
      <div class="frame-img" style="height:26vh"><img src="[경로3]" alt="[설명3]"></div>
      <figcaption class="img-cap">[캡션3]</figcaption>
    </figure>
  </div>
  <div class="foot"><span>[출처]</span><span>[번호] / [총수]</span></div>
</section>
```

---

## Layout 6 — 파이프라인 (Pipeline / Step Flow)

> 단계별 프로세스. data-animate="pipeline" 필수.
> ⚠️ PPTX: pipeline 애니메이션은 web only. PPTX에서 모든 step 동시 표시.

```html
<section class="slide light" data-animate="pipeline">
  <div class="chrome">
    <span class="left"><span>[섹션]</span><span class="sep"></span><span>[주제]</span></span>
    <span class="right"><span>[번호] / [총수]</span></span>
  </div>
  <p class="kicker" style="margin-top:3vh" data-anim>[kicker]</p>
  <h2 class="h-md" style="margin-top:1.5vh" data-anim>[전체 프로세스 이름]</h2>
  <div class="pipeline-section" style="margin-top:3vh">
    <p class="pipeline-label">[Phase 1 — 단계명]</p>
    <div class="pipeline" data-cols="4">
      <div class="step" data-anim="step">
        <p class="step-nb">01</p>
        <p class="step-title">[단계 제목]</p>
        <p class="step-desc">[단계 설명 1-2줄]</p>
      </div>
      <div class="step" data-anim="step">
        <p class="step-nb">02</p>
        <p class="step-title">[단계 제목]</p>
        <p class="step-desc">[단계 설명 1-2줄]</p>
      </div>
      <!-- step 반복 -->
    </div>
  </div>
  <div class="foot"><span>[출처]</span><span>[번호] / [총수]</span></div>
</section>
```
---

## Layout 7 — 질문 페이지 (Hero Question)

> 여백과 긴장감. hero dark 권장.

```html
<section class="slide hero dark" data-animate="hero">
  <div class="chrome">
    <span class="left"><span>[섹션]</span></span>
    <span class="right"><span>[번호] / [총수]</span></span>
  </div>
  <div class="fill center col">
    <p class="kicker" data-anim>[분위기 단어]</p>
    <h2 class="h-xl" style="max-width:60vw;text-align:center;margin-top:3vh" data-anim>
      [첫 번째 줄]<br>[두 번째 줄]?
    </h2>
  </div>
  <div class="foot"><span></span><span>[번호] / [총수]</span></div>
</section>
```

---

## Layout 8 — 대인용 (Big Quote)

> 세리프 금구, 줄별 애니메이션. data-animate="quote" 필수.

```html
<section class="slide light" data-animate="quote">
  <div class="chrome">
    <span class="left"><span>[섹션]</span></span>
    <span class="right"><span>[번호] / [총수]</span></span>
  </div>
  <div class="fill center col" style="max-width:64vw;margin:0 auto">
    <p class="kicker" data-anim>[인용 유형]</p>
    <div style="margin-top:4vh">
      <p class="h-xl body-serif" data-anim>
        <span data-anim="line" style="display:block">[첫 번째 줄]</span>
        <span data-anim="line" style="display:block">[두 번째 줄]</span>
        <span data-anim="line" style="display:block">[세 번째 줄]</span>
      </p>
    </div>
    <div class="callout-src" data-anim>— [출처 / 작성자]</div>
  </div>
  <div class="foot"><span>[맥락]</span><span>[번호] / [총수]</span></div>
</section>
```
---

## Layout 9 — 대비 페이지 (Before / After Comparison)

> 이전 vs 이후 6:6 분할. data-animate="directional" 필수.

```html
<section class="slide light" data-animate="directional">
  <div class="chrome">
    <span class="left"><span>[섹션]</span><span class="sep"></span><span>[주제]</span></span>
    <span class="right"><span>[번호] / [총수]</span></span>
  </div>
  <p class="kicker" style="margin-top:3vh" data-anim>[대비 주제]</p>
  <div class="frame grid-2-6-6" style="margin-top:3vh;gap:4vw">
    <div data-anim="left">
      <p class="meta" style="margin-bottom:2vh">BEFORE</p>
      <h3 class="h-md" style="margin-bottom:2vh">[이전 상태]</h3>
      <div class="frame-img" style="height:34vh"><img src="[이전 이미지]" alt="Before"></div>
      <p class="body-zh" style="margin-top:2vh">[이전 설명]</p>
    </div>
    <div class="rule v" data-anim="divider" style="align-self:stretch;height:auto;margin:0"></div>
    <div data-anim="right">
      <p class="meta" style="margin-bottom:2vh">AFTER</p>
      <h3 class="h-md" style="margin-bottom:2vh">[이후 상태]</h3>
      <div class="frame-img" style="height:34vh"><img src="[이후 이미지]" alt="After"></div>
      <p class="body-zh" style="margin-top:2vh">[이후 설명]</p>
    </div>
  </div>
  <div class="foot"><span>[출처]</span><span>[번호] / [총수]</span></div>
</section>
```

---

## Layout 10 — 이미지 + 사이드 텍스트 (Lead + Sidebar)

> 대단락 텍스트 + 세로 이미지. grid-2-8-4 (8:4 분할).

```html
<section class="slide dark">
  <div class="chrome">
    <span class="left"><span>[섹션]</span><span class="sep"></span><span>[주제]</span></span>
    <span class="right"><span>[번호] / [총수]</span></span>
  </div>
  <div class="frame grid-2-8-4" style="margin-top:3vh;align-items:start">
    <div class="col">
      <p class="kicker" data-anim>[kicker]</p>
      <h2 class="h-xl" style="margin-top:2vh" data-anim>[메인 제목]</h2>
      <p class="body-zh" style="margin-top:3vh" data-anim>[긴 본문 3-5줄]</p>
      <div class="rule" style="margin-top:4vh" data-anim></div>
      <div class="rowline" data-anim>
        <span class="k">[키1]</span><span class="v">[값1]</span><span class="m">[메타1]</span>
      </div>
      <div class="rowline" data-anim>
        <span class="k">[키2]</span><span class="v">[값2]</span><span class="m">[메타2]</span>
      </div>
    </div>
    <figure class="tile" data-anim>
      <div class="frame-img r-3x4" style="margin-top:7vh">
        <img src="[세로 이미지]" alt="[설명]">
      </div>
    </figure>
  </div>
  <div class="foot"><span>[출처]</span><span>[번호] / [총수]</span></div>
</section>
```

---

## 레이아웃 × 테마 권장 매핑

| 레이아웃 | 권장 테마 | 비고 |
|---------|----------|------|
| 1. Opening Cover | `hero dark` | 강렬한 첫인상 |
| 2. Act Divider | `hero dark` / `hero light` 교차 | 챕터 전환 |
| 3. Stat Grid | `light` | 숫자 가독성 |
| 4. Left Text + Image | `light` / `dark` 교차 | 리듬 조절 |
| 5. Image Grid | `light` | 이미지 대비 |
| 6. Pipeline | `light` | 프로세스 명확성 |
| 7. Hero Question | `hero dark` | 긴장감 |
| 8. Big Quote | `light` / `dark` 교차 | 인용 강조 |
| 9. Before/After | `light` | 비교 명확성 |
| 10. Lead + Sidebar | `dark` | 깊이감, 긴 텍스트 |
