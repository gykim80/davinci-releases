# Anti-AI-Slop & Content Quality Rules

> Reference document for da:create skill. These rules ensure generated
> designs are indistinguishable from hand-crafted professional work.
> Ported from Open Design lint-artifact.js deterministic linter.

---

## P0 -- Blocker (must fix before emit)

### P0-1: Purple/Violet Gradient

**Detection:** `linear-gradient()` containing any purple/violet hex
(`#a855f7`, `#9333ea`, `#7c3aed`, `#6d28d9`, `#581c87`, `#8b5cf6`,
`#a78bfa`, `#c4b5fd`, `#ddd6fe`, `#ede9fe`) or the keywords
`purple`/`violet`.

**Fix:** Replace gradient with a flat surface (`var(--bg)` or `var(--surface)`)
or use the active accent at a single intensity, not in a gradient.

### P0-2: Emoji as UI Icons

**Detection:** Unicode emoji (U+1F300-1F9FF range, including but not limited to:
sparkles, rocket, target, lightning, fire, bulb, chart, palette, shield, star,
flexed biceps, party, wave, raised hands, checkmark, star, trophy) used inside
`<h1>`-`<h6>`, `<button>`, `<li>`, or icon-classed `<span>` elements.

**Fix:** Replace with a small inline SVG icon (1.6-1.8px stroke, currentColor)
or remove the icon entirely. Emoji in body prose is acceptable.

### P0-3: Rounded Card + Left-Border Accent

**Detection:** Any CSS class combining `border-left` (solid, colored) with
`border-radius` > 0. The canonical AI-slop card pattern.

**Fix:** Drop either the border-radius (set 0) or the border-left.
Cards should use hairline borders all-round or no border.

### P0-4: Sans-Serif Display Face

**Detection:** `h1`, `h2`, `h3` (or `.h-hero`, `.h-xl`, `.h-lg`, `.h-md`)
with `font-family` set to Inter, Roboto, Arial, -apple-system, system-ui,
or SF Pro without a serif preceding it.

**Fix:** Use `font-family: var(--font-display)` on headings and let the
active design system pick the serif. Override only if the active direction
is explicitly "tech / utility" or "modern minimal".

### P0-5: Invented Metrics

**Detection:** Phrases matching these patterns:
- "10x faster/better/easier"
- "100x faster/better"
- "99.X% uptime"
- "zero downtime" / "zero-downtime"
- "3x more productive/efficient"

**Fix:** Remove the claim or replace with a placeholder dash until the user
supplies a real, sourced number.

### P0-6: Filler / Lorem Copy

**Detection:**
- "Feature One/Two/Three" or "Feature 1/2/3"
- "Lorem ipsum"
- "dolor sit amet"
- "placeholder text"
- "sample content"

**Fix:** Replace with copy specific to the brief or delete the section
entirely. An empty section is better than invented words.

### P0-7: scrollIntoView()

**Detection:** `Element.scrollIntoView()` call in any script block.

**Fix:** Use `scrollTo({ left, top, behavior: "smooth" })` on the actual
scroller element. scrollIntoView yanks the host page when an iframe
boundary is crossed.

---

## P1 -- Important (should fix before handoff)

### P1-1: External Placeholder Image CDN

**Detection:** `<img>` with `src` pointing to `images.unsplash.com`,
`placehold.co`, `placekitten.com`, `via.placeholder.com`, `picsum.photos`,
or `loremflickr.com`.

**Fix:** Use solid-color placeholder rectangles (CSS `background-color` on
a sized `<div>`) or the `.ph-img` placeholder class if available.

### P1-2: Raw Hex Outside :root (> 12)

**Detection:** More than 12 `#xxxxxx` hex values in `<style>` blocks
outside the `:root { }` declaration.

**Fix:** Move every color into the `:root` token block
(`--bg`, `--surface`, `--fg`, `--muted`, `--border`, `--accent`) and
reference via `var()`. Use `color-mix()` for derived tones.

### P1-3: Accent Color Overuse (> 6 inline)

**Detection:** `var(--accent)` used more than 6 times in inline styles
(outside `<style>` blocks) in the rendered body.

**Fix:** Cap accent usage at 2 visible uses per screen (one eyebrow + one
CTA, OR one accent card + one tab). Demote the rest to `var(--fg)` or
`var(--muted)`.

---

## P2 -- Nice-to-have (tracked, non-blocking)

### P2-1: Missing Section Anchor

**Detection:** `<section>` elements lacking `data-screen-label` (slides)
or `data-od-id` (prototypes) attribute.

**Fix:** Add `data-screen-label="Screen N"` to every top-level `<section>`
so comment mode and the preview pipeline can target individual sections.

### P2-2: Missing Slide Theme Class

**Detection:** (Deck artifacts only) `<section class="slide">` elements
that lack a theme class (`light`, `dark`, `hero light`, `hero dark`).

**Fix:** Every slide section must include exactly one theme class.
Avoid 3+ same-theme slides in a row (visual fatigue).

---

## Banned Patterns (Quick Reference Table)

| Pattern | Severity | Detection Signal | Alternative |
|---------|----------|-----------------|-------------|
| Purple/violet gradients | P0 | `linear-gradient` + purple hex/keyword | Flat surface or single accent |
| Emoji as UI icons | P0 | Emoji in h1-h6/button/li/icon span | Inline SVG monoline |
| Card + left-border accent | P0 | `border-left` + `border-radius` combo | Hairline borders or no border |
| Sans-serif display face | P0 | h1-h3 with Inter/Roboto/Arial | `var(--font-display)` serif |
| Invented metrics | P0 | "10x faster", "99.9% uptime" | Real sourced numbers or dash |
| Filler copy | P0 | "Feature One", "Lorem ipsum" | Brief-derived copy |
| scrollIntoView() | P0 | `.scrollIntoView(` in script | `scrollTo()` on scroller |
| Full-page gradient bg | P0 | `bg-gradient-to-*` on main/body | Solid color or texture |
| SVG humanoid illustrations | P0 | `<path>` with body proportions | Solid-color rectangles |
| Circle-bg icon grids | P0 | `rounded-full bg-* p-3` x3+ | Varied layout per feature |
| External placeholder images | P1 | unsplash/placehold.co in src | CSS placeholder rectangles |
| Raw hex outside :root | P1 | > 12 hex values outside :root | CSS custom properties |
| Accent overuse | P1 | `var(--accent)` > 6 inline | 2 accent uses per screen |
| Drop shadow everywhere | P1 | `shadow-*` on >50% of elements | Shadows on elevated only |
| Wave/angle dividers | P1 | `clip-path` between sections | Clean breaks or overlap |
| Missing section anchor | P2 | `<section>` without data-screen-label | Add label attribute |
| Missing slide theme | P2 | `.slide` without light/dark class | Add theme class |

---

## Banned Fonts (as primary display or body)

- Inter
- Roboto
- Arial
- Fraunces
- system-ui / -apple-system / BlinkMacSystemFont / sans-serif (as explicit primary)

**Choose instead**: Distinctive fonts from Google Fonts that match the project personality.
Examples: Space Grotesk, Outfit, Sora, Plus Jakarta Sans, DM Serif Display, Instrument Serif.

---

## Required Quality Markers

### CSS Requirements
```css
/* MUST use on body/paragraphs */
text-wrap: pretty;

/* MUST use oklch for colors */
color: oklch(45% 0.15 250);    /* NOT rgb(59, 130, 246) */
background: oklch(98% 0.01 250); /* NOT #f8fafc */

/* MUST use CSS Grid for page layout */
display: grid;
grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
```

### State Persistence
```javascript
// MUST persist user state where applicable
localStorage.setItem('theme', dark ? 'dark' : 'light');
localStorage.setItem('slide-position', currentSlide);
localStorage.setItem('scroll-position', window.scrollY);
```

### Visual Rhythm
Each section MUST differ from adjacent sections in at least 2 of:
1. Background color/tone
2. Layout pattern (grid columns, alignment)
3. Typography treatment (size, weight, style)
4. Spacing density
5. Visual element placement

### Content Scale Minimums
| Context | Minimum Size |
|---------|-------------|
| Slides (1920x1080) | Body text >= 24px, headings >= 48px |
| Mobile mockups | Touch targets >= 44px, body >= 16px |
| Print documents | Body >= 12pt, headings >= 18pt |
| Prototypes | Reasonable margins, viewport-centered |

---

## Visual Variety Mandate

> "CSS, HTML, JS, SVG offer amazing possibilities. Surprise the user."

### Exploration Gradient
1. **First variation**: Conservative, close to existing brand/reference
2. **Second variation**: Moderate push on 1-2 axes
3. **Third+ variation**: Experimental on scale, fills, texture, rhythm, layering

### Section Diversity Checklist
- [ ] No two adjacent sections share the same background
- [ ] Heading treatments vary (size, case, decoration, alignment)
- [ ] At least one section uses a non-standard layout (asymmetric, overlap, magazine)
- [ ] Whitespace is generous but not uniform
- [ ] Color usage follows the declared palette (no random new colors)

---

## Content Authenticity

### Banned Copy Patterns
- "Lorem ipsum" (unless explicitly wireframe mode)
- "Feature One / Feature Two / Feature Three"
- "100+ customers" (use specific: "2,847 active teams")
- "Happy team collaborating" placeholder descriptions
- "Revolutionize your workflow" and similar empty marketing copy
- "Seamlessly integrate with your existing tools"

### Data Requirements
- Use plausible specific numbers (not round numbers)
- Include realistic dates, names, locations
- Write microcopy that sounds human (button labels, empty states, error messages)
- Cultural appropriateness for target audience

### Brand DNA Remix
When extending an existing design system:
1. Extract the core visual vocabulary (shapes, colors, spacing rhythm)
2. Identify the "personality traits" (playful vs. serious, dense vs. airy)
3. Remix within those constraints (new layouts, same DNA)
4. NEVER invent colors not derivable from the existing palette
