# Web Prototype Layouts

**8 paste-ready section skeletons.** Drop into `<main id="content">` of `assets/template-web.html`. Do not write sections from scratch -- pick the closest layout, paste, swap copy.

## Pre-flight

1. **Read `assets/template-web.html`** through `<style>`. Every class below must exist there.
2. **Pick a section list before writing copy.** Default rhythms:
   - **Landing**: Hero -> Features -> Stats or Quote -> Split -> CTA -> Footer
   - **Marketing**: Hero Center -> Log List -> Split -> CTA
   - **Pricing**: Hero Center -> Table -> CTA
3. **One accent per screen, used at most twice.** Eyebrow + primary button already use it.

## Class inventory (must exist in template-web.html)

> `section` `container` `hero` `hero-center` `hero-split` `hero-cta` `eyebrow` `lead`
> `h1` `h2` `h3` `meta` `num` `btn` `btn-primary` `btn-secondary` `btn-ghost` `btn-arrow`
> `card` `card-flat` `feature` `feature-mark` `stat` `stat-num` `stat-label`
> `quote` `quote-mark` `quote-author` `pill` `ph-img` `wide` `square`
> `grid-2` `grid-3` `grid-4` `row` `row-between` `stack` `ds-table` `topnav` `pagefoot`

---

## Layout 1 -- Hero Centered

```html
<section class="section hero" data-screen-label="Screen N">
  <div class="container hero-center">
    <p class="eyebrow">EYEBROW</p>
    <h1>One sharp sentence about what this is.</h1>
    <p class="lead">Concrete-value subhead -- what changes for the reader.</p>
    <div class="hero-cta">
      <button class="btn btn-primary">Primary action</button>
      <button class="btn btn-secondary">Secondary</button>
    </div>
  </div>
</section>
```

## Layout 2 -- Hero Split

Use when there is a real product visual. Left half copy, right half a `ph-img` placeholder.

```html
<section class="section" data-screen-label="Screen N">
  <div class="container hero-split">
    <div>
      <p class="eyebrow">EYEBROW</p>
      <h1>Headline that names the change.</h1>
      <p class="lead" style="margin-top: 20px;">Short subhead -- concrete, not corporate.</p>
      <div class="hero-cta" style="margin-top: 28px;">
        <button class="btn btn-primary">Primary action</button>
        <button class="btn btn-ghost btn-arrow">Read the story</button>
      </div>
    </div>
    <div class="ph-img wide" aria-label="Hero visual placeholder">[ Hero visual / 16:9 ]</div>
  </div>
</section>
```

## Layout 3 -- Features Grid

Three feature cells. Lead with a small `<h2>`. One tasteful SVG mark per cell.

```html
<section class="section" data-screen-label="Screen N">
  <div class="container stack" style="gap: 56px;">
    <div style="max-width: 36ch;">
      <p class="eyebrow">WHAT'S DIFFERENT</p>
      <h2>Three things you'll notice in the first ten minutes.</h2>
    </div>
    <div class="grid-3">
      <div class="feature card-flat">
        <div class="feature-mark">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M12 3v18M3 12h18"/></svg>
        </div>
        <h3>[REPLACE] Feature one</h3>
        <p>[REPLACE] Two-sentence description naming user value.</p>
      </div>
      <div class="feature card-flat">
        <div class="feature-mark">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="12" cy="12" r="8"/><path d="M12 8v4l3 2"/></svg>
        </div>
        <h3>[REPLACE] Feature two</h3>
        <p>[REPLACE] Two-sentence description naming user value.</p>
      </div>
      <div class="feature card-flat">
        <div class="feature-mark">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M4 7h16M4 12h10M4 17h16"/></svg>
        </div>
        <h3>[REPLACE] Feature three</h3>
        <p>[REPLACE] Two-sentence description naming user value.</p>
      </div>
    </div>
  </div>
</section>
```

## Layout 4 -- Stats Row

Three stats max. Do not invent metrics -- if no real number exists, use a different layout.

```html
<section class="section" data-screen-label="Screen N">
  <div class="container">
    <p class="eyebrow" style="margin-bottom: 40px;">BY THE NUMBERS</p>
    <div class="grid-3">
      <div class="stat">
        <div class="stat-num num">[REPLACE]<span class="stat-unit">[REPLACE]</span></div>
        <p class="stat-label">[REPLACE] What this number means in context.</p>
      </div>
      <div class="stat">
        <div class="stat-num num">[REPLACE]</div>
        <p class="stat-label">[REPLACE] Concrete outcome description.</p>
      </div>
      <div class="stat">
        <div class="stat-num num">[REPLACE]<span class="stat-unit">[REPLACE]</span></div>
        <p class="stat-label">[REPLACE] Real impact statement.</p>
      </div>
    </div>
  </div>
</section>
```

## Layout 5 -- Pull Quote

Single decisive quote with attribution. One per page, never two in a row.

```html
<section class="section" data-screen-label="Screen N">
  <div class="container" style="max-width: 800px;">
    <div class="quote-mark">"</div>
    <blockquote class="quote">[REPLACE] A real, specific testimonial sentence.</blockquote>
    <p class="quote-author">-- [REPLACE] Name, Title at Company</p>
  </div>
</section>
```

## Layout 6 -- CTA Strip

End the page on one decisive ask. Centered, generous whitespace, one primary button.

```html
<section class="section" data-screen-label="Screen N" style="text-align: center;">
  <div class="container" style="max-width: 600px;">
    <h2>[REPLACE] One closing statement.</h2>
    <p class="lead" style="margin: 16px auto 32px;">[REPLACE] Pricing or next-step context.</p>
    <button class="btn btn-primary">[REPLACE] Start free</button>
  </div>
</section>
```

## Layout 7 -- Log List

Editorial layout for dated entries. Date mono left, title + dek center, optional pull stat right.

```html
<section class="section" data-screen-label="Screen N">
  <div class="container">
    <div class="row-between" style="margin-bottom: 32px;">
      <h2>[REPLACE] Section heading</h2>
      <a class="btn btn-ghost btn-arrow" href="#">View all</a>
    </div>
    <div>
      <article style="display: grid; grid-template-columns: 120px 1fr 100px; gap: var(--gap-lg); padding: 22px 0; border-top: 1px solid var(--border); align-items: baseline;">
        <span class="meta">[REPLACE] Date</span>
        <div>
          <h3 style="font-size: 19px;">[REPLACE] Entry title</h3>
          <p style="margin: 4px 0 0; color: var(--muted); font-size: 14px;">[REPLACE] One-line description.</p>
        </div>
        <span class="meta" style="text-align: right;">[REPLACE] Tag</span>
      </article>
      <article style="display: grid; grid-template-columns: 120px 1fr 100px; gap: var(--gap-lg); padding: 22px 0; border-top: 1px solid var(--border); align-items: baseline;">
        <span class="meta">[REPLACE] Date</span>
        <div>
          <h3 style="font-size: 19px;">[REPLACE] Entry title</h3>
          <p style="margin: 4px 0 0; color: var(--muted); font-size: 14px;">[REPLACE] One-line description.</p>
        </div>
        <span class="meta" style="text-align: right;">[REPLACE] Tag</span>
      </article>
    </div>
  </div>
</section>
```

## Layout 8 -- Pricing Table

Hairline borders, mono numerics. One column highlighted via accent border.

```html
<section class="section" data-screen-label="Screen N">
  <div class="container">
    <div style="text-align: center; max-width: 36ch; margin: 0 auto 56px;">
      <p class="eyebrow">PRICING</p>
      <h2>[REPLACE] Pricing headline.</h2>
    </div>
    <table class="ds-table">
      <thead>
        <tr>
          <th>Feature</th>
          <th class="num-col">[REPLACE] Tier 1</th>
          <th class="num-col">[REPLACE] Tier 2</th>
          <th class="num-col">[REPLACE] Tier 3</th>
        </tr>
      </thead>
      <tbody>
        <tr><td>[REPLACE] Feature</td><td class="num-col">--</td><td class="num-col">--</td><td class="num-col">--</td></tr>
        <tr><td>[REPLACE] Feature</td><td class="num-col">--</td><td class="num-col">--</td><td class="num-col">--</td></tr>
        <tr style="border-top: 1px solid var(--fg);">
          <td><strong>Monthly</strong></td>
          <td class="num-col"><strong>[REPLACE]</strong></td>
          <td class="num-col"><strong>[REPLACE]</strong></td>
          <td class="num-col"><strong>[REPLACE]</strong></td>
        </tr>
      </tbody>
    </table>
  </div>
</section>
```

---

## Section Rhythm Guide

For a 5-section landing: Hero (1 or 2) -> Features (3) -> Stats or Quote (4 or 5) -> Split detail -> CTA (6).
For a 4-section marketing index: Hero Center (1) -> Log List (7) -> CTA (6).
Two stat rows in a row, two quotes in a row, two feature triplets in a row -- all visual fatigue. Alternate.
