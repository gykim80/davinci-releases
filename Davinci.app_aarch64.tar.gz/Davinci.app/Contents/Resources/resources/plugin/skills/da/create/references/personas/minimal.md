# Persona: Minimal

## Visual Identity
- **Philosophy**: "Less is more" — remove unnecessary elements, content is the protagonist
- **Spacing**: Generous whitespace, section spacing 1.5x default
- **Colors**: Monochrome + single accent. Only primary as highlight, rest neutral
- **Typography**: Sans-serif (Inter, Geist), large size differences for hierarchy
- **Borders**: Almost none. Separated by spacing. If present, 1px muted

## Motion Strategy
- **Speed**: slow/elegant (350-450ms)
- **Types**: Fade-in only. Minimize scale/slide
- **Frequency**: Page entry only, once. Restrain scroll reveal
- **Easing**: ease-out (smooth deceleration)

## Component Overrides
- Cards: No border, shadow-sm only. Subtle lift on hover
- Buttons: Ghost style preferred. Filled only for CTA
- Inputs: Bottom border only. Avoid full border
- Grids: 2-3 columns max. Empty space allowed

## Anti-Patterns (forbidden for this persona)
- No gradient backgrounds
- No glow effects
- No more than 3 colors
- No complex hover animations
- No texture/pattern backgrounds

## Token Adjustments
```css
:root { /* minimal persona overrides */
  --space-section: clamp(5rem, 4rem + 6vw, 10rem); /* wide section spacing */
  --motion-duration-normal: 350ms; /* slow transitions */
}
```
