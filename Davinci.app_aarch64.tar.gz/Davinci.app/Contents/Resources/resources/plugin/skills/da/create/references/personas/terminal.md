# Persona: Terminal

## Visual Identity
- **Philosophy**: "Hacker/developer aesthetic" — monospace, dark background, glow, matrix
- **Spacing**: Narrow. High information density (terminal feel)
- **Colors**: Dark background + green/cyan/amber glow. Pure black background allowed (exception for this persona only)
- **Typography**: Monospace (JetBrains Mono, Fira Code). Small sizes allowed
- **Borders**: 1px solid, muted colors. Terminal frame feel

## Motion Strategy
- **Speed**: fast/instant (50-150ms)
- **Types**: Typing effects, blinking, glitch. Fast fade-in
- **Frequency**: Minimal. Typing effects and cursor blinking only
- **Easing**: linear (mechanical)

## Component Overrides
- Cards: Dark background, 1px border, slightly rounded corners (rounded-md)
- Buttons: Monospace labels, border style, glow on hover
- Code blocks: Main component. Syntax highlighting required
- Inputs: Terminal prompt style ($ prefix)

## Anti-Patterns (forbidden for this persona)
- No pastel colors
- No serif fonts
- No large rounded corners (rounded-xl or above)
- No image-centric layouts
- No smooth/elegant animations

## Special Rules (exceptions)
- bg-black usage allowed (Anti-Generic Rule_5 exception)
- Pure #000 background allowed
- Active use of glow effects
- Direct usage of text-green-400, text-cyan-400 allowed

## Token Adjustments
```css
:root { /* terminal persona overrides */
  --motion-duration-fast: 50ms;
  --motion-duration-normal: 150ms;
  --motion-ease-out: linear; /* mechanical transitions */
}
```
