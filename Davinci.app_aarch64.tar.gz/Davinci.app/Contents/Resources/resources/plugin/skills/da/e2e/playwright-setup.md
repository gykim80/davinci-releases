# Playwright Setup

Project configuration, directory structure, and multi-browser setup for Playwright E2E testing.

## Installation

Install Playwright and its test runner as dev dependencies. The `install` command downloads browser binaries.

```bash
npm init playwright@latest
# or manual setup
npm install -D @playwright/test
npx playwright install
```

## Project Structure

Organize tests, fixtures, and page objects in a predictable layout.

```
project-root/
  playwright.config.ts        # Central configuration
  tests/
    e2e/                      # End-to-end test specs
      auth.spec.ts
      dashboard.spec.ts
    fixtures/                 # Custom fixture definitions
      auth.fixture.ts
      test-data.fixture.ts
    page-objects/             # Page Object Model classes
      login.page.ts
      dashboard.page.ts
  test-results/               # Generated: test artifacts
  playwright-report/          # Generated: HTML report
```

**Detect:** No `tests/` directory or flat test files in project root -- suggest structured directory layout.

## Configuration: `playwright.config.ts`

### Base Configuration

The configuration file controls every aspect of test execution. Always define `baseURL` to avoid hardcoded URLs.

```typescript
// playwright.config.ts
import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  testDir: './tests/e2e',
  fullyParallelTests: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 1 : undefined,
  reporter: 'html',

  use: {
    baseURL: 'http://localhost:3000',
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
  },
});
```

**Detect:** No `playwright.config.ts` in project root -- suggest generating a base configuration.

### Multi-Browser Setup

Define projects to run tests across Chromium, Firefox, and WebKit simultaneously.

```typescript
// playwright.config.ts (projects section)
export default defineConfig({
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
    {
      name: 'firefox',
      use: { ...devices['Desktop Firefox'] },
    },
    {
      name: 'webkit',
      use: { ...devices['Desktop Safari'] },
    },
    {
      name: 'mobile-chrome',
      use: { ...devices['Pixel 5'] },
    },
    {
      name: 'mobile-safari',
      use: { ...devices['iPhone 13'] },
    },
  ],
});
```

### Dev Server Auto-Start

Use `webServer` to start the development server automatically before tests run.

```typescript
// playwright.config.ts (webServer section)
export default defineConfig({
  webServer: {
    command: 'npm run dev',
    url: 'http://localhost:3000',
    reuseExistingServer: !process.env.CI,
    timeout: 120_000,
  },
});
```

This eliminates the need to manually start the server before running tests.

## Configuration Best Practices

### baseURL

**Detect:** Hardcoded URL string (`http://localhost`) inside a test file -- suggest using `baseURL` from config.

```typescript
// Bad: Hardcoded URL in test file
test('loads homepage', async ({ page }) => {
  await page.goto('http://localhost:3000/dashboard');
});

// Good: Relative path uses baseURL from config
test('loads homepage', async ({ page }) => {
  await page.goto('/dashboard');
});
```

### Retries

```typescript
// Bad: No retries, flaky tests fail CI immediately
export default defineConfig({
  retries: 0,
});

// Good: Conditional retries for CI stability
export default defineConfig({
  retries: process.env.CI ? 2 : 0,
});
```

### Timeouts

```typescript
// Bad: Default timeout with no explicit configuration
export default defineConfig({});

// Good: Explicit timeouts for different contexts
export default defineConfig({
  timeout: 30_000,           // Per-test timeout
  expect: {
    timeout: 5_000,          // Per-assertion timeout
  },
  use: {
    actionTimeout: 10_000,   // Per-action timeout (click, fill)
    navigationTimeout: 15_000,
  },
});
```

### Workers

```typescript
// Bad: Unlimited workers in CI (resource exhaustion)
export default defineConfig({
  workers: undefined,
});

// Good: Constrained workers in CI, parallel locally
export default defineConfig({
  workers: process.env.CI ? 1 : undefined,
  fullyParallelTests: true,
});
```

## Environment-Specific Configuration

Use environment variables to switch configurations between local and CI.

```typescript
// playwright.config.ts
const isCI = !!process.env.CI;

export default defineConfig({
  retries: isCI ? 2 : 0,
  workers: isCI ? 1 : undefined,
  reporter: isCI ? 'github' : 'html',

  use: {
    baseURL: process.env.BASE_URL ?? 'http://localhost:3000',
    trace: isCI ? 'on-first-retry' : 'on',
    video: isCI ? 'on-first-retry' : 'off',
  },

  webServer: {
    command: 'npm run dev',
    url: process.env.BASE_URL ?? 'http://localhost:3000',
    reuseExistingServer: !isCI,
  },
});
```

## Quick Reference

| Config Option | Purpose | Recommended Value |
|---|---|---|
| `testDir` | Test file location | `'./tests/e2e'` |
| `baseURL` | Base URL for `page.goto()` | `'http://localhost:3000'` |
| `timeout` | Per-test timeout (ms) | `30_000` |
| `expect.timeout` | Per-assertion timeout (ms) | `5_000` |
| `retries` | Retry count on failure | `process.env.CI ? 2 : 0` |
| `workers` | Parallel worker count | `process.env.CI ? 1 : undefined` |
| `fullyParallelTests` | Run tests in parallel | `true` |
| `trace` | Trace recording mode | `'on-first-retry'` |
| `screenshot` | Screenshot capture mode | `'only-on-failure'` |
| `webServer.command` | Dev server start command | `'npm run dev'` |
| `webServer.reuseExistingServer` | Reuse running server | `!process.env.CI` |
| `forbidOnly` | Block `.only` in CI | `!!process.env.CI` |
