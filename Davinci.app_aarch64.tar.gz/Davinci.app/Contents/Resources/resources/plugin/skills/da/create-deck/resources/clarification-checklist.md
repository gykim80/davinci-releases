<!--
Source: op7418/guizang-ppt-skill (Apache-2.0)
Original: https://github.com/op7418/guizang-ppt-skill
Copyright (c) op7418. Licensed under Apache-2.0.
Modifications: Adapted for davinci-framework — Korean comments + PPTX Iron Law conflict notes.
-->

# 사전 명확화 체크리스트 (Pre-Work Clarification Framework)

> 원본: op7418/guizang-ppt-skill `SKILL.md` Step 1 — 6-Question 프리플라이트 프레임워크
>
> **목적**: 구조 수정을 방지하기 위한 코딩 시작 전 6가지 질문.
> 이 질문들에 대한 답변 없이 슬라이드 생성을 시작하지 마세요.

---

## 6-Question Pre-Work Framework

### Q1. 관객 (Audience)

> "이 덱을 누가 볼 건가요?"

```
- [ ] 투자자 / 파트너 (Pitch Deck → pitch preset 권장)
- [ ] 내부 팀 / 임원 (Business Report → business preset 권장)
- [ ] 학술 / 연구자 (Academic → academic preset 권장)
- [ ] 일반 공개 / 행사 (Creative → creative preset 권장)
- [ ] 기타: _______________
```

**영향**: preset 선택, 슬라이드 수, 정보 밀도

---

### Q2. 시간 (Duration / Slide Count)

> "발표 시간은 얼마나 되나요? 슬라이드가 몇 장 정도 필요한가요?"

```
- [ ] 5분 이하 → 5-8 슬라이드
- [ ] 10-15분 → 10-15 슬라이드
- [ ] 20-30분 → 15-25 슬라이드
- [ ] 발표 없음 (자료 공유용) → 페이지 수 제한 없음
- [ ] 직접 지정: ___ 슬라이드
```

**영향**: 슬라이드 수, 정보 밀도 (슬라이드당 개념 수)

---

### Q3. 소스 자료 (Source Material)

> "기존 자료가 있나요? 어떤 형식인가요?"

```
- [ ] 텍스트 개요 / 워드 문서
- [ ] 기존 PPT/Keynote
- [ ] 데이터/스프레드시트 (차트/표 포함)
- [ ] 이미지/스크린샷 자료
- [ ] 없음 — 처음부터 생성
- [ ] 기타: _______________
```

**영향**: 레이아웃 선택 (데이터 → Layout 3, 이미지 → Layout 4/5)

---

### Q4. 이미지 (Images)

> "이미지 자료가 있나요? 어떤 유형의 이미지가 필요한가요?"

```
- [ ] 실제 제품/서비스 스크린샷 있음
- [ ] 팀/사람 사진 있음
- [ ] AI 생성 이미지 필요 (davinci da:asset으로 생성 가능)
- [ ] 플레이스홀더로 충분 (class="placeholder" 사용)
- [ ] 이미지 불필요 (텍스트/데이터 중심)
```

**영향**: 이미지 레이아웃(4, 5, 10) 사용 여부, 플레이스홀더 vs 실제 이미지

> ⚠️ PPTX 주의: 이미지는 반드시 `<img>` 태그 사용 (CSS background-image 금지 — Iron Law #4)

---

### Q5. 테마 (Theme)

> "어떤 분위기의 테마를 원하시나요?"

`resources/themes.md`의 5개 중 선택 (커스텀 HEX 불가 — Iron Law #15):

```
- [ ] 먹빛 클래식 (Ink Classic) — 비즈니스, 범용
- [ ] 남빛 자기 (Indigo Porcelain) — 기술, 리서치
- [ ] 숲빛 먹 (Forest Ink) — 자연, 지속가능성
- [ ] 크라프트지 (Kraft Paper) — 빈티지, 인문학
- [ ] 모래언덕 (Dune) — 예술, 디자인
```

> 5개 외 요청 시: "5개 잠금 테마 — 다음 중 선택해주세요"로 응답

---

### Q6. 하드 제약 (Hard Constraints)

> "절대로 포함하면 안 되거나, 반드시 포함해야 하는 요소가 있나요?"

```
- [ ] PPTX export 필요 (Iron Law 모두 적용)
- [ ] 애니메이션 불필요 (정적 슬라이드만)
- [ ] 특정 브랜드 가이드라인 준수 필요
- [ ] 특정 언어만 사용 (한국어만 / 영어만 / 혼용)
- [ ] 접근성 요구사항 (고대비, 스크린리더 등)
- [ ] 슬라이드당 텍스트 분량 제한
- [ ] 기타: _______________
```

**영향**: Iron Law 적용 수준, 애니메이션 포함 여부, 언어 설정

---

## 답변 수집 후 — 생성 시작 전 확인사항

```
□ Q1-Q6 모두 답변 받음 (또는 기본값으로 진행 동의 확인)
□ da:create-deck preset 결정: pitch / business / academic / creative
□ 슬라이드 수 결정: ___
□ 테마 결정: ___ (themes.md 5개 중)
□ PPTX export 필요 여부: Y / N
□ 이미지 처리 방식: 실제 이미지 / 플레이스홀더 / AI 생성
```

---

## 빠른 시작 기본값 (Fast Path)

사용자가 빠른 시작을 원하는 경우 다음 기본값을 적용하세요:

```yaml
preset: pitch
slides: 12
theme: 먹빛 클래식 (Ink Classic)
images: placeholder (class="placeholder")
pptx_export: true (Iron Law 모두 적용)
language: Korean
animation: enabled (web preview)
```

> 기본값 적용 시 사용자에게 먼저 확인하거나,
> Outline 단계에서 수정 기회를 제공하세요.

---

## davinci da:create-deck 연동

이 체크리스트 완료 후:

1. `Template preset: {preset}` 메시지로 da:create-deck 실행
2. `<!-- da:outline {...} -->` 태그로 개요 먼저 emit
3. 사용자 승인 후 슬라이드 생성 시작
4. 각 슬라이드는 `resources/layouts.md` 10개 중 선택
5. PPTX export 필요 시 Iron Law #1-15 전체 준수
