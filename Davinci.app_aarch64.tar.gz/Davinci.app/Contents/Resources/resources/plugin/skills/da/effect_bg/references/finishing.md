# Background Finishing Overlays Reference

> da:effect_bg L5 Finishing — CSS-only overlay effects applied on top of Vanta background
> Dependencies: none (pure CSS)

## GrainOverlay

Film grain noise texture. Uses CSS `background-image` with inline SVG data URI.

> **Iron Rule**: SVG `<filter>` element forbidden for grain. Use static CSS `background-image` for GPU compositing.

```tsx
function GrainOverlay({ opacity = 0.4 }: { opacity?: number }) {
  return (
    <div
      style={{
        position: "absolute",
        inset: 0,
        pointerEvents: "none",
        zIndex: 10,
        mixBlendMode: "overlay",
        opacity,
        backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='g'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23g)'/%3E%3C/svg%3E")`,
        backgroundSize: "256px 256px",
      }}
    />
  )
}
```

## VignetteOverlay

Radial gradient edge darkening for depth and focus effect.

```tsx
function VignetteOverlay({ intensity = 0.6 }: { intensity?: number }) {
  return (
    <div
      style={{
        position: "absolute",
        inset: 0,
        pointerEvents: "none",
        zIndex: 10,
        background: `radial-gradient(ellipse at center, transparent 50%, rgba(0,0,0,${intensity}) 100%)`,
      }}
    />
  )
}
```

## GlowOverlay

Radial gradient center glow for ambient lighting effect.

```tsx
function GlowOverlay({ color = "rgba(124,58,237,0.15)" }: { color?: string }) {
  return (
    <div
      style={{
        position: "absolute",
        inset: 0,
        pointerEvents: "none",
        zIndex: 10,
        background: `radial-gradient(circle at 50% 50%, ${color} 0%, transparent 70%)`,
      }}
    />
  )
}
```

## ScanlinesOverlay

Horizontal repeating lines for CRT/retro aesthetic.

```tsx
function ScanlinesOverlay({ opacity = 0.05 }: { opacity?: number }) {
  return (
    <div
      style={{
        position: "absolute",
        inset: 0,
        pointerEvents: "none",
        zIndex: 10,
        opacity,
        background:
          "repeating-linear-gradient(0deg, transparent, transparent 1px, rgba(0,0,0,0.3) 1px, rgba(0,0,0,0.3) 2px)",
      }}
    />
  )
}
```

## Tone -> Finishing Mapping

| Tone | Finishing Overlays | Notes |
|------|-------------------|-------|
| dark | grain(0.4) + vignette(0.6) + glow(purple) | Full atmosphere stack |
| neon | glow(cyan 0.2) + scanlines(0.05) | Digital glow + CRT |
| minimal | — | Clean, no overlays |
| organic | grain(0.3) | Subtle film texture |
| luxury | grain(0.25) + vignette(0.7) | Cinematic depth |
| corporate | — | Professional, no overlays |
| playful | — | Colorful birds are enough |
| cyber | glow(green 0.15) + scanlines(0.06) | Terminal aesthetic |

## Finishing Glow Colors by Tone

| Tone | Glow Color |
|------|-----------|
| dark | `rgba(124,58,237,0.15)` — purple |
| neon | `rgba(0,255,255,0.2)` — cyan |
| cyber | `rgba(0,255,65,0.15)` — green |

## Integration Pattern

Finishing overlays are placed as children inside the VantaBackground container,
after the EffectLoader and before the main content.

```tsx
<VantaBackground effect="halo" options={darkOptions} onReady={setReady}>
  <EffectLoader ready={bgReady} tone="dark" />
  {/* L5 finishing overlays */}
  <GrainOverlay opacity={0.4} />
  <VignetteOverlay intensity={0.6} />
  <GlowOverlay color="rgba(124,58,237,0.15)" />
  {/* L4 interaction wrapper */}
  <ParallaxContent>
    {children}
  </ParallaxContent>
</VantaBackground>
```

## All Overlay Common Properties

- `position: absolute` + `inset: 0` — full coverage of parent
- `pointerEvents: "none"` — transparent to mouse/touch events
- `zIndex: 10` — above canvas (z:0) but below interactive content (z:auto from Vanta prepareEl)
- Pure CSS — no JavaScript animation, no GPU-intensive filters
