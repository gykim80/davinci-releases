# Premium Effects Reference

> Selected and applied according to Persona + Creative Brief in da:design.
> This file uses a copy-paste approach — no npm installation needed, copy the code directly.

## Backgrounds (ibelick/background-snippets reference)

### Dot Grid
```tsx
// Subtle dot grid background
<div className="relative">
  <div
    className="absolute inset-0 opacity-[0.03]"
    style={{
      backgroundImage: "radial-gradient(circle, hsl(var(--foreground)) 1px, transparent 1px)",
      backgroundSize: "24px 24px"
    }}
  />
  {children}
</div>
```

### Gradient Mesh
```tsx
// Multi-color mesh gradient background
<div className="relative overflow-hidden">
  <div className="absolute -inset-[100px] opacity-30 blur-[100px]">
    <div className="absolute top-0 left-1/4 w-96 h-96 rounded-full bg-primary/40" />
    <div className="absolute bottom-0 right-1/4 w-96 h-96 rounded-full bg-accent/30" />
    <div className="absolute top-1/2 left-1/2 w-96 h-96 rounded-full bg-muted/20" />
  </div>
  {children}
</div>
```

### Aurora
```tsx
// Aurora effect background (recommended for dark mode)
<div className="relative overflow-hidden">
  <div className="absolute inset-0">
    <div className="absolute -top-1/2 left-1/4 w-[600px] h-[600px] rounded-full bg-primary/20 blur-[120px] animate-pulse" />
    <div className="absolute -bottom-1/2 right-1/4 w-[500px] h-[500px] rounded-full bg-accent/15 blur-[100px] animate-pulse [animation-delay:2s]" />
  </div>
  {children}
</div>
```

## Text Effects

### Text Reveal (character-by-character entrance)
```tsx
import { motion } from "motion/react"

function TextReveal({ text }: { text: string }) {
  return (
    <motion.span
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true }}
      variants={{ visible: { transition: { staggerChildren: 0.03 } } }}
    >
      {text.split("").map((char, i) => (
        <motion.span
          key={i}
          className="inline-block"
          variants={{
            hidden: { opacity: 0, y: 20 },
            visible: { opacity: 1, y: 0 }
          }}
        >
          {char === " " ? "\u00A0" : char}
        </motion.span>
      ))}
    </motion.span>
  )
}
```

### Morphing Text (text transformation)
```tsx
import { AnimatePresence, motion } from "motion/react"
import { useEffect, useState } from "react"

function MorphingText({ texts }: { texts: string[] }) {
  const [index, setIndex] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setIndex((prev) => (prev + 1) % texts.length)
    }, 3000)
    return () => clearInterval(interval)
  }, [texts.length])

  return (
    <AnimatePresence mode="wait">
      <motion.span
        key={index}
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -10 }}
        transition={{ duration: 0.3 }}
      >
        {texts[index]}
      </motion.span>
    </AnimatePresence>
  )
}
```

## Card Effects

### Animated Card (hover 3D tilt)
```tsx
import { motion, useMotionValue, useTransform } from "motion/react"

function TiltCard({ children }: { children: React.ReactNode }) {
  const x = useMotionValue(0)
  const y = useMotionValue(0)
  const rotateX = useTransform(y, [-100, 100], [5, -5])
  const rotateY = useTransform(x, [-100, 100], [-5, 5])

  return (
    <motion.div
      style={{ rotateX, rotateY, transformStyle: "preserve-3d" }}
      onMouseMove={(e) => {
        const rect = e.currentTarget.getBoundingClientRect()
        x.set(e.clientX - rect.left - rect.width / 2)
        y.set(e.clientY - rect.top - rect.height / 2)
      }}
      onMouseLeave={() => { x.set(0); y.set(0) }}
      className="rounded-xl border bg-card p-6"
    >
      {children}
    </motion.div>
  )
}
```

### Bento Grid
```tsx
// Asymmetric grid layout (Magic UI reference)
<div className="grid grid-cols-3 gap-4">
  <div className="col-span-2 row-span-2 rounded-xl border bg-card p-6">
    {/* Large card */}
  </div>
  <div className="rounded-xl border bg-card p-6">{/* Small 1 */}</div>
  <div className="rounded-xl border bg-card p-6">{/* Small 2 */}</div>
  <div className="col-span-3 rounded-xl border bg-card p-6">
    {/* Full-width card */}
  </div>
</div>
```

## SVG Noise Overlay (universal)
```tsx
// Universal noise texture overlay that can be added anywhere
function NoiseOverlay({ opacity = 0.03 }: { opacity?: number }) {
  return (
    <svg className="pointer-events-none absolute inset-0 h-full w-full" style={{ opacity }}>
      <filter id="noise">
        <feTurbulence type="fractalNoise" baseFrequency="0.65" numOctaves="3" stitchTiles="stitch" />
      </filter>
      <rect width="100%" height="100%" filter="url(#noise)" />
    </svg>
  )
}
```

---

## ★ External Libraries (library-based — prioritized over CSS-only)

> **Warning: Effects in this section take priority over the CSS-only effects above.**
> For hero, CTA, and other key sections, you must use external library effects.
> CSS-only effects should only be applied to supporting sections (feature cards, footer, etc.).

### tsParticles — Particle System
```bash
pnpm add @tsparticles/react @tsparticles/slim
```
```tsx
import Particles, { initParticlesEngine } from "@tsparticles/react";
import { loadSlim } from "@tsparticles/slim";
import { useEffect, useState } from "react";

function ParticleBackground() {
  const [init, setInit] = useState(false);

  useEffect(() => {
    initParticlesEngine(async (engine) => {
      await loadSlim(engine);
    }).then(() => setInit(true));
  }, []);

  if (!init) return null;

  return (
    <Particles
      className="absolute inset-0"
      options={{
        fullScreen: false,
        background: { color: { value: "transparent" } },
        fpsLimit: 60,
        particles: {
          color: { value: "hsl(var(--primary))" },
          links: {
            color: "hsl(var(--primary))",
            distance: 150,
            enable: true,
            opacity: 0.15,
            width: 1,
          },
          move: { enable: true, speed: 0.8, direction: "none", outModes: { default: "out" } },
          number: { value: 60, density: { enable: true, width: 800, height: 800 } },
          opacity: { value: 0.3 },
          size: { value: { min: 1, max: 3 } },
        },
        detectRetina: true,
      }}
    />
  );
}
```

### simplex-noise — Flow Field (organic flow field)
```bash
pnpm add simplex-noise
```
```tsx
import { createNoise3D } from "simplex-noise";
import { useEffect, useRef } from "react";

function FlowField() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const noise3D = createNoise3D();
    let animationId: number;
    let time = 0;

    const resize = () => {
      canvas.width = canvas.offsetWidth * window.devicePixelRatio;
      canvas.height = canvas.offsetHeight * window.devicePixelRatio;
      ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
    };
    resize();
    window.addEventListener("resize", resize);

    const draw = () => {
      const w = canvas.offsetWidth;
      const h = canvas.offsetHeight;
      ctx.clearRect(0, 0, w, h);

      const step = 20;
      for (let x = 0; x < w; x += step) {
        for (let y = 0; y < h; y += step) {
          const angle = noise3D(x * 0.003, y * 0.003, time * 0.0005) * Math.PI * 2;
          const length = step * 0.6;

          ctx.beginPath();
          ctx.moveTo(x, y);
          ctx.lineTo(x + Math.cos(angle) * length, y + Math.sin(angle) * length);
          ctx.strokeStyle = `hsla(var(--primary), 0.12)`;
          ctx.lineWidth = 1;
          ctx.stroke();
        }
      }
      time++;
      animationId = requestAnimationFrame(draw);
    };
    draw();

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener("resize", resize);
    };
  }, []);

  return <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />;
}
```

### Lenis — Smooth Scroll
```bash
pnpm add lenis
```
```tsx
// Initialize in main.tsx or layout component
import Lenis from "lenis";

const lenis = new Lenis({
  duration: 1.2,
  easing: (t: number) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
  smoothWheel: true,
});

function raf(time: number) {
  lenis.raf(time);
  requestAnimationFrame(raf);
}
requestAnimationFrame(raf);
```

### Animated Gradient Background (granim.js alternative — pure Canvas)
```bash
# No external dependencies — uses Canvas API only
```
```tsx
import { useEffect, useRef } from "react";

function AnimatedGradient({ colors }: { colors: string[][] }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationId: number;
    let step = 0;
    const totalSteps = 600;

    const resize = () => {
      canvas.width = canvas.offsetWidth * 2;
      canvas.height = canvas.offsetHeight * 2;
    };
    resize();

    const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

    const draw = () => {
      const progress = (step % totalSteps) / totalSteps;
      const colorIndex = Math.floor(progress * colors.length) % colors.length;
      const nextIndex = (colorIndex + 1) % colors.length;
      const t = (progress * colors.length) % 1;

      const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
      gradient.addColorStop(0, colors[colorIndex][0]);
      gradient.addColorStop(1, colors[nextIndex][1] || colors[nextIndex][0]);

      ctx.globalAlpha = 0.15;
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      step++;
      animationId = requestAnimationFrame(draw);
    };
    draw();

    return () => cancelAnimationFrame(animationId);
  }, [colors]);

  return <canvas ref={canvasRef} className="absolute inset-0 w-full h-full opacity-40" />;
}
```

### React Three Fiber — 3D Scene (advanced)
```bash
pnpm add three @react-three/fiber @react-three/drei
```
```tsx
import { Canvas } from "@react-three/fiber";
import { Float, MeshDistortMaterial } from "@react-three/drei";

function Scene3D() {
  return (
    <div className="absolute inset-0">
      <Canvas camera={{ position: [0, 0, 5], fov: 45 }}>
        <ambientLight intensity={0.5} />
        <directionalLight position={[5, 5, 5]} intensity={0.8} />
        <Float speed={2} rotationIntensity={0.5} floatIntensity={1}>
          <mesh>
            <sphereGeometry args={[1.5, 64, 64]} />
            <MeshDistortMaterial
              color="hsl(38, 75%, 55%)"
              distort={0.3}
              speed={1.5}
              roughness={0.2}
              metalness={0.8}
            />
          </mesh>
        </Float>
      </Canvas>
    </div>
  );
}
```

---

## Application Guide

### Priority Matrix
| Section Type | Priority 1 (External Library) | Priority 2 (CSS-only) | Notes |
|-----------|----------------------|-----------------|------|
| Hero | tsParticles, FlowField, Scene3D | Do not use | Key first-impression section — external effects required |
| CTA | AnimatedGradient, FlowField | Aurora | Conversion-driving section |
| Feature Cards | Tilt Card (motion) | Bento Grid | Interaction-focused |
| Visual Showcase | Scene3D, tsParticles | Gradient Mesh | Technical demo |
| Background Support | — | Dot Grid, Noise Overlay | Subtle textures only |
| Full Page | Lenis smooth scroll | — | Always recommended |

### Effects Mapping by Persona
| Effect | minimal | bold | playful | elegant | terminal |
|------|---------|------|---------|---------|----------|
| tsParticles | ○ (sparse) | ◎ | ◎ | ○ | ◎ (matrix) |
| FlowField | ○ | ◎ | ○ | ◎ | ◎ |
| AnimatedGradient | — | ◎ | ◎ | ◎ | — |
| Scene3D | — | ◎ | ○ | ○ | ◎ |
| Lenis | ◎ | ◎ | ◎ | ◎ | ◎ |
| Dot Grid | ◎ | — | — | ◎ | ◎ |
| Gradient Mesh | — | ◎ | ◎ | ○ | — |
| Aurora | — | ◎ | — | — | ◎ |
| Text Reveal | — | ◎ | — | ◎ | — |
| Morphing Text | — | — | ◎ | — | ◎ |
| Tilt Card | — | ◎ | ◎ | — | — |
| Noise Overlay | ◎ | — | — | ◎ | — |

`◎ Strongly recommended` `○ Compatible` `— Incompatible`
