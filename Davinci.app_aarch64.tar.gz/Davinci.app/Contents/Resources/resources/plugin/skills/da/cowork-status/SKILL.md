---
description: "Check current team collaboration session status including active teammates, pattern, and progress."
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 유틸리티: 부작용(외부 API/배포/삭제) 전 §7 destructive/cost_gate 규칙을 확인한다.

## Tool Parameter Rules → See CLAUDE.md (ABSOLUTE)

# /da:cowork:status - Team Session Status

## Purpose
Display the current state of an active team collaboration session.

## Usage
```
/da:cowork:status
```

## Output
- Session ID and feature name
- Current DAVINCI phase
- Orchestration pattern in use
- Active teammates and roles
- Task assignments and completion
- Current blockers
- Progress metrics
