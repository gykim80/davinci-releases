# Next.js E2E Patterns

E2E testing strategies specific to Next.js App Router, covering Server Components, Server Actions, dynamic routes, loading/error states, middleware, authentication, and ISR/SSG cache behavior.

## Server Component Rendering Verification

Server Components render on the server and send HTML to the client. E2E tests should verify that the rendered content is present in the DOM immediately, without waiting for client-side hydration.

**Detect:** `app/` directory with `page.tsx` files that have no `"use client"` directive -- apply Server Component testing patterns.

```typescript
// Bad: Checking page source HTML instead of DOM assertions
test('server component renders', async ({ page }) => {
  const response = await page.goto('/products');
  const html = await response?.text();
  expect(html).toContain('Product List'); // Fragile, tests raw HTML
});

// Good: DOM assertion that verifies rendered content immediately
test('server component renders product list', async ({ page }) => {
  await page.goto('/products');
  await expect(page.getByRole('heading', { name: 'Product List' })).toBeVisible();
  await expect(page.getByRole('listitem')).toHaveCount(10);
});
```

### Key Points

- Server Component content is available on first paint -- no need to wait for hydration.
- Assert on DOM elements, not raw HTML source.
- Verify data fetched on the server appears in rendered output.

## Server Actions Testing

Server Actions are async functions that execute on the server, typically triggered by form submissions. Test them by interacting with the form and verifying the resulting state change.

**Detect:** `"use server"` directive in action files or inline in components -- apply Server Action test patterns.

```typescript
// Bad: Calling the server action function directly (bypasses form + middleware)
test('create item', async ({ request }) => {
  await request.post('/api/items', { data: { name: 'New Item' } });
});

// Good: Submit the form that triggers the Server Action
test('create item via server action', async ({ page }) => {
  await page.goto('/items/new');
  await page.getByLabel('Item name').fill('New Item');
  await page.getByRole('button', { name: 'Create' }).click();

  // Verify the action result: redirect or updated UI
  await expect(page).toHaveURL('/items');
  await expect(page.getByText('New Item')).toBeVisible();
});
```

### Key Points

- Always test Server Actions through the UI form that triggers them.
- Verify both success (redirect, toast, updated list) and failure (validation errors).
- Test progressive enhancement by verifying the form works with JS disabled if applicable.

## Dynamic Route Testing

Next.js supports dynamic segments (`[slug]`), catch-all segments (`[...params]`), and optional catch-all segments (`[[...optional]]`). Test each pattern explicitly.

```typescript
// Bad: Only testing a single hardcoded dynamic route
test('product page', async ({ page }) => {
  await page.goto('/products/abc123');
  await expect(page.locator('.product')).toBeVisible();
});

// Good: Test multiple dynamic route variations with parameterized tests
const dynamicRoutes = [
  { path: '/products/widget-a', heading: 'Widget A' },
  { path: '/products/gadget-b', heading: 'Gadget B' },
  { path: '/blog/2024/01/hello-world', heading: 'Hello World' }, // catch-all
  { path: '/docs', heading: 'Documentation' }, // optional catch-all base
  { path: '/docs/getting-started/install', heading: 'Installation' }, // optional catch-all nested
];

for (const route of dynamicRoutes) {
  test(`dynamic route: ${route.path}`, async ({ page }) => {
    await page.goto(route.path);
    await expect(page.getByRole('heading', { level: 1 })).toHaveText(route.heading);
  });
}
```

### Key Points

- Test multiple values for each dynamic segment, not just one.
- Test catch-all routes with varying depth (1 segment, 2 segments, etc.).
- Verify 404 behavior for invalid dynamic segments.

## Loading UI Testing

The `loading.tsx` file in the App Router provides an instant loading state while the route segment content loads. Verify it appears during slow data fetches and disappears once content arrives.

**Detect:** `loading.tsx` file in any `app/` route segment -- add loading UI verification tests.

```typescript
// Bad: No loading state test at all
test('page loads', async ({ page }) => {
  await page.goto('/dashboard');
  await expect(page.getByText('Dashboard')).toBeVisible();
});

// Good: Explicitly verify loading UI appears and then resolves
test('shows loading skeleton then content', async ({ page }) => {
  // Slow down the API to ensure loading state is visible
  await page.route('**/api/dashboard-data', async (route) => {
    await new Promise((resolve) => setTimeout(resolve, 1000));
    await route.continue();
  });

  await page.goto('/dashboard');

  // Verify loading UI appears
  await expect(page.getByTestId('dashboard-skeleton')).toBeVisible();

  // Verify loading UI disappears and real content appears
  await expect(page.getByTestId('dashboard-skeleton')).not.toBeVisible({ timeout: 5000 });
  await expect(page.getByRole('heading', { name: 'Dashboard' })).toBeVisible();
});
```

### Key Points

- Use `page.route()` to intercept and delay API responses, forcing the loading state to be visible.
- Assert loading UI is visible before content arrives.
- Assert loading UI disappears and content renders after data resolves.

## Error UI Testing

The `error.tsx` file provides an error boundary for a route segment. Trigger an error condition and verify the error UI renders correctly, including any retry functionality.

**Detect:** `error.tsx` file in any `app/` route segment -- add error boundary verification tests.

```typescript
// Bad: No error state testing
test('page works', async ({ page }) => {
  await page.goto('/dashboard');
  await expect(page.getByText('Dashboard')).toBeVisible();
});

// Good: Trigger error and verify error boundary
test('shows error boundary on server error', async ({ page }) => {
  // Intercept the data request and return an error
  await page.route('**/api/dashboard-data', (route) =>
    route.fulfill({ status: 500, body: 'Internal Server Error' })
  );

  await page.goto('/dashboard');

  // Verify error UI renders
  await expect(page.getByRole('heading', { name: /something went wrong/i })).toBeVisible();

  // Verify retry button works
  await page.route('**/api/dashboard-data', (route) => route.continue()); // Remove error mock
  await page.getByRole('button', { name: /try again/i }).click();
  await expect(page.getByRole('heading', { name: 'Dashboard' })).toBeVisible();
});
```

## Not Found Testing

The `not-found.tsx` file renders when `notFound()` is called or when a route does not exist. Verify both explicit not-found triggers and invalid URLs.

**Detect:** `not-found.tsx` file in `app/` directory -- add 404 verification tests.

```typescript
test('shows 404 page for invalid route', async ({ page }) => {
  const response = await page.goto('/this-route-does-not-exist');
  expect(response?.status()).toBe(404);
  await expect(page.getByRole('heading', { name: /not found/i })).toBeVisible();
  await expect(page.getByRole('link', { name: /go home/i })).toBeVisible();
});

test('shows 404 for invalid dynamic segment', async ({ page }) => {
  const response = await page.goto('/products/nonexistent-id-xyz');
  expect(response?.status()).toBe(404);
  await expect(page.getByText(/product not found/i)).toBeVisible();
});
```

## Middleware Redirect Testing

Next.js middleware (`middleware.ts`) can redirect, rewrite, or modify requests. Test that redirects happen correctly and that protected routes enforce authentication.

**Detect:** `middleware.ts` or `middleware.js` in project root -- add middleware redirect tests.

```typescript
// Bad: Only checking that the final page renders, ignoring redirect behavior
test('protected page', async ({ page }) => {
  await page.goto('/dashboard');
  await expect(page.getByText('Login')).toBeVisible(); // How did we get here?
});

// Good: Verify redirect status and destination explicitly
test('middleware redirects unauthenticated user to login', async ({ page }) => {
  // Navigate without authentication
  const response = await page.goto('/dashboard');

  // Verify redirect happened
  expect(page.url()).toContain('/login');
  expect(response?.request().redirectedFrom()?.url()).toContain('/dashboard');

  // Verify return URL is preserved
  expect(page.url()).toContain('callbackUrl=%2Fdashboard');
});

test('middleware allows authenticated user', async ({ page, context }) => {
  // Set authentication cookie
  await context.addCookies([{
    name: 'session-token',
    value: 'valid-session-token',
    domain: 'localhost',
    path: '/',
  }]);

  await page.goto('/dashboard');
  expect(page.url()).toContain('/dashboard'); // No redirect
  await expect(page.getByRole('heading', { name: 'Dashboard' })).toBeVisible();
});
```

## Authentication Flow Testing

Test the complete authentication lifecycle including login, session persistence, and logout.

```typescript
// Setup: Create an auth fixture for reuse
import { test as base } from '@playwright/test';

type AuthFixtures = {
  authenticatedPage: Page;
};

export const test = base.extend<AuthFixtures>({
  authenticatedPage: async ({ page, context }, use) => {
    await page.goto('/login');
    await page.getByLabel('Email').fill('test@example.com');
    await page.getByLabel('Password').fill('password123');
    await page.getByRole('button', { name: 'Sign in' }).click();
    await expect(page).toHaveURL('/dashboard');

    // Save storage state for reuse
    await context.storageState({ path: './tests/.auth/user.json' });
    await use(page);
  },
});

// Use in tests
test('authenticated user sees profile', async ({ authenticatedPage: page }) => {
  await page.goto('/profile');
  await expect(page.getByText('test@example.com')).toBeVisible();
});

test('logout clears session', async ({ authenticatedPage: page }) => {
  await page.getByRole('button', { name: 'Logout' }).click();
  await expect(page).toHaveURL('/login');

  // Verify session is cleared
  await page.goto('/dashboard');
  expect(page.url()).toContain('/login');
});
```

## ISR/SSG Cache Behavior

Incremental Static Regeneration (ISR) and Static Site Generation (SSG) cache pages at build time. Test that initial content is correct and that revalidation updates stale content.

**Detect:** `revalidate` export or `fetch` with `next: { revalidate }` in page/layout files -- add ISR cache tests.

```typescript
test('ISR page shows cached content then revalidates', async ({ page, request }) => {
  // First visit: get initial cached content
  await page.goto('/blog/cached-post');
  const initialContent = await page.getByTestId('post-content').textContent();
  expect(initialContent).toBeTruthy();

  // Trigger revalidation via API route (or on-demand revalidation)
  await request.post('/api/revalidate', {
    data: { path: '/blog/cached-post', secret: process.env.REVALIDATION_SECRET },
  });

  // Second visit: content should be updated after revalidation
  await page.goto('/blog/cached-post');
  await expect(page.getByTestId('post-content')).toBeVisible();
});

test('static page returns correct cache headers', async ({ request }) => {
  const response = await request.get('/about');
  const cacheControl = response.headers()['cache-control'];
  expect(cacheControl).toContain('s-maxage');
});
```

## App Router Layout Persistence

Layouts in the App Router persist across navigations within the same segment. Verify that shared layouts do not re-render when navigating between child routes.

```typescript
test('layout persists across child route navigation', async ({ page }) => {
  await page.goto('/dashboard/overview');

  // Mark the layout with a unique identifier to track re-renders
  const layoutElement = page.getByTestId('dashboard-layout');
  await expect(layoutElement).toBeVisible();

  // Navigate to sibling route within the same layout
  await page.getByRole('link', { name: 'Settings' }).click();
  await expect(page).toHaveURL('/dashboard/settings');

  // Layout should still be visible (no flash/re-mount)
  await expect(layoutElement).toBeVisible();
  await expect(page.getByRole('heading', { name: 'Settings' })).toBeVisible();
});
```

## Route Group Testing

Route groups `(group)` organize routes without affecting the URL structure. Verify that grouped routes render with the correct layout.

```typescript
test('route group applies correct layout', async ({ page }) => {
  // (marketing) group layout
  await page.goto('/about');
  await expect(page.getByTestId('marketing-layout')).toBeVisible();
  await expect(page.getByTestId('app-layout')).not.toBeVisible();

  // (app) group layout
  await page.goto('/dashboard');
  await expect(page.getByTestId('app-layout')).toBeVisible();
  await expect(page.getByTestId('marketing-layout')).not.toBeVisible();
});
```

## Parallel Route Testing

Parallel routes (`@slot`) render multiple pages in the same layout simultaneously. Verify that each slot renders the correct content.

```typescript
test('parallel routes render correct slot content', async ({ page }) => {
  await page.goto('/dashboard');

  // Verify @analytics slot
  await expect(page.getByTestId('analytics-slot')).toBeVisible();
  await expect(page.getByText('Page Views')).toBeVisible();

  // Verify @notifications slot
  await expect(page.getByTestId('notifications-slot')).toBeVisible();
  await expect(page.getByText('Recent Notifications')).toBeVisible();
});

test('parallel route default.tsx renders on unmatched navigation', async ({ page }) => {
  await page.goto('/dashboard');
  await page.getByRole('link', { name: 'Deep Page' }).click();

  // Slots without a matching route should show their default.tsx content
  await expect(page.getByTestId('analytics-slot')).toBeVisible();
  await expect(page.getByText('Default Analytics View')).toBeVisible();
});
```

## webServer Configuration

Configure Playwright to automatically start the Next.js dev or production server before running tests.

```typescript
// Bad: Hardcoded port, manual server start required
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  use: {
    baseURL: 'http://localhost:3000', // What if port 3000 is taken?
  },
  // No webServer -- tests fail if server isn't running
});

// Good: webServer auto-start with build for production-like testing
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  webServer: {
    command: 'npm run build && npm run start',
    url: 'http://localhost:3000',
    reuseExistingServer: !process.env.CI,
    timeout: 120_000,
    env: {
      NODE_ENV: 'test',
      DATABASE_URL: process.env.TEST_DATABASE_URL ?? '',
    },
  },
  use: {
    baseURL: 'http://localhost:3000',
  },
});
```

### Development vs Production Server

```typescript
// For faster iteration during development
// playwright.config.ts
export default defineConfig({
  webServer: {
    command: process.env.CI
      ? 'npm run build && npm run start'  // Production build in CI
      : 'npm run dev',                     // Dev server locally
    url: 'http://localhost:3000',
    reuseExistingServer: !process.env.CI,
    timeout: process.env.CI ? 120_000 : 60_000,
  },
});
```

## Auto-Detection Rules

```
Detect: `next.config.mjs` or `next.config.js` or `next.config.ts` in project root
  --> Apply all Next.js E2E testing patterns automatically.

Detect: `app/` directory exists
  --> Use App Router patterns (layouts, loading.tsx, error.tsx, route groups, parallel routes).

Detect: `pages/` directory exists
  --> Use Pages Router patterns (getServerSideProps, getStaticProps, _app.tsx, _document.tsx).

Detect: `middleware.ts` or `middleware.js` in project root
  --> Add middleware redirect/rewrite tests.

Detect: `loading.tsx` in any route segment
  --> Add loading UI verification test for that segment.

Detect: `error.tsx` in any route segment
  --> Add error boundary test for that segment.

Detect: `not-found.tsx` in `app/` directory
  --> Add 404 verification tests.

Detect: "use server" directive in any file
  --> Add Server Action form submission tests.

Detect: `revalidate` or `next: { revalidate }` in page/layout files
  --> Add ISR cache behavior tests.
```

## Quick Reference

| Pattern | Test Strategy | Key Assertion |
|---|---|---|
| Server Component | Assert rendered DOM content immediately | `toBeVisible()`, `toHaveText()` |
| Server Action | Submit form, verify result/redirect | `toHaveURL()`, content visible |
| Dynamic Route `[slug]` | Parameterized tests with multiple values | Correct heading per slug |
| Catch-All `[...params]` | Test varying depth segments | Content matches path depth |
| Loading UI `loading.tsx` | Intercept + delay API, verify skeleton | Skeleton visible then hidden |
| Error UI `error.tsx` | Intercept API with 500, verify boundary | Error heading, retry button |
| Not Found `not-found.tsx` | Navigate to invalid route | 404 status, not-found content |
| Middleware Redirect | Navigate unauthenticated, check redirect | URL contains `/login` |
| Auth Flow | Login via form, verify session persistence | `storageState` reuse |
| ISR/SSG | Verify cached content, trigger revalidation | Cache headers, updated content |
| Layout Persistence | Navigate between siblings, verify layout | Layout element stays visible |
| Route Groups `(group)` | Verify correct layout per group | Group-specific layout visible |
| Parallel Routes `@slot` | Verify each slot renders content | Slot test IDs visible |
| webServer Config | Auto-start server in `playwright.config.ts` | `reuseExistingServer: !CI` |
