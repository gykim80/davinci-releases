# da:create Verification Pipeline

## Overview

Playwright 기반 E2E 검증 절차. da:create 세션에서 생성된 HTML 아티팩트를
브라우저에서 렌더링하고 품질 기준을 자동 검사한다.

## Pass Criteria

| # | 항목 | 기준 | 중요도 |
|---|------|------|--------|
| 1 | Console Errors | 0개 (warning 제외) | CRITICAL |
| 2 | Blank Screen | document.body.children.length > 0 | CRITICAL |
| 3 | Screen Labels | data-screen-label 1개 이상 존재 | HIGH |
| 4 | Mobile Scroll | 375px 뷰포트에서 가로 스크롤 없음 | HIGH |
| 5 | Image Load | 깨진 이미지 0개 | MEDIUM |
| 6 | Contrast | WCAG AA 기준 텍스트 대비 | MEDIUM |

## Verification Procedure

### Step 1: Console Error Collection

```typescript
const errors: string[] = [];
page.on("console", (msg) => {
  if (msg.type() === "error") errors.push(msg.text());
});
page.on("pageerror", (err) => errors.push(err.message));
```

### Step 2: Page Load & Screenshot

```typescript
await page.setContent(htmlSource, { waitUntil: "networkidle" });
const screenshot = await page.screenshot({ fullPage: true });
```

### Step 3: DOM Validation

```typescript
// Blank screen check
const childCount = await page.evaluate(
  () => document.body.children.length
);
assert(childCount > 0, "Page must not be blank");

// Screen label check
const labels = await page.$$eval(
  "[data-screen-label]",
  (els) => els.map((e) => e.getAttribute("data-screen-label"))
);
assert(labels.length > 0, "At least one data-screen-label required");
```

### Step 4: Mobile Horizontal Scroll Check

```typescript
await page.setViewportSize({ width: 375, height: 812 });
await page.setContent(htmlSource, { waitUntil: "networkidle" });

const hasHScroll = await page.evaluate(() => {
  return document.documentElement.scrollWidth > document.documentElement.clientWidth;
});
assert(!hasHScroll, "No horizontal scroll on mobile viewport (375px)");
```

### Step 5: Broken Image Detection

```typescript
const brokenImages = await page.$$eval("img", (imgs) =>
  imgs
    .filter((img) => !img.complete || img.naturalWidth === 0)
    .map((img) => img.src)
);
assert(brokenImages.length === 0, `Broken images: ${brokenImages.join(", ")}`);
```

## Result Format

```json
{
  "pass": true,
  "checks": {
    "consoleErrors": { "pass": true, "count": 0 },
    "blankScreen": { "pass": true },
    "screenLabels": { "pass": true, "count": 3 },
    "mobileScroll": { "pass": true },
    "brokenImages": { "pass": true, "count": 0 }
  },
  "screenshot": "base64...",
  "timestamp": 1713800000000
}
```

## Integration with da:create Pipeline

1. da:create 세션에서 HTML 생성 완료
2. `extractHandoff(html)` 로 ICreateHandoff 추출
3. Playwright verification 실행 (위 절차)
4. Pass -> dev 세션으로 handoff (sync-bridge + context-bridge)
5. Fail -> 오류 리포트 + 자동 수정 제안
