# Background Effect Tone Presets

> da:effect_bg — 8 tone presets mapping Vanta effect + L5 finishing + palette + interactions

## Tone Preset Table

| Tone | Vanta Effect | L5 Finishing | L4 Mouse | L4 Scroll |
|------|-------------|-------------|----------|-----------|
| dark | halo | grain + vignette + glow | parallax | fade |
| neon | net | glow + scanlines | follower-glow | — |
| minimal | ripple | — | — | fade |
| organic | waves | grain | — | parallax |
| luxury | clouds | grain + vignette | parallax | — |
| corporate | dots | — | — | fade |
| playful | birds | — | parallax | — |
| cyber | rings | glow + scanlines | parallax | — |

## Detailed Presets

### dark
```yaml
vanta:
  effect: halo
  options:
    baseColor: 0x001a59
    color2: 0xf2e735
    backgroundColor: 0x131a43
    size: 1.5
    speed: 1.0
palette:
  bg: "#0a0a1a"
  primary: "#7c3aed"
  accent: "#f2e735"
finishing:
  - grain: { opacity: 0.4 }
  - vignette: { intensity: 0.6 }
  - glow: { color: "rgba(124,58,237,0.15)" }
interaction:
  mouse: parallax
  mouseStrength: 0.02
  scroll: fade
  scrollRange: [0, 400]
```

### neon
```yaml
vanta:
  effect: net
  options:
    color: 0xff3f81
    backgroundColor: 0x23153c
    points: 10
    maxDistance: 23
    spacing: 18
palette:
  bg: "#0a001a"
  primary: "#00ffff"
  accent: "#ff3f81"
finishing:
  - glow: { color: "rgba(0,255,255,0.2)" }
  - scanlines: { opacity: 0.05 }
interaction:
  mouse: glow
  scroll: null
```

### minimal
```yaml
vanta:
  effect: ripple
  options:
    color1: 0x60b25
    color2: 0xffffff
    ringFactor: 4.0
    backgroundColor: 0x000000
palette:
  bg: "#000000"
  primary: "#3b82f6"
  accent: "#e5e7eb"
finishing: []
interaction:
  mouse: null
  scroll: fade
  scrollRange: [0, 300]
```

### organic
```yaml
vanta:
  effect: waves
  options:
    color: 0x005588
    waveHeight: 15
    waveSpeed: 0.8
    shininess: 30
palette:
  bg: "#1a2e0a"
  primary: "#8fbc8f"
  accent: "#daa520"
finishing:
  - grain: { opacity: 0.3 }
interaction:
  mouse: null
  scroll: parallax
  scrollSpeed: 0.5
```

### luxury
```yaml
vanta:
  effect: clouds
  options:
    skyColor: 0x1a1a2e
    cloudColor: 0x2d2d4e
    sunColor: 0xd4af37
    speed: 0.8
palette:
  bg: "#0d0d0d"
  primary: "#d4af37"
  accent: "#f5f5dc"
finishing:
  - grain: { opacity: 0.25 }
  - vignette: { intensity: 0.7 }
interaction:
  mouse: parallax
  mouseStrength: 0.015
  scroll: null
```

### corporate
```yaml
vanta:
  effect: dots
  options:
    color: 0x3b82f6
    backgroundColor: 0xf8f9fa
    spacing: 35
    size: 2
palette:
  bg: "#f8f9fa"
  primary: "#3b82f6"
  accent: "#1e40af"
finishing: []
interaction:
  mouse: null
  scroll: fade
  scrollRange: [0, 350]
```

### playful
```yaml
vanta:
  effect: birds
  options:
    color1: 0xff6b6b
    color2: 0x00d1ff
    backgroundColor: 0x1a1a2e
    birdSize: 1.2
    quantity: 4
    speedLimit: 5
palette:
  bg: "#1a1a2e"
  primary: "#ff6b6b"
  accent: "#00d1ff"
finishing: []
interaction:
  mouse: parallax
  mouseStrength: 0.025
  scroll: null
```

### cyber
```yaml
vanta:
  effect: rings
  options:
    backgroundColor: 0x001100
    color: 0x00ff41
    speed: 1.2
palette:
  bg: "#001100"
  primary: "#00ff41"
  accent: "#88ff00"
finishing:
  - glow: { color: "rgba(0,255,65,0.15)" }
  - scanlines: { opacity: 0.06 }
interaction:
  mouse: parallax
  mouseStrength: 0.02
  scroll: null
```

## CSS Gradient Fallbacks (per tone)

Used when WebGL fails or `prefers-reduced-motion: reduce` is active.

| Tone | CSS Gradient |
|------|-------------|
| dark | `linear-gradient(135deg, #0a0a1a 0%, #1a1a2e 50%, #131a43 100%)` |
| neon | `linear-gradient(135deg, #0a001a 0%, #23153c 50%, #1a0033 100%)` |
| minimal | `linear-gradient(135deg, #000000 0%, #111111 100%)` |
| organic | `linear-gradient(135deg, #1a2e0a 0%, #0a3d2e 50%, #1a3a1a 100%)` |
| luxury | `linear-gradient(135deg, #0d0d0d 0%, #1a1a2e 50%, #2d2d4e 100%)` |
| corporate | `linear-gradient(135deg, #f8f9fa 0%, #e9ecef 50%, #dee2e6 100%)` |
| playful | `linear-gradient(135deg, #1a1a2e 0%, #2d1b4e 50%, #1a2e3e 100%)` |
| cyber | `linear-gradient(135deg, #001100 0%, #002200 50%, #001a00 100%)` |
