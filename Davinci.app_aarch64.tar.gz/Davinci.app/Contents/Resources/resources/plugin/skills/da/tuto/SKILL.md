---
name: tuto
description: "Use when creating YouTube tutorial videos from a topic, generating narration, cutscenes, and code demos automatically"
category: utility
complexity: advanced
thinking: ultra
mcp-servers: [context7, codegraph, tavily, playwright]
personas:
  # Core
  - tuto-producer
  # Support
  - video-creator
  - asset-gen-artist
  # Meta
  - pm-agent
  - self-review
modes: [orchestration, token-efficiency]
allowed-tools: [Read, Write, Edit, Bash, Grep, Glob, Task, Agent, WebSearch, WebFetch]
user-invocable: true
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 생성자: 자기 검증은 사전 점검일 뿐이다. 최종 판정은 독립 verify 노드가 낸다. 미완료 시 partial + remaining.

## Tool Parameter Rules → See CLAUDE.md (ABSOLUTE)

# /da:tuto v3.0 — AI Tutorial Video Generator (Ensemble Reality)

ultrathink

> Enter a single topic to fully auto-generate a YouTube tutorial video.
> v2.0: Audio-First Duration + real screen capture + Remotion native terminal
> v3.0: Ensemble Reality — Generated(AI) + Captured(Real) + Animated(Remotion) auto-ensemble

## Iron Law

**NEVER SKIP RESEARCH PHASE.** Never generate scenarios without sufficient research on the topic.
**AUDIO-FIRST DURATION.** All scene durationInFrames are derived from actual audio/recording file length. Never render with estimate values.
**SYNC GATE MANDATORY.** Cannot enter Phase 5 Assembly without passing Phase 4 Step_5 Duration Sync.
**REUSE EXISTING COMPONENTS.** `tuto-workspace/remotion/` already has 18 completed scene components + shared components + themes + fonts. Never create from scratch. Copy existing src/ during Workspace Init and only create new components when additional ones are needed.
**ENSEMBLE REALITY.** Target 30-50% real capture scene ratio for hands-on topics. Never fill entirely with AI images. Use Reality Score to automatically determine visual source per scene.

---

## Pipeline Overview

```
RESEARCH → SCENARIO (+ Reality Score) → CAPTURE PLAN → ASSET GEN (TTS‖Image‖Code‖Capture‖Install) → CAPTION + SYNC GATE → ASSEMBLY (+ Ensemble) → RENDER
```

### v3.0 Change Summary — Ensemble Reality
- **Reality Score**: Auto-calculate per-scene "real capture necessity" (0.0~1.0) → auto-determine visual source
- **Install Capture Pipeline**: Record actual npm install/pip install process via ttyd + Playwright
- **Smart Scene Type Promotion**: Auto-promote explanation/cutscene with Reality Score >= 0.7 → install-capture/browser-demo
- **Phase 2.5 Capture Planning**: Capture inventory + tool check + pre-generate scripts
- **Ensemble Mixer Layouts**: pip-capture, split-real-diagram, zoom-transition, before-after compositing
- **New scene type**: `install-capture` (ttyd + Playwright real installation process recording)
- **Capture ratio target**: 30-50% real capture scenes for hands-on topics

### v2.0 Change Summary (Preserved)
- **Audio-First Duration**: Finalize all scene durations based on ffprobe measurements (no estimates allowed)
- **SYNC GATE**: Phase 4 Step_5 is a mandatory verification gate (blocks Assembly entry on failure)
- **Scene types**: `live-demo` (Playwright browser recording), `terminal-demo` (Remotion native terminal)
- **Layout prop**: `layout: "full" | "split" | "pip"` applicable to all scenes
- **calculateMetadata**: Composition dynamic duration (parseMedia + slowDurationInSeconds)

## Usage
```
/da:tuto "Building a Claude MCP Server"
/da:tuto "React 19 New Features Complete Guide" --duration 15
/da:tuto "Three.js Introduction" --style dark --shorts-only
```

---

## ★ FIRST ACTION: Workspace Init

```yaml
Step_1_Workspace:
  Bash: |
    PROJECT_ID="tuto-$(date +%Y%m%d-%H%M%S)"
    WORKSPACE="tuto-workspace/$PROJECT_ID"
    mkdir -p "$WORKSPACE"/{remotion/public/{audio,images,captions,recordings,code},output}
    echo "$PROJECT_ID" > "$WORKSPACE/.project-id"
    echo "Workspace: $WORKSPACE"

Step_2_Reuse_Components:
  # ★ Iron Law: REUSE EXISTING COMPONENTS ★
  # tuto-workspace/remotion/ contains a completed V1 Remotion project.
  # 17 scene components + shared components + themes + fonts + types + pipeline scripts.
  # Never create from scratch; copy existing src/ to new workspace.
  BASE_REMOTION: "tuto-workspace/remotion"
  Bash: |
    BASE="tuto-workspace/remotion"
    if [ -d "$BASE/src" ]; then
      # Copy source code (scenes, components, styles, types, compositions)
      cp -R "$BASE/src" "$WORKSPACE/remotion/src"
      # Copy package.json + config
      cp "$BASE/package.json" "$WORKSPACE/remotion/package.json"
      cp "$BASE/tsconfig.json" "$WORKSPACE/remotion/tsconfig.json" 2>/dev/null
      cp "$BASE/remotion.config.ts" "$WORKSPACE/remotion/remotion.config.ts" 2>/dev/null
      # Symlink node_modules (avoid reinstallation)
      ln -s "$(cd "$BASE" && pwd)/node_modules" "$WORKSPACE/remotion/node_modules" 2>/dev/null || \
        (cd "$WORKSPACE/remotion" && npm install)
      echo "V1 component reuse complete ($(ls $WORKSPACE/remotion/src/scenes/*.tsx 2>/dev/null | wc -l) scenes)"
    else
      echo "ERROR: V1 components not found — if first run, build tuto-workspace/remotion/ first"
      exit 1
    fi
  Available_Scenes: |
    18 reusable scene components (v3.0: +1 install-capture):
    TitleScene, ExplanationScene, CodeDemoScene, CutsceneScene,
    TerminalScene, TransitionScene, SummaryScene, OutroScene,
    NewsScene, QuizScene, ComparisonScene, StatsScene,
    TimelineScene, ImageShowcaseScene, QuoteScene, DiagramScene,
    BrowserDemoScene, InstallCaptureScene (v3.0 new)
  Available_Shared: |
    Shared components: BoldBackground, CaptionOverlay, ProgressBar
    Theme: theme.ts (Premium light / emerald accent)
    Fonts: fonts.ts (Paperlogy, S-Core Dream, D2Coding)
    Types: scenario.ts (18 scene types)

Step_3_Copy_Channel_Assets:
  # ★ Copy channel branding assets to workspace
  # Source: ~/Desktop/andrew/tuto/assets/ (channel-exclusive assets — profile, expressions, poses, branding, video templates)
  ASSET_BASE: "~/Desktop/andrew/tuto/assets"
  Bash: |
    ASSETS="$HOME/Desktop/andrew/tuto/assets"
    PUB="$WORKSPACE/remotion/public"
    if [ -d "$ASSETS" ]; then
      # Profile + reference
      mkdir -p "$PUB/presenter"
      cp "$ASSETS/profile-new.jpg" "$PUB/presenter/profile.jpg"
      cp "$ASSETS/reference.jpg" "$PUB/presenter/reference.jpg"

      # 12 expressions (auto-selected based on narration context)
      mkdir -p "$PUB/presenter/expressions"
      cp "$ASSETS"/expr-*.jpg "$PUB/presenter/expressions/"

      # 10 poses (auto-selected based on scene type)
      mkdir -p "$PUB/presenter/poses"
      cp "$ASSETS"/pose-*.jpg "$PUB/presenter/poses/"

      # Branding (watermark, banner)
      mkdir -p "$PUB/branding"
      cp "$ASSETS/branding/watermark-150.jpg" "$PUB/branding/watermark.jpg"
      cp "$ASSETS/branding/banner-2560x1440.jpg" "$PUB/branding/banner.jpg" 2>/dev/null

      # Video templates (intro/outro/lower-third/end-screen)
      mkdir -p "$PUB/templates"
      cp "$ASSETS"/video/*.jpg "$PUB/templates/"

      # 8 thumbnail templates
      mkdir -p "$PUB/thumbnails"
      cp "$ASSETS"/thumbnails/templates/*.jpg "$PUB/thumbnails/"

      echo "Channel asset copy complete"
      echo "  - Expressions: $(ls $PUB/presenter/expressions/ | wc -l) types"
      echo "  - Poses: $(ls $PUB/presenter/poses/ | wc -l) types"
      echo "  - Watermark: $(ls $PUB/branding/watermark.jpg 2>/dev/null && echo 'OK' || echo 'MISSING')"
      echo "  - Video templates: $(ls $PUB/templates/ | wc -l) types"
      echo "  - Thumbnail templates: $(ls $PUB/thumbnails/ | wc -l) types"
    else
      echo "WARNING: Channel assets not found ($ASSETS) — proceeding without profile/watermark"
    fi

  Asset_Registry: |
    # Asset auto-selection map (referenced during Phase 2 scenario generation)
    expressions:
      surprised:   expr-01-surprised.jpg    # Surprising facts, "Is this possible?"
      excited:     expr-02-excited.jpg      # Interesting features, "This is amazing!"
      thinking:    expr-03-thinking.jpg     # Pondering, "How do we do this..."
      confident:   expr-04-confident.jpg    # Certainty, "Here's how to do it"
      frustrated:  expr-05-frustrated.jpg   # Problem situation, "We're getting an error"
      eureka:      expr-06-eureka.jpg       # Solution found, "This is it!"
      pointing:    expr-07-pointing.jpg     # Emphasis, "Pay attention to this part"
      smile:       expr-08-smile.jpg        # Greeting, wrap-up
      serious:     expr-09-serious.jpg      # Important explanation, cautions
      celebrating: expr-10-celebrating.jpg  # Completion, "Congratulations!"
      waving:      expr-11-waving.jpg       # Greeting (intro/outro)
      secret:      expr-12-secret.jpg       # Tips, "Here's a secret..."

    poses:
      coding:      pose-01-coding.jpg       # Code demo, terminal scenes
      whiteboard:  pose-02-whiteboard.jpg   # Concept explanation, diagrams
      point-left:  pose-03-point-left.jpg   # Pointing to left content
      point-right: pose-04-point-right.jpg  # Pointing to right content
      amazed:      pose-05-amazed.jpg       # Amazement, performance metrics
      arms-crossed: pose-06-arms-crossed.jpg # Comparison, judgment
      thumbsup:    pose-07-thumbsup.jpg     # Recommendation, conclusion
      chinrest:    pose-08-chinrest.jpg     # Analysis, deep thinking
      welcome:     pose-09-welcome.jpg      # Intro, welcome
      peace:       pose-10-peace.jpg        # Outro, farewell

    scene_type_to_pose:
      title:          welcome | waving
      explanation:    whiteboard | point-left | point-right
      code-demo:      coding
      cutscene:       thinking | confident
      news:           serious | surprised
      quiz:           thinking | pointing
      comparison:     arms-crossed | chinrest
      stats:          amazed | excited
      timeline:       whiteboard | pointing
      summary:        thumbsup | confident
      outro:          peace | waving | celebrating
      terminal-demo:  coding
      diagram:        whiteboard | pointing
      image-showcase: point-left | amazed

    narration_keyword_to_expression:
      "놀랍(amazing)": surprised
      "대박|신기(awesome|fascinating)": excited
      "고민|어려(worried|difficult)": thinking
      "확실|당연(certain|obvious)": confident
      "에러|오류|문제(error|bug|problem)": frustrated
      "해결|정답(solved|answer)": eureka
      "주목|중요(attention|important)": pointing
      "감사|반갑(thanks|pleased)": smile
      "주의|조심|필수(caution|careful|required)": serious
      "완성|성공|축하(complete|success|congrats)": celebrating
      "안녕|여러분(hello|everyone)": waving
      "팁|비밀|꿀팁(tip|secret|pro-tip)": secret

Step_4_ENV_Check:
  Bash: |
    # TTS API Key check
    [ -n "$OPENAI_API_KEY" ] && echo "OPENAI_KEY_OK" || echo "OPENAI_KEY_MISSING"
    # Gemini API Key check
    [ -n "$GEMINI_IMAGE_API_KEY" ] && echo "GEMINI_KEY_OK" || echo "GEMINI_KEY_MISSING"
    # Whisper check
    which whisper_cpp 2>/dev/null || npx @remotion/install-whisper-cpp@latest 2>/dev/null
    echo "ENV_CHECK_DONE"

Step_5_Customization:
  # Modify only when per-project customization is needed
  # Replace only scenario data in Root.tsx while preserving existing component structure
  Condition: Only when new scene types not coverable by existing scene types are needed
  Action: Add new scene components to src/scenes/ and add case to TutoMain.tsx renderScene()
```

---

## Phase 1: RESEARCH (Web Research + Source Collection)

```yaml
Goal: Collect latest information, key concepts, and code examples on the topic from 5+ sources
Duration: ~3min
Output: research_data.json

Step_1_Web_Search:
  # Execute at least 5 queries via Tavily MCP
  Queries:
    - "{topic} overview explanation 2025"
    - "{topic} key concepts principles"
    - "{topic} code examples tutorial"
    - "{topic} latest news updates"
    - "{topic} pros cons comparison analysis"
  Tool: mcp__tavily-search__tavily_search (search_depth: advanced)

Step_2_Source_Extraction:
  # Extract useful URLs from search results → detailed content extraction
  Tool: mcp__tavily-search__tavily_extract
  Criteria: Prioritize official docs, tech blogs, GitHub

Step_3_Local_Docs:
  # Parse if user specified local documents
  Condition: When args contain --docs or local file paths
  Tool: Read (*.md, *.txt) / Bash (docx conversion)

Step_4_Knowledge_Synthesis:
  # Collected data → structured JSON storage
  Output: "{workspace}/research_data.json"
  Schema: |
    {
      "topic": "string",
      "query_count": number,
      "sources": [
        {
          "url": "string",
          "title": "string",
          "key_points": ["string"],
          "code_snippets": ["string"],
          "credibility": "high|medium|low"
        }
      ],
      "key_concepts": ["string"],
      "code_examples": [{"language": "string", "code": "string", "description": "string"}],
      "latest_news": [{"headline": "string", "date": "string", "source": "string"}],
      "keywords": ["string"],
      "estimated_scenes": number
    }

Validation:
  - sources.length >= 5 (additional queries if insufficient)
  - key_concepts.length >= 3
  - code_examples.length >= 2 for code-related topics
```

---

## Phase 2: SCENARIO (Scenario JSON Generation)

```yaml
Goal: Research data → generate structured scenario JSON with 20+ scenes
Duration: ~2min
Input: research_data.json
Output: scenario.json

Step_1_Scenario_Generation:
  # LLM generates scenario based on research data
  Prompt_Template: |
    Generate a YouTube educational tutorial scenario based on the following research data.

    ## Rules
    - Scene types (18 types, all implemented in Component Library):
      Basic: title, explanation, code-demo, cutscene, news, transition, summary, outro
      v2.0: live-demo (Playwright recording), terminal-demo (Remotion native)
      Extended: quiz (A/B quiz), comparison (VS comparison), stats (statistics counter),
            timeline (step-by-step progress), image-showcase (image emphasis),
            quote (quotation), diagram (flowchart), browser-demo (recorded video embed)
      v3.0: install-capture (ttyd + Playwright real installation process recording)
    - Minimum 20 scenes, mixed types (explanation/code-demo as core, quiz/comparison for viewer engagement)
    - Narration text per scene (Korean, instructor tone)
    - Include working code in code-demo scenes
    - imagePrompt in cutscene scenes (English, for Gemini)
    - Target total length 10-20 minutes
    - ★ Actively mix 17+ scene types for varied, non-monotonous video composition

    ## Research Data
    {research_data_json}

Step_2_Schema_Validation:
  # Zod schema-based validation (refer to references/scenario-schema.md)
  Schema: |
    {
      "title": "string (video title)",
      "description": "string (video description)",
      "tags": ["string"],
      "scenes": [
        {
          "id": "scene-001",
          "type": "title|explanation|code-demo|cutscene|news|transition|summary|outro|live-demo|terminal-demo|quiz|comparison|stats|timeline|image-showcase|quote|diagram|browser-demo",
          "narration": "string (Korean narration script, within 4096 chars)",
          "duration_estimate": "number (seconds)",
          "visual": {
            "type": "cutscene|code|text|image|live-demo|terminal",
            "imagePrompt": "string (English, for Gemini — cutscene/explanation only)",
            "imageSource": "generate|search|capture|none",
            "layout": "full|split|pip",
            "code": "string (code-demo only)",
            "codeLanguage": "string (code-demo only)",
            "highlights": [number],
            "targetUrl": "string (live-demo only — Playwright recording start URL)",
            "captureSteps": [{"action":"goto|click|fill|wait|screenshot","selector":"string","value":"string","annotation":"string"}],
            "commands": [{"input":"string","expectedOutput":"string","typeDelay":80,"annotation":"string"}],
            "recordingSrc": "string (auto-generated in Phase 3E — recordings/{scene.id}.mp4)"
          },
          "presenter": {
            "expression": "string (select from expr-01~12 — auto-assigned based on narration tone)",
            "pose": "string (select from pose-01~10 — auto-assigned based on scene type)",
            "position": "left|right|none (presenter position, default: right)"
          },
          "transition": "fade|wipe|slide|none"
        }
      ],
      "metadata": {
        "estimated_duration_sec": number,
        "scene_count": number,
        "tts_char_count": number,
        "image_count": number,
        "code_demo_count": number
      }
    }

Step_3_Presenter_Auto_Assign:
  # ★ Channel asset auto-assignment — based on scene type + narration keywords
  # Reference Workspace Init Asset_Registry (scene_type_to_pose, narration_keyword_to_expression)
  Action: |
    for scene in scenario.scenes:
      # 1. Pose selection: scene type → representative pose mapping
      scene.presenter.pose = scene_type_to_pose[scene.type]  # Random pick 1 if multiple candidates

      # 2. Expression selection: narration keyword matching → corresponding expression
      for keyword, expression in narration_keyword_to_expression:
        if keyword in scene.narration:
          scene.presenter.expression = expression
          break
      if not scene.presenter.expression:
        scene.presenter.expression = "smile"  # Default

      # 3. Position decision: code/terminal scenes use none (must not obscure screen), rest use right
      if scene.type in ["code-demo", "terminal-demo", "live-demo", "browser-demo", "diagram"]:
        scene.presenter.position = "none"
      elif scene.type in ["transition"]:
        scene.presenter.position = "none"
      else:
        scene.presenter.position = "right"

  Validation:
    - All scenes (except transition): presenter.expression exists
    - All scenes (except transition): presenter.pose exists
    - Verify file exists: public/presenter/expressions/{expression}.jpg
    - Verify file exists: public/presenter/poses/{pose}.jpg

Step_3b_Reality_Score_Calculation:
  # ★ v3.0: Auto-calculate per-scene "real capture necessity"
  Reality_Score_Matrix:
    Scene_Type_Base_Score:
      live-demo: 1.0         # Always real capture
      browser-demo: 1.0      # Always real capture
      install-capture: 1.0   # Always real capture
      terminal-demo: 0.3     # Remotion native is sufficient (0.8 when real output needed)
      code-demo: 0.2         # Shiki is sufficient
      explanation: 0.3       # Default is AI image
      cutscene: 0.1          # AI image is appropriate
      image-showcase: 0.6    # Real screenshots recommended
      stats: 0.1             # Animation is sufficient
      diagram: 0.1           # Animation is sufficient
      quiz: 0.1              # Animation is sufficient
      comparison: 0.2        # Default is animation
      timeline: 0.2          # Default is animation
    Narration_Keyword_Boost:
      +0.4: ["설치(install)", "install", "실행해보(try running)", "직접(directly)", "실제로(actually)", "화면을 보시면(as you see on screen)", "결과를 보면(looking at the result)"]
      +0.3: ["npm", "pip", "brew", "cargo", "yarn", "pnpm", "apt", "docker"]
      +0.3: ["브라우저에서(in browser)", "웹에서(on web)", "사이트에(on site)", "URL", "localhost"]
      +0.2: ["터미널에서(in terminal)", "커맨드(command)", "명령어를 입력(enter command)", "실행하면(when running)"]
      +0.2: ["에러가(error)", "오류가(bug)", "디버깅(debugging)", "해결방법(solution)"]
      +0.1: ["보여드리(let me show)", "이렇게 나옵니다(it appears like this)", "화면처럼(like the screen)"]
  Action: |
    for scene in scenario.scenes:
      base = scene_type_base_score[scene.type]
      boost = 0
      for keywords, score in narration_keyword_boost:
        if any(kw in scene.narration for kw in keywords):
          boost += score
      scene.reality_score = min(1.0, base + boost)

      # Determine visual source
      if scene.reality_score >= 0.7:
        scene.visual.capture_required = true
        scene.visual.capture_type = determine_capture_type(scene)
      elif scene.reality_score >= 0.4:
        scene.visual.capture_recommended = true

  determine_capture_type: |
    if "브라우저(browser)" in narration or "웹(web)" in narration or "사이트(site)" in narration:
      return "browser-recording"
    elif "설치(install)" in narration or "install" in narration or "npm" in narration or "pip" in narration:
      return "install-capture"
    elif "터미널(terminal)" in narration and ("실제(actual)" in narration or "직접(directly)" in narration):
      return "terminal-recording"
    elif "결과(result)" in narration or "화면(screen)" in narration or "스크린샷(screenshot)" in narration:
      return "screenshot"
    else:
      return "browser-recording"

Step_3c_Smart_Scene_Type_Promotion:
  # ★ v3.0: Auto-upgrade scenes with Reality Score >= 0.7
  Rules:
    explanation + reality_score >= 0.7 + "설치(install)|install|npm|pip" keyword:
      → original_type = "explanation"
      → promote to: "install-capture"
      → visual.type = "install-capture"
      → Auto-generate installCommands (extract commands from narration)
      → Original narration preserved as audio overlay

    explanation + reality_score >= 0.7 + "브라우저(browser)|웹(web)|화면(screen)|사이트(site)" keyword:
      → original_type = "explanation"
      → promote to: "browser-demo"
      → Auto-generate captureSteps (targetUrl + basic navigation)

    cutscene + reality_score >= 0.7 + "결과(result)|실행(execute)|화면(screen)" keyword:
      → original_type = "cutscene"
      → promote to: "image-showcase"
      → imageSource: "capture" (Playwright screenshot)

    explanation + reality_score >= 0.5 + "코드(code)" keyword:
      → original_type = "explanation"
      → promote to: "code-demo"
      → Extract code blocks from narration → insert into visual.code

  Promotion_Log:
    Output: "{workspace}/promotion-log.json"
    Schema: |
      [{
        "scene_id": "scene-005",
        "original_type": "explanation",
        "promoted_to": "install-capture",
        "reality_score": 0.85,
        "trigger_keywords": ["설치(install)", "npm install"],
        "reason": "Installation process requires real terminal capture"
      }]

Step_4_Scene_Balance_Check:
  # Scene type distribution validation
  Rules:
    - title: exactly 1
    - outro: exactly 1
    - explanation + code-demo + install-capture: 60%+ of total
    - transition: 1 per major section change
    - summary: at least 1
    - No more than 3 consecutive scenes of the same type
    - v3.0 Reality Target: Hands-on topics → 30-50% real capture scene ratio

Step_4_Save:
  Output: "{workspace}/scenario.json"
  Backup: "{workspace}/scenario.backup.json"
```

---

## Phase 2.5: CAPTURE PLANNING (v3.0 — Pre-capture Planning)

```yaml
Goal: Establish capture plan based on Reality Score + verify required tools + pre-generate scripts
Duration: ~30s
Input: scenario.json (Reality Score calculation complete)
Output: capture-plan.json, capture-scripts/

Step_1_Capture_Inventory:
  # Classify capture target scenes based on Reality Score
  Action: |
    capture_plan = {
      browser_recordings: [],    # Playwright recordVideo
      install_captures: [],      # ttyd + Playwright (v3.0 new)
      screenshots: [],           # Playwright screenshot
      real_terminal: [],         # Real terminal recording (auxiliary)
      total_capture_scenes: 0,
      estimated_capture_time_sec: 0
    }

    for scene in scenes:
      if scene.reality_score >= 0.7 and scene.visual.capture_required:
        if scene.visual.capture_type == "browser-recording":
          capture_plan.browser_recordings.append(scene)
        elif scene.visual.capture_type == "install-capture":
          capture_plan.install_captures.append(scene)
        elif scene.visual.capture_type == "screenshot":
          capture_plan.screenshots.append(scene)
        elif scene.visual.capture_type == "terminal-recording":
          capture_plan.real_terminal.append(scene)

    capture_plan.total_capture_scenes = sum(len(v) for v in [
      capture_plan.browser_recordings, capture_plan.install_captures,
      capture_plan.screenshots, capture_plan.real_terminal
    ])

Step_2_Tool_Check:
  Bash: |
    echo "=== Capture Tool Check (v3.0) ==="
    # Playwright
    npx playwright --version 2>/dev/null && echo "PLAYWRIGHT_OK" || echo "PLAYWRIGHT_MISSING"
    # ttyd (for install-capture)
    which ttyd 2>/dev/null && echo "TTYD_OK" || echo "TTYD_MISSING"
    # ffmpeg
    which ffmpeg 2>/dev/null && echo "FFMPEG_OK" || echo "FFMPEG_MISSING"
    # ffprobe
    which ffprobe 2>/dev/null && echo "FFPROBE_OK" || echo "FFPROBE_MISSING"
  Fallback:
    PLAYWRIGHT_MISSING: npx playwright install chromium
    TTYD_MISSING:
      macOS: brew install ttyd
      Fallback: install-capture → auto-switch to terminal-demo (Remotion native)
    FFMPEG_MISSING: brew install ffmpeg

Step_3_Capture_Script_Gen:
  # Pre-generate automation scripts for each capture scene
  Action: |
    mkdir -p "{workspace}/capture-scripts"

    # browser-recording scripts
    for scene in capture_plan.browser_recordings:
      generate_playwright_script(scene)  # captureSteps → playwright test file
      → {workspace}/capture-scripts/{scene.id}-browser.ts

    # install-capture scripts (v3.0 new)
    for scene in capture_plan.install_captures:
      generate_install_script(scene)     # installCommands → ttyd + playwright script
      → {workspace}/capture-scripts/{scene.id}-install.ts

    # screenshot scripts
    for scene in capture_plan.screenshots:
      generate_screenshot_script(scene)  # targetUrl → screenshot script
      → {workspace}/capture-scripts/{scene.id}-screenshot.ts

Step_4_Estimate_Capture_Time:
  # Pre-estimate capture time
  Time_Estimates:
    browser_recording: ~30s per scene
    install_capture: ~60s per scene (including actual installation time)
    screenshot: ~10s per scene
    real_terminal: ~45s per scene
  Total: |
    estimated_time = (
      len(browser_recordings) * 30 +
      len(install_captures) * 60 +
      len(screenshots) * 10 +
      len(real_terminal) * 45
    )
    capture_plan.estimated_capture_time_sec = estimated_time

Step_5_Save:
  Output: "{workspace}/capture-plan.json"
  Report: |
    Capture plan summary:
    - Browser recordings: {N} scenes
    - Install captures: {N} scenes (ttyd + Playwright)
    - Screenshots: {N} scenes
    - Real terminal: {N} scenes
    - Estimated capture time: {estimated_time}s
    - Missing tools: {missing_tools}
```

---

## Phase 3: ASSET GENERATION (TTS + Image + Code + Capture Parallel)

```yaml
Goal: Generate TTS audio, images, code frames, and real capture assets for all scenario scenes
Duration: ~7min (parallel processing, including captures)
Input: scenario.json, capture-plan.json
Output: audio/*.mp3, images/*.png, code/*.json, recordings/*.mp4, screenshots/*.png

# ──── 3A: TTS Audio Generation ────

TTS_Config:
  Model: gpt-4o-mini-tts-2025-12-15
  Voice: cedar
  Instructions: "Speak in a calm and clear IT instructor tone. Pronounce technical terms distinctly."
  Format: mp3
  Speed: 1.0
  Max_Input: 4096 chars per request

TTS_Execution:
  for scene in scenes where scene.narration exists:
    # Split if narration exceeds 4096 chars
    chunks = split_by_sentence(scene.narration, max_chars=4096)
    for i, chunk in enumerate(chunks):
      Bash: |
        curl -s https://api.openai.com/v1/audio/speech \
          -H "Authorization: Bearer $OPENAI_API_KEY" \
          -H "Content-Type: application/json" \
          -d '{
            "model": "gpt-4o-mini-tts-2025-12-15",
            "voice": "cedar",
            "input": "{chunk_escaped}",
            "instructions": "Speak in a calm and clear IT instructor tone. Pronounce technical terms distinctly.",
            "response_format": "mp3",
            "speed": 1.0
          }' \
          --output "{workspace}/remotion/public/audio/{scene.id}.mp3"
    # If there are split chunks, ffmpeg concat
    if len(chunks) > 1:
      Bash: ffmpeg -i "concat:chunk1.mp3|chunk2.mp3" -c copy "{scene.id}.mp3"

TTS_Validation:
  - File size > 1KB (detect empty files)
  - Verify duration via ffprobe
  - Write-back duration to scenario.json (based on actual playback time)

# ──── 3B: Gemini Image Generation ────

Gemini_Config:
  Model: GEMINI_IMAGE_MODEL from .env.local (or default gemini-3-pro-image-preview)
  Key: GEMINI_IMAGE_API_KEY
  System_Instruction: |
    All generated images must follow this exact visual style:
    - Bold graphic illustration style with strong color contrasts
    - Dark gradient backgrounds (deep purple to dark blue)
    - Bright accent colors: amber, cyan, emerald
    - Clean geometric shapes, no photorealistic elements
    - Flat design with subtle depth (soft shadows, glows)
    - 16:9 aspect ratio, content centered
    - Consistent with tech/programming education aesthetic
    - No text in images (text added separately in video)

Gemini_Execution:
  for scene in scenes where scene.visual.imageSource == "generate":
    Bash: |
      MODEL=$(grep GEMINI_IMAGE_MODEL .env.local 2>/dev/null | cut -d= -f2)
      MODEL=${MODEL:-gemini-3-pro-image-preview}
      KEY=$(grep GEMINI_IMAGE_API_KEY .env.local 2>/dev/null | cut -d= -f2)
      KEY=${KEY:-$GEMINI_IMAGE_API_KEY}

      curl -s "https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent?key=${KEY}" \
        -H "Content-Type: application/json" \
        -d '{
          "systemInstruction": {"parts": [{"text": "{gemini_system_instruction}"}]},
          "contents": [{"parts": [{"text": "{scene.visual.imagePrompt}"}]}],
          "generationConfig": {"responseModalities": ["TEXT", "IMAGE"]}
        }' | python3 -c "
      import sys, json, base64
      resp = json.load(sys.stdin)
      for part in resp.get('candidates', [{}])[0].get('content', {}).get('parts', []):
          if 'inlineData' in part:
              data = base64.b64decode(part['inlineData']['data'])
              with open('{workspace}/remotion/public/images/{scene.id}.png', 'wb') as f:
                  f.write(data)
              print(f'Image saved: {scene.id}.png ({len(data)} bytes)')
              break
      "

Gemini_Validation:
  - File size > 1KB
  - Verify file extension (.png)

# ──── 3C: Web Image Collection ────

Web_Image_Execution:
  for scene in scenes where scene.visual.imageSource == "search":
    Tool: mcp__tavily-search__tavily_search (include_images=true)
    Query: scene.visual.imagePrompt
    Action: |
      Extract image URLs from search results → download via curl
      → {workspace}/remotion/public/images/{scene.id}.png

# ──── 3D: Code Frame Generation ────

Code_Frame_Execution:
  for scene in scenes where scene.type == "code-demo":
    # Generate syntax highlight data via Shiki
    Action: |
      Code → Shiki highlighter → HTML/token data
      Extract highlight line numbers
      → {workspace}/remotion/public/code/{scene.id}.json
    Schema: |
      {
        "code": "string",
        "language": "string",
        "theme": "dark-plus",
        "tokens": [[{"content":"string","color":"string"}]],
        "highlights": [number],
        "total_lines": number
      }

# ──── 3E: Real Screen Capture (v2.0 new) ────
# Refer to references/capture-config.md

Capture_Strategy:
  # Optimal approach per content type
  terminal-demo: Remotion native <TerminalSimulator> (NOT Playwright recording!)
    → Remotion component directly renders commands[] array from scenario.json
    → Pixel-perfect, frame-level deterministic timing, no conversion needed
    → Leverage remotion-bits type-writer + code-block components
  live-demo: Record browser UI via Playwright recordVideo
    → Real web app screens cannot be simulated → Playwright required
  imageSource "capture": Capture screenshots via Playwright page.screenshot()
    → Replace explanation scene images with real screen captures

Live_Demo_Capture:
  for scene in scenes where scene.visual.type == "live-demo":
    Bash: |
      # Playwright browser recording (1920x1080 WebM)
      npx playwright test --config="{workspace}/playwright.config.ts" \
        --project=recording \
        --grep "{scene.id}"
      # WebM → MP4 conversion (YouTube quality)
      ffmpeg -i "{workspace}/recordings/{scene.id}.webm" \
        -c:v libx264 -crf 18 -preset slow -movflags +faststart \
        -c:a aac -b:a 192k \
        "{workspace}/remotion/public/recordings/{scene.id}.mp4"
      # Measure recording duration via ffprobe
      RECORDING_DUR=$(ffprobe -v quiet -show_entries format=duration \
        -of csv=p=0 "{workspace}/remotion/public/recordings/{scene.id}.mp4")
      echo "Recording duration: ${RECORDING_DUR}s"
    Validation:
      - MP4 file size > 10KB
      - ffprobe duration > 0
      - Resolution = 1920x1080

Screenshot_Capture:
  for scene in scenes where scene.visual.imageSource == "capture":
    Bash: |
      # Playwright screenshot capture
      npx playwright test --config="{workspace}/playwright.config.ts" \
        --project=screenshots \
        --grep "{scene.id}"
    Output: "{workspace}/remotion/public/images/{scene.id}.png"

# ──── 3F: Real Install Capture (v3.0 new — ttyd + Playwright) ────
# Refer to references/capture-config.md

Install_Capture_Strategy:
  # ttyd: Expose real terminal via HTTP → Playwright records in browser
  # Advantage: Real command execution + real output (npm progress bar, package tree, etc.) + browser recording quality
  # Fallback: If ttyd not available → auto-switch to terminal-demo (Remotion native)

Install_Capture_Execution:
  for scene in scenes where scene.type == "install-capture":
    # 1. Start ttyd
    Bash: |
      SANDBOX="/tmp/tuto-capture-${scene_id}"
      mkdir -p "$SANDBOX"
      # Start ttyd in background (port 7681)
      ttyd -p 7681 -W bash -c "cd $SANDBOX && exec bash" &
      TTYD_PID=$!
      sleep 2
      echo "ttyd started on :7681 (PID: $TTYD_PID)"

    # 2. Record via Playwright + auto-type commands
    Bash: |
      node -e "
      const { chromium } = require('playwright');
      (async () => {
        const browser = await chromium.launch();
        const context = await browser.newContext({
          viewport: { width: 1920, height: 1080 },
          recordVideo: { dir: '${workspace}/recordings/', size: { width: 1920, height: 1080 } }
        });
        const page = await context.newPage();
        await page.goto('http://localhost:7681');
        await page.waitForTimeout(1000);

        // Execute installCommands sequentially
        const commands = ${JSON.stringify(scene.visual.installCommands)};
        for (const cmd of commands) {
          // Focus xterm.js
          await page.click('.xterm-helper-textarea');
          await page.keyboard.type(cmd.input, { delay: cmd.typeDelay || 50 });
          await page.keyboard.press('Enter');

          if (cmd.waitForText) {
            await page.waitForFunction(
              text => document.body.innerText.includes(text),
              cmd.waitForText,
              { timeout: cmd.timeout || 60000 }
            );
          } else {
            await page.waitForTimeout(cmd.waitAfter || 3000);
          }

          if (cmd.screenshot) {
            await page.screenshot({ path: '${workspace}/screenshots/${scene_id}-' + cmd.annotation + '.png' });
          }
        }

        await context.close();
        await browser.close();
      })();
      "

    # 3. Stop ttyd + clean up sandbox
    Bash: |
      kill $TTYD_PID 2>/dev/null
      rm -rf "$SANDBOX"

    # 4. WebM → MP4 conversion
    Bash: |
      ffmpeg -i "${workspace}/recordings/${scene_id}.webm" \
        -c:v libx264 -crf 18 -preset slow -movflags +faststart \
        -vf "scale=1920:1080" \
        "${workspace}/remotion/public/recordings/${scene_id}.mp4"

    Validation:
      - MP4 file size > 10KB
      - ffprobe duration > 0
      - Resolution = 1920x1080

  Install_Capture_Fallback:
    # If ttyd unavailable or recording failed → auto-switch to terminal-demo
    Condition: ttyd not installed or recording failed
    Action: |
      scene.type = "terminal-demo"
      scene.visual.type = "terminal"
      # Convert installCommands → TerminalCommand
      scene.visual.commands = scene.visual.installCommands.map(ic => ({
        input: ic.input,
        expectedOutput: ic.waitForText || "(installation complete)",
        typeDelay: ic.typeDelay || 80,
        waitAfter: ic.waitAfter || 3000,
        annotation: ic.annotation
      }))
      # Use Remotion native TerminalSimulator
```

---

## Phase 4: CAPTION (Whisper Subtitle Generation)

```yaml
Goal: TTS audio files → word-level subtitle JSON + SRT generation
Duration: ~2min
Input: audio/*.mp3
Output: captions/*.json, output/captions.srt

Step_1_WAV_Conversion:
  # Whisper requires 16KHz WAV
  for audio_file in audio/*.mp3:
    Bash: |
      ffmpeg -i "{audio_file}" -ar 16000 -ac 1 -c:a pcm_s16le \
        "{workspace}/remotion/public/captions/{scene_id}.wav"

Step_2_Whisper_Transcription:
  # Use @remotion/install-whisper-cpp
  for wav_file in captions/*.wav:
    Bash: |
      npx @remotion/install-whisper-cpp@latest transcribe \
        "{wav_file}" \
        --model medium \
        --language ko \
        --output-json \
        > "{workspace}/remotion/public/captions/{scene_id}.json"

Step_3_Caption_Processing:
  # Convert Whisper JSON → Remotion Caption format
  # Use toCaptions() from @remotion/captions
  Action: |
    Per-scene Whisper output → toCaptions() conversion
    Including word-level timestamps
    → Save per-scene caption JSON

Step_4_SRT_Generation:
  # Consolidate all scene subtitles → SRT file
  Action: |
    Sort all scene caption data chronologically
    Convert to SRT format (apply inter-scene offsets)
    → {workspace}/output/captions.srt

Step_5_Duration_Sync_Gate:
  # ★ Mandatory verification gate — blocks Phase 5 entry on failure ★
  # Audio-First Duration: Finalize scenario.json with actual duration of all scenes
  Gate_Type: MANDATORY (cannot skip, Iron Law)

  Step_5a_Audio_Duration_Measurement:
    Action: |
      for scene in scenes:
        AUDIO_DUR=$(ffprobe -v quiet -show_entries format=duration \
          -of csv=p=0 "{workspace}/remotion/public/audio/${scene.id}.mp3")
        # Per scene-type duration calculation:
        #   Default: audio_dur + 0.5s (end-of-scene breathing padding)
        #   code-demo: Math.max(audio_dur, code_lines x 0.5) + 0.5s
        #   title (with audio): Math.max(fixed_dur, audio_dur + 0.5)
        #   outro (with audio): Math.max(fixed_dur, audio_dur + 0.5)
        #   transition: audio_dur + 0.5s (or fixed 1-2s if no audio)

  Step_5b_Recording_Duration_Measurement:
    Condition: When live-demo or install-capture scenes exist
    Action: |
      for scene in scenes where scene.visual.type in ["live-demo", "install-capture"]:
        RECORDING_DUR=$(ffprobe -v quiet -show_entries format=duration \
          -of csv=p=0 "{workspace}/remotion/public/recordings/${scene.id}.mp4")
        # live-demo/install-capture: Math.max(audio_dur, recording_dur) + 0.5s

  Step_5c_Frame_Calculation:
    Action: |
      fps = 30
      for scene in scenes:
        duration_actual = <calculated above>
        durationInFrames = Math.ceil(duration_actual * fps) + 1  # +1 frame buffer to prevent cutoff
      total_durationInFrames = sum(all scene durationInFrames)
      → Finalize duration_actual + durationInFrames fields in scenario.json

  Step_5d_Validation_Gate:
    Checks:
      - All scenes: duration_actual > 0
      - All scenes: durationInFrames > 0
      - All audio scenes: |duration_actual - (audio_ffprobe + 0.5)| < 1.0s
      - total_durationInFrames === sum(scene durationInFrames)
    On_Fail: |
      SYNC GATE FAILED — Phase 5 Assembly entry blocked
      Output list of failed scenes → manual verification required
    On_Pass: |
      SYNC GATE PASSED — duration_actual finalized, Phase 5 entry allowed
      Final save of scenario.json (backup: scenario.pre-sync.json)
```

---

## Phase 5: ASSEMBLY (Remotion Composition)

```yaml
Goal: Scenario + assets + subtitles → Remotion composition assembly
Duration: ~3min
Input: scenario.json, audio/*, images/*, captions/*, code/*
Output: Remotion composition (previewable)

# ★★★ REUSE PROTOCOL (Iron Law) ★★★
# Since V1 src/ was already copied in Step_2_Reuse_Components,
# do not write scene components, shared components, themes, or types from scratch.
# Only files needing modification are Root.tsx (scenario data replacement) and TutoMain.tsx (scene mapping).
# Only write additional components in src/scenes/ when new scene types are required.

Step_0_Dependencies:
  # Skip if V1 node_modules symlink exists, install if not
  Bash: |
    cd "{workspace}/remotion"
    [ -d "node_modules" ] && echo "Dependencies OK (symlinked)" || npm install

Step_1_Root_Composition:
  # Root.tsx — Replace only scenario data (reuse V1 component structure as-is)
  # Replace the inline scenario data in V1 Root.tsx with new scenario.json.
  Action: |
    Replace Root.tsx scenario data with scenario.json import
    Maintain TutoMain + TutoShorts compositions (V1 pattern)
    Compose scene sequence with Series + TransitionSeries
    ★ Dynamic duration via calculateMetadata (use values finalized in SYNC GATE)
    Each scene type → corresponding React component mapping (17 types — all implemented in Component Library):
      # Basic 8 types
      title         → <TitleScene />
      explanation   → <ExplanationScene />
      code-demo     → <CodeDemoScene />
      cutscene      → <CutsceneScene />
      news          → <NewsScene />
      transition    → <TransitionScene />
      summary       → <SummaryScene />
      outro         → <OutroScene />
      # v2.0 capture 2 types
      live-demo     → <LiveDemoScene />         # Playwright browser recording
      terminal-demo → <TerminalDemoScene />     # Remotion native terminal
      # Extended 7 types (reused from Component Library)
      quiz          → <QuizScene />             # A/B quiz (viewer engagement)
      comparison    → <ComparisonScene />       # VS comparison layout
      stats         → <StatsScene />            # Statistics/counter animation
      timeline      → <TimelineScene />         # Step-by-step progress (installation process, etc.)
      image-showcase → <ImageShowcaseScene />   # Image fullbleed/framed/split
      quote         → <QuoteScene />            # Quotation (expert opinions, etc.)
      diagram       → <DiagramScene />          # Flowchart/architecture diagram
      browser-demo  → <BrowserDemoScene />      # Recorded video browser frame embed
      # v3.0 new
      install-capture → <InstallCaptureScene />  # ttyd + Playwright real installation recording

  calculateMetadata_Pattern: |
    # Must use this pattern in Root.tsx:
    import { parseMedia } from '@remotion/media-parser';

    const calculateMetadata: CalculateMetadataFunction<TutoProps> = async ({ props }) => {
      const fps = 30;
      // Sum durationInFrames finalized in SYNC GATE (loaded from scenario.json)
      const totalFrames = props.scenes.reduce((acc, s) => acc + s.durationInFrames, 0);
      return { durationInFrames: totalFrames, fps, width: 1920, height: 1080 };
    };

  Component_Props:
    Common: narration(Audio src), durationInFrames(SYNC GATE finalized value), captions(Caption[]), layout("full"|"split"|"pip")
    title: title, subtitle, animationStyle
    explanation: imageUrl, keyPoints[], narration
    code-demo: code, language, highlights[], narration
    cutscene: imageUrl, narration, overlayText
    news: headline, source, narration
    summary: points[], callToAction
    outro: channelName, nextVideoHint, subscribeUrl
    live-demo: recordingSrc, captureSteps[], overlay  # v2.0
    terminal-demo: commands[], style("full"|"split-with-code")  # v2.0

Step_2_Shared_Components:
  # Components shared across all scenes (refer to references/scene-components.md)
  Components:
    BoldBackground: |
      Gradient background (deep purple → dark blue)
      Subtle motion via useCurrentFrame() + interpolate()
    CaptionOverlay: |
      Word-level subtitle rendering
      Current frame-based highlighting
      @remotion/captions integration
    ProgressBar: |
      Bottom screen progress bar
      Current position relative to total duration
    GlowAccent: |
      Neon glow effect (accent color)
      spring()-based pulsing

    # ★ v2.1 Channel Asset Components ★
    Watermark: |
      # Bottom-right semi-transparent watermark (always displayed throughout video)
      Props: { opacity?: number }  // Default 0.3
      Source: staticFile('branding/watermark.jpg')
      Position: Bottom-right (right: 20px, bottom: 60px — above ProgressBar)
      Size: 150px width (maintain original aspect ratio)
      Animation: fade-in (first 30 frames)

    PresenterOverlay: |
      # Presenter character overlay (auto-select expression+pose per scene)
      Props: {
        expression: string,        // expr-01~12
        pose: string,              // pose-01~10
        position: 'left' | 'right' | 'none',
        size?: 'small' | 'medium' | 'large'  // Default 'medium'
      }
      Source: staticFile(`presenter/expressions/${expression}.jpg`) or poses/
      Position:
        right: Bottom-right (right: 40px, bottom: 100px)
        left: Bottom-left (left: 40px, bottom: 100px)
        none: Not rendered (code/terminal scenes)
      Size: small=120px, medium=180px, large=250px (maintain original aspect ratio)
      Animation: spring() slide-up + fade-in (entrance), crossfade on expression change
      Behavior:
        - Appear with pose image at scene start (spring slide-up)
        - Switch to expression image at narration keyword match point (crossfade 10 frames)
        - Hidden with position="none" in code/terminal/diagram scenes
      Note: Auto-determined from presenter field in scenario.json (Phase 2 Step_3)

Step_3_Media_Integration:
  # ★ v2.0: Per scene-type media branching ★
  # durationInFrames uses values finalized in SYNC GATE (estimates prohibited!)
  Action: |
    let accumulatedFrames = 0;
    for (const scene of scenes) {
      const frames = scene.durationInFrames;  // SYNC GATE finalized value

      // Basic scenes (cutscene, code, text, image, quiz, comparison, stats, etc.)
      if (['cutscene', 'code', 'text', 'image'].includes(scene.visual.type)) {
        <Sequence from={accumulatedFrames} durationInFrames={frames}>
          <Audio src={staticFile(`audio/${scene.id}.mp3`)} />
          <SceneComponent {...sceneProps} durationInFrames={frames} />
          {scene.presenter?.position !== 'none' && (
            <PresenterOverlay
              expression={scene.presenter.expression}
              pose={scene.presenter.pose}
              position={scene.presenter.position || 'right'}
            />
          )}
        </Sequence>
      }

      // live-demo scene — Playwright recorded video + narration overlay
      if (scene.visual.type === 'live-demo') {
        <Sequence from={accumulatedFrames} durationInFrames={frames}>
          <AbsoluteFill>
            <OffthreadVideo src={staticFile(`recordings/${scene.id}.mp4`)} />
          </AbsoluteFill>
          <Audio src={staticFile(`audio/${scene.id}.mp3`)} />  // Narration overlay
          <CaptionOverlay captions={scene.captions} />
          {scene.visual.layout === 'pip' && <StepBadge step={currentStep} />}
        </Sequence>
      }

      // terminal-demo scene — Remotion native rendering (NOT recording!)
      if (scene.visual.type === 'terminal') {
        <Sequence from={accumulatedFrames} durationInFrames={frames}>
          <Audio src={staticFile(`audio/${scene.id}.mp3`)} />
          {scene.visual.layout === 'split' ? (
            <AbsoluteFill style={{display:'flex'}}>
              <div style={{flex:1}}><CodeBlock code={scene.visual.code} /></div>
              <div style={{flex:1}}><TerminalSimulator commands={scene.visual.commands} /></div>
            </AbsoluteFill>
          ) : (
            <TerminalSimulator commands={scene.visual.commands} />
          )}
          <CaptionOverlay captions={scene.captions} />
        </Sequence>
      }

      // v3.0: install-capture scene — ttyd + Playwright real installation recording embed
      if (scene.visual.type === 'install-capture') {
        <Sequence from={accumulatedFrames} durationInFrames={frames}>
          <AbsoluteFill>
            <OffthreadVideo src={staticFile(`recordings/${scene.id}.mp4`)} />
          </AbsoluteFill>
          <Audio src={staticFile(`audio/${scene.id}.mp3`)} />
          <CaptionOverlay captions={scene.captions} />
          {scene.visual.ensemble_layout === 'pip-capture' && (
            <PresenterOverlay
              expression={scene.presenter?.expression}
              pose={scene.presenter?.pose}
              position="right"
              size="small"
            />
          )}
          {scene.visual.stepLabel && <StepBadge step={scene.visual.stepLabel} />}
        </Sequence>
      }

      // v3.0: Ensemble Mixer layout — capture + AI + animation compositing
      if (scene.visual.ensemble_layout === 'split-real-diagram') {
        // Left: capture video, Right: diagram/explanation
        <Sequence from={accumulatedFrames} durationInFrames={frames}>
          <AbsoluteFill style={{display:'flex'}}>
            <div style={{flex:1}}>
              <OffthreadVideo src={staticFile(`recordings/${scene.id}.mp4`)} />
            </div>
            <div style={{flex:1}}>
              <DiagramScene nodes={scene.visual.nodes} flowDirection={scene.visual.flowDirection} />
            </div>
          </AbsoluteFill>
          <Audio src={staticFile(`audio/${scene.id}.mp3`)} />
          <CaptionOverlay captions={scene.captions} />
        </Sequence>
      }

      accumulatedFrames += frames;
    }

    // ★ Global overlay (displayed above all scenes)
    <AbsoluteFill style={{pointerEvents:'none', zIndex:100}}>
      <Watermark opacity={0.3} />
    </AbsoluteFill>

Step_4_Transition_Setup:
  # Scene transition effects via TransitionSeries
  Transitions:
    fade: linearTiming({ durationInFrames: 15 })
    wipe: linearTiming({ durationInFrames: 20 })
    slide: springTiming({ durationInFrames: 20 })

Step_5_Layout_Adapters:
  # 16:9 → 9:16 layout conversion
  Strategy: |
    Pass orientation prop to <TutoComposition>
    orientation="landscape" (1920x1080) | "portrait" (1080x1920)
    Orientation-based layout branching inside each scene component:
      landscape: default layout
      portrait: shrink code blocks + reposition text + crop images

Step_6_Preview:
  # ★ Must run preview before rendering
  Bash: |
    cd "{workspace}/remotion"
    npx remotion studio
  # Verify in preview:
  #   - Scene order/timing
  #   - Audio-subtitle sync
  #   - Image display
  #   - Code highlighting
  #   - Transition effects
```

---

## Phase 6: RENDER (Dual Rendering)

```yaml
Goal: 16:9 + 9:16 dual MP4 output + thumbnail + metadata
Duration: ~10-20min (proportional to video length)
Input: Remotion composition
Output: output/ (video-16x9.mp4, video-9x16.mp4, thumbnail.png, captions.srt, metadata.json)

Step_1_Render_16x9:
  Bash: |
    cd "{workspace}/remotion"
    npx remotion render TutoMain \
      --output "../output/video-16x9.mp4" \
      --codec h264 \
      --props '{"orientation":"landscape"}' \
      --concurrency 50%

Step_2_Render_9x16:
  Bash: |
    cd "{workspace}/remotion"
    npx remotion render TutoMain \
      --output "../output/video-9x16.mp4" \
      --codec h264 \
      --width 1080 --height 1920 \
      --props '{"orientation":"portrait"}' \
      --concurrency 50%

Step_3_Thumbnail:
  # ★ Leverage channel thumbnail templates (8 types: A-beginner~H-review)
  # Auto-select template matching the topic then composite via Remotion still
  Template_Selection: |
    # Auto-select via scenario keywords:
    #   A-beginner: "intro", "start", "beginner"
    #   B-tutorial: "tutorial", "guide", "hands-on"
    #   C-comparison: "comparison", "VS", "difference"
    #   D-mindblown: "amazing", "incredible", "innovation"
    #   E-listicle: "roundup", "complete guide", "collection"
    #   F-secret: "pro-tip", "secret", "hidden"
    #   G-challenge: "challenge", "attempt", "try"
    #   H-review: "review", "experience", "evaluation"
    # Default: B-tutorial
  Bash: |
    cd "{workspace}/remotion"
    # Method 1: Remotion still (capture title scene frame)
    npx remotion still TutoMain \
      --output "../output/thumbnail.png" \
      --frame 30 \
      --props '{"orientation":"landscape"}'
    # Method 2: Thumbnail template + profile composite (ffmpeg)
    TEMPLATE=$(ls ../remotion/public/thumbnails/B-tutorial.jpg 2>/dev/null || echo "")
    PROFILE=$(ls ../remotion/public/presenter/profile.jpg 2>/dev/null || echo "")
    if [ -n "$TEMPLATE" ] && [ -n "$PROFILE" ]; then
      ffmpeg -i "$TEMPLATE" -i "$PROFILE" \
        -filter_complex "[1:v]scale=300:-1[prof];[0:v][prof]overlay=W-w-60:H-h-60" \
        -y "../output/thumbnail-branded.png" 2>/dev/null
      echo "Branded thumbnail generated: thumbnail-branded.png"
    fi

Step_4_Metadata:
  # Generate metadata for YouTube upload
  Output: "{workspace}/output/metadata.json"
  Schema: |
    {
      "title": "scenario.title",
      "description": "scenario.description + auto-generated summary",
      "tags": "scenario.tags",
      "category": "Science & Technology",
      "language": "ko",
      "files": {
        "video_16x9": "video-16x9.mp4",
        "video_9x16": "video-9x16.mp4",
        "thumbnail": "thumbnail.png",
        "thumbnail_branded": "thumbnail-branded.png",
        "captions_srt": "captions.srt"
      },
      "channel_assets_used": {
        "watermark": true,
        "presenter_expressions": ["list of used expressions"],
        "presenter_poses": ["list of used poses"],
        "thumbnail_template": "B-tutorial"
      },
      "duration_sec": number,
      "scene_count": number,
      "api_cost_estimate": {
        "tts": "$X.XX",
        "gemini": "$X.XX",
        "tavily": "$X.XX",
        "total": "$X.XX"
      }
    }

Step_5_Final_Report:
  # Output generation result summary
  Report: |
    Video generation complete!
    Output path: {workspace}/output/
    16:9: video-16x9.mp4 ({duration})
    9:16: video-9x16.mp4 ({duration})
    Thumbnail: thumbnail.png
    Subtitles: captions.srt
    Metadata: metadata.json
    Estimated API cost: ${total}
```

---

## Scene Types Registry

```yaml
# 18 scene types — keyword-based auto-mapping (v2.0: +2, v2.1: +7, v3.0: +1 install-capture)
# ★ All components are implemented in tuto-workspace/remotion/src/scenes/
# ★ Reuse from Component Library, do not create from scratch

title:
  keywords: ["intro", "title", "start"]
  component: TitleScene
  visual: Bold title + subtitle + motion graphics
  audio: intro BGM (optional)
  duration: 3-5s

explanation:
  keywords: ["explanation", "concept", "principle", "understanding"]
  component: ExplanationScene
  visual: Cutscene image + key point text overlay
  audio: Narration TTS
  duration: Based on narration length

code-demo:
  keywords: ["code", "implementation", "example", "hands-on"]
  component: CodeDemoScene
  visual: Shiki syntax highlight + line-by-line animation
  audio: Narration TTS
  duration: Narration length + code animation time

cutscene:
  keywords: ["transition", "visual", "image"]
  component: CutsceneScene
  visual: Gemini-generated/web-collected image fullscreen
  audio: Narration TTS
  duration: Based on narration length

news:
  keywords: ["news", "update", "announcement", "release"]
  component: NewsScene
  visual: News card layout + source display
  audio: Narration TTS
  duration: Based on narration length

transition:
  keywords: ["transition", "move on", "next"]
  component: TransitionScene
  visual: TransitionSeries (wipe/fade/slide)
  audio: transition SFX (optional)
  duration: 1-2s

summary:
  keywords: ["summary", "recap", "key points"]
  component: SummaryScene
  visual: Key point list + call to action
  audio: Narration TTS
  duration: Based on narration length

outro:
  keywords: ["wrap-up", "subscribe", "next video"]
  component: OutroScene
  visual: Channel subscribe CTA + next video preview
  audio: outro BGM (optional)
  duration: 5-8s (with audio: Math.max(fixed, audio+0.5))

# ──── v2.0 new scene types ────

live-demo:
  keywords: ["live", "real screen", "browser", "demo", "UI capture"]
  component: LiveDemoScene
  visual: Playwright recorded video (OffthreadVideo) + narration overlay
  audio: Narration TTS
  layout: full | pip (step badge)
  duration: Math.max(audio_dur, recording_dur) + 0.5s
  asset_source: Playwright recordVideo → ffmpeg → MP4

terminal-demo:
  keywords: ["terminal", "command", "CLI", "install", "execute"]
  component: TerminalDemoScene
  visual: Remotion native <TerminalSimulator> (not recording, direct rendering)
  audio: Narration TTS
  layout: full | split-with-code (left: code, right: terminal)
  duration: audio_dur + 0.5s
  asset_source: None (Remotion renders commands[] array frame-by-frame)

# ──── v2.1 Extended Scene Types (Reused from Component Library) ────

quiz:
  keywords: ["quiz", "question", "guess", "A vs B"]
  component: QuizScene
  visual: A/B card dual layout + VS badge + answer reveal highlight
  audio: Narration TTS
  duration: Based on narration length
  props: question, optionA, optionB, correctAnswer?

comparison:
  keywords: ["comparison", "VS", "difference", "matchup", "which one"]
  component: ComparisonScene
  visual: Left/right split VS layout + diagonal divider + sequential point reveal
  audio: Narration TTS
  duration: Based on narration length
  props: leftLabel, rightLabel, leftPoints[], rightPoints[]

stats:
  keywords: ["statistics", "numbers", "data", "percent", "performance"]
  component: StatsScene
  visual: Counter card grid + count-up animation + hero card
  audio: Narration TTS
  duration: Based on narration length
  props: headline, stats[{value, label, suffix?}]

timeline:
  keywords: ["step", "sequence", "process", "step-by-step", "stages"]
  component: TimelineScene
  visual: Vertical step progression + emerald line growth + numbered nodes
  audio: Narration TTS
  duration: Based on narration length
  props: heading, steps[{title, description?}]

image-showcase:
  keywords: ["screen", "result", "screenshot", "let me show", "as you see"]
  component: ImageShowcaseScene
  visual: fullbleed/framed/split layout + Ken Burns + caption
  audio: Narration TTS
  duration: Based on narration length
  props: imageUrl, caption, subcaption?, layout?("fullbleed"|"framed"|"split")

quote:
  keywords: ["quote", "opinion", "perspective", "expert"]
  component: QuoteScene
  visual: Serif large typography + decorative quotation marks + author card
  audio: Narration TTS
  duration: Based on narration length
  props: quote, author, role?, imageUrl?

diagram:
  keywords: ["architecture", "structure", "flow", "flowchart", "diagram"]
  component: DiagramScene
  visual: Node cards + arrow connectors + sequential reveal animation
  audio: Narration TTS
  duration: Based on narration length
  props: title, nodes[{label, description?, type?}], flowDirection?

browser-demo:
  keywords: ["browser", "website", "screen recording", "captured video"]
  component: BrowserDemoScene
  visual: macOS browser frame + OffthreadVideo + highlight region
  audio: Narration TTS
  duration: Math.max(audio_dur, recording_dur) + 0.5s
  props: videoSrc, title?, stepLabel?, highlightRegion?

# ──── v3.0 new scene types ────

install-capture:
  keywords: ["install", "npm install", "pip install", "brew", "real installation", "package install"]
  component: InstallCaptureScene
  visual: ttyd + Playwright recorded video (OffthreadVideo) + narration overlay
  audio: Narration TTS
  layout: full | pip (step badge + presenter)
  duration: Math.max(audio_dur, recording_dur) + 0.5s
  asset_source: ttyd (real terminal HTTP) + Playwright recordVideo → ffmpeg → MP4
  fallback: terminal-demo (Remotion native) — auto-switch when ttyd not installed
  props: installCommands[], recordingSrc, stepLabel?, ensemble_layout?
```

---

## MCP Routing

| Task | Tool |
|------|------|
| Web research / latest info | Tavily MCP |
| Framework docs lookup | Context7 MCP |
| Code analysis / editing | CodeGraph MCP |
| Browser recording / screenshots | Playwright MCP (v2.0) |
| TTS audio generation | OpenAI API (Bash curl) |
| Image generation | Gemini API (Bash curl) |
| Subtitle generation | Whisper (Bash) |
| Video rendering | Remotion CLI (Bash) |
| Media metadata | @remotion/media-parser (parseMedia) |

---

## Boundaries

**Will:**
- Generate complete YouTube tutorial video MP4 from topic input alone
- Auto-compose accurate scenarios based on web research
- Maintain consistent bold graphic visual style
- Auto-output 16:9 + 9:16 dual format
- Per-scene individual TTS + Whisper word-level subtitles
- Real browser screen Playwright recording (live-demo)
- Remotion native terminal simulation (terminal-demo)
- Perfect narration-video sync via Audio-First Duration
- Proceed to Assembly only after SYNC GATE passes
- v3.0: Auto-determine per-scene visual source via Reality Score (Generated/Captured/Animated)
- v3.0: Record real installation process via ttyd + Playwright (install-capture)
- v3.0: Smart Scene Type Promotion — auto-promote explanation/cutscene to capture scenes
- v3.0: Ensemble Mixer — composite capture + AI + animation in a single scene

**Will Not:**
- Generate scenarios without research (Iron Law)
- Combine all narrations into a single mp3
- Generate images without Gemini system instruction
- Render without Remotion Studio preview
- Output in single format (16:9 only)
- Render with duration_estimate values (SYNC GATE required)
- Record terminal sessions via Playwright (use Remotion native)
- v3.0: Fill hands-on topics with AI images only (Reality Target: 30-50% real capture)
- v3.0: Attempt install-capture without ttyd (auto fallback → terminal-demo)
