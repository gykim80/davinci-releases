# User Flows

End-to-end test patterns for common user journeys: authentication, form submission, navigation, CRUD operations, and multi-step workflows.

## Authentication Flows

### Login and Logout

Test the complete authentication lifecycle: credential entry, session creation, protected route access, and session destruction.

```typescript
// Bad: logging in manually in every single test
test('view dashboard', async ({ page }) => {
  await page.goto('/login');
  await page.getByLabel('Email').fill('user@test.com');
  await page.getByLabel('Password').fill('password123');
  await page.getByRole('button', { name: 'Sign in' }).click();
  await expect(page).toHaveURL('/dashboard');
  // actual test starts here...
});

test('view profile', async ({ page }) => {
  await page.goto('/login');
  await page.getByLabel('Email').fill('user@test.com');
  await page.getByLabel('Password').fill('password123');
  await page.getByRole('button', { name: 'Sign in' }).click();
  await page.goto('/profile');
  // actual test starts here...
});
```

```typescript
// Good: use storageState for authenticated session reuse
// global-setup.ts
import { chromium, FullConfig } from '@playwright/test';

async function globalSetup(config: FullConfig) {
  const browser = await chromium.launch();
  const page = await browser.newPage();

  await page.goto('http://localhost:3000/login');
  await page.getByLabel('Email').fill('user@test.com');
  await page.getByLabel('Password').fill('password123');
  await page.getByRole('button', { name: 'Sign in' }).click();
  await expect(page).toHaveURL('/dashboard');

  // Save signed-in state to reuse across tests
  await page.context().storageState({ path: './tests/.auth/user.json' });
  await browser.close();
}

export default globalSetup;
```

```typescript
// Good: playwright.config.ts referencing storageState
import { defineConfig } from '@playwright/test';

export default defineConfig({
  globalSetup: require.resolve('./global-setup'),
  projects: [
    {
      name: 'authenticated',
      use: { storageState: './tests/.auth/user.json' },
    },
    {
      name: 'unauthenticated',
      use: { storageState: { cookies: [], origins: [] } },
    },
  ],
});
```

```typescript
// Good: tests run with pre-authenticated state, no login step needed
test('view dashboard', async ({ page }) => {
  await page.goto('/dashboard');
  await expect(page.getByRole('heading', { name: 'Dashboard' })).toBeVisible();
});

test('view profile', async ({ page }) => {
  await page.goto('/profile');
  await expect(page.getByRole('heading', { name: 'Profile' })).toBeVisible();
});
```

**Detect:** Repeated `page.getByLabel('Email').fill(...)` or `page.getByLabel('Password').fill(...)` across multiple test files -- suggest `storageState` in global setup.

### Session Persistence

Validate that sessions survive page reloads and new tabs.

```typescript
// Good: verify session persistence after reload
test('session persists across page reload', async ({ page }) => {
  await page.goto('/dashboard');
  await expect(page.getByRole('heading', { name: 'Dashboard' })).toBeVisible();

  await page.reload();
  await expect(page.getByRole('heading', { name: 'Dashboard' })).toBeVisible();
  await expect(page.getByRole('button', { name: 'Sign out' })).toBeVisible();
});
```

### Logout Flow

```typescript
// Good: verify full logout and redirect
test('logout clears session and redirects to login', async ({ page }) => {
  await page.goto('/dashboard');
  await page.getByRole('button', { name: 'Sign out' }).click();

  // Verify redirect to login page
  await expect(page).toHaveURL('/login');

  // Verify protected route is no longer accessible
  await page.goto('/dashboard');
  await expect(page).toHaveURL('/login');
});
```

## Form Submission Flows

### Validation, Error, and Success States

Test the complete form lifecycle: empty submission, field-level validation, server-side errors, and successful submission.

```typescript
// Bad: only testing the happy path without error states
test('submit contact form', async ({ page }) => {
  await page.goto('/contact');
  await page.getByLabel('Name').fill('John');
  await page.getByLabel('Email').fill('john@test.com');
  await page.getByLabel('Message').fill('Hello');
  await page.getByRole('button', { name: 'Send' }).click();
  await expect(page.getByText('Message sent')).toBeVisible();
});
```

```typescript
// Good: comprehensive form testing with validation and error states
test.describe('Contact Form', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/contact');
  });

  test('shows validation errors on empty submission', async ({ page }) => {
    await page.getByRole('button', { name: 'Send' }).click();

    await expect(page.getByText('Name is required')).toBeVisible();
    await expect(page.getByText('Email is required')).toBeVisible();
    await expect(page.getByText('Message is required')).toBeVisible();
  });

  test('shows inline error for invalid email', async ({ page }) => {
    await page.getByLabel('Email').fill('not-an-email');
    await page.getByLabel('Email').blur();

    await expect(page.getByText('Please enter a valid email')).toBeVisible();
  });

  test('disables submit button during submission', async ({ page }) => {
    await page.getByLabel('Name').fill('John');
    await page.getByLabel('Email').fill('john@test.com');
    await page.getByLabel('Message').fill('Hello');
    await page.getByRole('button', { name: 'Send' }).click();

    await expect(page.getByRole('button', { name: 'Send' })).toBeDisabled();
  });

  test('shows success message after valid submission', async ({ page }) => {
    await page.getByLabel('Name').fill('John');
    await page.getByLabel('Email').fill('john@test.com');
    await page.getByLabel('Message').fill('Hello');
    await page.getByRole('button', { name: 'Send' }).click();

    await expect(page.getByText('Message sent successfully')).toBeVisible();
  });

  test('shows server error message on failure', async ({ page }) => {
    // Intercept the API call and force a server error
    await page.route('**/api/contact', (route) =>
      route.fulfill({ status: 500, body: JSON.stringify({ error: 'Server error' }) })
    );

    await page.getByLabel('Name').fill('John');
    await page.getByLabel('Email').fill('john@test.com');
    await page.getByLabel('Message').fill('Hello');
    await page.getByRole('button', { name: 'Send' }).click();

    await expect(page.getByText('Something went wrong')).toBeVisible();
    // Button should re-enable so user can retry
    await expect(page.getByRole('button', { name: 'Send' })).toBeEnabled();
  });
});
```

**Detect:** Form test with only a success-path assertion and no `getByText('error')` or `getByText('required')` checks -- suggest adding validation and error state tests.

## Navigation Flows

### Client-Side Routing

```typescript
// Bad: only asserting URL without checking rendered content
test('navigate to about page', async ({ page }) => {
  await page.goto('/');
  await page.getByRole('link', { name: 'About' }).click();
  await expect(page).toHaveURL('/about');
  // no content assertion -- the page could be blank or show an error
});
```

```typescript
// Good: assert both URL and DOM content for navigation
test('navigate to about page', async ({ page }) => {
  await page.goto('/');
  await page.getByRole('link', { name: 'About' }).click();

  await expect(page).toHaveURL('/about');
  await expect(page.getByRole('heading', { name: 'About Us' })).toBeVisible();
  await expect(page.getByText('Our mission')).toBeVisible();
});
```

**Detect:** `expect(page).toHaveURL(...)` without a subsequent DOM content assertion -- suggest adding `toBeVisible()` or `toHaveText()` check.

### Back and Forward Navigation

```typescript
// Good: verify browser history navigation
test('back and forward navigation works correctly', async ({ page }) => {
  await page.goto('/');
  await page.getByRole('link', { name: 'Products' }).click();
  await expect(page.getByRole('heading', { name: 'Products' })).toBeVisible();

  await page.getByRole('link', { name: 'Product A' }).click();
  await expect(page.getByRole('heading', { name: 'Product A' })).toBeVisible();

  await page.goBack();
  await expect(page.getByRole('heading', { name: 'Products' })).toBeVisible();

  await page.goForward();
  await expect(page.getByRole('heading', { name: 'Product A' })).toBeVisible();
});
```

### Deep Link Access

```typescript
// Good: verify direct URL access renders correctly
test('deep link to product detail renders correctly', async ({ page }) => {
  await page.goto('/products/abc-123');

  await expect(page.getByRole('heading', { name: 'Product A' })).toBeVisible();
  await expect(page.getByText('$29.99')).toBeVisible();
  await expect(page.getByRole('button', { name: 'Add to cart' })).toBeVisible();
});
```

## Search and Filter Flows

```typescript
// Good: test search with results and empty state
test.describe('Product Search', () => {
  test('displays matching results', async ({ page }) => {
    await page.goto('/products');
    await page.getByRole('searchbox', { name: 'Search products' }).fill('keyboard');
    await page.getByRole('searchbox', { name: 'Search products' }).press('Enter');

    await expect(page.getByRole('list')).toBeVisible();
    const items = page.getByRole('listitem');
    await expect(items).toHaveCount(3);
    await expect(items.first()).toContainText('keyboard');
  });

  test('shows empty state for no results', async ({ page }) => {
    await page.goto('/products');
    await page.getByRole('searchbox', { name: 'Search products' }).fill('xyznonexistent');
    await page.getByRole('searchbox', { name: 'Search products' }).press('Enter');

    await expect(page.getByText('No products found')).toBeVisible();
  });

  test('filters narrow results correctly', async ({ page }) => {
    await page.goto('/products');

    await page.getByRole('combobox', { name: 'Category' }).selectOption('Electronics');
    await expect(page.getByRole('listitem')).toHaveCount(5);

    await page.getByRole('combobox', { name: 'Price range' }).selectOption('Under $50');
    await expect(page.getByRole('listitem')).toHaveCount(2);
  });
});
```

## CRUD Operation Flows

Test create, read, update, and delete operations including confirmation dialogs and optimistic UI updates.

```typescript
// Good: full CRUD lifecycle test
test.describe('Task Management CRUD', () => {
  test('creates a new task', async ({ page }) => {
    await page.goto('/tasks');
    await page.getByRole('button', { name: 'New task' }).click();

    await page.getByLabel('Title').fill('Write E2E tests');
    await page.getByLabel('Description').fill('Cover all user flows');
    await page.getByRole('button', { name: 'Create' }).click();

    await expect(page.getByText('Task created')).toBeVisible();
    await expect(page.getByRole('listitem').filter({ hasText: 'Write E2E tests' })).toBeVisible();
  });

  test('reads task details', async ({ page }) => {
    await page.goto('/tasks');
    await page.getByRole('link', { name: 'Write E2E tests' }).click();

    await expect(page.getByRole('heading', { name: 'Write E2E tests' })).toBeVisible();
    await expect(page.getByText('Cover all user flows')).toBeVisible();
  });

  test('updates an existing task', async ({ page }) => {
    await page.goto('/tasks');
    await page.getByRole('link', { name: 'Write E2E tests' }).click();
    await page.getByRole('button', { name: 'Edit' }).click();

    await page.getByLabel('Title').clear();
    await page.getByLabel('Title').fill('Write comprehensive E2E tests');
    await page.getByRole('button', { name: 'Save' }).click();

    await expect(page.getByText('Task updated')).toBeVisible();
    await expect(page.getByRole('heading', { name: 'Write comprehensive E2E tests' })).toBeVisible();
  });

  test('deletes a task with confirmation', async ({ page }) => {
    await page.goto('/tasks');
    await page.getByRole('link', { name: 'Write comprehensive E2E tests' }).click();
    await page.getByRole('button', { name: 'Delete' }).click();

    // Confirm deletion dialog
    await expect(page.getByRole('dialog')).toBeVisible();
    await expect(page.getByText('Are you sure')).toBeVisible();
    await page.getByRole('button', { name: 'Confirm' }).click();

    await expect(page.getByText('Task deleted')).toBeVisible();
    await expect(page.getByRole('listitem').filter({ hasText: 'Write comprehensive E2E tests' })).not.toBeVisible();
  });
});
```

## Multi-Step Wizard Flows

Test multi-page or multi-step forms where state must persist across steps.

```typescript
// Good: verify each step of a wizard with back navigation
test.describe('Checkout Wizard', () => {
  test('completes full checkout flow', async ({ page }) => {
    await page.goto('/checkout');

    // Step 1: Shipping
    await expect(page.getByText('Step 1 of 3')).toBeVisible();
    await page.getByLabel('Address').fill('123 Main St');
    await page.getByLabel('City').fill('Portland');
    await page.getByLabel('Zip code').fill('97201');
    await page.getByRole('button', { name: 'Continue' }).click();

    // Step 2: Payment
    await expect(page.getByText('Step 2 of 3')).toBeVisible();
    await page.getByLabel('Card number').fill('4111111111111111');
    await page.getByLabel('Expiry').fill('12/28');
    await page.getByLabel('CVC').fill('123');
    await page.getByRole('button', { name: 'Continue' }).click();

    // Step 3: Review
    await expect(page.getByText('Step 3 of 3')).toBeVisible();
    await expect(page.getByText('123 Main St')).toBeVisible();
    await expect(page.getByText('****1111')).toBeVisible();
    await page.getByRole('button', { name: 'Place order' }).click();

    // Confirmation
    await expect(page.getByRole('heading', { name: 'Order confirmed' })).toBeVisible();
    await expect(page.getByText('Order #')).toBeVisible();
  });

  test('preserves data when navigating back between steps', async ({ page }) => {
    await page.goto('/checkout');

    // Fill Step 1
    await page.getByLabel('Address').fill('123 Main St');
    await page.getByRole('button', { name: 'Continue' }).click();

    // Go to Step 2, then back
    await expect(page.getByText('Step 2 of 3')).toBeVisible();
    await page.getByRole('button', { name: 'Back' }).click();

    // Verify Step 1 data is preserved
    await expect(page.getByLabel('Address')).toHaveValue('123 Main St');
  });
});
```

## Full Example: Authenticated CRUD Flow

A complete test file demonstrating storageState reuse, page object integration, and CRUD testing.

```typescript
// tests/e2e/tasks.spec.ts
import { test, expect } from '@playwright/test';

// Use the authenticated project (storageState applied via config)
test.use({ storageState: './tests/.auth/user.json' });

test.describe('Task Management', () => {
  const uniqueTitle = `Task ${Date.now()}`;

  test('authenticated user can create, view, edit, and delete a task', async ({ page }) => {
    // Create
    await page.goto('/tasks');
    await page.getByRole('button', { name: 'New task' }).click();
    await page.getByLabel('Title').fill(uniqueTitle);
    await page.getByRole('button', { name: 'Create' }).click();
    await expect(page.getByText('Task created')).toBeVisible();

    // Read
    await page.getByRole('link', { name: uniqueTitle }).click();
    await expect(page.getByRole('heading', { name: uniqueTitle })).toBeVisible();

    // Update
    await page.getByRole('button', { name: 'Edit' }).click();
    await page.getByLabel('Title').clear();
    await page.getByLabel('Title').fill(`${uniqueTitle} (edited)`);
    await page.getByRole('button', { name: 'Save' }).click();
    await expect(page.getByText('Task updated')).toBeVisible();

    // Delete
    await page.getByRole('button', { name: 'Delete' }).click();
    await page.getByRole('button', { name: 'Confirm' }).click();
    await expect(page.getByText('Task deleted')).toBeVisible();
  });

  test('unauthenticated user is redirected to login', async ({ browser }) => {
    const context = await browser.newContext({ storageState: { cookies: [], origins: [] } });
    const page = await context.newPage();

    await page.goto('/tasks');
    await expect(page).toHaveURL('/login');

    await context.close();
  });
});
```

## Quick Reference

| Flow Pattern | Key Technique | Detect Rule |
|---|---|---|
| Authentication | `storageState` in global setup | Repeated login code across tests |
| Session persistence | `page.reload()` + re-assert | No reload test in auth suite |
| Logout | Assert redirect + re-visit protected route | Logout test missing redirect check |
| Form validation | Test empty, invalid, and valid inputs | Form test with only happy path |
| Form errors | `page.route()` to mock server errors | No server error test for form |
| Navigation | Assert URL + DOM content together | `toHaveURL` without DOM assertion |
| Back/Forward | `page.goBack()` / `page.goForward()` | No history navigation tests |
| Deep links | Direct `page.goto('/path/id')` | All tests navigate via UI only |
| Search | Test results + empty state | Search test without empty state |
| Filters | Chain multiple filters, verify count | Single filter test only |
| CRUD create | Fill form + assert in list | No list assertion after create |
| CRUD update | Clear + refill + assert updated text | No content assertion after edit |
| CRUD delete | Confirmation dialog + assert removed | Delete without confirmation test |
| Multi-step wizard | Assert step indicator + data preservation | No back-navigation test in wizard |
| Test isolation | `Date.now()` or UUID for unique data | Hardcoded test data strings |
