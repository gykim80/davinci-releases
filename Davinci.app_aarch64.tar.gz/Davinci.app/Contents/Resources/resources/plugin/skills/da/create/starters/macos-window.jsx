/**
 * macos-window.jsx - macOS Window Chrome
 *
 * Provides: MacosWindow with traffic light buttons, title bar, and content area.
 */

function MacosWindow({ title = "Untitled", width = 900, height = 600, dark = false, children }) {
  const bgChrome = dark ? "#2d2d2d" : "#e8e8e8";
  const bgContent = dark ? "#1e1e1e" : "#fff";
  const textColor = dark ? "#ccc" : "#4d4d4d";

  const windowStyles = {
    width,
    maxWidth: "100%",
    borderRadius: 10,
    overflow: "hidden",
    boxShadow: dark
      ? "0 22px 70px rgba(0,0,0,0.6)"
      : "0 22px 70px rgba(0,0,0,0.15), 0 0 0 1px rgba(0,0,0,0.05)",
    margin: "0 auto",
  };

  const titleBarStyles = {
    height: 38,
    background: bgChrome,
    display: "flex",
    alignItems: "center",
    padding: "0 12px",
    position: "relative",
    borderBottom: dark ? "1px solid #3d3d3d" : "1px solid #d5d5d5",
    WebkitUserSelect: "none",
  };

  const trafficLights = [
    { bg: "#FF5F57", hover: "#E0443E" },
    { bg: "#FEBC2E", hover: "#DEA123" },
    { bg: "#28C840", hover: "#1AAB29" },
  ];

  const contentStyles = {
    background: bgContent,
    height: height - 38,
    overflow: "auto",
    position: "relative",
  };

  return (
    <div style={windowStyles}>
      <div style={titleBarStyles}>
        <div style={{ display: "flex", gap: 8 }}>
          {trafficLights.map((light, i) => (
            <div key={i} style={{
              width: 12, height: 12, borderRadius: "50%",
              background: light.bg,
              border: dark ? "none" : "0.5px solid rgba(0,0,0,0.1)",
            }} />
          ))}
        </div>
        <span style={{
          position: "absolute",
          left: "50%",
          transform: "translateX(-50%)",
          fontSize: 13,
          fontWeight: 500,
          color: textColor,
          fontFamily: "-apple-system, BlinkMacSystemFont, sans-serif",
        }}>
          {title}
        </span>
      </div>
      <div style={contentStyles}>
        {children}
      </div>
    </div>
  );
}

window.MacosWindow = MacosWindow;
