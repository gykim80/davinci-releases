<!--
Source: op7418/guizang-ppt-skill (Apache-2.0)
Original: https://github.com/op7418/guizang-ppt-skill
Copyright (c) op7418. Licensed under Apache-2.0.
Modifications: Adapted for davinci-framework — Korean comments + PPTX Iron Law conflict notes.
-->

# 품질 검증 체크리스트 (Quality Assurance Checklist)

> 원본: op7418/guizang-ppt-skill `references/checklist.md`
>
> 생성 전 통독, 생성 후 항목별 자기검증.
> **davinci 추가 항목**: PPTX Iron Law 충돌 섹션이 P0에 추가되어 있습니다.

---

## ★ davinci PPTX Iron Law 충돌 항목 (P0 — PPTX export 전 필수 확인)

> guizang-ppt-skill 원본은 단일 HTML 수평 스와이프 출력용으로 설계됩니다.
> davinci-framework는 PPTX export(pptxgenjs)를 지원하므로 아래 항목을 반드시 확인하세요.
> **Web Preview는 허용, PPTX Export는 금지**인 요소들입니다.

### Iron Law #4 — Gradient 금지
- `linear-gradient()`, `radial-gradient()`, `conic-gradient()` PPTX export 불가
- 대체: solid color (`background: var(--ink)` 등)
- ⚠️ slide::before, slide::after의 gradient overlay는 web preview 전용

### Iron Law #6 — SVG / Canvas / Video 금지
- `<svg>`, `<canvas>`, `<video>`, `<audio>` 요소 PPTX export 불가
- WebGL 배경 (`canvas#bg-dark`, `canvas#bg-light`): web preview 전용
  → PPTX export 시: 정적 스크린샷 이미지로 우회 (Wave 3 자동 캡처 예정)
- Lucide SVG 아이콘: web preview 전용 → PPTX 시 `<img>` 래스터화 필요
- ⚠️ WebGL hero 페이지를 PPTX에 포함할 경우 반드시 PPTX export 담당자에게 우회 방법 명시

### Iron Law #5 — Transform 제한
- `transform: rotate()` 만 허용
- `skew()`, `scale()`, `perspective()`, `matrix()` PPTX export 불가

### Iron Law #3 — 텍스트 태그 제한
- 모든 텍스트는 `<p>`, `<h1>`-`<h6>`, `<li>` 내에만 배치
- `<div>`, `<span>` 직속 텍스트 노드는 PPTX에서 무시됨

### Iron Law #2 — 슬라이드 래핑
- 모든 슬라이드는 `<section class="slide">` 로 래핑 필수

### Iron Law #8 — box-shadow 제한
- `inset` box-shadow PPTX export 불가 → outer shadow만 사용

### Iron Law #15 — Theme/Layout Determinism (davinci 전용)
- 테마: `resources/themes.md`의 5개 중 1개만 선택
- 레이아웃: `resources/layouts.md`의 10개 중에서만 선택
- 임의 색상/레이아웃 즉흥 생성 금지
- 사용자가 5개 외 테마 요청 시: "5개 잠금 테마 — 다음 중 선택해주세요"로 응답
---

## P0 — 절대 하면 안 되는 오류 (Critical Errors)

### 0. 생성 전 클래스명 검증 (가장 중요)
- 생성 전 반드시 `template.html`의 `<style>` 블록을 읽어 layouts.md에서 쓰는 클래스가 모두 정의되어 있는지 확인
- 자주 누락되는 클래스: `h-hero` / `h-xl` / `h-sub` / `h-md` / `lead` / `meta-row` / `stat-card` / `stat-label` / `stat-nb` / `stat-unit` / `stat-note` / `pipeline-section` / `pipeline-label` / `pipeline` / `step` / `step-nb` / `step-title` / `step-desc` / `grid-2-7-5` / `grid-2-6-6` / `grid-2-8-4` / `grid-3-3` / `frame` / `img-cap` / `callout-src`
- 클래스 누락 시 `template.html`의 `<style>`에 보완 (각 슬라이드 inline 재작성 금지)

### 1. 이모지 아이콘 사용 금지
- 중국/한국 잡지풍에서 이모지(🎯 💡 ✅)는 격조를 즉시 파괴
- Lucide 아이콘 CDN으로 대체: `<i data-lucide="target" class="ico-md"></i>`
- ⚠️ PPTX: Lucide SVG는 web preview 전용 — PPTX export 시 래스터화 필요

### 2. 이미지 크롭 규칙
- 이미지는 **아래만** 잘린다 — 좌우/상단 절대 불가
- `object-fit:cover + object-position:top` 적용 필수
- 그리드 내: `height:Nvh` 고정 (aspect-ratio 사용 금지)
- 잘못된 예: `<figure style="aspect-ratio:2592/1798">` → 표준 비율로 교체

### 3. 대제목 글자 수 제한
- `h-hero`: 10vw, 제목 5자 이하
- `h-xl`: 6vw-7vw
- 긴 제목은 `<br>` 수동 줄바꿈 사용

### 4. 폰트 분업 준수
- 대제목, 핵심 인용, 숫자 대자 → **세리프** (Noto Serif SC / Playfair Display)
- 본문, 설명, 파이프라인 단계명 → **비세리프** (Noto Sans SC / Inter)
- 메타데이터, 코드, 레이블 → **모노스페이스** (IBM Plex Mono)

### 5. 이미지 두꺼운 테두리/그림자 금지
- 최대 1-4px 미세 둥근 모서리 + 극히 미약한 노이즈만
- `box-shadow` 금지, `border` 금지 (1px 극담 회색 외)
- ⚠️ PPTX: inset box-shadow 금지 (Iron Law #8)
---

## P1 — 레이아웃 리듬 (Layout Rhythm)

### 6. Hero / Non-Hero 교차
- 연속 2 hero → 피로감. 연속 4 non-hero → 리듬 사망
- 권장: Hero Cover → Act Divider (hero) → 3-4 non-hero → Act Divider ...

### 7. 데이터 대자보 + 밀집 페이지 교차
- 큰 숫자 페이지 ↔ Pipeline/이미지 그리드 교차로 청중 눈 보호

### 8. 용어 일관성
- 영문/한국어 혼용 시 동일 개념은 동일 표기 유지
- 하드 번역 지양 (Skills → "기술" 대신 "Skills" 유지)

### 9. 테마 리듬 규칙
- 연속 3페이지 동일 테마 금지
- 8페이지 이상: hero dark + hero light 각 1개 이상 필수
- 전체 light만 금지 — dark 정문 페이지 1개 이상 필수
- 모든 slide에 명시적 테마 클래스 필수 (`light`/`dark`/`hero light`/`hero dark`)
---

## P2 — 시각 마감 (Visual Polish)

### 10. WebGL 배경 오버레이 투명도
- dark hero: 오버레이 12-15% (WebGL 충분히 투과)
- light hero: 오버레이 16-20% (WebGL 은은하게)
- 일반 light/dark: 오버레이 92-95% (거의 불투명)
- ⚠️ PPTX: WebGL 배경 자체가 정적 이미지로 우회됨

### 11. Light Hero의 WebGL 셰이더
- Spiral Vortex, 방사형 잔물결은 light 테마에서 과도하게 노출됨
- FBM 도메인 워핑 기반 무중심 흐름 권장

### 12. 이미지 미세 둥근 모서리
- 모든 `.frame-img`에 `border-radius:4px` — 최대 8px 초과 금지

### 13. 좌문우도 정렬
- 좌열 flex column + `justify-content:space-between`
- 우열 이미지 자연 상단 정렬 — `align-self:end` 절대 금지
- 우열 이미지 필요 시 `margin-top:7vh~9vh`로 본문 영역에 맞춤
---

## 최종 자기검증 체크리스트 (Final Self-Audit)

```
★ davinci PPTX Iron Law (생성 전)
  □ gradient 사용 없음 (Iron Law #4)
  □ SVG/canvas/video 슬라이드 내 없음 (Iron Law #6)
  □ WebGL hero → PPTX 우회 방법 명시됨
  □ 모든 텍스트 p/h*/li 내에 위치 (Iron Law #3)
  □ 테마: resources/themes.md 5개 중 선택 (Iron Law #15)
  □ 레이아웃: resources/layouts.md 10개 중 선택 (Iron Law #15)

예비검사 (생성 전)
  □ template.html <style> 읽어 필요 클래스 확인 완료
  □ 각 슬라이드 레이아웃(1-10) 결정 완료
  □ 테마 리듬표 작성: 각 페이지 hero dark/light/dark/light 명시
  □ 리듬표 하드 규칙 충족: 연속 3페이지 동일 테마 없음 / hero 각 1개 이상
  □ <title> 실제 덱 제목으로 수정됨

콘텐츠
  □ 각 막의 페이지 비율 균형
  □ 이모지 아이콘 미사용
  □ 용어 통일
  □ 각 페이지 kicker + 제목 + 본문 3단계 정보 명확

레이아웃
  □ 대제목 1자 1행 줄바꿈 없음
  □ 이미지 그리드: height:Nvh 사용 (aspect-ratio 없음)
  □ 이미지 상단/좌우 완전, 하단만 크롭
  □ 세리프/비세리프 분공 준수
  □ Pipeline 그룹 간 명확한 구분

시각
  □ hero/non-hero 교차
  □ WebGL 배경이 hero 페이지에서 보임
  □ 이미지 border-radius 4-8px
  □ 두꺼운 그림자/테두리 없음

애니메이션
  □ assets/motion.min.js 존재 (로컬 폴백)
  □ 각 페이지 data-anim 마커 존재
  □ 대인용 페이지: data-animate="quote" + 줄별 data-anim="line"
  □ Before/After: data-animate="directional" + left/right
  □ Pipeline: data-animate="pipeline" + data-anim="step"
```
