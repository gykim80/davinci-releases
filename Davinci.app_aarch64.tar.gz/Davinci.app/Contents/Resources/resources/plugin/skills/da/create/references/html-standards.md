# HTML Output Standards

> Reference document for da:create Phase 3.
> Defines CDN pinning, Tweaks markers, postMessage protocol, and file conventions.

## CDN Pinning (EXACT VERSIONS - DO NOT CHANGE)

### Required (every HTML artifact)
```html
<!-- React 18.3.1 -->
<script src="https://unpkg.com/react@18.3.1/umd/react.development.js"
  crossorigin="anonymous"></script>
<script src="https://unpkg.com/react-dom@18.3.1/umd/react-dom.development.js"
  crossorigin="anonymous"></script>

<!-- Babel 7.29.0 (JSX transpilation) -->
<script src="https://unpkg.com/@babel/standalone@7.29.0/babel.min.js"
  crossorigin="anonymous"></script>
```

### Optional (add only when needed)
```html
<!-- Recharts 2.15.0 (data visualization) -->
<script src="https://unpkg.com/recharts@2.15.0/umd/Recharts.min.js"
  crossorigin="anonymous"></script>

<!-- Lucide React 0.460.0 (icons) -->
<script src="https://unpkg.com/lucide-react@0.460.0/dist/umd/lucide-react.min.js"
  crossorigin="anonymous"></script>

<!-- Google Fonts (choose distinctive fonts) -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&display=swap"
  rel="stylesheet">
```

## Tweaks EDITMODE Markers

Every HTML artifact MUST include Tweaks markers for real-time editing:

```javascript
// Wrap adjustable defaults in EDITMODE markers
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "primaryColor": "oklch(65% 0.25 250)",
  "accentColor": "oklch(70% 0.2 150)",
  "fontSize": 16,
  "borderRadius": 8,
  "dark": false,
  "variant": "default",
  "heroTitle": "Build faster.",
  "heroSubtitle": "Ship with confidence."
}/*EDITMODE-END*/;
```

### Marker Rules
- `/*EDITMODE-BEGIN*/` and `/*EDITMODE-END*/` wrap a single JSON object
- Keys map to Tweaks panel controls automatically:
  - String starting with `#` or `oklch` -> ColorPicker
  - Number -> Slider (infer min/max from context)
  - Boolean -> Toggle switch
  - String (other) -> TextInput
  - String matching known enum -> Dropdown

### Multi-Variation via Tweaks
```javascript
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "variant": "conservative",  // "conservative" | "default" | "experimental"
  // ... other tweaks
}/*EDITMODE-END*/;

// Use variant to conditionally render different styles
const variantStyles = {
  conservative: { borderRadius: 4, fontSize: 14 },
  default: { borderRadius: 8, fontSize: 16 },
  experimental: { borderRadius: 20, fontSize: 18 },
};
const activeStyle = variantStyles[TWEAK_DEFAULTS.variant];
```

## postMessage Protocol

### From HTML artifact -> davinci-gui (parent)
```javascript
// Determine parent origin at runtime (same-origin) or fallback
var __parentOrigin = '*';
try { if (window.parent !== window) __parentOrigin = window.parent.location.origin; } catch(e) {}

// Signal that Tweaks are available
window.parent.postMessage({ type: '__edit_mode_available' }, __parentOrigin);

// Report current tweaks values
window.parent.postMessage({
  type: '__edit_mode_values',
  value: TWEAK_DEFAULTS
}, __parentOrigin);

// Report element click for Point-and-Prompt
window.parent.postMessage({
  type: '__element_clicked',
  value: {
    dom: 'div.hero > h1.title',
    react: 'App > HeroSection > Title',
    screenLabel: 'Screen 1',
    rect: { x, y, width, height },
  }
}, __parentOrigin);
```

### From davinci-gui (parent) -> HTML artifact
```javascript
window.addEventListener('message', (e) => {
  // Origin 검증: parent로부터 온 메시지만 처리
  if (__parentOrigin !== '*' && e.origin !== __parentOrigin && e.origin !== 'null' && e.origin !== '') return;
  switch (e.data.type) {
    case '__activate_edit_mode':
      // Show inline Tweaks UI overlay
      break;
    case '__deactivate_edit_mode':
      // Hide inline Tweaks UI overlay
      break;
    case '__edit_mode_set_keys':
      // Apply tweaks: e.data.value = { key: newValue, ... }
      Object.assign(TWEAK_DEFAULTS, e.data.value);
      // Trigger React re-render
      break;
    case '__viewport_resize':
      // e.data.value = { width, height }
      break;
  }
});
```

## File Conventions

### Naming
```
.davinci/artifacts/{sessionId}/{PageName}.html
.davinci/artifacts/{sessionId}/{PageName} v2.html  (major revision)
.davinci/artifacts/{sessionId}/shared.js            (shared modules)
```

### data-screen-label (MANDATORY)
```html
<!-- Every top-level section gets a label -->
<section data-screen-label="Screen 1">
  <!-- Hero content -->
</section>
<section data-screen-label="Screen 2">
  <!-- Features content -->
</section>
```

### Scope-Safe Naming
```javascript
// CORRECT - scoped names
const heroStyles = { background: 'oklch(15% 0.05 250)' };
const featureCardStyles = { borderRadius: 12 };
const footerStyles = { padding: '48px 24px' };

// WRONG - generic names cause conflicts
const styles = { ... };
const data = [ ... ];
const config = { ... };
```

### 1000-Line Limit
If a file approaches 1000 lines:
1. Extract reusable components to `shared.js`
2. Use `window.SharedComponents = { ComponentA, ComponentB }`
3. Load shared.js before the main script
```html
<script src="shared.js"></script>
<script type="text/babel">
  const { ComponentA, ComponentB } = window.SharedComponents;
</script>
```
