# Email Newsletter Layout (R4 mitigation)

**Email-client-safe HTML.** Gmail, Outlook 2016+, Apple Mail, Yahoo, Naver Mail, Daum.

Pair with: `assets/template-email-newsletter.html` (table-based, inline CSS).

> **R4 (Email 클라이언트 호환성)** — 이 레이아웃의 모든 규칙은 R4 risk를 해소하기 위해 강제된다. 위반 시 일부 클라이언트에서 깨진다.

## Pre-flight

1. **Read `assets/template-email-newsletter.html`** — table-based scaffold.
2. **Inline CSS only.** Every style attribute lives on the element. `<style>` blocks are dropped by Gmail.
3. **No flexbox / grid / oklch.** Tables for layout, hex for colors.
4. **600px desktop / fluid mobile** via inline `style="width:100%; max-width:600px"`.

## Trigger keywords

- Korean: `뉴스레터`, `이메일`, `메일`, `이메일 뉴스레터`, `메일 매거진`
- English: `newsletter`, `email`, `mail`, `email newsletter`, `EDM`

When matched, set `vertical=email-newsletter` and load this file + `assets/template-email-newsletter.html`.

## Mandatory technical rules

| Rule | Reason |
|---|---|
| Tables for layout (`<table role="presentation">`) | Outlook 2016+ ignores `<div>` width on Windows |
| Inline CSS on every element | Gmail strips `<style>` in some contexts |
| Hex colors only (no oklch / lab / lch / hsl) | Older clients drop modern color spaces |
| `<img>` with explicit `width` and `height` attrs | Outlook bloats unsized images |
| `width="100%" style="..."` belt-and-braces | Some clients honor attribute, some honor style |
| `<a>` with explicit color inline | Default link color varies wildly |
| No `position`, no `flex`, no `grid` | Unsupported in Outlook |
| `@media` allowed but optional fallback | Gmail mobile honors media queries; treat as enhancement |

## Token spec (hex fallback)

```text
--bg:        #f4f5f7
--surface:   #ffffff
--text:      #1a1a1a
--muted:     #6b7280
--accent:    #4f46e5
--rule:      #e5e7eb
--cta-bg:    #4f46e5
--cta-fg:    #ffffff
```

Dark mode (Apple Mail / iOS Mail / Outlook 2016+):
```css
@media (prefers-color-scheme: dark) {
  /* clients that respect this swap brand colors automatically */
}
```

## Section archetype

1. **Preheader** (hidden span) — first visible text in inbox preview, "이번 주 핵심 한 줄..."
2. **Header** — Logo (60-120px max-width) + brand title + issue number/date.
3. **Headline + Intro** — "이번 호 한 줄 요약" + 2-3 sentences from author.
4. **Articles (1-3)** — Each: image (16:9, max 600w) + heading + 2-3 line excerpt + "Read more" button.
5. **Divider** — 1px hex line, 32-48px vertical padding.
6. **Footer** — Plain-text address, **unsubscribe link (mandatory by law)**, social icons, "왜 이 메일을 받으셨나요?" copy.

## P0 Checklist (must pass — R4)

- [ ] Inline CSS on every styled element (no external stylesheet, no `<style>` for layout).
- [ ] Table-based layout only (`<table role="presentation" width="100%" cellspacing="0" cellpadding="0">`).
- [ ] Every `<img>` has `alt`, `width`, `height` attrs and inline display style.
- [ ] **Unsubscribe link in footer** (legal requirement: 정보통신망법 / CAN-SPAM / GDPR).
- [ ] Plaintext fallback hint comment near top: `<!-- Plain-text fallback should mirror this content -->`.
- [ ] Hex colors only — no oklch/lab/lch.
- [ ] Outer table 100% width, inner table fixed 600px centered.

## P1 Checklist (should pass)

- [ ] **Preheader** text present (first 90 chars visible in inbox list).
- [ ] **Dark mode email** — `@media (prefers-color-scheme: dark)` swaps brand colors gracefully.
- [ ] Web-safe fonts only (`-apple-system, "Segoe UI", Arial, sans-serif`). No web fonts.
- [ ] CTA buttons rendered as `<a>` styled like buttons (some clients ignore `<button>`).
- [ ] Bulletproof button: `<table>` wrapper around CTA for Outlook button rendering.
- [ ] Reply-to header note (in HTML comment): "Use real reply-to, not no-reply@".

## P2 Checklist (nice to have)

- [ ] **Litmus / Email on Acid mock test** before send (R4 mitigation).
- [ ] Animated GIFs first frame contains key message (Outlook shows only frame 1).
- [ ] AMP for Email progressive enhancement (optional, drop if not needed).
- [ ] List-Unsubscribe HTTP header note in send instructions.
- [ ] UTM params on tracked links.

## Korean / US format note

- **Korean**: 발신인 이름 (한글 가능), reply-to 실제 사람, 사업자정보 + 주소 푸터 필수 (정보통신망법 50조).
- **US**: from-name + reply-to convention, physical mailing address mandatory (CAN-SPAM Act §5).

## Anti-patterns (do NOT)

- `<style>` block for critical layout (Gmail strips it).
- `display: flex` or `display: grid`.
- `oklch()` / `lab()` / `lch()` / CSS custom properties for colors.
- Background image on body (Outlook ignores).
- Web font `@import` (slows render, often blocked).
- Missing unsubscribe link (legal violation).
