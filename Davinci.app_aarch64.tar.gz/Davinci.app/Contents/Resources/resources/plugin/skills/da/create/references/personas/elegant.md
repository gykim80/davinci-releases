# Persona: Elegant

## Visual Identity
- **Philosophy**: "Refined sophistication" — gold/cream, serif mix, smooth transitions
- **Spacing**: Wide. Conveys luxury and spaciousness
- **Colors**: Muted tones. Gold/cream/olive/charcoal. Low-saturation accent
- **Typography**: Serif headings (Playfair Display, Cormorant) + sans-serif body
- **Borders**: Thin gold/cream lines. Minimize dividers

## Motion Strategy
- **Speed**: slow/elegant (400-600ms)
- **Types**: Fade + subtle translate. Smooth parallax
- **Frequency**: Minimal. Page entry + section transitions only
- **Easing**: ease-in-out (symmetrical, graceful)

## Component Overrides
- Cards: Thin border, subtle shadow, border color change only on hover
- Buttons: Thin border + transparent background. Fill on hover
- Headings: Serif + italic combination. Wide letter-spacing
- Images: Maintain aspect-ratio, clean without overlay

## Anti-Patterns (forbidden for this persona)
- No neon/glow effects
- No primary colors (pure red, blue, green)
- No bounce/spring animations
- No rounded corners (rounded-full)
- No heavy shadows

## Token Adjustments
```css
:root { /* elegant persona overrides */
  --space-section: clamp(5rem, 4rem + 6vw, 10rem);
  --motion-duration-normal: 400ms;
  --motion-ease-out: cubic-bezier(0.25, 0.1, 0.25, 1); /* smooth deceleration */
}
```
