---
name: analyze
description: Code analysis across quality, security, performance, and architecture domains
agent: code-analyzer
agents: [code-analyzer, security-architect, qa-strategist]
davinci-phase: null
allowed-tools: [Read, Glob, Grep, Bash, Write, Task, AskUserQuestion]
next-skill: null
skill-type: flexible
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 검증자: items[] 기반 match rate와 4값 verdict(MET/NOT_MET/BLOCKED/IMPOSSIBLE)를 handoff에 포함. 생성자와 다른 컨텍스트에서 실행된다.

## Tool Parameter Rules -> See CLAUDE.md (ABSOLUTE)
# /da:analyze - Comprehensive Code Analysis

ultrathink


## Purpose
Comprehensive code analysis covering quality metrics, security vulnerabilities, performance bottlenecks, and architecture assessment.

## Usage
```
/da:analyze [target-path] [--focus quality|security|performance|architecture|all]
```

## Analysis Domains

### Quality Analysis
- Code complexity metrics (cyclomatic, cognitive)
- Test coverage gaps
- Code duplication detection
- Error handling completeness
- Documentation quality

### Security Analysis
- OWASP Top 10 vulnerability patterns
- Input validation gaps
- Authentication/authorization issues
- Data exposure risks
- Dependency vulnerabilities

### Performance Analysis
- Algorithm complexity (Big O)
- Database query efficiency
- Bundle size and code splitting
- Memory leak patterns
- Rendering performance (frontend)

### Architecture Analysis
- Design pattern compliance
- Component coupling and cohesion
- Dependency direction validation
- Layer violation detection
- API contract consistency

## Behavioral Flow

### Phase 1: Scope and Scan
```yaml
1. Target_Identification:
   - Determine files/directories to analyze
   - Detect primary language and framework
   - Select relevant analysis rules

2. Static_Analysis:
   - Run linters (ruff for Python, ESLint for JS/TS)
   - Check type safety
   - Identify code smells
```

### Phase 2: Deep Analysis
```yaml
1. Semantic_Analysis:
   - Pattern matching against anti-patterns
   - Framework best practice verification
   - Architecture compliance check

2. Evidence_Collection:
   - Run relevant tests
   - Measure performance metrics
   - Check security advisories
```

### Phase 3: Report
```yaml
1. Findings:
   - Categorize by severity (Critical/High/Medium/Low)
   - Group by domain (Security/Performance/Quality/Architecture)
   - Provide evidence and fix recommendations

2. Output:
   - Structured report with actionable items
   - Priority-ordered fix suggestions
```

> MCP Routing: See CLAUDE.md

## Over-Engineering Lens (과잉 설계 진단)

품질 분석에 "과잉 설계" 관점을 포함한다. 부족함만큼 **불필요한 복잡성**도 결함이다.
근거 규칙은 `davinci-plugin/rules/lean-mode.md` 참조.

점검 항목:
- 구현체가 하나뿐인 인터페이스/추상 클래스, 산출물이 하나뿐인 팩토리
- 절대 안 바뀌는 값을 위한 설정/플래그
- 표준 라이브러리·네이티브 기능으로 대체 가능한 커스텀 코드 (예: 직접 만든 date picker → `<input type="date">`)
- 몇 줄로 될 일에 추가된 의존성
- "나중을 위한" 스캐폴딩/빈 레이어
- 코드보다 긴 방어성 주석/설명

산출: 도메인이 quality 또는 all일 때, 발견된 과잉 설계 항목을 **삭제 후보 리스트**로
보고한다(파일:라인 + 더 단순한 대안 한 줄). 자동 삭제는 하지 않는다(`/da:clean`/`/da:improve`로).
단, lean-mode 불가침 영역(검증·보안·접근성·요청된 기능/테스트)은 "과잉"으로 표시하지 않는다.

## Boundaries

**Will:**
- Provide evidence-based analysis with citations
- Identify issues with severity and impact assessment
- Recommend prioritized fixes

**Will Not:**
- Apply fixes automatically (use /da:improve for that)
- Make claims without supporting evidence
