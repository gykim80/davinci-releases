# Mobile Screen Layouts

**6 screen archetypes.** Paste into `<main class="content">` of `assets/template-mobile.html`. A mobile screen does ONE job. If the brief combines two, ship one and offer the other as follow-up.

## Pre-flight

1. **Read `assets/template-mobile.html`** through `<style>`. Device frame, Dynamic Island, status bar, tab bar are already drawn.
2. **Read the active DESIGN.md** -- map tokens to the six `:root` variables in the seed.
3. **Pick exactly one archetype** per artifact.

## Archetype selection

| Brief language | Use |
|---|---|
| feed, inbox, timeline, list, messages, notifications | A -- Feed |
| article, post, item, recipe, product detail | B -- Detail |
| sign-up, welcome, intro, walkthrough | C -- Onboarding |
| profile, account, user page, bio | D -- Profile |
| checkout, payment, order, form, settings | E -- Checkout |
| timer, map, dashboard widget, big number | F -- Focus |

---

## A -- Feed

List of items with avatar, title, and meta. Drop the `<nav class="tabbar">` only if brief says no tabs.

```html
<div class="screen-header">
  <h1 class="screen-title">[REPLACE] Feed Title</h1>
</div>
<div class="screen-body">
  <div class="mobile-card">
    <div class="mobile-row">
      <div class="mobile-avatar">[REPLACE]</div>
      <div style="flex:1; min-width:0;">
        <p style="margin:0; font-weight:600; font-size:15px;">[REPLACE] Item title</p>
        <p style="margin:2px 0 0; font-size:13px; color:var(--muted);">[REPLACE] Subtitle or timestamp</p>
      </div>
    </div>
  </div>
  <div class="mobile-card">
    <div class="mobile-row">
      <div class="mobile-avatar">[REPLACE]</div>
      <div style="flex:1; min-width:0;">
        <p style="margin:0; font-weight:600; font-size:15px;">[REPLACE] Item title</p>
        <p style="margin:2px 0 0; font-size:13px; color:var(--muted);">[REPLACE] Subtitle or timestamp</p>
      </div>
    </div>
  </div>
  <div class="mobile-card">
    <div class="mobile-row">
      <div class="mobile-avatar">[REPLACE]</div>
      <div style="flex:1; min-width:0;">
        <p style="margin:0; font-weight:600; font-size:15px;">[REPLACE] Item title</p>
        <p style="margin:2px 0 0; font-size:13px; color:var(--muted);">[REPLACE] Subtitle or timestamp</p>
      </div>
    </div>
  </div>
</div>
```

## B -- Detail

Full-width hero image, title, body text. Drop the tab bar for this archetype.

```html
<div class="ph-img" style="aspect-ratio:16/10; border-radius:0; margin: 0 calc(var(--gap-md) * -1);">[ Hero image ]</div>
<div class="screen-header" style="padding-top: var(--gap-md);">
  <h1 class="screen-title">[REPLACE] Detail Title</h1>
  <p style="margin:8px 0 0; font-size:13px; color:var(--muted);">[REPLACE] Author or date</p>
</div>
<div class="screen-body">
  <p style="margin:0 0 var(--gap-md); line-height:1.6;">[REPLACE] Body text -- two to three paragraphs of real content.</p>
  <button class="mobile-btn mobile-btn-primary" style="width:100%;">[REPLACE] Action</button>
</div>
```

## C -- Onboarding

Centered illustration area, headline, subtext, primary CTA. Drop the tab bar for this archetype.

```html
<div style="flex:1; display:flex; flex-direction:column; justify-content:center; align-items:center; text-align:center; padding: var(--gap-xl) var(--gap-md);">
  <div class="ph-img square" style="width:200px; margin-bottom:var(--gap-xl);">[ Illustration ]</div>
  <h1 class="screen-title" style="font-size:24px;">[REPLACE] Welcome headline</h1>
  <p style="margin:12px 0 var(--gap-xl); color:var(--muted); font-size:15px; max-width:28ch;">[REPLACE] One sentence of value proposition.</p>
  <button class="mobile-btn mobile-btn-primary" style="width:100%; max-width:300px;">[REPLACE] Get Started</button>
  <button class="mobile-btn mobile-btn-secondary" style="width:100%; max-width:300px; margin-top:var(--gap-sm);">[REPLACE] Skip</button>
</div>
```

## D -- Profile

Avatar, name, stats row, action buttons, content list.

```html
<div style="text-align:center; padding:var(--gap-md) 0 var(--gap-lg);">
  <div class="mobile-avatar" style="width:80px; height:80px; font-size:28px; margin:0 auto var(--gap-md);">[REPLACE]</div>
  <h1 class="screen-title" style="font-size:22px;">[REPLACE] Display Name</h1>
  <p style="margin:4px 0 0; font-size:14px; color:var(--muted);">@[REPLACE] handle</p>
</div>
<div style="display:flex; justify-content:space-around; padding:var(--gap-md) 0; border-top:1px solid var(--border); border-bottom:1px solid var(--border);">
  <div style="text-align:center;">
    <p style="margin:0; font-weight:700; font-family:var(--font-mono);">[REPLACE]</p>
    <p style="margin:2px 0 0; font-size:12px; color:var(--muted);">Posts</p>
  </div>
  <div style="text-align:center;">
    <p style="margin:0; font-weight:700; font-family:var(--font-mono);">[REPLACE]</p>
    <p style="margin:2px 0 0; font-size:12px; color:var(--muted);">Followers</p>
  </div>
  <div style="text-align:center;">
    <p style="margin:0; font-weight:700; font-family:var(--font-mono);">[REPLACE]</p>
    <p style="margin:2px 0 0; font-size:12px; color:var(--muted);">Following</p>
  </div>
</div>
<div class="screen-body" style="padding-top:var(--gap-md);">
  <button class="mobile-btn mobile-btn-primary" style="width:100%;">[REPLACE] Follow</button>
</div>
```

## E -- Checkout

Form fields stacked vertically with clear labels. Drop the tab bar for this archetype.

```html
<div class="screen-header">
  <h1 class="screen-title" style="font-size:22px;">[REPLACE] Checkout Title</h1>
</div>
<div class="screen-body">
  <div style="margin-bottom:var(--gap-md);">
    <label style="font-size:13px; color:var(--muted); display:block; margin-bottom:4px;">[REPLACE] Label</label>
    <input type="text" placeholder="[REPLACE]" style="width:100%; padding:12px 14px; border:1px solid var(--border); border-radius:var(--radius); background:var(--surface); font-size:16px; min-height:44px;">
  </div>
  <div style="margin-bottom:var(--gap-md);">
    <label style="font-size:13px; color:var(--muted); display:block; margin-bottom:4px;">[REPLACE] Label</label>
    <input type="text" placeholder="[REPLACE]" style="width:100%; padding:12px 14px; border:1px solid var(--border); border-radius:var(--radius); background:var(--surface); font-size:16px; min-height:44px;">
  </div>
  <div class="mobile-card" style="margin-top:var(--gap-lg);">
    <div style="display:flex; justify-content:space-between; margin-bottom:8px;">
      <span style="color:var(--muted);">Total</span>
      <span style="font-weight:700; font-family:var(--font-mono);">[REPLACE] $0.00</span>
    </div>
  </div>
  <button class="mobile-btn mobile-btn-primary" style="width:100%; margin-top:var(--gap-md);">[REPLACE] Pay Now</button>
</div>
```

## F -- Focus

Single big number or hero card, centered. Minimal UI, maximum impact.

```html
<div style="flex:1; display:flex; flex-direction:column; justify-content:center; align-items:center; text-align:center; padding:var(--gap-xl) var(--gap-md);">
  <p style="font-family:var(--font-mono); font-size:12px; letter-spacing:0.08em; text-transform:uppercase; color:var(--accent); margin:0 0 var(--gap-md);">[REPLACE] Label</p>
  <p style="font-family:var(--font-display); font-size:72px; font-weight:700; line-height:0.95; letter-spacing:-0.04em; color:var(--accent); margin:0;">[REPLACE]</p>
  <p style="margin:var(--gap-md) 0 0; font-size:15px; color:var(--muted); max-width:24ch;">[REPLACE] Context sentence.</p>
</div>
<div style="padding:0 var(--gap-md) var(--gap-md);">
  <button class="mobile-btn mobile-btn-primary" style="width:100%;">[REPLACE] Action</button>
</div>
```

---

## Rules

- **Touch targets >= 44x44px.** All interactive elements.
- **Safe area insets.** Status bar and home indicator areas are protected by the seed frame.
- **Accent budget = 2.** One active tab + one primary action.
- **Display in serif** via `var(--font-display)` for screen titles.
- **No external images** -- use `.ph-img` placeholders.
