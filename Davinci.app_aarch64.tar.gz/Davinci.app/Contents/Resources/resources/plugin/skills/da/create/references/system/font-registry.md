# Font Registry — da:design v3 Typography System

> 10 English Display fonts + pre-registered Korean fonts from noonnu.cc organized by category.
> Automatically selects the right combination based on project character during Creative Brief Phase 1.5.

---

## 1. English Display Fonts (dedicated to English headlines/hero)

> **Purpose**: Applied to the `--font-display` variable for h1, h2 hero/section titles.
> **Rule**: Fonts not on Google Fonts are loaded via local @font-face or CDN.
> **Anti-Pretendard Rule**: When a sans-serif body is needed, consider ITC Avant Garde first.

| ID | Font Name | Personality | Use Case | Source |
|----|-----------|-------------|----------|--------|
| EN-01 | Bebas Neue | Modern + impact | Large hero titles, SaaS landing, tech | Google Fonts |
| EN-02 | Dazzle Unicase | Unique sans-serif | When standard sans-serif feels boring, brand differentiation | Local/CDN |
| EN-03 | Komu | Oriental + modern | Asian culture, beauty, lifestyle, food | Local/CDN |
| EN-04 | Copal Std | Youthful energy + freedom | Creative, music, festivals, street | Adobe/Local |
| EN-05 | Abolition | Minimal college | Sports, education, casual branding | Local/CDN |
| EN-06 | Miller Banner | High-end serif | Fashion, luxury, editorial, urban | Local/CDN |
| EN-07 | Cabazon | Clean gothic | Clean branding, corporate, minimal | Local/CDN |
| EN-08 | Ethnocentric | Sci-fi + futuristic | Games, sci-fi, space, future concepts (not IT look) | Local/CDN |
| EN-09 | Desire Pro | Heritage serif | Wine, cafe, countryside, nature, classic | Local/CDN |
| EN-10 | ITC Avant Garde Gothic | Classic sans-serif | Pretendard alternative, clean sans-serif for body/display dual use | Local/CDN |

### Personality → Font Mapping (for auto-selection)

```yaml
modern_impact: [EN-01, EN-05]        # Bebas Neue, Abolition
unique_creative: [EN-02, EN-04]       # Dazzle, Copal
oriental_cultural: [EN-03]            # Komu
luxury_editorial: [EN-06, EN-09]      # Miller Banner, Desire Pro
minimal_clean: [EN-07, EN-10]         # Cabazon, ITC Avant Garde
futuristic_scifi: [EN-08]             # Ethnocentric
```

---

## 2. Korean Fonts — noonnu.cc Registry

> **Source**: https://noonnu.cc — Directory of commercially free Korean fonts.
> **Purpose**: Applied to `--font-sans` (body) and `--font-display` (Korean headings) variables.
> **Loading**: noonnu CDN (`https://cdn.jsdelivr.net/gh/...`) or Google Fonts (some).

### 2-A. Gothic (Sans-Serif) — Body + UI Default

> **Role**: `--font-sans` body font or Korean UI dedicated.
> **Instead of Pretendard**: Choose a gothic font matching the project's personality.

| Rank | Font Name | CSS Family | Weights | Character | Recommended Use |
|------|--------|-----------|---------|------|----------|
| 1 | Pretendard | Pretendard | 9 | Default gothic, versatile | Default (only when no personality needed) |
| 2 | Paperlogy | Paperlogy | 9 | Modern gothic | SaaS, tech, startups |
| 3 | Gmarket Sans | GmarketSans | 3 | Full-bodied impact | Commerce, promotions, headings |
| 4 | A2Z | A2Z | 9 | Contemporary gothic | Branding, portfolios |
| 5 | S-CoreDream | S-CoreDream | 9 | Refined gothic | Corporate, finance, official |
| 6 | Noto Sans KR | Noto Sans KR | Multi | Universal gothic | Multilingual, public |
| 7 | NanumSquare | NanumSquare | Multi | Square gothic | Clean headings |
| 8 | SUIT | SUIT | 9 | Geometric gothic | Tech, dashboards |
| 9 | Cafe24 Ssurround | Cafe24Ssurround | 1 | Rounded gothic | Cafes, lifestyle |
| 10 | BMJUA | BMJUA | 1 | Rounded heading | Friendly services, kids |
| 11 | Freesentation | Freesentation | 9 | Presentation | Presentations, educational materials |
| 12 | TheJamsil | TheJamsil | 6 | Soft gothic | Games, casual |
| 13 | Wanted Sans | WantedSans | 7 | Modern gothic | Recruiting, HR, tech |
| 14 | Spoqa Han Sans | SpoqaHanSans | 4 | Readable gothic | Mobile apps, dashboards |
| 15 | Nexon Lv.1 Gothic | NexonLv1Gothic | 3 | Gaming gothic | Games, entertainment |

### 2-B. Batang/Myeongjo (Serif) — Editorial + Luxury

> **Role**: `--font-display` for Korean serif headings or editorial body text.
> **Pairing**: English Serif Display (Miller Banner, Desire Pro) + Korean Myeongjo.

| Rank | Font Name | CSS Family | Weights | Character | Recommended Use |
|------|--------|-----------|---------|------|----------|
| 1 | NanumMyeongjo | NanumMyeongjo | 1 | Classic myeongjo | Literature, essays, traditional |
| 2 | MaruBuri | MaruBuri | 5 | Modern myeongjo | Editorial, magazines, luxury |
| 3 | BookkMyungjo | BookkMyungjo | 2 | Book myeongjo | Publishing, reading, culture |
| 4 | ChosunSm | ChosunSm | 1 | Newspaper myeongjo | News, media, official |
| 5 | KoPubBatang | KoPubBatang | 1 | Publishing batang | Documents, public, education |
| 6 | GounBatang | GounBatang | 2 | Soft batang | Beauty, lifestyle |
| 7 | RidiBatang | RidiBatang | 1 | E-book batang | E-books, reading |
| 8 | NotoSerifKR | NotoSerifKR | 1 | Universal myeongjo | Multilingual, public |
| 9 | Eulyu1945 | Eulyu1945 | 2 | Retro myeongjo | Heritage, history, traditional |
| 10 | AritaBuri | AritaBuri | 1 | Elegant buri | Beauty, fashion, premium |
| 11 | YESMyeongjo | YESMyeongjo | 2 | Modern myeongjo | Bookstores, culture, editorial |
| 12 | National Museum Classic | — | 3 | Classical myeongjo | Museums, cultural heritage, traditional |

### 2-C. Handwriting — Warmth + Humanity

> **Role**: Accent text, quotes, signatures, emotional copy.
> **Caution**: Never use for body text. Limited to headings/accents only.

| Rank | Font Name | CSS Family | Character | Recommended Use |
|------|--------|-----------|------|----------|
| 1 | Memoment KkukKkuk | memomentKkukKkuk | Firmly pressed | Diaries, emotional, personal |
| 2 | Ownglyph ParkDaHyun | Ownglyph_ParkDaHyun | Cute handwriting | Kids, daily, cards |
| 3 | LeeSeoyun | LeeSeoyun | Child handwriting | Kids, fairy tales, education |
| 4 | KyoboHand | KyoboHand | Neat adult handwriting | Bookstores, reading, letters |
| 5 | BMEULJIRO | BMEULJIRO | Retro handwriting | Delivery, restaurants, retro |
| 6 | Cafe24 Supermagic | Cafe24Supermagic | Lively handwriting | Cafes, events |
| 7 | Ownglyph Corncorn | Ownglyph_corncorn | Round and soft | Lifestyle, social media |
| 8 | KOTRAHOPE | KOTRAHOPE | Hopeful handwriting | Public, campaigns |

### 2-D. Decorative / Unique — Strong Impact

> **Role**: Hero large titles, posters, banners only.
> **Caution**: Never use for body text or UI. Display only.

| Rank | Font Name | CSS Family | Character | Recommended Use |
|------|--------|-----------|------|----------|
| 1 | YG Jalnan | yg-jalnan | Full-bodied impact | Promotions, sales, hero |
| 2 | SB Aggro | SBAggroB | Thick impact | Games, sports, intensity |
| 3 | EF Jejudoldam | EF_jejudoldam | Unique texture | Travel, Jeju, nature |
| 4 | Laundry Gothic | LaundryGothic | Retro decorative | Retro, vintage, cafes |
| 5 | Partial Sans | PartialSans | Deconstructed | Art, experimental, galleries |
| 6 | Waguri | Waguri | Strong personality | Games, comics, entertainment |
| 7 | Cafe24 ClassicType | Cafe24ClassicType | Retro type | Vintage, typography-focused |
| 8 | MapleStory | MapleStory | Gaming rounded | Games, kids, casual |

### 2-E. Brush / Calligraphy — Traditional + Calligraphic

> **Role**: Display only for Korean traditional and cultural projects.
> **Pairing**: English Desire Pro + Korean brush calligraphy.

| Rank | Font Name | CSS Family | Character | Recommended Use |
|------|--------|-----------|------|----------|
| 1 | Griun PolSensibility | Griun_PolSensibility | Emotional brush | Culture, emotional, campaigns |
| 2 | Shilla | Shilla | Classic calligraphy | Traditional, temples, history |
| 3 | BMEULJIRO | BMEULJIRO | Retro brush | Restaurants, markets, retro |
| 4 | Gapyeong Hanseokbong | — | Large brush | Calligraphy, festivals, large headings |
| 5 | NanumBrush | NanumBrush | Soft brush | General calligraphy, cards |

### 2-F. Coding / Monospace — Code + Data

> **Role**: Applied to `--font-mono` variable. Code blocks, terminals, numeric data.

| Rank | Font Name | CSS Family | Character | Recommended Use |
|------|--------|-----------|------|----------|
| 1 | D2 Coding | D2Coding | Naver coding font | Korean coding environments |
| 2 | NanumGothic Coding | NanumGothicCoding | Gothic coding | Korean terminal |
| 3 | Cloud Sans Code | CloudSansCode | Modern coding | Dev tools, IDE |
| 4 | Intel One Mono | IntelOneMono | Intel coding | Technical docs, data |

### 2-G. Pixel / Retro — Gaming + Nostalgia

> **Role**: Display or full font for retro/gaming projects.

| Rank | Font Name | CSS Family | Character | Recommended Use |
|------|--------|-----------|------|----------|
| 1 | Mona12 | Mona12 | Modern pixel | Indie games, retro UI |
| 2 | Galmuri9 | Galmuri9 | Korean pixel | Retro games, dot art |
| 3 | NeoDunggeunmo | NeoDunggeunmo | Retro dot | MS-DOS feel, nostalgia |
| 4 | DOSGothic | DOSGothic | DOS era | Extreme retro, terminal |

---

## 3. Persona × Font Pairing Recommendation Matrix

> After determining the persona in the Creative Brief, this matrix is used to auto-select font combinations.

```yaml
minimal:
  en_display: [EN-07, EN-10]  # Cabazon, ITC Avant Garde
  kr_body: [Pretendard, SUIT, WantedSans]
  kr_display: null  # Use English Display only
  mono: [JetBrains Mono, D2Coding]
  vibe: "Restraint, whitespace, geometric"

bold:
  en_display: [EN-01, EN-05]  # Bebas Neue, Abolition
  kr_body: [GmarketSans, S-CoreDream, Paperlogy]
  kr_display: [yg-jalnan, SBAggroB]  # Jalnan, Aggro
  mono: [JetBrains Mono, IntelOneMono]
  vibe: "Intense, impactful, high contrast"

playful:
  en_display: [EN-02, EN-04]  # Dazzle, Copal
  kr_body: [Cafe24Ssurround, BMJUA, TheJamsil]
  kr_display: [MapleStory, LaundryGothic]
  mono: [D2Coding, Mona12]
  vibe: "Cute, rounded, bouncy"

elegant:
  en_display: [EN-06, EN-09]  # Miller Banner, Desire Pro
  kr_body: [MaruBuri, AritaBuri, NanumMyeongjo]
  kr_display: [BookkMyungjo, YESMyeongjo]
  mono: [JetBrains Mono, IntelOneMono]
  vibe: "Serif, gold/cream, editorial"

terminal:
  en_display: [EN-08, EN-01]  # Ethnocentric, Bebas Neue
  kr_body: [D2Coding, NanumGothicCoding, CloudSansCode]
  kr_display: null  # Monospace unified
  mono: [D2Coding, NanumGothicCoding, JetBrains Mono]
  vibe: "Monospace, dark, glow"
```

---

## 4. Font Loading Protocol

### Google Fonts (preferred)
```html
<!-- index.html head -->
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link href="https://fonts.googleapis.com/css2?family={font1}&family={font2}&display=swap" rel="stylesheet" />
```

**Fonts available on Google Fonts:**
- English: Bebas Neue (EN-01)
- Korean: Noto Sans KR, Noto Serif KR, Nanum Gothic, Nanum Myeongjo, NanumSquare, BMJUA, Gmarket Sans, Do Hyeon, Black Han Sans, Jua

### noonnu CDN / Web Fonts
```css
/* Top of globals.css */
@import url('https://cdn.jsdelivr.net/gh/projectnoonnu/.../{font}.css');
```

Or declare `@font-face` directly:
```css
@font-face {
  font-family: 'MaruBuri';
  src: url('https://cdn.jsdelivr.net/gh/projectnoonnu/maruburi/MaruBuri-Regular.woff2') format('woff2');
  font-weight: 400;
  font-display: swap;
}
```

### Local Fonts (for EN-02~EN-10 without CDN)
```css
@font-face {
  font-family: 'Miller Banner';
  src: url('/fonts/MillerBanner-Roman.woff2') format('woff2');
  font-weight: 400;
  font-display: swap;
}
```

**Create a `public/fonts/` directory in the project and place woff2 files there.**

---

## 5. Anti-Pretendard Rule

```yaml
Rule: |
  Pretendard is a "characterless default."
  If the project has a distinct personality, you must choose a gothic other than Pretendard.

  BAD:
    --font-display: Pretendard;
    --font-sans: Pretendard;
    → Entire page flooded with Pretendard

  GOOD (when sans-serif body is needed):
    --font-display: 'ITC Avant Garde Gothic';  # Or Bebas Neue, Cabazon
    --font-sans: 'Paperlogy';                   # Or SUIT, S-CoreDream, WantedSans
    → Each of English Display + Korean body has a distinctive font

  Exception: Extremely neutral corporate sites, government sites, multilingual sites → Pretendard allowed
  Fidelity Score: Pretendard + Pretendard combination scores 0 on Font_Diversity dimension
```

---

## 6. Korean + English Font Stack Combination Examples

```css
/* Example 1: elegant persona */
--font-display: 'Miller Banner', 'MaruBuri', serif;
--font-sans: 'ITC Avant Garde Gothic', 'Paperlogy', sans-serif;
--font-mono: 'JetBrains Mono', 'D2Coding', monospace;

/* Example 2: bold persona */
--font-display: 'Bebas Neue', 'GmarketSans', sans-serif;
--font-sans: 'ITC Avant Garde Gothic', 'S-CoreDream', sans-serif;
--font-mono: 'JetBrains Mono', 'NanumGothicCoding', monospace;

/* Example 3: playful persona */
--font-display: 'Copal Std', 'MapleStory', cursive;
--font-sans: 'ITC Avant Garde Gothic', 'Cafe24Ssurround', sans-serif;
--font-mono: 'D2Coding', monospace;

/* Example 4: terminal persona */
--font-display: 'Ethnocentric', 'D2Coding', monospace;
--font-sans: 'NanumGothicCoding', monospace;
--font-mono: 'JetBrains Mono', 'D2Coding', monospace;
```

> **Key**: Declare the English font first and place the Korean font as fallback.
> The browser automatically renders English glyphs from the English font and Korean glyphs from the Korean font.
