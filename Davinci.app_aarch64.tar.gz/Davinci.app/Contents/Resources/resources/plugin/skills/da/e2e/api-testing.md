# API Testing

Headless API endpoint testing using Playwright's `APIRequestContext` and Vitest-based patterns, covering CRUD operations, authentication, error responses, and test isolation.

## Playwright APIRequestContext

### Why APIRequestContext Over Browser

Playwright provides `APIRequestContext` for making HTTP requests without launching a browser. This is faster, uses fewer resources, and is the correct approach for testing API endpoints directly.

```typescript
// Bad: using a browser page to test an API endpoint
import { test, expect } from '@playwright/test';

test('fetch users via browser', async ({ page }) => {
  await page.goto('/api/users');
  const body = await page.locator('pre').textContent();
  const users = JSON.parse(body ?? '[]');
  expect(users.length).toBeGreaterThan(0);
});
```

```typescript
// Good: using APIRequestContext for direct API testing
import { test, expect } from '@playwright/test';

test('fetch users via API request', async ({ request }) => {
  const response = await request.get('/api/users');

  expect(response.status()).toBe(200);
  const users = await response.json();
  expect(users.length).toBeGreaterThan(0);
});
```

**Detect:** `page.goto('/api/')` or `page.goto` targeting an API route -- suggest using `request.get()` or `request.post()` via `APIRequestContext` instead.

### Creating API Request Context in Fixtures

Define reusable API contexts with base URLs, headers, and authentication tokens using Playwright fixtures.

```typescript
// Good: custom fixture with authenticated API context
// tests/fixtures/api-fixture.ts
import { test as base, APIRequestContext } from '@playwright/test';

type ApiFixtures = {
  apiContext: APIRequestContext;
};

export const test = base.extend<ApiFixtures>({
  apiContext: async ({ playwright }, use) => {
    const context = await playwright.request.newContext({
      baseURL: 'http://localhost:3000',
      extraHTTPHeaders: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${process.env.TEST_API_TOKEN}`,
      },
    });
    await use(context);
    await context.dispose();
  },
});

export { expect } from '@playwright/test';
```

## Request Patterns

### GET Requests

```typescript
// Good: GET with query parameters and response validation
test('fetches paginated users', async ({ request }) => {
  const response = await request.get('/api/users', {
    params: { page: '1', limit: '10' },
  });

  expect(response.status()).toBe(200);

  const body = await response.json();
  expect(body.data).toHaveLength(10);
  expect(body.meta.page).toBe(1);
  expect(body.meta.totalPages).toBeGreaterThanOrEqual(1);
});
```

### POST Requests

```typescript
// Good: POST with body and response validation
test('creates a new user', async ({ request }) => {
  const response = await request.post('/api/users', {
    data: {
      name: 'Jane Doe',
      email: `jane-${Date.now()}@test.com`,
      role: 'editor',
    },
  });

  expect(response.status()).toBe(201);

  const user = await response.json();
  expect(user.id).toBeTruthy();
  expect(user.name).toBe('Jane Doe');
  expect(user.role).toBe('editor');
});
```

### PUT Requests

```typescript
// Good: PUT with full resource replacement
test('updates an existing user', async ({ request }) => {
  const response = await request.put('/api/users/123', {
    data: {
      name: 'Jane Smith',
      email: 'jane-smith@test.com',
      role: 'admin',
    },
  });

  expect(response.status()).toBe(200);

  const user = await response.json();
  expect(user.name).toBe('Jane Smith');
  expect(user.role).toBe('admin');
});
```

### DELETE Requests

```typescript
// Good: DELETE with confirmation and re-fetch verification
test('deletes a user and confirms removal', async ({ request }) => {
  const deleteResponse = await request.delete('/api/users/123');
  expect(deleteResponse.status()).toBe(204);

  // Verify the resource is gone
  const getResponse = await request.get('/api/users/123');
  expect(getResponse.status()).toBe(404);
});
```

## Request Headers

### Authentication Tokens

```typescript
// Bad: no auth header on protected endpoint
test('access protected resource', async ({ request }) => {
  const response = await request.get('/api/admin/settings');
  // will return 401, test fails unexpectedly
  expect(response.status()).toBe(200);
});
```

```typescript
// Good: include auth token in request headers
test('access protected resource with token', async ({ request }) => {
  const response = await request.get('/api/admin/settings', {
    headers: {
      Authorization: `Bearer ${process.env.TEST_API_TOKEN}`,
    },
  });

  expect(response.status()).toBe(200);
  const settings = await response.json();
  expect(settings).toHaveProperty('maintenance');
});
```

### Content-Type Headers

```typescript
// Good: explicitly set content type for non-JSON payloads
test('upload file via multipart form', async ({ request }) => {
  const response = await request.post('/api/upload', {
    multipart: {
      file: {
        name: 'test.csv',
        mimeType: 'text/csv',
        buffer: Buffer.from('name,email\nJohn,john@test.com'),
      },
    },
  });

  expect(response.status()).toBe(200);
  const result = await response.json();
  expect(result.rowsProcessed).toBe(1);
});
```

## Response Assertion Patterns

### Status Code Assertions

```typescript
// Good: assert specific status codes for each scenario
test('returns correct status codes', async ({ request }) => {
  // 200 for successful retrieval
  const getResponse = await request.get('/api/users/1');
  expect(getResponse.status()).toBe(200);

  // 201 for successful creation
  const postResponse = await request.post('/api/users', {
    data: { name: 'New User', email: `new-${Date.now()}@test.com` },
  });
  expect(postResponse.status()).toBe(201);

  // 204 for successful deletion with no content
  const id = (await postResponse.json()).id;
  const deleteResponse = await request.delete(`/api/users/${id}`);
  expect(deleteResponse.status()).toBe(204);
});
```

### Response Body Assertions

```typescript
// Good: validate response structure and data types
test('user response has correct shape', async ({ request }) => {
  const response = await request.get('/api/users/1');
  const user = await response.json();

  expect(user).toMatchObject({
    id: expect.any(Number),
    name: expect.any(String),
    email: expect.stringMatching(/@/),
    createdAt: expect.any(String),
  });
});
```

### Response Header Assertions

```typescript
// Good: verify response headers for caching, content type, etc.
test('response includes correct headers', async ({ request }) => {
  const response = await request.get('/api/users');

  expect(response.headers()['content-type']).toContain('application/json');
  expect(response.headers()['x-request-id']).toBeTruthy();
});
```

## API Test Isolation

### Per-Test Data

Each test should create and clean up its own data to avoid order-dependent failures.

```typescript
// Bad: tests share data and depend on execution order
let sharedUserId: string;

test('create user', async ({ request }) => {
  const response = await request.post('/api/users', {
    data: { name: 'Shared User', email: 'shared@test.com' },
  });
  sharedUserId = (await response.json()).id;
});

test('delete user', async ({ request }) => {
  // fails if "create user" test did not run first
  const response = await request.delete(`/api/users/${sharedUserId}`);
  expect(response.status()).toBe(204);
});
```

```typescript
// Good: each test creates and cleans up its own data
test('create and delete a user independently', async ({ request }) => {
  // Setup: create test-specific data
  const createResponse = await request.post('/api/users', {
    data: { name: 'Isolated User', email: `isolated-${Date.now()}@test.com` },
  });
  expect(createResponse.status()).toBe(201);
  const userId = (await createResponse.json()).id;

  // Exercise: verify the user exists
  const getResponse = await request.get(`/api/users/${userId}`);
  expect(getResponse.status()).toBe(200);

  // Cleanup: remove the test data
  const deleteResponse = await request.delete(`/api/users/${userId}`);
  expect(deleteResponse.status()).toBe(204);
});
```

### Fixture-Based Isolation

```typescript
// Good: use a fixture to handle setup and teardown
import { test as base, expect, APIRequestContext } from '@playwright/test';

type TestUser = { id: string; name: string; email: string };

const test = base.extend<{ testUser: TestUser }>({
  testUser: async ({ request }, use) => {
    // Setup: create a user before the test
    const response = await request.post('/api/users', {
      data: { name: 'Fixture User', email: `fixture-${Date.now()}@test.com` },
    });
    const user = await response.json();

    await use(user);

    // Teardown: delete the user after the test
    await request.delete(`/api/users/${user.id}`);
  },
});

test('update user name', async ({ request, testUser }) => {
  const response = await request.put(`/api/users/${testUser.id}`, {
    data: { ...testUser, name: 'Updated Name' },
  });

  expect(response.status()).toBe(200);
  const updated = await response.json();
  expect(updated.name).toBe('Updated Name');
});
```

## Vitest-Based API E2E Patterns

For projects that use Vitest and do not require a browser, API tests can be written using `fetch` or an HTTP client directly.

```typescript
// tests/api/users.test.ts (Vitest)
import { describe, it, expect, beforeAll, afterAll } from 'vitest';

const BASE_URL = process.env.API_URL ?? 'http://localhost:3000';
let testUserId: string;

describe('Users API', () => {
  it('creates a user', async () => {
    const response = await fetch(`${BASE_URL}/api/users`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: 'Vitest User',
        email: `vitest-${Date.now()}@test.com`,
      }),
    });

    expect(response.status).toBe(201);
    const user = await response.json();
    expect(user.id).toBeTruthy();
    testUserId = user.id;
  });

  it('reads the created user', async () => {
    const response = await fetch(`${BASE_URL}/api/users/${testUserId}`);

    expect(response.status).toBe(200);
    const user = await response.json();
    expect(user.name).toBe('Vitest User');
  });

  afterAll(async () => {
    if (testUserId) {
      await fetch(`${BASE_URL}/api/users/${testUserId}`, { method: 'DELETE' });
    }
  });
});
```

## Health Check Endpoint Testing

```typescript
// Good: verify health check returns expected shape
test('health check returns service status', async ({ request }) => {
  const response = await request.get('/api/health');

  expect(response.status()).toBe(200);

  const health = await response.json();
  expect(health).toMatchObject({
    status: 'ok',
    version: expect.any(String),
    uptime: expect.any(Number),
  });
});
```

## Error Response Testing

Test all common error codes to verify the API returns correct status codes and descriptive error bodies.

### 400 Bad Request

```typescript
test('returns 400 for invalid request body', async ({ request }) => {
  const response = await request.post('/api/users', {
    data: { name: '' }, // missing required email
  });

  expect(response.status()).toBe(400);
  const error = await response.json();
  expect(error.message).toContain('email');
});
```

### 401 Unauthorized

```typescript
test('returns 401 without auth token', async ({ playwright }) => {
  const context = await playwright.request.newContext({
    baseURL: 'http://localhost:3000',
    // no Authorization header
  });

  const response = await context.get('/api/admin/settings');
  expect(response.status()).toBe(401);

  const error = await response.json();
  expect(error.message).toContain('Unauthorized');

  await context.dispose();
});
```

### 403 Forbidden

```typescript
test('returns 403 for insufficient permissions', async ({ request }) => {
  // request fixture uses a regular user token
  const response = await request.delete('/api/admin/users/1');

  expect(response.status()).toBe(403);
  const error = await response.json();
  expect(error.message).toContain('Forbidden');
});
```

### 404 Not Found

```typescript
test('returns 404 for nonexistent resource', async ({ request }) => {
  const response = await request.get('/api/users/nonexistent-id');

  expect(response.status()).toBe(404);
  const error = await response.json();
  expect(error.message).toContain('not found');
});
```

### 500 Internal Server Error

```typescript
test('returns 500 for server-side failure', async ({ request }) => {
  // Trigger a known server error scenario (e.g., malformed data that bypasses validation)
  const response = await request.post('/api/process', {
    data: { payload: null }, // causes unhandled error in handler
  });

  expect(response.status()).toBe(500);
  const error = await response.json();
  expect(error.message).toBeDefined();
  // Ensure no stack trace is leaked to the client
  expect(error.stack).toBeUndefined();
});
```

## Full Example: CRUD API Test with Fixture

```typescript
// tests/e2e/api-tasks.spec.ts
import { test as base, expect, APIRequestContext } from '@playwright/test';

type Task = { id: string; title: string; status: string };

const test = base.extend<{ apiContext: APIRequestContext; testTask: Task }>({
  apiContext: async ({ playwright }, use) => {
    const context = await playwright.request.newContext({
      baseURL: process.env.BASE_URL ?? 'http://localhost:3000',
      extraHTTPHeaders: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${process.env.TEST_API_TOKEN}`,
      },
    });
    await use(context);
    await context.dispose();
  },

  testTask: async ({ apiContext }, use) => {
    // Setup: create a task for the test
    const response = await apiContext.post('/api/tasks', {
      data: { title: `Test Task ${Date.now()}`, status: 'todo' },
    });
    const task = await response.json();

    await use(task);

    // Teardown: clean up
    await apiContext.delete(`/api/tasks/${task.id}`);
  },
});

test.describe('Tasks API CRUD', () => {
  test('POST /api/tasks creates a new task', async ({ apiContext }) => {
    const response = await apiContext.post('/api/tasks', {
      data: { title: 'New Task', status: 'todo' },
    });

    expect(response.status()).toBe(201);
    const task = await response.json();
    expect(task.title).toBe('New Task');
    expect(task.status).toBe('todo');
    expect(task.id).toBeTruthy();

    // Cleanup
    await apiContext.delete(`/api/tasks/${task.id}`);
  });

  test('GET /api/tasks/:id returns the task', async ({ apiContext, testTask }) => {
    const response = await apiContext.get(`/api/tasks/${testTask.id}`);

    expect(response.status()).toBe(200);
    const task = await response.json();
    expect(task.id).toBe(testTask.id);
    expect(task.title).toBe(testTask.title);
  });

  test('PUT /api/tasks/:id updates the task', async ({ apiContext, testTask }) => {
    const response = await apiContext.put(`/api/tasks/${testTask.id}`, {
      data: { title: 'Updated Title', status: 'in-progress' },
    });

    expect(response.status()).toBe(200);
    const task = await response.json();
    expect(task.title).toBe('Updated Title');
    expect(task.status).toBe('in-progress');
  });

  test('DELETE /api/tasks/:id removes the task', async ({ apiContext }) => {
    // Create a task specifically for deletion
    const createResponse = await apiContext.post('/api/tasks', {
      data: { title: 'To Delete', status: 'todo' },
    });
    const taskId = (await createResponse.json()).id;

    const deleteResponse = await apiContext.delete(`/api/tasks/${taskId}`);
    expect(deleteResponse.status()).toBe(204);

    // Verify it is gone
    const getResponse = await apiContext.get(`/api/tasks/${taskId}`);
    expect(getResponse.status()).toBe(404);
  });

  test('POST /api/tasks returns 400 for missing title', async ({ apiContext }) => {
    const response = await apiContext.post('/api/tasks', {
      data: { status: 'todo' },
    });

    expect(response.status()).toBe(400);
    const error = await response.json();
    expect(error.message).toContain('title');
  });

  test('GET /api/tasks/:id returns 404 for nonexistent task', async ({ apiContext }) => {
    const response = await apiContext.get('/api/tasks/nonexistent-id');

    expect(response.status()).toBe(404);
  });

  test('DELETE /api/tasks/:id returns 401 without auth', async ({ playwright }) => {
    const unauthContext = await playwright.request.newContext({
      baseURL: process.env.BASE_URL ?? 'http://localhost:3000',
    });

    const response = await unauthContext.delete('/api/tasks/any-id');
    expect(response.status()).toBe(401);

    await unauthContext.dispose();
  });
});
```

## Quick Reference

| Pattern | Approach | Detect Rule |
|---|---|---|
| API GET | `request.get('/path')` | `page.goto('/api/')` in test |
| API POST | `request.post('/path', { data })` | `page.goto('/api/')` with form fill |
| API PUT | `request.put('/path', { data })` | Manual fetch in browser context |
| API DELETE | `request.delete('/path')` | `page.evaluate(() => fetch(...))` |
| Auth header | `extraHTTPHeaders` in context or per-request `headers` | No `Authorization` on protected route test |
| Custom fixture | `base.extend<{ apiContext }>` with setup/teardown | Repeated `playwright.request.newContext` calls |
| Test isolation | Per-test create + cleanup or fixture teardown | Shared mutable `let` variable across tests |
| Health check | `request.get('/api/health')` + status 200 | No health check test in API suite |
| 400 validation | POST with invalid/missing fields | Only happy-path POST tests |
| 401 unauthorized | Request without auth token | No unauthenticated request tests |
| 403 forbidden | Request with low-privilege token | No permission boundary tests |
| 404 not found | GET with nonexistent ID | No missing resource tests |
| 500 server error | Trigger known failure path | No error response tests |
| Response shape | `toMatchObject` with `expect.any()` | No response body structure assertions |
| Response headers | `response.headers()['key']` | No header assertions |
| Vitest API tests | `fetch()` with `describe`/`it` blocks | Pure API project without Playwright |
| File upload | `request.post` with `multipart` option | Manual form submission for uploads |
