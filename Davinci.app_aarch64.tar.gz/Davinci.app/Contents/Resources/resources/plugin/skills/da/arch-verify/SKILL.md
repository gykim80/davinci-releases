---
name: arch-verify
description: "아키텍처 준수 검증 -- 헥사고날 레이어 위반, ADR 준수, DOMAIN-MODEL.md 불변식, CONTEXT.md 용어 위반을 코드 스캔으로 검출. da:dev 구현 후 MODERATE+ 복잡도에서 자동 호출, da:verify Phase 2에 결과 병합"
agent: senior-architect
agents: [security-architect]
davinci-phase: check
allowed-tools: [Read, Grep, Glob, Bash, Write]
next-skill: verify
skill-type: rigid
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 검증자: items[] 기반 match rate와 4값 verdict(MET/NOT_MET/BLOCKED/IMPOSSIBLE)를 handoff에 포함. 생성자와 다른 컨텍스트에서 실행된다.

## Tool Parameter Rules -> See CLAUDE.md (ABSOLUTE)
# /da:arch-verify - 아키텍처 준수 검증

## Role in DAVINCI Workflow
```yaml
Invocation: da:dev 구현 완료 후 (MODERATE+ 복잡도) 자동 호출, 또는 독립 실행
  `/da:arch-verify [path]`
Input: docs/domain/DOMAIN-MODEL.md, docs/adr/*.md (Accepted만), CONTEXT.md, 대상 diff/경로
Output: docs/ARCH-VERIFY-REPORT.md (체크리스트 항목별 PASS/FAIL/N-A)
Handoff_To: da:verify Phase 2 Semantic Analysis -- terminology_violation과 함께 병합 보고
```

## What it Checks (4 dimensions)

전체 체크리스트와 Grep 패턴: `references/arch-checklist.md`

```yaml
1_Layer_Purity (헥사고날 -- DOMAIN-MODEL.md에 scaffold가 제안된 경우):
  - domain/ 내부에 프레임워크/DB/HTTP 클라이언트 import 존재 여부

2_Port_Compliance:
  - adapters/ 밖에서 외부 라이브러리를 직접 import하는지 (use-cases가 port를 우회하는지)

3_ADR_Compliance:
  - 의존성 매니페스트(package.json/Cargo.toml/go.mod 등) 변경이 Accepted ADR과 매치되는지
  - 매치되는 ADR이 없으면 violation으로 보고 (차단은 da:work의 역할, 이 스킬은 보고만)

4_Terminology_and_Invariant_Compliance:
  - CONTEXT.md Avoid 목록 용어가 코드/UI 텍스트에 사용됐는지
  - DOMAIN-MODEL.md의 Invariant 문장에 대응하는 검증 코드/가드가 존재하는지 (휴리스틱 -- 확정적 아님)
```

## Execution Steps

```yaml
1_Load_Constraints:
  - Glob("docs/domain/DOMAIN-MODEL.md"), Glob("docs/adr/*.md"), Glob("CONTEXT.md")
  - 없는 항목은 해당 차원을 N/A로 스킵 (에러 아님 -- 모든 프로젝트가 3종 문서를 다 갖출 필요 없음)

2_Scope:
  - 인자로 경로 지정 시 해당 범위
  - 미지정 시 `git diff --stat HEAD~1` 또는 최근 da:dev 커밋 변경분

3_Deterministic_Scan:
  - CodeGraph MCP 가용 시: codegraph_impact / codegraph_callers로 레이어 간 참조 확인 (우선)
  - 비가용 시: Grep으로 폴백 (references/arch-checklist.md의 패턴 사용) -- 규칙이 텍스트
    매칭 기반이라 폴백 정확도 손실이 적음

4_Classify: 항목별 PASS / FAIL / N-A

5_Write_Report:
  - docs/ARCH-VERIFY-REPORT.md 작성 (스킵된 차원은 "N/A -- 문서 없음"으로 명시)

6_Gate:
  - FAIL 존재 && severity=blocking (ADR_Compliance, Layer_Purity) → da:verify에 blocking 전달
  - FAIL 존재 && severity=warning (Terminology, Invariant 휴리스틱) → 경고만, 비차단
```

## Report Format

```markdown
# Architecture Verification Report

Scope: {대상 경로/diff}
Date: {날짜}

| Dimension | Item | Result | Detail |
|---|---|---|---|
| Layer Purity | domain/ 프레임워크 import | PASS | - |
| ADR Compliance | 신규 의존성 X 추가 | FAIL | ADR 없음 -- da:adr 필요 |

## Blocking Violations
- {있으면 나열, 없으면 "없음"}

## Warnings
- {있으면 나열}
```

## Handoff Output (MANDATORY)

```json
{
  "skill": "da:arch-verify",
  "report_file": "docs/ARCH-VERIFY-REPORT.md",
  "violations": 0,
  "blocking": false
}
```
