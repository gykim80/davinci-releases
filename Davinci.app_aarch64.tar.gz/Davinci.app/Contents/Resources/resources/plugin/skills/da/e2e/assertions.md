# Assertions

DOM-based assertion patterns for Playwright, covering auto-retrying assertions, strict mode, negation, and soft assertions.

## Auto-Retrying Assertions

Playwright's `expect(locator)` assertions automatically retry until the condition is met or the timeout expires. These are the primary assertions for E2E tests because they handle asynchronous rendering, animations, and network delays without explicit waits.

```typescript
// Visibility
await expect(page.getByRole('dialog')).toBeVisible();
await expect(page.getByRole('dialog')).toBeHidden();

// Text content
await expect(page.getByRole('heading')).toHaveText('Dashboard');
await expect(page.getByRole('status')).toContainText('saved');

// Input values
await expect(page.getByLabel('Email')).toHaveValue('user@example.com');

// Attributes
await expect(page.getByRole('button')).toHaveAttribute('disabled', '');
await expect(page.getByRole('link')).toHaveAttribute('href', '/docs');

// Element count
await expect(page.getByRole('listitem')).toHaveCount(5);

// CSS state
await expect(page.getByRole('button')).toBeEnabled();
await expect(page.getByRole('button')).toBeDisabled();
await expect(page.getByRole('checkbox')).toBeChecked();

// CSS classes and properties
await expect(page.getByTestId('banner')).toHaveClass(/active/);
await expect(page.getByTestId('banner')).toHaveCSS('display', 'flex');

// Page-level assertions
await expect(page).toHaveURL('/dashboard');
await expect(page).toHaveTitle('My App - Dashboard');
```

All of these retry internally. There is no need to add `waitForTimeout`, `waitForSelector`, or manual polling.

## Non-Retrying Assertions

When you extract a value from a locator first (e.g., `textContent()`, `getAttribute()`), the result is a plain JavaScript value. Standard `expect()` assertions on plain values do **not** retry.

```typescript
// Non-retrying: value is resolved once, then compared
const count = await page.getByTestId('item-count').textContent();
expect(count).toBe('5'); // No retry if count changes later

const href = await page.getByRole('link', { name: 'Docs' }).getAttribute('href');
expect(href).toBe('/docs'); // No retry
```

Use non-retrying assertions only when:

- The value is guaranteed stable at the point of extraction.
- You need to perform complex transformations on the value before asserting.
- You are asserting on API response bodies or other non-DOM data.

## Strict Mode

By default, Playwright locators operate in strict mode. If a locator matches more than one element, the action or assertion throws an error rather than silently picking the first match.

```typescript
// Throws if multiple buttons match
await page.getByRole('button', { name: 'Delete' }).click();
// Error: strict mode violation, locator resolved to 3 elements

// Fix: narrow the scope
await page
  .getByRole('row')
  .filter({ hasText: 'Project Alpha' })
  .getByRole('button', { name: 'Delete' })
  .click();
```

For cases where you intentionally want all matches, use `locator.all()` or `toHaveCount()`.

```typescript
// Assert count of all matching elements
await expect(page.getByRole('listitem')).toHaveCount(3);

// Iterate over all matches
const items = await page.getByRole('listitem').all();
for (const item of items) {
  await expect(item).toBeVisible();
}
```

## Negation Assertions

Use `.not` for negative assertions. These also auto-retry.

```typescript
// Wait until the element is no longer visible
await expect(page.getByRole('dialog')).not.toBeVisible();

// Wait until loading indicator disappears
await expect(page.getByTestId('spinner')).not.toBeVisible();

// Verify text is absent
await expect(page.getByRole('alert')).not.toHaveText('Error');

// Verify element is not in DOM at all
await expect(page.getByTestId('deleted-item')).toBeHidden();

// Verify checkbox is unchecked
await expect(page.getByRole('checkbox', { name: 'Subscribe' })).not.toBeChecked();
```

## Soft Assertions

Soft assertions record failures without stopping the test. The test continues executing and reports all failures at the end. Use them when you want to verify multiple independent conditions in a single test run.

```typescript
test('dashboard displays all widgets', async ({ page }) => {
  await page.goto('/dashboard');

  // Soft assertions: test continues even if one fails
  await expect.soft(page.getByTestId('revenue-widget')).toBeVisible();
  await expect.soft(page.getByTestId('users-widget')).toBeVisible();
  await expect.soft(page.getByTestId('orders-widget')).toBeVisible();
  await expect.soft(page.getByTestId('analytics-widget')).toBeVisible();

  // Hard assertion: test stops here if it fails
  await expect(page.getByRole('heading', { name: 'Dashboard' })).toBeVisible();
});
```

Use soft assertions sparingly. If one failure logically invalidates subsequent checks, use standard assertions instead.

## Bad/Good Patterns

### Hardcoded Waits

**Detect:** `waitForTimeout` in test file -- replace with auto-retrying assertion.

```typescript
// Bad: Arbitrary sleep, slows tests, still flaky
await page.getByRole('button', { name: 'Save' }).click();
await page.waitForTimeout(3000);
const message = await page.getByRole('status').textContent();
expect(message).toBe('Saved successfully');

// Good: Auto-retrying assertion waits exactly as long as needed
await page.getByRole('button', { name: 'Save' }).click();
await expect(page.getByRole('status')).toHaveText('Saved successfully');
```

### Screenshot-Based Assertions

**Detect:** `page.screenshot()` used as a verification step in a test assertion block -- suggest DOM-based assertion.

```typescript
// Bad: Screenshot comparison is fragile and slow
await page.getByRole('button', { name: 'Submit' }).click();
expect(await page.screenshot()).toMatchSnapshot('success-state.png');

// Good: Assert specific DOM state
await page.getByRole('button', { name: 'Submit' }).click();
await expect(page.getByRole('alert')).toHaveText('Form submitted');
await expect(page.getByRole('button', { name: 'Submit' })).toBeDisabled();
```

Visual regression testing has its place (dedicated visual test suites), but functional assertions should always verify DOM state.

### Manual Text Extraction

**Detect:** `.textContent()` followed by `expect()` in test file -- suggest `toHaveText()` or `toContainText()`.

```typescript
// Bad: Extracts text once, no retry on dynamic content
const text = await page.getByRole('heading').textContent();
expect(text).toBe('Welcome, Alice');

// Good: Auto-retrying, handles async rendering
await expect(page.getByRole('heading')).toHaveText('Welcome, Alice');
```

### waitForSelector

**Detect:** `page.waitForSelector()` in test file -- suggest `expect(locator).toBeVisible()`.

```typescript
// Bad: Legacy wait pattern, returns ElementHandle
await page.waitForSelector('.notification');
const el = await page.$('.notification');
const text = await el?.textContent();
expect(text).toContain('Success');

// Good: Locator-based assertion, auto-retrying
await expect(page.getByRole('alert')).toContainText('Success');
```

### innerHTML Inspection

**Detect:** `.innerHTML()` or `.innerText()` followed by assertion -- suggest `toHaveText()` or `toHaveAttribute()`.

```typescript
// Bad: Extracts raw HTML, fragile and non-retrying
const html = await page.getByTestId('user-card').innerHTML();
expect(html).toContain('aria-label="verified"');

// Good: Assert the attribute directly, auto-retrying
await expect(page.getByTestId('user-card').getByRole('img')).toHaveAttribute(
  'aria-label',
  'verified'
);
```

## Custom Timeout per Assertion

Override the default assertion timeout for individual checks when specific operations are expected to take longer.

```typescript
// Default timeout from config (typically 5s)
await expect(page.getByRole('status')).toHaveText('Ready');

// Extended timeout for slow operations
await expect(page.getByRole('status')).toHaveText('Upload complete', {
  timeout: 30_000,
});
```

## Polling Assertions

For values that are not tied to a locator, use `expect.poll()` to retry a function until it satisfies the assertion.

```typescript
// Poll an API endpoint until the condition is met
await expect
  .poll(async () => {
    const response = await page.request.get('/api/status');
    return response.json();
  }, { timeout: 30_000 })
  .toEqual({ status: 'complete' });
```

## Quick Reference

| Assertion | Auto-Retry | Category | Example |
|---|---|---|---|
| `toBeVisible()` | Yes | Visibility | `expect(locator).toBeVisible()` |
| `toBeHidden()` | Yes | Visibility | `expect(locator).toBeHidden()` |
| `toBeEnabled()` | Yes | State | `expect(locator).toBeEnabled()` |
| `toBeDisabled()` | Yes | State | `expect(locator).toBeDisabled()` |
| `toBeChecked()` | Yes | State | `expect(locator).toBeChecked()` |
| `toHaveText(text)` | Yes | Content | `expect(locator).toHaveText('Hello')` |
| `toContainText(text)` | Yes | Content | `expect(locator).toContainText('Hello')` |
| `toHaveValue(value)` | Yes | Form | `expect(locator).toHaveValue('test@mail.com')` |
| `toHaveAttribute(name, value)` | Yes | Attribute | `expect(locator).toHaveAttribute('href', '/docs')` |
| `toHaveCount(n)` | Yes | Collection | `expect(locator).toHaveCount(5)` |
| `toHaveClass(class)` | Yes | Style | `expect(locator).toHaveClass(/active/)` |
| `toHaveCSS(prop, value)` | Yes | Style | `expect(locator).toHaveCSS('color', 'red')` |
| `toHaveURL(url)` | Yes | Page | `expect(page).toHaveURL('/dashboard')` |
| `toHaveTitle(title)` | Yes | Page | `expect(page).toHaveTitle('My App')` |
| `.not.toBeVisible()` | Yes | Negation | `expect(locator).not.toBeVisible()` |
| `expect.soft()` | Yes | Soft | `expect.soft(locator).toHaveText('X')` |
| `expect.poll(fn)` | Yes | Polling | `expect.poll(() => api()).toEqual(val)` |
| `toBe(value)` | No | Plain value | `expect(await loc.textContent()).toBe('X')` |
| `toEqual(value)` | No | Plain value | `expect(data).toEqual({ key: 'val' })` |
| `toBeTruthy()` | No | Plain value | `expect(result).toBeTruthy()` |
