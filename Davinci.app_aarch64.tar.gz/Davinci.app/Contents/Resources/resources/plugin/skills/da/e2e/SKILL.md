---
name: e2e
description: E2E testing strategy, Playwright DOM-based validation, accessibility audit, CI/CD integration
agent: e2e-testing-patterns
agents: [qa-strategist]
davinci-phase: null
allowed-tools: [Write, Edit, Read, Bash, Glob, Grep, Task]
next-skill: null
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 검증자: items[] 기반 match rate와 4값 verdict(MET/NOT_MET/BLOCKED/IMPOSSIBLE)를 handoff에 포함. 생성자와 다른 컨텍스트에서 실행된다.

## Tool Parameter Rules -> See CLAUDE.md (ABSOLUTE)
# /da:e2e - E2E Testing with Playwright

ultrathink

> Claude MUST analyze the project structure and design optimal E2E test strategy before writing any test code.

## Extended Thinking Protocol
- **Analyze**: Project structure, framework, existing test patterns
- **Strategy**: Critical user paths, selector approach, page object needs
- **Generate**: Test code with DOM assertions, page objects, fixtures
- **Validate**: Accessibility compliance, CI/CD readiness

---

## CORE PRINCIPLE: DOM-Only Verification

```yaml
Absolute_Rules:
  - NEVER take screenshots or send images to LLM
  - NEVER use page.screenshot() for assertions
  - NEVER use waitForTimeout() -- use auto-retrying assertions
  - NEVER use CSS class selectors -- use getByRole, getByLabel, getByTestId
  - ALWAYS validate via DOM queries, assertions, and axe-core
  - ALWAYS use Page Object Model for pages with 3+ interactions
  - ALWAYS include axe-core accessibility check per page

Selector_Priority:
  1. getByRole('button', { name: 'Submit' })   # Semantic, accessible
  2. getByLabel('Email')                         # Form inputs
  3. getByTestId('user-avatar')                  # Non-semantic elements
  4. getByText('Welcome')                        # Static content
  5. locator('[data-testid="x"]')               # Last resort
```

---

## INTEGRATED MODES

### Token Efficiency Mode
`Pass/Fail/Skip | A11y/Flow/API | "[File] [Type] [Status] -- [Details]"`

### Orchestration Mode
Framework detection: CodeGraph | Playwright docs: Context7 | Component analysis: codegraph_node | Test run: Bash npx playwright test

---

## SPECIALIZED AGENTS

### E2E Test Engineer (Primary)
```yaml
Focus:
  - Test strategy and critical path identification
  - Page Object Model design and implementation
  - Fixture-based test data isolation
  - Cross-browser compatibility
  - Flaky test prevention

Approach:
  1. Analyze project structure and framework
  2. Identify critical user flows
  3. Design page objects for complex pages
  4. Write tests with auto-retrying assertions
  5. Configure test parallelization
```

### Accessibility Auditor
```yaml
Focus:
  - WCAG 2.1 AA compliance via axe-core
  - Keyboard navigation coverage
  - ARIA attribute validation
  - Focus management (modals, skip links)
  - Screen reader compatibility

Mandatory_Checks:
  - axe-core scan per tested page
  - Tab order verification for forms
  - aria-label on all interactive elements
  - Focus trap in modal dialogs
```

### CI/CD Engineer
```yaml
Focus:
  - GitHub Actions workflow configuration
  - Docker-based Playwright execution
  - Test sharding for parallel runs
  - Artifact management (traces, reports)
  - Failure notification pipelines

Deliverables:
  - .github/workflows/e2e.yml
  - Playwright Docker configuration
  - Retry and sharding strategy
```

---

## BEHAVIORAL FLOW

### Phase 1: Analyze
```yaml
1. Project_Detection:
   - CodeGraph: codegraph_explore on project root
   - Detect framework (Next.js, React, API-only)
   - Identify existing test infrastructure

2. Test_Inventory:
   - Glob: Find existing *.spec.ts, *.test.ts files
   - Grep: Scan for existing page objects, fixtures
   - Assess current coverage and gaps

3. Dependency_Check:
   - Verify @playwright/test installation
   - Check @axe-core/playwright availability
   - Identify missing test dependencies
```

### Phase 2: Strategy
```yaml
1. Critical_Path_Identification:
   - User authentication flow (highest priority)
   - Core CRUD operations
   - Navigation and routing
   - Form submissions with validation
   - Error states and edge cases

2. Page_Object_Planning:
   - Pages with 3+ interactions get POM
   - Shared components get shared POM fixtures
   - API endpoints get request context fixtures

3. Framework_Pattern_Selection:
   - Next.js: SSR/SSG verification, Server Actions, middleware
   - React SPA: Client routing, state management flows
   - API: APIRequestContext, health checks, CRUD
```

### Phase 3: Generate
```yaml
1. Configuration:
   - playwright.config.ts (if not exists)
   - Test fixtures and global setup
   - Page object base classes

2. Test_Code:
   - User flow tests (Arrange-Act-Assert pattern)
   - Page objects with lazy locators
   - Accessibility tests with axe-core
   - API tests with request context

3. CI_Pipeline:
   - GitHub Actions workflow (if --ci flag)
   - Docker configuration
   - Sharding and retry setup
```

### Phase 4: Execute and Report
```yaml
1. Execution:
   - Run tests: npx playwright test
   - Collect results and traces
   - Identify failures and flaky tests

2. Accessibility_Audit:
   - Run axe-core assertions
   - Report WCAG violations by severity
   - Provide fix recommendations

3. Coverage_Report:
   - Pages tested vs total pages
   - User flows covered
   - Accessibility compliance score
   - CI/CD readiness assessment
```

---

## VERDICT HANDOFF (MANDATORY — da:protocol §3.3-b)
Phase 4 종료 시 응답 마지막에 반환한다. 테스트 결과 없는 verdict는 무효.
```json
{"skill": "da:e2e", "status": "completed", "verdict": "MET|NOT_MET|BLOCKED|IMPOSSIBLE",
 "test_results": {"passed": 41, "failed": 2, "skipped": 0, "total": 43},
 "severity_max": "High", "reason": "checkout flow: payment step timeout",
 "next_action_hint": "결제 API mock 대신 실제 sandbox 키 주입 또는 대기 조건 수정",
 "failures": [{"test": "checkout.spec.ts > pays", "reason": "...", "severity": "High"}],
 "evidence": [{"kind": "test", "ref": "npx playwright test", "result": "41 passed, 2 failed / exit 1", "ok": false},
              {"kind": "screenshot", "ref": "test-results/checkout-pays/failed.png", "result": "captured", "ok": true}]}
```
- 서버 미기동/브라우저 미설치/키 부재 → `BLOCKED` (테스트 실패로 위장하지 않는다).
- `NOT_MET`은 재시도 가능한 경우에만. 오케스트레이터의 fix 루프(max 3)는 매 회 `next_action_hint`가 달라야 한다.
- Critical/High 실패가 남은 상태에서 "E2E 통과"로 보고하는 것은 금지(§3.4).

## FRAMEWORK-SPECIFIC PATTERNS

### Next.js App Router
```yaml
Auto_Detection: next.config.ts or next.config.js in project root

Patterns:
  - Server Component rendering: verify DOM content after SSR
  - Server Actions: submit forms, verify side effects
  - Loading states: trigger slow requests, verify loading.tsx UI
  - Error boundaries: trigger errors, verify error.tsx UI
  - Middleware redirects: navigate to protected routes, verify redirect
  - Dynamic routes: test [slug] pages with various params
  - ISR/SSG: verify initial content, trigger revalidation

Config:
  webServer:
    command: 'npm run dev'
    url: 'http://localhost:3000'
    reuseExistingServer: !process.env.CI
```

### React SPA
```yaml
Auto_Detection: vite.config.ts or react-scripts in package.json

Patterns:
  - Client-side routing: navigate and verify DOM updates
  - State management: trigger actions, verify UI reflection
  - Lazy loading: verify component loading states
  - Error boundaries: verify graceful error handling
```

### API-Only
```yaml
Auto_Detection: No frontend framework, express/fastify/hono in dependencies

Patterns:
  - Use APIRequestContext exclusively (no browser)
  - Health check endpoint verification
  - CRUD operation lifecycle tests
  - Auth token flow (login, use token, refresh, logout)
  - Error response format validation
```

---

## MCP INTEGRATION

| MCP Server | Role | Auto-Activation |
|------------|------|-----------------|
| **Playwright** | Browser automation and DOM queries | Always |
| **Context7** | Playwright API documentation | New API usage |
| **CodeGraph** | Code analysis and symbol navigation | Always |

---

## ANTI-PATTERN DETECTION

```yaml
Detection_Rules:
  waitForTimeout:
    pattern: "waitForTimeout\\("
    severity: High
    message: "Replace with auto-retrying assertion"
    fix: "Use expect(locator).toBeVisible() instead"

  screenshot_assertion:
    pattern: "toHaveScreenshot\\(|page\\.screenshot\\("
    severity: Critical
    message: "Use DOM-based assertions, not screenshots"
    fix: "Use expect(locator).toHaveText() or toBeVisible()"

  css_class_selector:
    pattern: "page\\.(click|locator)\\(['\"]\\."
    severity: High
    message: "CSS class selectors are fragile"
    fix: "Use getByRole, getByLabel, or getByTestId"

  xpath_selector:
    pattern: "page\\.(click|locator)\\(['\"]\\/"
    severity: High
    message: "XPath selectors are fragile and hard to maintain"
    fix: "Use semantic selectors (role, label, testid)"

  hardcoded_url:
    pattern: "page\\.goto\\(['\"]https?://"
    severity: Medium
    message: "Hardcoded URL detected"
    fix: "Use baseURL from playwright.config.ts"

  repeated_login:
    pattern: "fill.*password.*click.*sign.in"
    severity: Medium
    message: "Login repeated across tests"
    fix: "Use storageState for auth reuse"

  no_accessibility:
    pattern: "test\\("
    absence: "AxeBuilder|axe-core"
    severity: Medium
    message: "No accessibility tests found"
    fix: "Add axe-core assertions per page"
```

---

## EXAMPLES

### Basic E2E Setup
```
/da:e2e src/ --framework nextjs
# Detects Next.js, creates playwright.config.ts, writes critical path tests
# Generates: config, page objects, auth flow, CRUD tests, a11y tests
```

### Accessibility Audit
```
/da:e2e src/ --focus a11y
# Runs axe-core on all pages
# Reports WCAG 2.1 AA violations with fix suggestions
```

### API Testing
```
/da:e2e src/api/ --focus api
# Uses APIRequestContext for headless API testing
# Tests: health, auth, CRUD, error responses
```

### Full Suite with CI
```
/da:e2e src/ --focus all --ci
# Generates complete test suite + GitHub Actions workflow
# Includes: flows, a11y, API, sharding, artifact upload
```

### Compact Report
```
/da:e2e src/ --compact
# Outputs symbolic report format
# "login.spec.ts Flow Pass -- auth flow OK"
```

---

## BOUNDARIES

**Will:**
- Analyze project and design E2E test strategy
- Generate Playwright test code with DOM assertions
- Create Page Object Models for complex pages
- Run accessibility audits with axe-core
- Configure CI/CD pipelines for E2E
- Detect and report anti-patterns

**Will Not:**
- Use screenshots or visual regression testing
- Implement unit or integration tests (use /da:verify)
- Modify application source code (tests only)
- Run tests on external/production environments without approval

---

## PM AGENT SESSION END

```yaml
Session_Completion:
  1. write_memory("e2e_session", summary)
  2. write_memory("e2e_coverage", coverage_report)

Artifacts:
  - Test files: tests/**/*.spec.ts
  - Page objects: tests/page-objects/*.ts
  - Fixtures: tests/fixtures/*.ts
  - Config: playwright.config.ts
  - CI: .github/workflows/e2e.yml (if --ci)
  - Report: docs/e2e-report.md
```

**Relation to /da:verify**: This command focuses exclusively on E2E testing. For full verification (unit + integration + E2E + performance), use `/da:verify` which orchestrates all test types including `/da:e2e` for the E2E portion.
