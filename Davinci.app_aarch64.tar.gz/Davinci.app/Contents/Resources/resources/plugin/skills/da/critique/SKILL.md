---
name: critique
description: |
  Run a 5-dimension expert design review on any HTML artifact --
  Philosophy / Visual Hierarchy / Detail-Execution / Functionality /
  Innovation, each scored 0-10. Outputs a single self-contained HTML
  report with an SVG radar chart + Keep / Fix / Quick-wins lists.
triggers:
  - "critique"
  - "design review"
  - "design audit"
  - "review my deck"
  - "review my landing page"
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 검증자: items[] 기반 match rate와 4값 verdict(MET/NOT_MET/BLOCKED/IMPOSSIBLE)를 handoff에 포함. 생성자와 다른 컨텍스트에서 실행된다.

# Critique Skill -- 5-Dimension Expert Review

Produce a single-file HTML "design review report" that scores any
artifact across 5 dimensions and proposes actionable fixes.

## When to use

- After the agent (or user) generates an artifact and the user asks
  "what's wrong?" or "review this"
- As a self-check loop the agent can run on its own output before
  emitting it
- For comparing two variants of the same design

## What you produce

A single self-contained `<artifact type="text/html">` review report:

1. **Header** -- artifact name, date, reviewer ("Davinci Critique"),
   1-line verdict
2. **Radar chart** (inline SVG, no library) showing the 5 scores
3. **Five dimension cards**, each with:
   - Score 0-10 (band: 0-4 Broken, 5-6 Functional, 7-8 Strong,
     9-10 Exceptional)
   - 1-paragraph evidence (cite specific elements / classes / lines)
   - One Keep / Fix / Quick-win bullet
4. **Combined action lists**:
   - **Keep** -- what works, do not touch
   - **Fix** -- P0/P1 issues that are visually expensive
   - **Quick wins** -- 5-15 minute tweaks with disproportionate impact

## The 5 dimensions

### 1. Philosophy consistency

Does the artifact pick a clear direction and stick to it through
every micro-decision (chrome / kicker / spacing / accent)?

**0-4** Three styles fighting. **5-6** One direction but half drifts.
**7-8** Coherent, occasional edge drift. **9-10** Every element argues
for the same thesis.

### 2. Visual hierarchy

Can a stranger figure out what to read first, second, third without
being told?

**0-4** Everything shouts. **5-6** Works on hero, breaks on body.
**7-8** Clear tiers, occasional collision. **9-10** Eye moves with
zero friction.

### 3. Detail execution

Alignment, leading, kerning at large sizes, image framing, foot/chrome
polish, edge-case spacing.

**0-4** Visible tape and string. **5-6** Most pages clean, 1-2 ragged.
**7-8** Polished, expert eye finds 2-3 misses. **9-10** Magazine-grade.

### 4. Functionality

Does it work for its intended use? Click targets, nav, readability at
presentation distance, mobile fallback.

**0-4** Visually fine but broken. **5-6** Core flow works, edges broken.
**7-8** Robust through normal use. **9-10** Defensively engineered.

### 5. Innovation

Does this push past the median? Is there one element that makes people
lean in?

**0-4** Generic AI-slop median. **5-6** Competent, unmemorable.
**7-8** One memorable moment. **9-10** Multiple moves you would steal.

## Scoring discipline

- Always cite evidence -- numbers without evidence get rejected
- Do not average up -- score reflects the worst sustained band
- Do not grade-inflate -- 7 means strong, not acceptable
- Innovation is allowed to be low -- 5/10 is fine for production

## Workflow

### Step 1 -- Acquire the artifact

Open from project folder, read from pasted chat, or re-read your own
previous artifact output. If multiple HTML files exist, ask which one.

### Step 2 -- Read enough to score

Skim the entire `<style>`, then read 6-8 representative content blocks.
Score depends on executed design, not declared intent.

### Step 3 -- Score with evidence

For each dimension, write the score and a 30-80 word evidence paragraph
naming specific elements, line numbers, class names, page numbers.

### Step 4 -- Build the action lists

Aggregate evidence into Keep (3-5), Fix (3-6), Quick wins (3-5).

### Step 5 -- Emit the report HTML

Single file: header + radar SVG + 5 dimension cards + 3 action lists.
Use active DESIGN.md tokens if available; otherwise neutral light theme.

## Output contract

```
<artifact identifier="critique-{slug}" type="text/html"
  title="Critique -- {Artifact Title}">
<!doctype html><html>...</html>
</artifact>
```

One sentence before the artifact, then stop after `</artifact>`.

## Hard rules

- 5 scores every time -- partial reports not allowed
- Evidence per score -- no "feels off" / "needs work"
- Do not grade-inflate -- overall mean above 8 is suspicious
- Single-file HTML only -- no external CSS/JS, inline everything
- Radar chart is mandatory -- gives recognizable silhouette
