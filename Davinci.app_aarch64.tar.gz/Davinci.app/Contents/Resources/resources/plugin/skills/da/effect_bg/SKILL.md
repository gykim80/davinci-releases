---
name: effect_bg
description: Vanta.js WebGL background effect generation with L4 interactions and L5 finishing overlays.
agent: effect-composer
agents: [frontend-architect]
davinci-phase: design
allowed-tools: [Write, Edit, Read, Bash, Glob, Grep, Task]
next-skill: verify
skill-type: flexible
thinking: ultra
mcp-servers: [context7, codegraph]
skills-ref:
  - davinci_framework/agent-skills/skills/mengto-gsap
  - davinci_framework/agent-skills/skills/mengto-cinematic-gsap-lenis-motion-system
  - davinci_framework/agent-skills/skills/mengto-scroll-scrubbed-visual-sequence
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 생성자: 자기 검증은 사전 점검일 뿐이다. 최종 판정은 독립 verify 노드가 낸다. 미완료 시 partial + remaining.

# /da:effect_bg -- Vanta.js WebGL Background Effect Engine

## MengTo Reference Skills (on-demand — 필요 시에만 Read)
> 경로: `~/.claude/plugin/agent-skills/skills/<name>/SKILL.md`
- `mengto-gsap`: GSAP timeline/ScrollTrigger 패턴
- `mengto-cinematic-gsap-lenis-motion-system`: Lenis 스무스 스크롤 + 시네마틱 배경 모션
- `mengto-scroll-scrubbed-visual-sequence`: 스크롤 스크럽 비주얼 시퀀스
## Tool Parameter Rules -> See CLAUDE.md (ABSOLUTE)


ultrathink

> Independent skill. No dependency on da:effect_text or da:effect_particle.

## Execution Protocol

### Step 1: Context Detection
```yaml
1. Check invocation mode:
   - ARGUMENTS contains persona info -> da:design delegation mode
   - ARGUMENTS contains only tone/prompt -> standalone mode
2. Read package.json -> verify required dependencies
   - three, vanta
3. Missing packages -> run pnpm add
```

### Step 2: Tone Selection
```yaml
When delegated from da:design:
  persona -> automatic tone mapping (refer to tone-presets.md)
  minimal->minimal, bold->dark, playful->playful, elegant->luxury, terminal->cyber

When invoked standalone:
  Analyze prompt keywords -> select optimal tone
```

### Step 3: Implementation
```yaml
1. Layer 1 (Background):
   - vanta-backgrounds.md -> Create VantaBackground component
   - Include CSS fallback for WebGL failure
   - Vanta children pattern required (content as children, NOT siblings)

2. Layer 4 (Interaction, built-in):
   - mouse:parallax, scroll:parallax, hover:glow
   - Refer to references/interactions.md

3. Layer 5 (Finishing, built-in):
   - grain, vignette, glow, scanlines per tone
   - Refer to references/finishing.md

4. Loading State:
   - EffectLoader required for WebGL init wait
   - Refer to references/effect-loading.md
```

### Step 4: Validation
```yaml
1. tsc --noEmit (type check)
2. Verify prefers-reduced-motion CSS fallback
3. Verify WebGL failure -> CSS gradient fallback
4. Verify Vanta children pattern (NOT sibling)
```

## Iron Rules

### Common (C1-C4)
- C1: prefers-reduced-motion -> CSS fallback only, no WebGL
- C2: cleanup function required (unmount -> destroy Vanta instance)
- C3: "use client" required
- C4: EffectLoader required (async WebGL init)

### Background-Specific (B1-B4)
- B1: Vanta children pattern (content as children, z-index auto-managed)
- B2: THREE static import + manual renderer creation for DPR cap
- B3: Visibility API (pause render on hidden tab)
- B4: WebGL failure -> CSS gradient fallback

### Performance
- DPR cap: renderer.setPixelRatio(Math.min(dpr, 2))
- powerPreference: "default" (NOT "high-performance")
- stencil: false (Vanta does not use stencil)
- mousemove rAF throttle required
- GrainOverlay: CSS background-image (NOT SVG filter)

### Bundler Compatibility
- THREE static import: import * as THREE from "three" + window.THREE = THREE
- await import("three") forbidden
- Vite optimizeDeps include: ["three"]

## Deliverables
- VantaBackground component
- Interaction hooks (useMouseParallax, ScrollParallax, GlowFollower)
- Finishing overlays (GrainOverlay, VignetteOverlay, GlowOverlay, ScanlinesOverlay)
- EffectLoader component
