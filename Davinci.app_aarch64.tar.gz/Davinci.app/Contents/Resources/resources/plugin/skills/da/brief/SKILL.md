---
name: brief
description: Brief Gate — design 세션의 아티팩트와 chatLog를 합성하여 9-section PRD + per-page sub-PRD를 생성하는 게이트 스킬. SendToDev 클릭 시 davinci-gui가 자동 호출한다.
agent: senior-architect
agents: [ux-designer, cto-lead]
davinci-phase: brief
allowed-tools: [Read, Write, Glob]
next-skill: plan
skill-type: gate
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 생성자: 자기 검증은 사전 점검일 뿐이다. 최종 판정은 독립 verify 노드가 낸다. 미완료 시 partial + remaining.

# /da:brief

Brief Gate 스킬. design 세션 종료 → dev 세션 진입 사이에 삽입되어 PRD를 자동 합성한다.

## Iron Law
**디자인 의도(WHY)를 잃지 않는다. 각 페이지는 ≥3개의 측정 가능한 Acceptance Criteria를 가진다.**

## Input Contract

호출자(GUI/triggerBriefGate)는 다음 JSON을 stdin/슬래시 인자로 전달한다.

```json
{
  "designSessionId": "sess-abc",
  "devSessionId": "sess-def",
  "artifacts": [
    { "id": "art-1", "html": "<...>", "jsx": "<optional>", "title": "Landing Page" }
  ],
  "originalBrief": "유저가 처음 입력한 브리프 텍스트",
  "chatLog": [
    { "role": "user", "content": "..." },
    { "role": "assistant", "content": "..." }
  ]
}
```

토큰 예산: 입력 ~10K, 출력 ~4K.

## 4-Phase Protocol

### Phase 1 — Context Collection
1. 입력 JSON을 파싱하여 `artifacts[]`, `chatLog[]`, `originalBrief`를 분리
2. chatLog에서 디자인 의도(WHY) 단서 추출: 사용자 의사결정 근거, 거부된 대안, 강조한 제약
3. artifacts에서 페이지 메타 추출: title, 주요 영역, 인터랙션 단서

### Phase 2 — Synthesis (Sonnet 4.6)
9-section PRD를 다음 구조로 생성한다.

```markdown
# PRD — {projectName}

## 1. Overview
## 2. Problem Statement
## 3. Goals & Non-Goals
## 4. Target Users
## 5. User Stories
## 6. Functional Requirements
## 7. Non-Functional Requirements
## 8. Success Metrics
## 9. Constraints & Risks

## Pages

### Page: {pageId}
- Purpose: {one sentence}
- Core Functions:
  - {bullet 1}
  - {bullet 2}
- States: Empty / Loading / Error / Success
- Data Dependencies: {list or "none"}
- Navigation: Entry={...} / Exit={...}
- Acceptance Criteria:
  - [ ] {measurable criterion 1}
  - [ ] {measurable criterion 2}
  - [ ] {measurable criterion 3}
```

**강제 사항**:
- 각 페이지마다 Acceptance Criteria **≥3개** (측정 가능, 체크리스트 형식)
- 빈 섹션 금지 — 정보 부족 시 "TBD: {질문}"으로 표시
- chatLog의 의도 단서를 인용하여 추론 근거를 명시

### Phase 3 — Review Gate (Streaming)
- markdown 토큰을 stdout으로 스트리밍 출력 (GUI가 PrdReviewPanel에 렌더)
- **`AskUserQuestion` 호출 금지** — 승인/편집/스킵은 GUI가 처리
- 합성 완료 후 `[BRIEF_SYNTH_DONE]` 마커 라인 출력

### Phase 4 — Persist
1. 슬러그 생성: `originalBrief`에서 영문 키워드 3개 추출 → kebab-case
2. 파일 경로: `docs/prd/PRD-{slug}-{YYYY-MM-DD}.md`
   - 동일 경로 존재 시 `-v2`, `-v3` 접미사 사용
3. `Write(prd_path, content)`로 파일 저장
4. Handoff JSON을 stdout 마지막 줄에 출력:

```json
{
  "skill": "da:brief",
  "status": "completed",
  "prd_path": "docs/prd/PRD-...",
  "page_count": 3,
  "ac_count": 12
}
```

GUI는 `prd_path`를 받아 `save_prd_artifact` Tauri command로 DB에 영속화한다.

## Validation Checklist
- [ ] 9개 PRD 섹션 모두 작성됨 (TBD 마커 허용)
- [ ] 페이지 수 ≥ 1
- [ ] 모든 페이지에 Acceptance Criteria ≥ 3
- [ ] 파일 저장 성공
- [ ] Handoff JSON에 `prd_path`, `page_count`, `ac_count` 포함

## Failure Modes
- 입력 JSON 파싱 실패 → `{"status":"failed","reason":"input_parse_error"}` 출력 후 종료
- artifacts 0개 → originalBrief만으로 합성 시도, 페이지 수 1로 강제
- 출력 토큰 초과 → 페이지를 sub-PRD 인덱스로 축약하고 본문은 별도 파일로 분리

## Skip Flow
사용자가 GUI에서 Skip 선택 시: 이 스킬은 호출되지 않는다.
이미 호출 중이라면 GUI가 프로세스를 종료한다 (스킬은 자체적으로 skip을 판단하지 않음).

## Downstream Contract
- da:plan: `[PRD_CONTEXT]` 블록을 인지하여 PLAN-{slug}.md 명명 매칭
- da:dev: 페이지별 sub-PRD를 TaskGroup으로, AC를 testCriteria로 변환
- da:verify: AC 항목을 자동 체크리스트로 변환 (Phase 2)
