# DaisyUI v5 Component Reference for Davinci

> Includes shadcn/ui equivalent mappings. Automatically loaded when da:design detects a DaisyUI project.

## Component Mapping Table

| shadcn/ui Component | DaisyUI Equivalent | Key Classes |
|--------------------|--------------------|-------------|
| `<Button>` | `<button class="btn">` | `btn`, `btn-primary`, `btn-secondary`, `btn-accent`, `btn-ghost`, `btn-outline`, `btn-link` |
| `<Card>` | `<div class="card">` | `card`, `card-body`, `card-title`, `card-actions` |
| `<Dialog>` | `<dialog class="modal">` | `modal`, `modal-box`, `modal-action`, `modal-backdrop` |
| `<Badge>` | `<span class="badge">` | `badge`, `badge-primary`, `badge-secondary`, `badge-outline` |
| `<Input>` | `<input class="input">` | `input`, `input-bordered`, `input-primary` |
| `<Textarea>` | `<textarea class="textarea">` | `textarea`, `textarea-bordered` |
| `<Select>` | `<select class="select">` | `select`, `select-bordered` |
| `<Checkbox>` | `<input class="checkbox">` | `checkbox`, `checkbox-primary` |
| `<Switch>` | `<input class="toggle">` | `toggle`, `toggle-primary` |
| `<Alert>` | `<div class="alert">` | `alert`, `alert-info`, `alert-success`, `alert-warning`, `alert-error` |
| `<Avatar>` | `<div class="avatar">` | `avatar`, `online`, `offline`, `placeholder` |
| `<Tooltip>` | `<div class="tooltip">` | `tooltip`, `data-tip="..."` |
| `<Separator>` | `<div class="divider">` | `divider`, `divider-horizontal` |
| `<Skeleton>` | `<div class="skeleton">` | `skeleton`, `h-32`, `w-full` |
| `<Progress>` | `<progress class="progress">` | `progress`, `progress-primary` |
| `<Sheet>` | Drawer pattern | `drawer`, `drawer-toggle`, `drawer-side` |
| `<Tabs>` | `<div role="tablist" class="tabs">` | `tabs`, `tabs-bordered`, `tabs-lifted`, `tab`, `tab-active` |
| `<Accordion>` | Collapse (join pattern) | `collapse`, `collapse-arrow`, `join`, `join-vertical` |
| `<Table>` | `<table class="table">` | `table`, `table-zebra`, `table-pin-rows` |
| `<DropdownMenu>` | `<div class="dropdown">` | `dropdown`, `dropdown-content`, `menu` |

---

## Button

```html
<!-- Base variants -->
<button class="btn btn-primary">Primary</button>
<button class="btn btn-secondary">Secondary</button>
<button class="btn btn-accent">Accent</button>
<button class="btn btn-neutral">Neutral</button>
<button class="btn btn-info">Info</button>
<button class="btn btn-success">Success</button>
<button class="btn btn-warning">Warning</button>
<button class="btn btn-error">Error</button>

<!-- Style variants -->
<button class="btn btn-outline btn-primary">Outline</button>
<button class="btn btn-ghost">Ghost</button>
<button class="btn btn-link">Link</button>
<button class="btn btn-soft btn-primary">Soft</button>

<!-- Sizes -->
<button class="btn btn-xs">Extra Small</button>
<button class="btn btn-sm">Small</button>
<button class="btn">Default</button>
<button class="btn btn-lg">Large</button>

<!-- Loading state -->
<button class="btn btn-primary">
  <span class="loading loading-spinner loading-sm"></span>
  Loading...
</button>

<!-- Icon button -->
<button class="btn btn-square btn-sm">
  <svg>...</svg>
</button>
<button class="btn btn-circle">
  <svg>...</svg>
</button>
```

## Card

```html
<div class="card bg-base-100 shadow-xl">
  <figure>
    <img src="/images/cover.jpg" alt="Cover" />
  </figure>
  <div class="card-body">
    <h2 class="card-title">
      Card Title
      <div class="badge badge-secondary">NEW</div>
    </h2>
    <p>Card description text goes here.</p>
    <div class="card-actions justify-end">
      <button class="btn btn-primary">Action</button>
    </div>
  </div>
</div>

<!-- Compact card -->
<div class="card card-compact bg-base-100 shadow-xl">
  <div class="card-body">
    <h2 class="card-title">Compact</h2>
    <p>Less padding</p>
  </div>
</div>

<!-- Side image card -->
<div class="card card-side bg-base-100 shadow-xl">
  <figure><img src="/images/side.jpg" alt="Side" /></figure>
  <div class="card-body">
    <h2 class="card-title">Side Image</h2>
    <p>Horizontal layout</p>
  </div>
</div>
```

## Modal (Dialog)

```html
<!-- Trigger -->
<button class="btn" onclick="my_modal.showModal()">Open Modal</button>

<!-- Modal -->
<dialog id="my_modal" class="modal">
  <div class="modal-box">
    <h3 class="text-lg font-bold">Modal Title</h3>
    <p class="py-4">Modal content goes here.</p>
    <div class="modal-action">
      <form method="dialog">
        <button class="btn">Close</button>
      </form>
    </div>
  </div>
  <form method="dialog" class="modal-backdrop">
    <button>close</button>
  </form>
</dialog>
```

## Navbar

```html
<div class="navbar bg-base-100">
  <div class="navbar-start">
    <a class="btn btn-ghost text-xl">Logo</a>
  </div>
  <div class="navbar-center hidden lg:flex">
    <ul class="menu menu-horizontal px-1">
      <li><a>Features</a></li>
      <li><a>Pricing</a></li>
      <li><a>Docs</a></li>
    </ul>
  </div>
  <div class="navbar-end">
    <a class="btn btn-primary">Get Started</a>
  </div>
</div>
```

## Drawer (Sheet replacement)

```html
<div class="drawer lg:drawer-open">
  <input id="app-drawer" type="checkbox" class="drawer-toggle" />
  <div class="drawer-content">
    <!-- Main content -->
    <label for="app-drawer" class="btn btn-ghost drawer-button lg:hidden">
      <svg><!-- Menu icon --></svg>
    </label>
  </div>
  <div class="drawer-side">
    <label for="app-drawer" class="drawer-overlay"></label>
    <ul class="menu bg-base-200 min-h-full w-80 p-4">
      <li><a>Dashboard</a></li>
      <li><a>Settings</a></li>
    </ul>
  </div>
</div>
```

## Hero

```html
<div class="hero min-h-screen bg-base-200">
  <div class="hero-content text-center">
    <div class="max-w-md">
      <h1 class="text-5xl font-bold">Headline</h1>
      <p class="py-6">Description text for the hero section.</p>
      <button class="btn btn-primary">Get Started</button>
    </div>
  </div>
</div>

<!-- Overlay hero -->
<div class="hero min-h-screen" style="background-image: url(/images/hero.jpg);">
  <div class="hero-overlay bg-opacity-60"></div>
  <div class="hero-content text-neutral-content text-center">
    <div class="max-w-md">
      <h1 class="text-5xl font-bold mb-5">Overlay Hero</h1>
      <button class="btn btn-primary">Explore</button>
    </div>
  </div>
</div>
```

## Stats

```html
<div class="stats shadow">
  <div class="stat">
    <div class="stat-figure text-primary">
      <svg><!-- Icon --></svg>
    </div>
    <div class="stat-title">Total Users</div>
    <div class="stat-value text-primary">25.6K</div>
    <div class="stat-desc">21% more than last month</div>
  </div>
  <div class="stat">
    <div class="stat-title">Revenue</div>
    <div class="stat-value text-secondary">$4.2M</div>
    <div class="stat-desc text-secondary">+12%</div>
  </div>
</div>
```

## Tabs

```html
<div role="tablist" class="tabs tabs-bordered">
  <input type="radio" name="my_tabs" role="tab" class="tab" aria-label="Tab 1" checked />
  <div role="tabpanel" class="tab-content p-10">Tab 1 content</div>

  <input type="radio" name="my_tabs" role="tab" class="tab" aria-label="Tab 2" />
  <div role="tabpanel" class="tab-content p-10">Tab 2 content</div>
</div>
```

## Collapse / Accordion (FAQ)

```html
<div class="join join-vertical w-full">
  <div class="collapse collapse-arrow join-item border border-base-300">
    <input type="radio" name="accordion" checked />
    <div class="collapse-title text-xl font-medium">Question 1</div>
    <div class="collapse-content">
      <p>Answer to question 1.</p>
    </div>
  </div>
  <div class="collapse collapse-arrow join-item border border-base-300">
    <input type="radio" name="accordion" />
    <div class="collapse-title text-xl font-medium">Question 2</div>
    <div class="collapse-content">
      <p>Answer to question 2.</p>
    </div>
  </div>
</div>
```

## Pricing Card (composite pattern)

```html
<div class="card bg-base-100 shadow-xl border border-primary">
  <div class="card-body items-center text-center">
    <span class="badge badge-primary">Popular</span>
    <h2 class="card-title text-2xl">Pro Plan</h2>
    <p class="text-4xl font-bold text-primary">
      $29<span class="text-sm text-base-content/60">/mo</span>
    </p>
    <ul class="text-left space-y-2 my-4">
      <li>Feature 1</li>
      <li>Feature 2</li>
      <li>Feature 3</li>
    </ul>
    <div class="card-actions">
      <button class="btn btn-primary btn-wide">Get Started</button>
    </div>
  </div>
</div>
```

## Form Elements

```html
<!-- Input -->
<label class="form-control w-full">
  <div class="label"><span class="label-text">Email</span></div>
  <input type="email" placeholder="you@example.com" class="input input-bordered w-full" />
  <div class="label"><span class="label-text-alt">Required</span></div>
</label>

<!-- Textarea -->
<textarea class="textarea textarea-bordered w-full" placeholder="Message"></textarea>

<!-- Select -->
<select class="select select-bordered w-full">
  <option disabled selected>Pick one</option>
  <option>Option 1</option>
  <option>Option 2</option>
</select>

<!-- Checkbox -->
<label class="label cursor-pointer">
  <span class="label-text">Remember me</span>
  <input type="checkbox" class="checkbox checkbox-primary" />
</label>

<!-- Toggle -->
<input type="checkbox" class="toggle toggle-primary" />

<!-- Range -->
<input type="range" min="0" max="100" class="range range-primary" />
```

## Dropdown

```html
<div class="dropdown">
  <div tabindex="0" role="button" class="btn m-1">Click</div>
  <ul tabindex="0" class="dropdown-content menu bg-base-100 rounded-box z-[1] w-52 p-2 shadow">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>
```

## Loading / Skeleton

```html
<!-- Loading Spinner -->
<span class="loading loading-spinner loading-lg"></span>
<span class="loading loading-dots loading-lg"></span>
<span class="loading loading-ring loading-lg"></span>
<span class="loading loading-bars loading-lg"></span>

<!-- Skeleton -->
<div class="flex w-52 flex-col gap-4">
  <div class="skeleton h-32 w-full"></div>
  <div class="skeleton h-4 w-28"></div>
  <div class="skeleton h-4 w-full"></div>
  <div class="skeleton h-4 w-full"></div>
</div>
```

## Alert

```html
<div role="alert" class="alert alert-info">
  <svg><!-- Icon --></svg>
  <span>Info message here.</span>
</div>

<div role="alert" class="alert alert-success">
  <svg><!-- Icon --></svg>
  <span>Success!</span>
</div>

<div role="alert" class="alert alert-warning">
  <span>Warning message.</span>
</div>

<div role="alert" class="alert alert-error">
  <span>Error occurred.</span>
</div>
```

## Tooltip

```html
<div class="tooltip" data-tip="Tooltip text">
  <button class="btn">Hover me</button>
</div>

<!-- Direction -->
<div class="tooltip tooltip-bottom" data-tip="Bottom">
  <button class="btn">Bottom</button>
</div>
```

## Table

```html
<div class="overflow-x-auto">
  <table class="table table-zebra">
    <thead>
      <tr>
        <th>#</th>
        <th>Name</th>
        <th>Email</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <th>1</th>
        <td>John Doe</td>
        <td>john@example.com</td>
      </tr>
    </tbody>
  </table>
</div>
```

---

## React/Next.js Integration Pattern

DaisyUI is class-based, so use className without separate imports:

```tsx
// shadcn/ui approach (requires import)
import { Button } from "@/components/ui/button"
<Button variant="default" size="lg">Click</Button>

// DaisyUI approach (no import needed)
<button className="btn btn-primary btn-lg">Click</button>
```

### Conditional Styling (clsx/cn)

```tsx
import { clsx } from "clsx"

function ActionButton({ variant = "primary", loading = false }) {
  return (
    <button className={clsx(
      "btn",
      `btn-${variant}`,
      loading && "btn-disabled"
    )}>
      {loading && <span className="loading loading-spinner loading-sm" />}
      {loading ? "Processing..." : "Submit"}
    </button>
  )
}
```
