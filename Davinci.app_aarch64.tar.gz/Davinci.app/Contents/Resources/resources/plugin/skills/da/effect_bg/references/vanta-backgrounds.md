# Vanta.js Background Effects Reference

> da:effect_bg Layer 1 — 14-type WebGL background effects
> Dependencies: `vanta@^0.5.24` (three 별도 설치 불필요 -- vanta 번들 사용)

## React Integration Pattern (common)

```tsx
"use client"
import { useEffect, useRef, useState } from "react"

// B2: Vanta 번들 Three.js r134 사용 (프로젝트의 three 패키지 사용 금지)
// Vanta 0.5.24는 Three.js r134용으로 설계됨. r150+ 사용 시 breaking changes:
// - PlaneBufferGeometry 제거 (r151) -> birds GPGPU 깨짐
// - VertexColors 제거 (r136) -> birds CPU fallback 깨짐
// - BufferAttribute.length 제거 -> birds 색상 배열 깨짐
// - setClearColor(undefined) throw -> waves/fog animation loop 중단
// eslint-disable-next-line @typescript-eslint/no-explicit-any
let threeCache: any = null
async function loadThree() {
  if (threeCache) return threeCache
  const mod = await import("vanta/vendor/three.r134.min")
  threeCache = mod.default || mod
  if (typeof window !== "undefined") {
    ;(window as any).THREE = threeCache
    if (!(window as any).VANTA) (window as any).VANTA = {}
  }
  return threeCache
}

interface VantaBgProps {
  effect: string
  options?: Record<string, unknown>
  className?: string
  children?: React.ReactNode
  fallbackGradient?: string
  onReady?: () => void
}

export function VantaBackground({
  effect,
  options = {},
  className,
  children,
  fallbackGradient = "linear-gradient(135deg, #0a0a1a 0%, #1a1a2e 100%)",
  onReady,
}: VantaBgProps) {
  const ref = useRef<HTMLDivElement>(null)
  const [instance, setInstance] = useState<{ destroy: () => void } | null>(null)

  useEffect(() => {
    // C1: prefers-reduced-motion -> CSS fallback only
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      if (ref.current) ref.current.style.background = fallbackGradient
      onReady?.()
      return
    }

    let vantaEffect: { destroy: () => void } | null = null

    async function init() {
      // THREE r134 + Vanta effect 병렬 로드
      const [THREE, mod] = await Promise.all([
        loadThree(),
        import(`vanta/dist/vanta.${effect}.min`),
      ])
      const effectFn = mod.default || (window as any).VANTA?.[effect.toUpperCase()]

      if (ref.current && effectFn) {
        vantaEffect = effectFn({
          el: ref.current,
          THREE,
          mouseControls: true,
          touchControls: true,
          gyroControls: false,
          forceAnimate: true,
          minHeight: 200,
          minWidth: 200,
          scale: 1.0,
          scaleMobile: 1.0,
          ...options,
        })
        setInstance(vantaEffect)
        onReady?.()
      }
    }

    // B4: WebGL failure -> CSS gradient fallback
    init().catch(() => {
      if (ref.current) {
        ref.current.style.background = fallbackGradient
      }
    })

    // C2: cleanup required
    return () => { vantaEffect?.destroy() }
  }, [effect, JSON.stringify(options)])

  return (
    <div ref={ref} className={className} style={{ position: "relative", width: "100%", minHeight: "100vh" }}>
      {/* B1: content as children, z-index auto-managed by Vanta prepareEl() */}
      {children}
    </div>
  )
}
```

## Layer Integration — Hero Integration Required Pattern

### Children Pattern (required)

The Vanta container **must wrap content as children**.
Vanta's `prepareEl()` automatically assigns `position: relative; z-index: 1` to child elements,
so text, buttons, and particles placed inside children render correctly above the canvas.

```tsx
// Correct pattern — place content inside children
<VantaBackground effect="waves" options={waveOpts}>
  <div className="hero-content">
    <h1>Welcome</h1>
    <button>Get Started</button>
  </div>
</VantaBackground>
```

```tsx
// Forbidden pattern — separating Vanta as sibling
// Canvas covers everything with absolute positioning, hiding content
<div className="hero">
  <VantaBackground effect="waves" options={waveOpts} />
  <div className="hero-content">  {/* Buried under canvas */}
    <h1>Welcome</h1>
  </div>
</div>
```

### prepareEl() How It Works

Vanta performs the following on the `el` container during initialization:
1. Sets `position: relative` (keeps existing if already set)
2. Inserts `<canvas>` — `position: absolute; z-index: 0; inset: 0`
3. Automatically assigns `position: relative; z-index: 1` to **existing child elements**

Therefore, children inside VantaBackground are displayed above the canvas without separate z-index handling.

> **Iron Rule**: Use the Vanta container as the outermost wrapper,
> and place all other layers (Interaction, Finishing, content) as children.
> Separating Vanta as a sibling element is forbidden under all circumstances.

## 14-Type Effect Catalog

### Shader-based (6 types) — ShaderBase extension, pure GLSL

| Effect | Complexity | Tone Match | Default Options |
|--------|-----------|---------|----------|
| **halo** | 3 | dark, luxury | `baseColor:0x001a59, color2:0xf2e735, backgroundColor:0x131a43` |
| **fog** | 2 | organic, luxury | `highlightColor:0xffc300, midtoneColor:0xff1f00, blurFactor:0.6` |
| **cells** | 2 | cyber, neon | `color1:0x8c8c, color2:0xf2e735, backgroundColor:0xd7ff8f` |
| **clouds** | 3 | luxury, elegant | `skyColor:0x68b8d7, cloudColor:0xadc1de, sunColor:0xff9919` |
| **clouds2** | 2 | dark, organic | `skyColor:0x5ca6ca, cloudColor:0x334d80, lightColor:0xffffff` |
| **ripple** | 2 | minimal, corporate | `color1:0x60b25, color2:0xffffff, ringFactor:4.0` |

### Three.js 3D-based (6 types) — VantaBase extension, 3D objects

| Effect | Complexity | Tone Match | Default Options |
|--------|-----------|---------|----------|
| **waves** | 2 | organic, luxury | `color:0x005588, waveHeight:15, waveSpeed:1` |
| **net** | 2 | neon, cyber | `color:0xff3f81, backgroundColor:0x23153c, points:10` |
| **dots** | 1 | corporate, minimal | `color:0xff8820, backgroundColor:0x222222, spacing:35` |
| **birds** | 2 | playful | `color1:0xff0000, color2:0x00d1ff, birdSize:1, quantity:5` |
| **globe** | 2 | corporate, tech | `color:0xff3f81, points:10, maxDistance:20` |
| **rings** | 2 | neon, cyber | `backgroundColor:0x202428, color:0x88ff00` |

### p5.js-based (2 types) — P5Base extension, additional 390KB

| Effect | Complexity | Tone Match | Default Options |
|--------|-----------|---------|----------|
| **topology** | 2 | cyber, terminal | `color:0x89964e, backgroundColor:0x002222` |
| **trunk** | 1 | organic, playful | `color:0x98465f, backgroundColor:0x222426, chaos:1` |

> Warning: topology/trunk require additional p5.js dependency. Avoid when bundle size is sensitive.

## Common Options (all effects)

```typescript
interface VantaBaseOptions {
  el: HTMLElement | string        // Required: container
  mouseControls?: boolean         // Default true
  touchControls?: boolean         // Default true
  gyroControls?: boolean          // Default false
  minHeight?: number              // Default 200
  minWidth?: number               // Default 200
  scale?: number                  // Desktop scale (default 1)
  scaleMobile?: number            // Mobile scale (default 1)
  speed?: number                  // Animation speed multiplier (default 1)
  backgroundAlpha?: number        // Background opacity (default 1)
}
```

## API Methods

```typescript
const effect = VANTA_EFFECT({ el, THREE, ...options })
effect.setOptions({ speed: 0.5 })  // Runtime option change
effect.resize()                     // Force resize
effect.destroy()                    // Cleanup (useEffect cleanup required)
```

## Performance Optimization (required)

### DPR Cap via Vanta scale option

Vanta의 `scale` 옵션으로 DPR을 제어합니다. 수동 renderer 생성은 불필요합니다.
(수동 renderer 생성 시 THREE r134와 프로젝트 THREE 충돌 위험)

```tsx
// scale로 DPR 제어
vantaEffect = effectFn({
  el: ref.current,
  THREE,
  scale: 1.0,        // high tier (Vanta 내부에서 DPR 적용)
  scaleMobile: 1.0,   // mobile
  ...options,
})
```

### Device Tier Downgrade

| Tier | scale | touchControls | speed |
|------|-------|---------------|-------|
| high | 1.0 | true | original |
| medium | 0.5 | false | original x 0.6 |
| low | --- | --- | CSS fallback only |

### Visibility API — Pause on Hidden Tab

```tsx
useEffect(() => {
  const handler = () => {
    if (ref.current) {
      ref.current.style.visibility = document.hidden ? "hidden" : "visible"
    }
  }
  document.addEventListener("visibilitychange", handler)
  return () => document.removeEventListener("visibilitychange", handler)
}, [])
```

### prefers-reduced-motion

When `prefers-reduced-motion: reduce` is detected, skip Vanta initialization and display only the CSS gradient fallback.
This satisfies both accessibility and performance requirements.
