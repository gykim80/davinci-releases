# Blog Post Layout

**Single-article reading layout.** Use when the request mentions blog, post, article, essay, 글, 블로그, 포스트.

Pair with: `assets/template-blog-post.html` (working HTML skeleton).

## Pre-flight

1. **Read `assets/template-blog-post.html`** — every class/section below already exists there.
2. **Pick a section list before writing copy.** Default rhythm:
   - Hero -> TOC -> Section heading -> Body -> Pull quote -> Image+caption -> Code block -> Author bio + Related
3. **Reading time** is mandatory in the hero meta.
4. **One accent color** only. Used in eyebrow, links, callout edges.

## Trigger keywords

- Korean: `블로그`, `블로그 글`, `포스트`, `아티클`, `글`, `에세이`
- English: `blog`, `blog post`, `post`, `article`, `essay`, `long-form`

When matched in the user prompt, set `vertical=blog-post` and load this file + `assets/template-blog-post.html`.

## Token spec (oklch)

```css
:root {
  --bg: oklch(0.99 0 0);
  --surface: oklch(0.97 0.005 260);
  --text: oklch(0.18 0.02 260);
  --muted: oklch(0.55 0.02 260);
  --accent: oklch(0.55 0.18 260);
  --rule: oklch(0.92 0.005 260);
  --code-bg: oklch(0.96 0.01 260);
  --callout-info: oklch(0.95 0.04 240);
  --callout-warn: oklch(0.95 0.06 80);
  --callout-success: oklch(0.95 0.06 150);
  --callout-error: oklch(0.95 0.06 25);
  --measure: 65ch;       /* body max-width */
  --leading: 1.7;
}
@media (prefers-color-scheme: dark) {
  :root {
    --bg: oklch(0.14 0.01 260);
    --surface: oklch(0.18 0.01 260);
    --text: oklch(0.96 0.005 260);
    --muted: oklch(0.65 0.02 260);
    --accent: oklch(0.75 0.18 260);
    --rule: oklch(0.28 0.01 260);
    --code-bg: oklch(0.22 0.01 260);
  }
}
```

## Section archetype (8 sections)

1. **Hero** — H1 title + meta row (author avatar + name + date + reading time) + cover image slot (16:9 `ph-img wide`).
2. **TOC** — Sticky sidebar on `>=1024px`, collapsible `<details>` on mobile. Anchor links to each H2.
3. **Section heading** — H2 with auto-generated anchor (`<h2 id="...">`). Always preceded by 48px top spacing.
4. **Body paragraph** — `line-height: 1.7`, `max-width: 65ch`, justified left, generous bottom margin.
5. **Inline code + code block** — `<code>` for inline, `<pre><code>` for block. Syntax highlighting hook via `data-lang="ts"` attribute. Monospace font, scroll-x on overflow.
6. **Pull quote / Callout box** — 4 variants via `class="callout callout-info|warn|success|error"`. Left border 4px in callout color.
7. **Image with caption** — `<figure><img alt><figcaption>`, alt text MANDATORY, caption muted color.
8. **Author bio + Related posts grid** — Footer-of-article block. Avatar + bio paragraph + 2-card related grid.

## Mobile-first breakpoints

- `< 640px` — Single column. TOC hidden behind `<details>` summary "목차 보기".
- `640-1023px` — Single column wider, TOC still collapsible.
- `>= 1024px` — TOC sticky sidebar (`position: sticky; top: 24px`), main column centered with `max-width: 65ch`.

## P0 Checklist (must pass)

- [ ] Single `<h1>` per page (in Hero only).
- [ ] Every `<img>` has descriptive `alt=""` (empty alt only for decorative).
- [ ] Article wrapped in semantic `<article>` tag.
- [ ] Reading time visible in hero meta (`X min read` / `X분 소요`).
- [ ] Body uses `<p>` not `<div>` for paragraphs.
- [ ] All anchor links resolve to valid `id` on the page.

## P1 Checklist (should pass)

- [ ] TOC scroll-spy: active section highlighted as user scrolls.
- [ ] `@media (prefers-reduced-motion: reduce)` disables smooth-scroll and any transitions.
- [ ] Dark mode tokens via `prefers-color-scheme: dark` — no separate stylesheet.
- [ ] Body type scale: H1 40-48px, H2 28-32px, H3 22-24px, body 17-18px.
- [ ] Pull quote uses larger size (24-28px) and accent color border.
- [ ] Code blocks scroll horizontally on small screens, no layout shift.

## P2 Checklist (nice to have)

- [ ] Print stylesheet: `@media print` removes TOC sidebar, expands main column, monochrome.
- [ ] Open Graph meta hints in `<head>` (`og:title`, `og:description`, `og:image`).
- [ ] JSON-LD `Article` schema in `<script type="application/ld+json">`.
- [ ] Estimated reading time auto-calc note (200 wpm baseline).
- [ ] Copy-link button on each H2 anchor.

## Anti-patterns (do NOT)

- Multiple `<h1>` per page.
- Images without `alt`.
- Body width > 75ch (hurts readability).
- Smooth-scroll without `prefers-reduced-motion` guard.
- Fixed-px font sizes that break user zoom.
