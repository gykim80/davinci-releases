/**
 * design-canvas.jsx - Multi-Option Design Exploration Grid
 *
 * Provides: DesignCanvas, OptionCell, OptionLabel
 * Usage: Display 2+ design variations in a labeled grid for A/B/C comparison.
 */

const { useState } = React;

// --- DesignCanvas: grid container for multiple design options ---
function DesignCanvas({ columns = 2, gap = 24, padding = 32, bg = "#111", children }) {
  return (
    <div style={{
      display: "grid",
      gridTemplateColumns: `repeat(${columns}, 1fr)`,
      gap,
      padding,
      background: bg,
      minHeight: "100vh",
      alignItems: "start",
    }}>
      {children}
    </div>
  );
}

// --- OptionCell: single design option with label ---
function OptionCell({ label = "Option A", selected = false, onClick, children, aspectRatio = "16/10" }) {
  return (
    <div
      onClick={onClick}
      style={{
        position: "relative",
        borderRadius: 12,
        overflow: "hidden",
        border: selected ? "2px solid #3B82F6" : "2px solid transparent",
        cursor: onClick ? "pointer" : "default",
        transition: "border-color 0.2s ease",
        aspectRatio,
      }}
    >
      <OptionLabel text={label} selected={selected} />
      <div style={{ width: "100%", height: "100%" }}>
        {children}
      </div>
    </div>
  );
}

// --- OptionLabel: floating label badge ---
function OptionLabel({ text, selected = false }) {
  return (
    <div style={{
      position: "absolute",
      top: 12,
      left: 12,
      zIndex: 10,
      background: selected ? "#3B82F6" : "rgba(0,0,0,0.7)",
      color: "#fff",
      padding: "4px 12px",
      borderRadius: 6,
      fontSize: 13,
      fontWeight: 600,
      letterSpacing: "0.02em",
      backdropFilter: "blur(8px)",
    }}>
      {text}
    </div>
  );
}

// --- Example usage component ---
function DesignCanvasExample() {
  const [selected, setSelected] = useState(0);
  const options = ["Option A", "Option B", "Option C", "Option D"];

  return (
    <DesignCanvas columns={2}>
      {options.map((label, i) => (
        <OptionCell
          key={i}
          label={label}
          selected={selected === i}
          onClick={() => setSelected(i)}
        >
          <div style={{
            width: "100%",
            height: "100%",
            background: `oklch(${30 + i * 15}% 0.1 ${200 + i * 40})`,
            display: "grid",
            placeItems: "center",
            color: "#fff",
            fontSize: 24,
          }}>
            {label} Preview
          </div>
        </OptionCell>
      ))}
    </DesignCanvas>
  );
}

window.DesignCanvasKit = { DesignCanvas, OptionCell, OptionLabel };
