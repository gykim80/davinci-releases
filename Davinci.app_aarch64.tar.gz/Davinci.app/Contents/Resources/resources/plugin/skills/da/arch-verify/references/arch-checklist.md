# Architecture Verification Checklist

> 각 항목은 결정적(deterministic) Grep 패턴 또는 CodeGraph 쿼리로 검증 가능하도록 설계됨.
> ECC hexagonal-architecture 7항목 체크리스트 + ADR/Domain-Model 준수 항목을 결합.

## 1. Layer Purity (domain/ 레이어 순수성)

```yaml
Check: src/features/*/domain/**/*.{ts,tsx} 파일에 아래 import가 없어야 함
Grep_Pattern: "^import .* from ['\"](react|next|express|@nestjs|axios|prisma|@supabase)"
Severity: blocking
Rationale: domain/은 프레임워크 교체 시에도 재사용 가능해야 함 (Evans DDD 핵심 원칙)
```

## 2. Port Compliance (외부 의존성은 반드시 Port 경유)

```yaml
Check: src/features/*/application/use-cases/**/*.ts 파일이 adapters/ 구체 클래스를
  직접 import하지 않아야 함 (ports/의 인터페이스만 참조)
Grep_Pattern: "^import .* from ['\"].*\\/adapters\\/"
  (application/use-cases 내부에서 이 패턴 매치되면 위반)
Severity: blocking
```

## 3. Composition Root 단일화

```yaml
Check: adapter 구체 클래스(class ...Adapter, class ...Repository 구현체)가
  composition/ 밖에서 new 되지 않아야 함
Grep_Pattern: "new \\w+(Adapter|RepositoryImpl)\\(" -- composition/ 디렉토리 밖에서 매치되면 위반
Severity: warning
```

## 4. ADR Compliance (신규 의존성은 Accepted ADR 필요)

```yaml
Check:
  1. git diff로 package.json/Cargo.toml/go.mod/requirements.txt의 dependency 추가분 추출
  2. docs/adr/*.md 중 Status: Accepted 문서를 Grep으로 스캔, 추가된 패키지명이 본문에
     언급되는지 확인
  3. 언급 없으면 FAIL -- "새 의존성 {pkg}에 대응하는 Accepted ADR 없음"
Severity: blocking
Note: 이 항목이 이 프로젝트가 겪었던 실제 갭이다 -- 과거 커밋들(OAuth 로그인, Nexus CLI
  백엔드 통합 등)이 ADR 없이 병합된 사례가 존재함 (da:arch-verify 실증 참조)
```

## 5. Bounded Context 경계 위반

```yaml
Check: src/features/<contextA>/ 내부 파일이 src/features/<contextB>/domain/ 또는
  adapters/를 직접 import하지 않아야 함 (컨텍스트 간에는 명시적 Anticorruption Layer
  또는 공유 계약을 통해서만 통신)
Grep_Pattern: "from ['\"]\\.\\./\\.\\./<otherContext>\\/(domain|adapters)"
Severity: warning
```

## 6. Terminology Compliance (CONTEXT.md Avoid 목록)

```yaml
Check: CONTEXT.md의 각 Term에 대한 Avoid 목록 단어가 신규/변경된 코드 식별자·주석·UI
  텍스트에 사용되지 않아야 함
Method: CONTEXT.md 파싱 -> Avoid 단어 목록 추출 -> 대상 diff에 Grep
Severity: warning
```

## 7. Invariant Compliance (DOMAIN-MODEL.md, 휴리스틱)

```yaml
Check: DOMAIN-MODEL.md의 각 Invariant 문장에 대해, 관련 Aggregate 코드에 상태 전이 가드
  (if/guard/assert 등)가 존재하는지 확인
Method: 결정적 검증 불가 -- 휴리스틱. Aggregate Root 클래스/모듈에 조건 분기가 전혀
  없으면 "가드 없음 가능성" 경고만 (FAIL 아님, "Needs Review")
Severity: info
```

## Severity → Gate 매핑

```yaml
blocking: da:verify를 통과시키지 않음 (사용자 확인 없이는 report 완료 처리 불가)
warning: 보고만, da:verify는 계속 진행
info: Needs Review로 표시, 자동 처리 없음
```
