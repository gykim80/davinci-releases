---
name: report
description: Documentation generation and project status reporting
agent: report-generator
agents: [senior-fullstack, senior-architect]
davinci-phase: report
allowed-tools: [Write, Edit, Read, Bash, Glob, Grep, Task]
next-skill: clean
skill-type: flexible
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 생성자: 자기 검증은 사전 점검일 뿐이다. 최종 판정은 독립 verify 노드가 낸다. 미완료 시 partial + remaining.

## Tool Parameter Rules -> See CLAUDE.md (ABSOLUTE)
# /da:report - Final Report Generation

ultrathink

> Claude MUST compile comprehensive project metrics before generating the report.

## Extended Thinking Protocol
- **Collect**: Gather all DAVINCI cycle metrics and deliverable inventory
- **Analyze**: Evaluate match rate progression and quality trends
- **Synthesize**: Compile findings into structured report sections
- **Recommend**: Identify technical debt and future improvement areas

## Behavioral Flow

### Phase 1: Collect Metrics
```yaml
1. DAVINCI_Cycle_Summary:
   - Feature name and description
   - Phase progression timeline
   - Total iterations and duration

2. Match_Rate_History:
   - Initial match rate from first /da:verify
   - Match rate after each /da:improve iteration
   - Final match rate

3. Deliverable_Inventory:
   - All files created/modified
   - Documentation generated
   - Tests written
```

### Phase 2: Generate Report
```yaml
1. Executive_Summary:
   - One-paragraph overview
   - Key metrics table
   - Final status (pass/fail)

2. Detailed_Sections:
   - Requirements coverage
   - Design-to-implementation fidelity
   - Quality metrics
   - Lessons learned

3. Recommendations:
   - Technical debt identified
   - Future improvement areas
   - Architecture notes

4. Deployment_Results (if Deploy Gate was activated):
   format: |
     ## Deployment Results (if Deploy Gate was activated)
     | Provider | Environment | Status | URL | Deploy Time |
     |----------|-------------|--------|-----|-------------|

     ### Monitoring Summary
     - Health Check: [PASS/FAIL per provider]
     - Error Rate: [if applicable]
     - Rollback recommended: [Yes/No]
   source:
     - Collect from /da:deploy execution artifacts
     - Run /da:monitor if post-deploy data is needed
     - Skip section entirely if no deployment occurred
```

### Phase 3: Archive
```yaml
1. Save_Report:
   - Create docs/{feature}/report.md
   - Update DAVINCI status to 'report'
   - Record in deliverable tracker

2. Run_Guide (★ 항상 포함):
   - dev.sh 존재 여부 확인: Glob("./dev.sh")
   - 존재 시: report.md 하단에 "## 실행 방법" 섹션 추가
     ```markdown
     ## 실행 방법

     ```bash
     ./dev.sh
     ```
     브라우저: http://localhost:{PORT}
     ```
   - PORT: dev.sh 내부 `PORT=` 라인에서 추출

3. Prepare_Cleanup:
   - List temporary files for removal
   - Identify archival candidates
```

## Triggers
- After /da:verify passes match rate threshold
- After /da:improve completes iteration cycle
- Manual report generation request

## Usage
```
/da:report [--format detailed|summary|compact]
```

## Boundaries

**Will:**
- Compile accurate metrics from DAVINCI state
- Generate structured report with evidence
- Prepare for cleanup phase

**Will Not:**
- Fabricate metrics or estimates
- Skip deliverable verification

---

## Documentation Integration (Auto-Activated)

### Documentation Child Page/Note (Auto-Created)
```yaml
Trigger: Auto-activated when document sync is enabled during /da:report execution

Behavior:
  1. Check_Active_Sync:
     - Confluence: Check .davinci-confluence-sync.json exists
     - Obsidian: Check .davinci-obsidian-sync.json exists
     - Verify plan page/note ID created by /da:plan

  2. Create_Child:
     Confluence:
       - Auto-create "[REPORT] {feature} - {date}" page under plan page
       - Labels: davinci, report, final, auto-generated
       - Skeleton: Executive Summary, DAVINCI Cycle Summary, Quality Metrics sections
     Obsidian:
       - Call ObsidianPublisher.publish_phase("report")
       - Create "[REPORT] {feature}.md" note (with Frontmatter)
       - Add REPORT link to MOC
       - Git commit + tag + push on auto_push (including tags)

  3. Real-Time_Sync:
     - Auto-sync on report.md file modification
     - PostToolUse(Write|Edit) hook integration
     - Confluence: Markdown → Confluence Storage Format conversion
     - Obsidian: File copy + Git commit

  4. Page_Tree_Structure:
     [PLAN] Feature X - 2026-02-25           ← /da:plan
       ├── [SYSTEM] Feature X - 2026-02-25   ← /da:system
       ├── [DESIGN] Feature X - 2026-02-25   ← /da:design
       └── [REPORT] Feature X - 2026-02-25   ← /da:report (auto-generated)
```

---

> MCP Routing: See CLAUDE.md

---

## Session End
Save checkpoint and proceed to next step.
