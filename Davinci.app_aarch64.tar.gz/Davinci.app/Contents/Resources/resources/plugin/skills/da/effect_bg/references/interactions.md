# Background Interaction Effects Reference

> da:effect_bg L4 Interactions — mouse/scroll/hover effects for background sections
> Dependencies: `motion@^12.x`

## Mouse: parallax

Subtle parallax shift of content based on mouse position.
Uses `useMotionValue` + `useSpring` pattern (useState-based tracking forbidden).

```tsx
import { useEffect } from "react"
import { useMotionValue, useSpring } from "motion/react"

function useMouseParallax(strength = 0.02) {
  const mouseX = useMotionValue(0)
  const mouseY = useMotionValue(0)
  const springX = useSpring(mouseX, { stiffness: 50, damping: 20 })
  const springY = useSpring(mouseY, { stiffness: 50, damping: 20 })

  useEffect(() => {
    let rafId: number | null = null
    let latestEvent: MouseEvent | null = null

    const update = () => {
      if (latestEvent) {
        const cx = window.innerWidth / 2
        const cy = window.innerHeight / 2
        mouseX.set((latestEvent.clientX - cx) * strength)
        mouseY.set((latestEvent.clientY - cy) * strength)
        latestEvent = null
      }
      rafId = null
    }

    const handler = (e: MouseEvent) => {
      latestEvent = e
      if (!rafId) {
        rafId = requestAnimationFrame(update)
      }
    }

    window.addEventListener("mousemove", handler)
    return () => {
      window.removeEventListener("mousemove", handler)
      if (rafId) cancelAnimationFrame(rafId)
    }
  }, [strength])

  return { x: springX, y: springY }
}
```

> **Note**: rAF throttle is applied to prevent calling `set()` on every mousemove event.
> This is a Performance Iron Law requirement.

### Usage
```tsx
function ParallaxContent({ children }: { children: React.ReactNode }) {
  const { x, y } = useMouseParallax(0.02)
  return <motion.div style={{ x, y }}>{children}</motion.div>
}
```

## Scroll: parallax

Vertical parallax displacement based on scroll position.

```tsx
import { useRef } from "react"
import { motion, useScroll, useTransform } from "motion/react"

function ScrollParallax({ children, speed = 0.5 }: { children: React.ReactNode; speed?: number }) {
  const ref = useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] })
  const y = useTransform(scrollYProgress, [0, 1], [`${speed * -50}px`, `${speed * 50}px`])

  return <motion.div ref={ref} style={{ y }}>{children}</motion.div>
}
```

## Scroll: fade

Fade + subtle scale on scroll for hero sections.

```tsx
import { motion, useScroll, useTransform } from "motion/react"

function ScrollFadeHero({ children }: { children: React.ReactNode }) {
  const { scrollY } = useScroll()
  const opacity = useTransform(scrollY, [0, 400], [1, 0])
  const scale = useTransform(scrollY, [0, 400], [1, 0.95])

  return <motion.div style={{ opacity, scale }}>{children}</motion.div>
}
```

## Hover: glow

Radial gradient glow that follows cursor position within the container.

```tsx
import { useState } from "react"

function GlowFollower({ children, color = "rgba(124,58,237,0.3)" }: { children: React.ReactNode; color?: string }) {
  const [pos, setPos] = useState({ x: 50, y: 50 })

  const handleMouse = (e: React.MouseEvent) => {
    const rect = e.currentTarget.getBoundingClientRect()
    setPos({
      x: ((e.clientX - rect.left) / rect.width) * 100,
      y: ((e.clientY - rect.top) / rect.height) * 100,
    })
  }

  return (
    <div onMouseMove={handleMouse} style={{ position: "relative" }}>
      <div style={{
        position: "absolute", inset: 0, pointerEvents: "none",
        background: `radial-gradient(circle at ${pos.x}% ${pos.y}%, ${color} 0%, transparent 50%)`,
      }} />
      {children}
    </div>
  )
}
```

## Tone -> Interaction Mapping

| Tone | Mouse | Scroll |
|------|-------|--------|
| dark | parallax (0.02) | fade |
| neon | glow | — |
| minimal | — | fade |
| organic | — | parallax (0.5) |
| luxury | parallax (0.015) | — |
| corporate | — | fade |
| playful | parallax (0.025) | — |
| cyber | parallax (0.02) | — |

## Mobile Behavior

- Disable all cursor-based effects (mouse:parallax, hover:glow)
- Reduce scroll parallax speed by 50%
- Touch-based interactions rely on Vanta's built-in `touchControls`
