/**
 * android-frame.jsx - Android Device Frame
 *
 * Provides: AndroidFrame component with status bar + gesture navigation bar.
 * Default: Pixel 8 dimensions (412x915 logical).
 */

function AndroidFrame({ children, width = 412, statusBarTime = "12:30", dark = false }) {
  const bg = dark ? "#121212" : "#fafafa";
  const fg = dark ? "#e0e0e0" : "#1f1f1f";
  const height = Math.round(width * (915 / 412));

  const frameStyles = {
    width, height,
    borderRadius: width * 0.08,
    border: `3px solid ${dark ? "#333" : "#c4c4c4"}`,
    background: bg,
    position: "relative",
    overflow: "hidden",
    boxShadow: "0 25px 60px rgba(0,0,0,0.25)",
    margin: "0 auto",
  };

  const statusBarStyles = {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "8px 20px",
    fontSize: 14,
    fontFamily: "'Google Sans', 'Roboto', sans-serif",
    color: fg,
    height: 40,
    background: dark ? "#1a1a1a" : "#f5f5f5",
  };

  const punchHoleStyles = {
    position: "absolute",
    top: 12,
    left: "50%",
    transform: "translateX(-50%)",
    width: 12,
    height: 12,
    borderRadius: "50%",
    background: "#000",
    zIndex: 20,
  };

  const navBarStyles = {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    height: 28,
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    paddingBottom: 6,
  };

  const gestureBarStyles = {
    width: width * 0.35,
    height: 4,
    borderRadius: 100,
    background: dark ? "rgba(255,255,255,0.25)" : "rgba(0,0,0,0.2)",
  };

  const contentStyles = {
    position: "absolute",
    top: 40,
    left: 0,
    right: 0,
    bottom: 28,
    overflow: "auto",
  };

  return (
    <div style={frameStyles}>
      <div style={punchHoleStyles} />
      <div style={statusBarStyles}>
        <span>{statusBarTime}</span>
        <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill={fg}><path d="M1 9l2 2c4.97-4.97 13.03-4.97 18 0l2-2C16.93 2.93 7.08 2.93 1 9zm8 8l3 3 3-3c-1.65-1.66-4.34-1.66-6 0zm-4-4l2 2c2.76-2.76 7.24-2.76 10 0l2-2C15.14 9.14 8.87 9.14 5 13z"/></svg>
          <svg width="16" height="14" viewBox="0 0 27 13" fill={fg}><rect x="0" y="1" width="23" height="11" rx="2.5" stroke={fg} strokeWidth="1" fill="none"/><rect x="2" y="3" width="18" height="7" rx="1" fill={fg}/><rect x="24.5" y="4.5" width="2" height="4" rx="1"/></svg>
        </div>
      </div>
      <div style={contentStyles}>
        {children}
      </div>
      <div style={navBarStyles}>
        <div style={gestureBarStyles} />
      </div>
    </div>
  );
}

window.AndroidFrame = AndroidFrame;
