# Assembly Spec Format

> Phase 3 (Component Assembly)에서 생성하고 Phase 4 (Design Restructure)에서 수정하는 페이지 조립 명세.

## YAML 구조

```yaml
# Assembly Spec v1.0
version: "1.0"
page: landing                    # 페이지 유형 (landing, dashboard, auth, docs, blog)
template_base: nextjs-saas-starter  # da:plan template_foundation 참조 (없으면 null)

sections:
  - block: hero-editorial        # block-registry.json의 블록 ID
    order: 1                     # 섹션 순서
    customization:               # 블록별 커스터마이즈 가능 필드
      title: "AI로 디자인하는 새로운 방법"
      subtitle: "더 빠르게, 더 아름답게"
      cta_text: "시작하기"
      image: "/hero-visual.webp"
      layout_direction: rtl      # 블록 지원 옵션
    effect: vanta-waves           # Phase 2 Effect 연결 (hero 섹션만)
    tokens_override: {}           # Phase 4에서 디자인 토큰 오버라이드

  - block: features-bento
    order: 2
    customization:
      columns: 3
      items:
        - title: "스마트 레이아웃"
          description: "AI가 최적의 배치를 자동 생성"
          icon: "Layout"
        - title: "컴포넌트 조립"
          description: "검증된 블록을 조합하여 빠르게 구성"
          icon: "Puzzle"
        - title: "디자인 토큰"
          description: "일관된 디자인 시스템 자동 적용"
          icon: "Palette"
    tokens_override: {}

  - block: testimonial-masonry
    order: 3
    customization:
      testimonials:
        - quote: "개발 시간이 60% 단축되었습니다"
          author: "김개발"
          role: "CTO"
          company: "테크스타트"
    tokens_override: {}

  - block: pricing-three-column
    order: 4
    customization:
      plans:
        - name: Free
          price: 0
          features: ["기본 템플릿", "3개 프로젝트"]
        - name: Pro
          price: 29
          features: ["모든 템플릿", "무제한 프로젝트", "우선 지원"]
          highlighted: true
        - name: Enterprise
          price: 99
          features: ["커스텀 블록", "전담 지원", "SLA 보장"]
      currency: "USD"
      billing_period: monthly
    tokens_override: {}

  - block: cta-centered
    order: 5
    customization:
      title: "지금 시작하세요"
      subtitle: "무료로 체험해보세요"
      cta_text: "무료 시작"
    tokens_override: {}

design_tokens:
  source: design.tokens.json     # DTCG 토큰 파일 경로
  overrides:                     # Brief 기반 토큰 오버라이드
    --primary: "oklch(0.65 0.25 275)"
    --background: "oklch(0.98 0.01 275)"

metadata:
  generated_by: "da:design Phase 3"
  brief_ref: ".design-ref/creative-brief.md"
  registry_version: "1.0"
```

## 필드 설명

### 최상위

| 필드 | 필수 | 설명 |
|------|------|------|
| version | Y | Assembly Spec 버전 (현재 "1.0") |
| page | Y | 페이지 유형 식별자 |
| template_base | N | da:plan의 template_foundation에서 선택된 템플릿 ID. 없으면 null |
| sections | Y | 섹션 배열 (순서대로) |
| design_tokens | Y | 디자인 토큰 소스 및 오버라이드 |
| metadata | Y | 생성 메타데이터 |

### sections[*]

| 필드 | 필수 | 설명 |
|------|------|------|
| block | Y | block-registry.json의 블록 ID (예: "hero-editorial") |
| order | Y | 페이지 내 섹션 순서 (1부터 시작) |
| customization | Y | 블록의 customizable 필드에 대한 값. block-registry.json의 customizable 배열 참조 |
| effect | N | Phase 2 Effect 연결. hero/cta 섹션에서만 사용 |
| tokens_override | N | Phase 4에서 채워짐. 블록별 디자인 토큰 오버라이드 |

### design_tokens

| 필드 | 필수 | 설명 |
|------|------|------|
| source | Y | DTCG 토큰 파일 경로 |
| overrides | N | Brief 기반 CSS 변수 오버라이드. oklch() 포맷 권장 |

## Phase 3 생성 규칙

1. **블록 선택**: Brief 의도 + 페이지 목적에 맞는 카테고리별 블록 선택
   - Landing page: hero(필수) + features + testimonial/pricing + cta(필수)
   - Dashboard: dashboard-sidebar + dashboard-header + dashboard-cards
   - Auth: form-login 또는 form-register
   - Docs: content-docs + nav-sidebar
   - Blog: content-blog + nav-simple + footer-minimal

2. **선택 기준**: block-registry.json의 description과 Brief 톤 매칭
   - 모던/미니멀 → hero-minimal, features-icon-grid
   - 에디토리얼/매거진 → hero-editorial, testimonial-quote
   - 대담/풀블리드 → hero-fullbleed, cta-fullbleed

3. **Section Diversity**: 연속 2개 섹션이 동일 레이아웃 패턴 금지
   - 위반 시 대안 블록으로 교체

4. **Fallback**: 적합한 블록이 없으면 customization에 `custom: true` 표시하고 기존 Layout 참조로 생성

## Phase 4 Restructure 규칙

1. **토큰 적용**: design_tokens.overrides를 각 섹션의 tokens_override에 전파
2. **커스터마이즈 심화**: Brief 톤에 맞게 간격, 모션, 색상 미세 조정
3. **Anti-Generic**: 첫 번째 흔한 선택 버리기 (Iron Law 5)
4. **최종 출력**: Restructured Spec = Assembly Spec + 토큰 적용 + 커스터마이즈 완료

## 호환성

- block-registry.json이 없거나 빈 경우 → Assembly Spec 생성 스킵, 기존 v4 Layout Phase로 fallback
- template_base가 null이면 → 제로베이스 구성 (블록만으로 페이지 골격 생성)
- 블록 TSX 파일이 누락된 경우 → 해당 블록은 from-scratch 구현으로 전환
