# Background Effect Loading State Reference

> da:effect_bg Loading System — Vanta WebGL background initialization loading state
> Dependencies: `motion@^12.x` (AnimatePresence)

## Problem

Vanta WebGL background requires async initialization (three.js import -> WebGL context -> shader compile)
resulting in **500-1500ms blank screen**. A loading indicator is required during this period.

## useEffectReady Hook

Tracks the background layer's ready state. Simplified from the full 5-layer version
to track only the background layer.

```tsx
"use client"
import { useState, useCallback } from "react"

export function useEffectReady() {
  const [bgReady, setBgReady] = useState(false)

  const setReady = useCallback(() => {
    setBgReady(true)
  }, [])

  return { bgReady, setReady }
}
```

## EffectLoader Component

Displays a tone-colored progress bar during loading. Fades out when `bgReady` is true.

```tsx
"use client"
import { AnimatePresence, motion } from "motion/react"

// tone-specific loading colors
const TONE_COLORS: Record<string, { bg: string; bar: string }> = {
  dark:      { bg: "#0a0a1a", bar: "#7c3aed" },
  neon:      { bg: "#0a001a", bar: "#00ffff" },
  minimal:   { bg: "#000000", bar: "#3b82f6" },
  organic:   { bg: "#1a2e0a", bar: "#8fbc8f" },
  luxury:    { bg: "#0d0d0d", bar: "#d4af37" },
  corporate: { bg: "#f8f9fa", bar: "#3b82f6" },
  playful:   { bg: "#1a1a2e", bar: "#ff6b6b" },
  cyber:     { bg: "#001100", bar: "#00ff41" },
}

interface EffectLoaderProps {
  ready: boolean
  tone?: string
}

export function EffectLoader({ ready, tone = "dark" }: EffectLoaderProps) {
  const colors = TONE_COLORS[tone] ?? TONE_COLORS.dark

  return (
    <AnimatePresence>
      {!ready && (
        <motion.div
          key="effect-loader"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.6, ease: "easeInOut" }}
          style={{
            position: "absolute",
            inset: 0,
            zIndex: 50,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            gap: 16,
            background: colors.bg,
          }}
        >
          {/* Progress bar */}
          <div style={{
            width: 160,
            height: 3,
            borderRadius: 2,
            background: "rgba(255,255,255,0.08)",
            overflow: "hidden",
          }}>
            <motion.div
              style={{
                width: "40%",
                height: "100%",
                borderRadius: 2,
                background: colors.bar,
              }}
              animate={{ x: ["-100%", "300%"] }}
              transition={{ duration: 1.2, ease: "easeInOut", repeat: Infinity }}
            />
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
```

## BgEffectHero Integration Pattern

```tsx
export function BgEffectHero({ tone, children }: { tone: string; children: React.ReactNode }) {
  const { bgReady, setReady } = useEffectReady()

  return (
    <VantaBackground effect="clouds" options={...} onReady={setReady}>
      <EffectLoader ready={bgReady} tone={tone} />
      {/* L4 interaction + L5 finishing as children */}
      {children}
    </VantaBackground>
  )
}
```

## onReady Callback Contract

The VantaBackground component must call `onReady` after the first frame renders.

| Component | onReady Trigger |
|-----------|----------------|
| VantaBackground | Vanta effect initialized + first frame rendered |

> **Iron Rule**: `EffectLoader` must always be included in BgEffectHero.
> Displaying a blank screen while waiting for WebGL initialization is forbidden.
