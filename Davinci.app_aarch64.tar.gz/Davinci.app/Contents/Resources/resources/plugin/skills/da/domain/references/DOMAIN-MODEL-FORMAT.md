# DOMAIN-MODEL.md Format Guide

> CONTEXT.md(용어 사전)의 상위 확장. Role/Domain/Interaction 3계층 온톨로지 프레임워크와
> Evans DDD의 Bounded Context/Aggregate/Invariant 개념을 결합한 경량 포맷.

## File Location

```
{project-root}/docs/domain/DOMAIN-MODEL.md
```

## Template

```markdown
# {Project Name} -- Domain Model

{프로젝트의 핵심 도메인을 1~2문장으로}

## Bounded Contexts

### {ContextName} (예: 주문 컨텍스트)
- **책임**: {이 컨텍스트가 소유하는 비즈니스 능력}
- **소유 용어**: {CONTEXT.md Language 섹션의 하위 집합}

## Entities & Aggregates

### {AggregateRoot} (Aggregate Root)
- **소속 컨텍스트**: {ContextName}
- **식별자**: {ID 필드/규칙}
- **포함**: {하위 Entity/VO 목록}
- **Invariants**:
  - {규칙 1 -- 항상 참이어야 하는 문장}
  - {규칙 2}

## Value Objects

### {VOName}
- **속성**: {구성 필드}
- **불변성**: 생성 후 변경 불가, 값 자체로 동일성 판단

## Context Map

- **{ContextA}** --(Customer-Supplier)--> **{ContextB}**: {관계 설명}
- **{ContextC}** --(Shared Kernel)--> **{ContextD}**: {공유 범위}

## Directory Scaffold (optional)

{da:domain Step 6에서 제안한 경우에만 포함. references/hexagonal-scaffold.md 참조}
```

## Rules

1. **Bounded Context 수 제한**: 명확하지 않으면 억지로 쪼개지 않는다 (과설계 방지)
2. **Invariant는 코드로 옮길 수 있는 문장으로**: "~해야 한다" 형태, 검증 가능해야 함
3. **Aggregate Root만 외부에서 참조 가능**: 내부 Entity/VO는 Root를 통해서만 접근
4. **Context Map 관계는 5종으로 제한**: Shared Kernel / Customer-Supplier / Conformist /
   Anticorruption Layer / Partnership -- 자의적 명칭 금지
5. **CONTEXT.md와의 관계**: CONTEXT.md는 용어(Language), DOMAIN-MODEL.md는 구조(Entity/관계/불변식).
   DOMAIN-MODEL.md 작성 후에도 CONTEXT.md는 유지하며 서로 참조한다
6. **da:arch-verify 연동**: Invariants 섹션은 아키텍처 검증 시 "이 규칙을 어기는 코드 경로가
   있는가"를 확인하는 체크리스트 항목이 된다

## Example

```markdown
# TaskFlow -- Domain Model

프로젝트 관리 SaaS. 팀 협업과 작업 추적을 위한 도구.

## Bounded Contexts

### 워크스페이스 컨텍스트
- **책임**: 조직 단위 관리, 빌링, 멤버십
- **소유 용어**: Workspace, Workspace Member, Billing Plan

### 작업 컨텍스트
- **책임**: 프로젝트/보드/태스크의 생성과 상태 전이
- **소유 용어**: Project, Board, Task

## Entities & Aggregates

### Task (Aggregate Root)
- **소속 컨텍스트**: 작업 컨텍스트
- **식별자**: task_id (UUID)
- **포함**: Assignee(VO 참조), DueDate(VO), Status(VO)
- **Invariants**:
  - Task는 정확히 1개의 Project에 귀속되어야 한다
  - Status가 "Done"인 Task는 DueDate를 변경할 수 없다

## Value Objects

### DueDate
- **속성**: date, timezone
- **불변성**: 생성 후 값 변경 불가 -- 변경은 새 DueDate로 교체

## Context Map

- **작업 컨텍스트** --(Customer-Supplier)--> **워크스페이스 컨텍스트**:
  작업 컨텍스트가 워크스페이스의 멤버십 정보를 소비 (역방향 의존 금지)
```
