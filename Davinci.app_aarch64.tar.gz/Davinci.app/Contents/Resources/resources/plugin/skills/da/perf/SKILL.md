---
name: perf
description: Performance optimization with profiling, bottleneck detection, and framework-specific patterns
agent: code-analyzer
agents: [code-analyzer, bkend-expert, frontend-architect]
davinci-phase: null
allowed-tools: [Read, Glob, Grep, Bash, Write, Edit, Task]
next-skill: null
skill-type: flexible
skills-ref:
  - davinci_framework/agent-skills/skills/mengto-optimize-web-animations
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 생성자: 자기 검증은 사전 점검일 뿐이다. 최종 판정은 독립 verify 노드가 낸다. 미완료 시 partial + remaining.

# /da:perf - Performance Optimization

## MengTo Reference Skills (on-demand — 필요 시에만 Read)
> 경로: `~/.claude/plugin/agent-skills/skills/<name>/SKILL.md`
- `mengto-optimize-web-animations`: rAF 루프/애니메이션 릭/장시간 세션 저하 진단
## Tool Parameter Rules -> See CLAUDE.md (ABSOLUTE)


ultrathink


## Purpose
Performance profiling, bottleneck detection, and optimization with framework-specific best practices.

## Usage
```
/da:perf [target-path] [--profile] [--framework react|next|express|fastapi]
```

## Analysis Areas

### Algorithm Complexity
- Big O analysis of hot paths
- Data structure selection review
- Loop optimization opportunities

### Database Performance
- N+1 query detection
- Index usage analysis
- Query plan review
- Connection pooling

### Frontend Performance
- Bundle size analysis
- Code splitting opportunities
- Render performance (React.memo, useMemo)
- Image and asset optimization

### Backend Performance
- API response time profiling
- Memory usage patterns
- Async/await parallelization
- Caching strategy review

> MCP Routing: See CLAUDE.md

## 3-Step Optimization Flow

### 1. Profile
- Code complexity analysis (Big O)
- DB query pattern detection (N+1, missing indexes)
- Bundle size analysis (barrel imports, tree-shaking)
- Rendering performance analysis (unnecessary re-renders, missing memoization)

### 2. Identify
- Identify critical paths and hotspot code
- Analyze resource usage patterns
- Severity-based priority determination

### 3. Optimize
- Algorithm optimization (O(n^2) -> O(n log n))
- Query optimization (batching, indexes)
- Frontend optimization (React.memo, useMemo, code splitting)
- Apply caching strategies

## Performance Pattern Library

```yaml
N+1_Queries:
  detection: DB calls inside loops
  fix: Batch queries / eager loading

Expensive_Renders:
  detection: Large components without React.memo
  fix: Memoization, derived state

Memory_Leaks:
  detection: Uncleared subscriptions/timers
  fix: Cleanup functions, AbortController

Bundle_Bloat:
  detection: Barrel file imports, large libraries
  fix: Direct imports, dynamic imports
```

## Output Format

```
# Performance Report: [Target]

## Critical (Immediate Fix)
  api/users.ts:45 O(n^2) -> Map lookup

## High
  UserList.tsx:25 needs React.memo

## Medium
  utils.ts:34 magic number -> named constant

Before/After: Response time 450ms -> 120ms
```

## Boundaries

**Will:**
- Profile and identify bottlenecks
- Recommend optimizations with evidence
- Apply safe performance fixes

**Will Not:**
- Optimize prematurely without profiling data
- Sacrifice readability for marginal gains
