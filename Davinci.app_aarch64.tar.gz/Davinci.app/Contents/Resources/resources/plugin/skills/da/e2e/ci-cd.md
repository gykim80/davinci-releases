# CI/CD Integration for E2E Testing

Pipeline configuration for running Playwright E2E tests in continuous integration environments, covering GitHub Actions workflows, Docker containers, test sharding, artifact management, and failure notifications.

## GitHub Actions Workflow

The standard workflow installs dependencies, installs Playwright browsers, runs tests, and uploads artifacts on failure.

**Detect:** `.github/workflows/` directory exists in project -- suggest adding an E2E testing workflow.

### Basic Workflow

```yaml
# .github/workflows/e2e.yml
name: E2E Tests

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  e2e:
    runs-on: ubuntu-latest
    timeout-minutes: 30

    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: 'npm'

      - name: Install dependencies
        run: npm ci

      - name: Install Playwright browsers
        run: npx playwright install --with-deps chromium

      - name: Build application
        run: npm run build

      - name: Run E2E tests
        run: npx playwright test
        env:
          CI: 'true'

      - name: Upload test results
        if: ${{ !cancelled() }}
        uses: actions/upload-artifact@v4
        with:
          name: playwright-report
          path: playwright-report/
          retention-days: 14

      - name: Upload traces on failure
        if: failure()
        uses: actions/upload-artifact@v4
        with:
          name: test-traces
          path: test-results/
          retention-days: 7
```

## Ubuntu Runner with Playwright Dependencies

Playwright requires system-level browser dependencies on Ubuntu. The `--with-deps` flag installs them automatically, or you can use the official Playwright Docker image.

```yaml
# Option 1: Install with system dependencies (recommended for GitHub Actions)
- name: Install Playwright browsers with system deps
  run: npx playwright install --with-deps chromium

# Option 2: Install specific browsers only (faster)
- name: Install only Chromium
  run: npx playwright install --with-deps chromium

# Option 3: Install all browsers
- name: Install all browsers
  run: npx playwright install --with-deps
```

### Key Points

- Use `--with-deps` to install OS-level dependencies (libgbm, libasound, etc.).
- Install only the browsers you need (`chromium` is fastest for CI).
- The GitHub Actions `ubuntu-latest` runner supports all Playwright browsers.

## Playwright Docker Image

Microsoft provides official Docker images with all browsers and dependencies pre-installed. This eliminates dependency installation time.

```yaml
# .github/workflows/e2e-docker.yml
jobs:
  e2e:
    runs-on: ubuntu-latest
    container:
      image: mcr.microsoft.com/playwright:v1.48.0-noble

    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: 'npm'

      - name: Install dependencies
        run: npm ci

      - name: Build application
        run: npm run build

      - name: Run E2E tests
        run: npx playwright test
        env:
          CI: 'true'
          HOME: /root  # Required for container environments
```

### Full Dockerfile for Containerized E2E

```dockerfile
# Dockerfile.e2e
FROM mcr.microsoft.com/playwright:v1.48.0-noble

WORKDIR /app

# Copy package files
COPY package.json package-lock.json ./

# Install dependencies
RUN npm ci

# Copy application code
COPY . .

# Build the application
RUN npm run build

# Run tests
CMD ["npx", "playwright", "test"]
```

```bash
# Build and run
docker build -f Dockerfile.e2e -t e2e-tests .
docker run --rm -e CI=true e2e-tests

# Run with specific test file
docker run --rm -e CI=true e2e-tests npx playwright test tests/auth.spec.ts

# Run with report output
docker run --rm -e CI=true -v $(pwd)/playwright-report:/app/playwright-report e2e-tests
```

## Test Sharding for Parallel Execution

Split tests across multiple CI jobs for faster execution. Playwright supports native sharding that distributes test files across workers.

```yaml
# Bad: Running all tests sequentially in a single job
jobs:
  e2e:
    runs-on: ubuntu-latest
    steps:
      - run: npx playwright test  # All tests in one job, slow

# Good: Shard tests across parallel jobs
jobs:
  e2e:
    runs-on: ubuntu-latest
    strategy:
      fail-fast: false
      matrix:
        shard: [1/4, 2/4, 3/4, 4/4]

    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: 'npm'

      - name: Install dependencies
        run: npm ci

      - name: Install Playwright browsers
        run: npx playwright install --with-deps chromium

      - name: Build application
        run: npm run build

      - name: Run E2E tests (shard ${{ matrix.shard }})
        run: npx playwright test --shard=${{ matrix.shard }}
        env:
          CI: 'true'

      - name: Upload shard report
        if: ${{ !cancelled() }}
        uses: actions/upload-artifact@v4
        with:
          name: blob-report-${{ strategy.job-index }}
          path: blob-report/
          retention-days: 1
```

### Key Points

- Use `fail-fast: false` so one shard failure does not cancel other shards.
- Playwright distributes test files (not individual tests) across shards.
- 4 shards is a good starting point; adjust based on test suite size.

## Merge Shard Reports

After all shards complete, merge their blob reports into a single HTML report.

```yaml
  merge-reports:
    if: ${{ !cancelled() }}
    needs: e2e
    runs-on: ubuntu-latest

    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: 'npm'

      - name: Install dependencies
        run: npm ci

      - name: Download shard reports
        uses: actions/download-artifact@v4
        with:
          path: all-blob-reports
          pattern: blob-report-*
          merge-multiple: true

      - name: Merge reports
        run: npx playwright merge-reports --reporter html ./all-blob-reports

      - name: Upload merged report
        uses: actions/upload-artifact@v4
        with:
          name: playwright-report
          path: playwright-report/
          retention-days: 14
```

### Playwright Config for Sharding

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  reporter: process.env.CI
    ? [['blob'], ['github']]   // Blob for merging, GitHub for annotations
    : [['html', { open: 'never' }]],

  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 1 : undefined, // 1 worker per shard in CI
});
```

## Artifact Upload on Failure

Upload traces, screenshots, and test results when tests fail so developers can debug without reproducing locally.

```yaml
# Bad: No artifacts saved on failure
- name: Run tests
  run: npx playwright test
# Test fails, no way to debug

# Good: Upload traces, screenshots, and report on any failure
- name: Run E2E tests
  run: npx playwright test

- name: Upload test report
  if: ${{ !cancelled() }}
  uses: actions/upload-artifact@v4
  with:
    name: playwright-report
    path: playwright-report/
    retention-days: 14

- name: Upload traces and screenshots
  if: failure()
  uses: actions/upload-artifact@v4
  with:
    name: test-traces
    path: |
      test-results/
      screenshots/
    retention-days: 7
```

### Playwright Config for Trace Collection

```typescript
// playwright.config.ts
export default defineConfig({
  use: {
    trace: 'on-first-retry',          // Capture trace on retry
    screenshot: 'only-on-failure',     // Screenshot on failure
    video: 'retain-on-failure',        // Video on failure
  },
});
```

## Caching Node Modules and Playwright Browsers

Cache dependencies and browser binaries to speed up CI runs significantly.

```yaml
# Bad: Installing browsers on every single run (2-3 minutes wasted)
- name: Install browsers
  run: npx playwright install --with-deps

# Good: Cache Playwright browsers between runs
- name: Cache Playwright browsers
  id: playwright-cache
  uses: actions/cache@v4
  with:
    path: ~/.cache/ms-playwright
    key: playwright-${{ runner.os }}-${{ hashFiles('package-lock.json') }}

- name: Install Playwright browsers
  if: steps.playwright-cache.outputs.cache-hit != 'true'
  run: npx playwright install --with-deps chromium

- name: Install Playwright system deps (when cache hit)
  if: steps.playwright-cache.outputs.cache-hit == 'true'
  run: npx playwright install-deps chromium
```

### Key Points

- Cache key should include `package-lock.json` hash so cache invalidates when Playwright version changes.
- Even with cached browsers, you still need `install-deps` for OS-level dependencies.
- `actions/setup-node` with `cache: 'npm'` handles `node_modules` caching automatically.

## webServer Configuration for CI

Configure Playwright to build and start the application server automatically in CI.

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  webServer: {
    command: process.env.CI
      ? 'npm run build && npm run start'
      : 'npm run dev',
    url: 'http://localhost:3000',
    reuseExistingServer: !process.env.CI,
    timeout: 120_000,
  },
  use: {
    baseURL: process.env.BASE_URL ?? 'http://localhost:3000',
  },
});
```

## Environment Variables for CI

```yaml
- name: Run E2E tests
  run: npx playwright test
  env:
    CI: 'true'
    BASE_URL: 'http://localhost:3000'
    DATABASE_URL: ${{ secrets.TEST_DATABASE_URL }}
    NEXTAUTH_SECRET: 'test-secret-for-ci'
    NEXTAUTH_URL: 'http://localhost:3000'
```

### Key Environment Variables

| Variable | Purpose | Example |
|---|---|---|
| `CI` | Enable CI-specific config (retries, workers) | `true` |
| `BASE_URL` | Application base URL | `http://localhost:3000` |
| `DATABASE_URL` | Test database connection | Secrets manager |
| `NEXTAUTH_SECRET` | Auth secret for testing | Fixed test value |
| `PLAYWRIGHT_BROWSERS_PATH` | Custom browser cache path | `~/.cache/ms-playwright` |

## Retry Strategy

Configure retries differently for CI vs local development. CI environments are more prone to flakiness due to shared resources and network variability.

```typescript
// playwright.config.ts
export default defineConfig({
  retries: process.env.CI ? 2 : 0,  // Retry twice in CI, never locally
  expect: {
    timeout: process.env.CI ? 10_000 : 5_000,  // Longer timeout in CI
  },
  timeout: process.env.CI ? 60_000 : 30_000,    // Longer test timeout in CI
});
```

### Key Points

- Zero retries locally forces you to fix flaky tests immediately.
- Two retries in CI provides resilience against transient failures.
- Track retry rate as a metric -- high retry rate indicates flaky tests.

## PR Comment with Test Results

Post test results as a comment on the pull request for immediate visibility.

```yaml
  # Add to the merge-reports job or a separate reporting job
  - name: Comment test results on PR
    if: github.event_name == 'pull_request' && !cancelled()
    uses: daun/playwright-report-summary@v3
    with:
      report-file: playwright-report/results.json
      comment-title: 'E2E Test Results'
      job-summary: true
```

### Alternative: Custom PR Comment

```yaml
  - name: Post test results comment
    if: github.event_name == 'pull_request' && !cancelled()
    uses: actions/github-script@v7
    with:
      script: |
        const fs = require('fs');
        const results = JSON.parse(fs.readFileSync('test-results.json', 'utf8'));
        const passed = results.suites.flatMap(s => s.specs).filter(s => s.ok).length;
        const failed = results.suites.flatMap(s => s.specs).filter(s => !s.ok).length;
        const total = passed + failed;

        const body = `## E2E Test Results\n\n` +
          `| Status | Count |\n|---|---|\n` +
          `| Passed | ${passed} |\n` +
          `| Failed | ${failed} |\n` +
          `| Total | ${total} |\n\n` +
          (failed > 0 ? '> Download the test report artifact for details.' : '');

        github.rest.issues.createComment({
          issue_number: context.issue.number,
          owner: context.repo.owner,
          repo: context.repo.repo,
          body,
        });
```

## Slack Notification on Failure

Send a Slack message when E2E tests fail in CI so the team can respond quickly.

```yaml
  - name: Notify Slack on failure
    if: failure()
    uses: slackapi/slack-github-action@v1.26.0
    with:
      payload: |
        {
          "text": "E2E Tests Failed",
          "blocks": [
            {
              "type": "header",
              "text": { "type": "plain_text", "text": "E2E Test Failure" }
            },
            {
              "type": "section",
              "fields": [
                { "type": "mrkdwn", "text": "*Repository:*\n${{ github.repository }}" },
                { "type": "mrkdwn", "text": "*Branch:*\n${{ github.ref_name }}" },
                { "type": "mrkdwn", "text": "*Commit:*\n${{ github.sha }}" },
                { "type": "mrkdwn", "text": "*Author:*\n${{ github.actor }}" }
              ]
            },
            {
              "type": "actions",
              "elements": [
                {
                  "type": "button",
                  "text": { "type": "plain_text", "text": "View Run" },
                  "url": "${{ github.server_url }}/${{ github.repository }}/actions/runs/${{ github.run_id }}"
                }
              ]
            }
          ]
        }
    env:
      SLACK_WEBHOOK_URL: ${{ secrets.SLACK_WEBHOOK_URL }}
      SLACK_WEBHOOK_TYPE: INCOMING_WEBHOOK
```

## Full GitHub Actions Workflow Example

Complete workflow with sharding, report merging, and failure notifications.

```yaml
# .github/workflows/e2e.yml
name: E2E Tests

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

concurrency:
  group: e2e-${{ github.ref }}
  cancel-in-progress: true

jobs:
  e2e:
    runs-on: ubuntu-latest
    timeout-minutes: 30
    strategy:
      fail-fast: false
      matrix:
        shard: [1/4, 2/4, 3/4, 4/4]

    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: 'npm'

      - name: Install dependencies
        run: npm ci

      - name: Cache Playwright browsers
        id: playwright-cache
        uses: actions/cache@v4
        with:
          path: ~/.cache/ms-playwright
          key: playwright-${{ runner.os }}-${{ hashFiles('package-lock.json') }}

      - name: Install Playwright browsers
        if: steps.playwright-cache.outputs.cache-hit != 'true'
        run: npx playwright install --with-deps chromium

      - name: Install Playwright system deps
        if: steps.playwright-cache.outputs.cache-hit == 'true'
        run: npx playwright install-deps chromium

      - name: Build application
        run: npm run build

      - name: Run E2E tests (shard ${{ matrix.shard }})
        run: npx playwright test --shard=${{ matrix.shard }}
        env:
          CI: 'true'

      - name: Upload shard report
        if: ${{ !cancelled() }}
        uses: actions/upload-artifact@v4
        with:
          name: blob-report-${{ strategy.job-index }}
          path: blob-report/
          retention-days: 1

  merge-reports:
    if: ${{ !cancelled() }}
    needs: e2e
    runs-on: ubuntu-latest

    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: 'npm'

      - name: Install dependencies
        run: npm ci

      - name: Download shard reports
        uses: actions/download-artifact@v4
        with:
          path: all-blob-reports
          pattern: blob-report-*
          merge-multiple: true

      - name: Merge reports
        run: npx playwright merge-reports --reporter html ./all-blob-reports

      - name: Upload merged report
        uses: actions/upload-artifact@v4
        with:
          name: playwright-report
          path: playwright-report/
          retention-days: 14

      - name: Comment results on PR
        if: github.event_name == 'pull_request'
        uses: daun/playwright-report-summary@v3
        with:
          report-file: playwright-report/results.json
          comment-title: 'E2E Test Results'

      - name: Notify Slack on failure
        if: failure()
        uses: slackapi/slack-github-action@v1.26.0
        with:
          payload: |
            {
              "text": "E2E Tests Failed on ${{ github.ref_name }}",
              "blocks": [
                {
                  "type": "section",
                  "text": {
                    "type": "mrkdwn",
                    "text": "*E2E Test Failure*\nRepo: ${{ github.repository }}\nBranch: ${{ github.ref_name }}\n<${{ github.server_url }}/${{ github.repository }}/actions/runs/${{ github.run_id }}|View Run>"
                  }
                }
              ]
            }
        env:
          SLACK_WEBHOOK_URL: ${{ secrets.SLACK_WEBHOOK_URL }}
          SLACK_WEBHOOK_TYPE: INCOMING_WEBHOOK
```

## Auto-Detection Rules

```
Detect: `.github/workflows/` directory exists
  --> Suggest adding E2E workflow file if none exists with "playwright" in name.

Detect: `Dockerfile` in project root
  --> Suggest Playwright Docker image for containerized E2E.

Detect: `playwright.config.ts` with no `reporter: 'blob'` and CI sharding is configured
  --> Suggest adding blob reporter for shard report merging.

Detect: No artifact upload step after `npx playwright test`
  --> Suggest adding artifact upload for test reports and traces.

Detect: `npx playwright install` without `--with-deps` in CI workflow
  --> Suggest adding `--with-deps` flag to install system dependencies.

Detect: No `concurrency` configuration in workflow
  --> Suggest adding concurrency group to cancel redundant runs on same branch.
```

## Quick Reference

| Pattern | Configuration | Key Detail |
|---|---|---|
| Basic workflow | `on: push/pr`, single job | `npx playwright install --with-deps` |
| Docker runner | `container: mcr.microsoft.com/playwright` | Set `HOME: /root` |
| Test sharding | `matrix: shard: [1/4, 2/4, 3/4, 4/4]` | `fail-fast: false` |
| Report merging | Separate `merge-reports` job | `npx playwright merge-reports` |
| Artifact upload | `actions/upload-artifact@v4` | `if: !cancelled()` for report, `if: failure()` for traces |
| Browser caching | `actions/cache@v4` on `~/.cache/ms-playwright` | Key on `package-lock.json` hash |
| webServer (CI) | `npm run build && npm run start` | `reuseExistingServer: !process.env.CI` |
| Retry strategy | `retries: process.env.CI ? 2 : 0` | Zero retries locally |
| PR comment | `daun/playwright-report-summary@v3` | Requires `results.json` |
| Slack notification | `slackapi/slack-github-action@v1.26.0` | `if: failure()` |
| Concurrency | `concurrency: { group, cancel-in-progress }` | Prevents duplicate runs |
| Environment vars | `CI`, `BASE_URL`, secrets | Use `${{ secrets.* }}` for sensitive values |
