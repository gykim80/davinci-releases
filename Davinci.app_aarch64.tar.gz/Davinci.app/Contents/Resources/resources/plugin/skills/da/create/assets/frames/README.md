# Device Frames

Reusable, pixel-accurate device chrome for multi-device and multi-screen layouts.
Each frame is a self-contained HTML file that renders a device shell and embeds
inner screen content via an `<iframe src="?screen=...">` query parameter.

## Files

```
frames/
  iphone-15-pro.html    -- 390x844, Dynamic Island + status bar + home indicator
  android-pixel.html    -- 412x900, punch-hole camera + nav bar
  ipad-pro.html         -- 584x836 (70% scale of 834x1194)
  macbook.html          -- 880px laptop shell, 1440x900 inner viewport (50% scale)
  browser-chrome.html   -- Safari/Chrome window with traffic lights + URL bar
```

## Usage

Each frame accepts `?screen=<path>` to embed content inside the device viewport:

```html
<iframe
  src="assets/frames/iphone-15-pro.html?screen=screens/home.html"
  width="390" height="844"
  loading="lazy"
></iframe>
```

The `browser-chrome.html` frame also accepts `?url=<domain>` for the URL bar text:

```html
<iframe
  src="assets/frames/browser-chrome.html?screen=screens/dashboard.html&url=app.example.com"
  width="960" height="600"
  loading="lazy"
></iframe>
```

## Rules

1. No external assets -- all SVG is inlined, no font imports, no image URLs.
2. One frame per file.
3. `?screen=` is the only required query param (browser-chrome also supports `?url=`).
4. Frames are decorative chrome only -- all content lives in the inner screen file.
5. Dimensions match real devices (logical pixels).
