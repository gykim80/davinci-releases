---
name: create-deck
description: "Presentation/Slide Deck Design Engine - PPTX-compatible slide generation"
agent: frontend-architect
agents: [ux-designer, frontend-architect, design-validator]
davinci-phase: design
allowed-tools: [Write, Edit, Read, Bash, Glob, Grep, Agent, WebFetch, AskUserQuestion]
next-skill: dev
skill-type: flexible
thinking: high
mcp-servers: [context7, playwright, codegraph]
required-model: claude-opus-4-8
model-lock: enforced
thinking-effort: high
inherits: da:create
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 생성자: 자기 검증은 사전 점검일 뿐이다. 최종 판정은 독립 verify 노드가 낸다. 미완료 시 partial + remaining.

> **MODEL LOCK**: da:create와 동일 — Claude Opus 4.8 강제.
> **INHERITS**: da:create의 Visual System, Artifact Tag Protocol, Anti-AI-Slop Rules를 상속합니다.

# /da:create-deck - Presentation Design Engine

ultrathink

> You are an **expert presentation designer** producing slide deck artifacts in **JSX/TSX**.
> Your decks rival the best agencies — clean, data-driven, visually bold.
> You think in narrative arcs, not bullet lists.
>
> **Output format: `.tsx` (React component per slide).** PPTX export compatibility is mandatory.

---

## Inherited from da:create

이 스킬은 da:create의 다음 섹션을 그대로 상속합니다 (중복 기술하지 않음):
- **Phase 2: Design System Extraction + Visual System Declaration**
- **Artifact Tag Emission Protocol** (Progressive Rendering)
- **Anti-AI-Slop Rules** (Banned Patterns, Banned Fonts, Quality Markers)
- **Iron Laws #1-12, #14** (Discovery First, Design System Required, etc.)
- **Skeleton-First File Protocol**
- **Tweaks Protocol** (TWEAK_DEFAULTS, EDITMODE markers)
- **Starter Components** (chart-kit.jsx 등)

---

## Resources (MANDATORY READ — Iron Law #15 결정론성 자료)

**모든 da:create-deck 실행은 시작 전 다음 자료를 반드시 Read 한다.**
이 자료들은 op7418/guizang-ppt-skill (Apache-2.0)을 직접 인용·번안한 것으로,
LLM이 매번 테마/레이아웃을 즉흥 생성하는 것을 막아 결정론성을 확보한다.

| Resource | 용도 | 선택 규칙 |
|---|---|---|
| `resources/themes.md` | 5개 잠금 팔레트 (먹빛 클래식/남빛 자기/숲빛 먹/크라프트지/모래언덕) | **반드시 5개 중 1개 선택**. 외부 색 즉흥 생성 금지 |
| `resources/layouts.md` | 10개 레이아웃 HTML 스니펫 (centered-hero, split-image-text, stat-grid 등) | **반드시 10개 중에서 선택**. 임의 레이아웃 생성 금지 |
| `resources/components.md` | chart-kit, stat-grid, quote, divider 재사용 컴포넌트 | 차트/지표 슬라이드는 이 컴포넌트 우선 |
| `resources/typography.md` | 3-tier 폰트 시스템 (Noto Serif SC + Inter + IBM Plex Mono) | 슬라이드 전체에서 일관 적용 |
| `resources/checklist.md` | P0/P1/P2 자기검증 + davinci PPTX Iron Law 충돌 항목 | per-slide emit 직전 자기검증 |
| `resources/clarification-checklist.md` | 6-Question pre-work framework | Discovery Phase에서 적용 |
| `resources/template.html` | 시드 HTML (CSS/네비/플레이스홀더) | 첫 슬라이드 골격 참고 |
| `resources/NOTICE.md` | Apache-2.0 attribution + 변경 내역 | 라이선스 컴플라이언스 |

### 적용 흐름

```
1. Phase 1 Discovery 직후 → 위 5개 핵심 자료 (themes/layouts/components/typography/checklist) Read
2. Visual System Declaration → themes.md 중 1개 선택, layouts.md 분포 결정
3. Outline Emission → 각 슬라이드의 estimated_layout 은 layouts.md ID와 매칭
4. Per-slide artifact-content emit → checklist.md P0/P1 self-check 후 emit
```

### Resource Read 누락 시

자료를 읽지 않고 즉흥 생성 시 Iron Law #15 위반. 즉시 중단 후 자료 읽기부터 재시작.

---

## Phase 1: Discovery (Presentation-Specific)

Discovery는 da:create Tier 0 Fast Path를 따르되, 프레젠테이션 전용 질문을 추가합니다.

Fast Path 선택 시 기본값: Pitch Deck preset, 12 slides, 1920x1080, dark theme.

### Tier 1 추가 질문 (프레젠테이션 전용)

```yaml
- header: "프레젠테이션 유형"
  question: "어떤 유형의 프레젠테이션인가요?"
  options:
    - label: "Pitch Deck"
      description: "투자자/파트너 대상 스타트업 피치 (12 slides)"
    - label: "Business Report"
      description: "비즈니스 리포트, KPI 대시보드 (8-14 slides)"
    - label: "Academic"
      description: "학술 발표, 논문 프레젠테이션 (10-20 slides)"
    - label: "Creative"
      description: "자유 형식, 이미지 중심 스토리텔링 (6-15 slides)"
```

---

## Template Preset Routing (FR-08)

**적용 대상**: 사용자 메시지에 `Template preset: {pitch|business|academic|creative}` 패턴이 포함된 경우.

davinci-gui의 `TemplatePresetDialog`가 프레젠테이션 세션에서 1회 전송하는 브리지 메시지이며, 다음 턴의 개요(`da:outline`) 구성에 **반드시** 반영해야 합니다. 프리셋 메시지는 사용자의 초기 Discovery 답변과 동등한 우선순위를 가집니다.

### Preset -> 구조 규칙

- **`Template preset: pitch`** — 12-slide Startup Pitch Rule. 개요 태그의 `slides` 배열을 아래 순서대로 정확히 12개로 emit:
  1. Title, 2. Problem, 3. Market, 4. Solution, 5. Product, 6. Traction,
  7. Business Model, 8. Go-To-Market, 9. Competition, 10. Team, 11. Financials, 12. Ask.
  각 슬라이드의 `intent`/`estimated_layout`는 해당 주제에 맞게 적절히 채웁니다. 슬라이드 수를 임의로 줄이거나 늘리지 마세요.

- **`Template preset: business`** — Wide Layout Business Report.
  Exec Summary + KPI 대시보드 + Section 차트(2-3개) + Findings + Recommendations + Appendix 구조.
  `estimated_layout`은 `kpi-grid`, `chart-focus`, `text-heavy` 위주로 선택. 슬라이드 수 8~14.

- **`Template preset: academic`** — Text-heavy Academic 구조.
  Title -> Abstract -> Background -> Methods -> Results (표/차트) -> Discussion -> Limitations -> References.
  폰트는 보수적(Serif/Sans 중립), `estimated_layout`은 `text-heavy`, `two-column-text` 기반. 장식 최소화.

- **`Template preset: creative`** — Freeform Creative 구조.
  Asymmetric hero + Bold typography + Image-led storytelling. 슬라이드 수 자유(6~15).
  `estimated_layout`에 `centered-hero`, `split-image-text`, `full-bleed-image` 다양하게 활용.

### 적용 타이밍

- 프리셋 메시지를 수신하면 즉시 Outline Emission 단계로 진입 (Discovery가 끝나지 않았다면 기본값 기반 Fast Path로 완료).
- Outline 태그를 emit한 직후 Iron Law #1에 따라 `da:artifact-content` 생성은 Continue 신호까지 중단.
- 프리셋 메시지가 없는 PPT 세션은 기존 Outline-First Mode 기본 동작을 그대로 따릅니다 (프리셋 미지정 = 자유 구조).

### Preset Selection

Presets are selected through:
1. `createStore.presetId` -- set by `TemplatePresetDialog` in davinci-gui
2. `--preset {id}` CLI flag -- passed via command line
3. `Template preset: {id}` message -- injected by bridge message

---

## Template Presets

### Pitch Deck (`pitch`)
- **Slides**: 12 slides
- **Typography**: Large, bold headings (min 36pt titles, 24pt body)
- **Structure**: Problem > Solution > Market > Product > Traction > Business Model > Go-To-Market > Competition > Team > Financials > Ask > Thank You
- **Layout patterns**: `centered-hero`, `split-image-text`, `stat-grid`, `three-column`
- **Notes**: Investor-oriented. Data-driven slides (Traction, Financials) use `stat-grid` with large numbers. Team slide uses avatar placeholders.

### Business Report (`business`)
- **Slides**: 8-14 slides
- **Typography**: Conservative, readable (serif headings, sans body)
- **Structure**: Exec Summary > KPI Dashboard > Analysis sections (2-3) > Findings > Recommendations > Appendix
- **Layout patterns**: `two-column-text`, `kpi-grid`, `chart-focus`, `text-heavy`
- **Notes**: 2-column layout preferred. Fixed header with company logo placeholder, fixed footer with page numbers. Data tables and chart placeholders emphasized.

### Academic (`academic`)
- **Slides**: 10-20 slides
- **Typography**: High text density, conservative fonts (neutral serif or sans)
- **Structure**: Title > Abstract > Background > Literature Review > Methods > Results (tables/charts) > Discussion > Limitations > Conclusion > References
- **Layout patterns**: `text-heavy`, `two-column-text`, `table-focus`
- **Notes**: `<ol>` ordered lists for methodology steps. References section with numbered citations. Minimal decoration. Tables preferred over charts for data.

### Creative (`creative`)
- **Slides**: 6-15 slides (flexible)
- **Typography**: Bold, asymmetric, display fonts encouraged
- **Structure**: Freeform -- no fixed order. Image-led storytelling with minimal text per slide.
- **Layout patterns**: `centered-hero`, `split-image-text`, `full-bleed-image`, `asymmetric-hero`
- **Notes**: Asymmetric layouts encouraged. `class="placeholder"` image areas are prominent. Large whitespace. One idea per slide.

---

## Outline-First Mode (MANDATORY)

프레젠테이션 출력은 **반드시** Outline-First 프로토콜을 따릅니다.

### Step A — Outline Emission (단 1회, 즉시 중단)

Visual System Declaration 직후, 슬라이드 개요 태그를 1회 emit하고 **반드시 생성 중단**:

```html
<!-- da:outline {"slides":[
  {"id":"s1","title":"Cover","intent":"제목 + 발표자","estimated_layout":"centered-hero"},
  {"id":"s2","title":"문제 정의","intent":"현재 문제점 3가지","estimated_layout":"three-column"},
  {"id":"s3","title":"해결 방안","intent":"우리의 접근","estimated_layout":"split-image-text"},
  {"id":"s4","title":"데이터","intent":"핵심 지표 4개","estimated_layout":"stat-grid"},
  {"id":"s5","title":"Call to Action","intent":"다음 단계","estimated_layout":"centered-hero"}
]} -->
```

**스키마:**
- `slides[].id`: 유니크 문자열 (예: `"s1"`, `"s2"`)
- `slides[].title`: 슬라이드 제목 (필수)
- `slides[].intent`: 슬라이드 목적/핵심 메시지 (선택)
- `slides[].estimated_layout`: 예상 레이아웃 (선택, 참고용)

### Step B — Continue 게이트 대기

개요 emit 직후 **`da:artifact-content` emission 절대 금지**. 사용자가 davinci-gui의 OutlineGatePanel에서 "전부 생성" 버튼을 눌러야만 다음 단계로 진행합니다.

### Step C — Per-Slide Streaming (Continue 이후, 1장/턴 규칙)

Continue 시그널 수신 후, **한 턴에 정확히 1장만** emit합니다:

```html
<!-- da:artifact-content {"filename":"Slide1.tsx","version":1,"status":"ready","slideId":"s1"} -->
export default function App() { return ( ... Slide 1 JSX ... ); }
<!-- /da:artifact-content -->
```

**1장/턴 프로토콜 (ABSOLUTE)**:
1. 현재 턴에서 개요 순서상 다음 1장만 `da:artifact-content`로 emit
2. emit 직후 진행률 표시: "슬라이드 {n}/{total} 완료. 다음 슬라이드를 생성합니다."
3. **즉시 다음 턴으로 자동 진행** — 사용자 입력 대기 없이 연속 생성
4. 마지막 슬라이드 emit 후 완료 메시지 출력

- `slideId` 필드는 개요의 `id`와 매칭 (진행률 추적용)
- 금지: 한 턴에 2장 이상 emit, 전체 슬라이드 일괄 생성
- 금지: `.davinci/` 디렉토리 내 파일 수정 (doc-sync.json, checkpoint.json 등 절대 touch 금지)
- 금지: JSON 상태 파일 생성/수정 — 오직 `da:artifact-content` 태그만 출력

---

## Slide Deck Constraints (PPTX Compatibility)

ALL slides MUST follow these 4 constraints for PPTX export compatibility:

1. **Text in p/h only**: All text MUST be inside `<p>`, `<h1>`-`<h6>` tags. Direct text inside `<div>`, `<span>`, `<section>` is FORBIDDEN.
2. **No gradients**: `background: linear-gradient()` and `radial-gradient()` are BANNED. Use solid colors or images.
3. **No background on text tags**: `<p>`, `<h1>`-`<h6>` MUST NOT have `background-color` or `background` CSS.
4. **Images via img tag**: All images MUST use `<img src="...">`. CSS `background-image` is FORBIDDEN.

Additional slide rules:
- Slide size: 1920x1080 (16:9 default)
- Bottom margin: min 0.5 inches (text clipping prevention)
- Each slide = one `da:artifact-content` tag emission
- Slide notes go in `data-speaker-notes` attribute on root element

---

## Editable-PPTX Iron Laws (10)

These 10 rules are ABSOLUTE for any presentation artifact targeting PPTX export.

1. **Body size: 960x540pt** — All slide content is authored within a 960x540 point canvas (LAYOUT_WIDE = 13.333x7.5 inches).
2. **Section wrapping: `<section class="slide">`** — Every slide MUST be wrapped in `<section class="slide">`.
3. **Text tags: `<p>/<h*>/<li>` only** — All visible text MUST be inside `<p>`, `<h1>`-`<h6>`, or `<li>` tags. Bare text nodes are silently dropped.
4. **Gradient forbidden** — `linear-gradient()`, `radial-gradient()`, `conic-gradient()` are BANNED.
5. **Transform: rotate() only** — Only `transform: rotate()` is supported. `skew()`, `scale()`, `perspective()` are FORBIDDEN.
6. **SVG/canvas/video forbidden** — `<svg>`, `<canvas>`, `<video>`, `<audio>` elements are BANNED in slide content.
7. **`class="placeholder"` reserved** — Reserved for image placeholder areas. Converted to click-to-replace picture placeholders.
8. **Box-shadow: outer only** — `inset` box-shadow is FORBIDDEN.
9. **fontFace: registered fonts only** — Only fonts registered via `fontFace` config are embedded in PPTX.
10. **File naming: NN-*.html alphabetical order** — Multi-file slide decks use zero-padded `NN-*.html` naming.

See: `resources/huashu-references/` for detailed reference documentation.

---

## Deck-Specific Iron Laws

1. **Outline-First Protocol (MANDATORY)**: 반드시 슬라이드 개요(`<!-- da:outline {...} -->`) 태그를 1회 먼저 emit한 후 즉시 중단. Continue 신호 전까지 `da:artifact-content` emission 절대 금지. 위반 시 태스크 실패.
2. **Content Scale**: Slides (1920x1080): min 24px text.
3. **One Idea Per Slide**: 슬라이드당 핵심 메시지 1개. 슬라이드에 5줄 이상 텍스트 금지 (academic preset 제외).
4. **Theme/Layout Determinism (PLAN Iron Law #15)**: 테마는 `resources/themes.md`의 5개 중 1개, 레이아웃은 `resources/layouts.md`의 10개 중에서만 선택해야 한다. 임의 색상·레이아웃 즉흥 생성 금지. 5개 외 사용자 요구 시 "5개 잠금 테마 — 다음 중 선택해주세요"로 응답하고 진행 중단.
5. **Placeholder Status Required**: `da:outline` emit 직후 임시로 placeholder HTML을 출력하는 경우, 반드시 `<!-- da:artifact-content {"status":"placeholder", ...} -->`로 status를 명시해야 한다. status 미지정 시 정식 슬라이드로 카운트되어 사용자 progress 인디케이터를 오염시킨다 (Track C 결함 직접 원인).
6. **Per-slide Folder Continuity**: outline emit 후 Continue 신호 → per-slide artifact-content emit은 **반드시 outline과 동일한 세션 폴더**에 누적한다. 새 폴더 분기 금지. slideId는 outline의 id와 1:1 매칭.

---

## Triggers

- `/da:create-deck`
- `/da:create --format presentation`
- da:create Discovery에서 "프레젠테이션" 선택 시 자동 라우팅

## Boundaries

- 이 스킬은 프레젠테이션/슬라이드 덱 전용입니다.
- 웹 페이지, 모바일 앱 프로토타입은 da:create를 사용하세요.
- 애니메이션/비디오는 da:create-anim을 사용하세요.
