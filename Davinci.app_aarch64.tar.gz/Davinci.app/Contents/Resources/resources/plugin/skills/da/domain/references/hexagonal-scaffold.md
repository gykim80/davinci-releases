# Hexagonal Directory Scaffold (optional proposal)

> DOMAIN-MODEL.md의 Bounded Context를 디렉토리 경계로 물리화하는 선택적 제안.
> da:domain Step 6에서 MODERATE+ 복잡도 & 사용자 동의 시에만 제안한다. 강제 아님.

## Layout

```
src/features/<bounded-context>/
├── domain/              # 순수 비즈니스 로직 -- 프레임워크/DB/HTTP import 금지
│   ├── entities.ts      # Entity/Aggregate Root
│   └── value-objects.ts
├── application/
│   ├── ports/           # 외부 의존성 인터페이스 (Outbound Port)
│   └── use-cases/       # 애플리케이션 서비스 (도메인 오케스트레이션)
├── adapters/            # Port 구현체 -- DB, HTTP client, 외부 API
└── composition/         # 의존성 조립 (composition root) -- 이 feature 전용
```

## Layer Rules (da:arch-verify가 검증하는 항목)

```yaml
domain/:
  - 프레임워크(React/Express/Next 등) import 금지
  - DB/ORM/HTTP 클라이언트 import 금지
  - 다른 feature의 adapters/ 직접 import 금지
  - 순수 함수/클래스만 -- 부수효과 없음

application/ports/:
  - 인터페이스/타입 정의만 -- 구현 없음
  - domain/의 타입만 참조 가능

application/use-cases/:
  - ports/의 인터페이스를 통해서만 외부 의존성 접근 (구체 adapter 직접 import 금지)

adapters/:
  - 정확히 하나 이상의 port를 구현
  - domain/에 대한 지식은 port 인터페이스 경유로만

composition/:
  - 이 파일에서만 adapter 구체 클래스와 use-case를 조립
  - 다른 계층에서 composition/을 import 금지 (단방향)
```

## When NOT to scaffold

- 단일 바운디드 컨텍스트 & SIMPLE 이하 복잡도 -- 오버엔지니어링
- 프로토타입/실험 코드
- 사용자가 기존 구조 유지를 명시적으로 요청한 경우

## Migration note

기존 코드베이스에 소급 적용할 때는 새 기능부터 적용하고, 기존 코드는 점진적으로
옮기는 strangler-fig 방식을 권장한다 (한 번에 전체 리라이트 금지).
