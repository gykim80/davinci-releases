<!--
Source: op7418/guizang-ppt-skill (Apache-2.0)
Original: https://github.com/op7418/guizang-ppt-skill
Copyright (c) op7418. Licensed under Apache-2.0.
Modifications: Adapted for davinci-framework — Korean comments + PPTX Iron Law conflict notes.
-->

# 테마 프리셋 (Theme Presets)

> **잠금 정책 (Lock Policy)**: 5개 테마 중 1개만 선택 가능합니다.
> 커스텀 HEX 요청 시: "5개 잠금 테마 — 다음 중 선택해주세요"로 응답합니다.
> (Iron Law #15: Theme/Layout Determinism)
>
> 원본 출처: op7418/guizang-ppt-skill `references/themes.md`
> One deck = one theme. 테마 간 색상 혼용 금지.

---

## 적용 방법 (How to Apply)

`assets/template.html`의 `:root` CSS 블록에서 아래 변수를 선택한 테마 값으로 교체하세요:

```css
:root {
  --ink: <PRIMARY>;
  --ink-rgb: <PRIMARY_RGB>;
  --paper: <BACKGROUND>;
  --paper-rgb: <BACKGROUND_RGB>;
  --paper-tint: <BACKGROUND_TINT>;
  --ink-tint: <PRIMARY_TINT>;
}
```

---

## 1. 먹빛 클래식 — Ink Classic / Monocle

> 순수한 먹빛 잉크 + 따뜻한 오프화이트. 범용 공유, 비즈니스 용도에 최적.
> Pure black ink on warm off-white. Universal and business-appropriate.

```css
:root {
  --ink:        #0a0a0b;
  --ink-rgb:    10, 10, 11;
  --paper:      #f1efea;
  --paper-rgb:  241, 239, 234;
  --paper-tint: #e8e5de;
  --ink-tint:   #18181a;
}
```

| 역할 (Role)   | HEX       | RGB           |
|--------------|-----------|---------------|
| Primary (먹빛) | `#0a0a0b` | 10, 10, 11    |
| Background (종이) | `#f1efea` | 241, 239, 234 |
| BG Tint      | `#e8e5de` | 232, 229, 222 |
| Primary Tint | `#18181a` | 24, 24, 26    |

---

## 2. 남빛 자기 — Indigo Porcelain

> 깊은 남색 + 자기 흰색. 기술, 리서치 콘텐츠에 적합.
> Deep indigo with porcelain white. Ideal for tech and research content.

```css
:root {
  --ink:        #1a2744;
  --ink-rgb:    26, 39, 68;
  --paper:      #f5f4f0;
  --paper-rgb:  245, 244, 240;
  --paper-tint: #eceae4;
  --ink-tint:   #243360;
}
```

| 역할 (Role)   | HEX       | RGB           |
|--------------|-----------|---------------|
| Primary (남빛) | `#1a2744` | 26, 39, 68    |
| Background (자기) | `#f5f4f0` | 245, 244, 240 |
| BG Tint      | `#eceae4` | 236, 234, 228 |
| Primary Tint | `#243360` | 36, 51, 96    |

---

## 3. 숲빛 먹 — Forest Ink

> 깊은 숲 초록 + 아이보리. 자연, 지속가능성 주제에 어울림.
> Deep forest green on ivory. Matches natural and sustainability topics.

```css
:root {
  --ink:        #1c2e1e;
  --ink-rgb:    28, 46, 30;
  --paper:      #f3f1eb;
  --paper-rgb:  243, 241, 235;
  --paper-tint: #e9e6de;
  --ink-tint:   #263d28;
}
```

| 역할 (Role)   | HEX       | RGB           |
|--------------|-----------|---------------|
| Primary (숲빛) | `#1c2e1e` | 28, 46, 30    |
| Background (아이보리) | `#f3f1eb` | 243, 241, 235 |
| BG Tint      | `#e9e6de` | 233, 230, 222 |
| Primary Tint | `#263d28` | 38, 61, 40    |

---

## 4. 크라프트지 — Kraft Paper

> 깊은 갈색 + 따뜻한 베이지. 빈티지, 인문학적 콘텐츠를 연상.
> Deep brown with warm beige. Evokes vintage, humanistic content.

```css
:root {
  --ink:        #2e1f0e;
  --ink-rgb:    46, 31, 14;
  --paper:      #f0ebe0;
  --paper-rgb:  240, 235, 224;
  --paper-tint: #e6dfd0;
  --ink-tint:   #3d2a14;
}
```

| 역할 (Role)   | HEX       | RGB           |
|--------------|-----------|---------------|
| Primary (갈색) | `#2e1f0e` | 46, 31, 14    |
| Background (베이지) | `#f0ebe0` | 240, 235, 224 |
| BG Tint      | `#e6dfd0` | 230, 223, 208 |
| Primary Tint | `#3d2a14` | 61, 42, 20    |

---

## 5. 모래언덕 — Dune

> 차콜 그레이 + 모래빛. 예술적, 디자인 중심 소재를 전달.
> Charcoal gray with sand tone. Conveys artistic and design-focused material.

```css
:root {
  --ink:        #2a2825;
  --ink-rgb:    42, 40, 37;
  --paper:      #ede9e1;
  --paper-rgb:  237, 233, 225;
  --paper-tint: #e3ded4;
  --ink-tint:   #383530;
}
```

| 역할 (Role)   | HEX       | RGB           |
|--------------|-----------|---------------|
| Primary (차콜) | `#2a2825` | 42, 40, 37    |
| Background (모래) | `#ede9e1` | 237, 233, 225 |
| BG Tint      | `#e3ded4` | 227, 222, 212 |
| Primary Tint | `#383530` | 56, 53, 48    |

---

## 테마 선택 가이드

| 영문 | 한국어 | 최적 용도 |
|------|--------|-----------|
| Ink Classic | 먹빛 클래식 | 비즈니스, 범용 |
| Indigo Porcelain | 남빛 자기 | 기술, 리서치 |
| Forest Ink | 숲빛 먹 | 자연, 지속가능성 |
| Kraft Paper | 크라프트지 | 빈티지, 인문학 |
| Dune | 모래언덕 | 예술, 디자인 |

> **주의**: 위 5개 외 커스텀 팔레트는 이번 사이클에서 지원하지 않습니다.
> 사용자 요청 시 "5개 잠금 테마 — 다음 중 선택해주세요"로 안내하세요.
