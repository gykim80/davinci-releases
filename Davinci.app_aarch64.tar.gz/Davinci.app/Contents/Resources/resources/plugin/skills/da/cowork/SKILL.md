---
name: cowork
description: Multi-agent collaboration and parallel task coordination
agent: cto-lead
agents: [cto-lead, senior-fullstack, ux-designer, e2e-testing-patterns]
davinci-phase: null
allowed-tools: [Write, Edit, Read, Bash, Glob, Grep, Task]
next-skill: verify
skill-type: flexible
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 오케스트레이터: §4 그래프 ready-set 디스패치, §6 노드 단위 checkpoint, §7 interrupt 표 외 질문 금지.

## Tool Parameter Rules -> See CLAUDE.md (ABSOLUTE)
# /da:cowork - Team Collaboration

ultrathink


## Purpose
Multi-agent team collaboration session where a CTO Lead agent coordinates specialized teammates using phase-appropriate orchestration patterns.

## Usage
```
/da:cowork [feature-name] [--pattern leader|council|swarm|watchdog] [--max-teammates N]
```

## Orchestration Patterns

### Leader Pattern
- CTO makes decisions, delegates tasks
- Best for: plan, design, act phases
- Single decision authority

### Council Pattern
- Team votes on decisions
- Best for: check phase (quality review)
- Consensus-driven

### Swarm Pattern
- Parallel independent work
- Best for: do phase (implementation)
- Maximum parallelism

### Watchdog Pattern
- Continuous monitoring and alerts
- Best for: act phase (Enterprise)
- Quality enforcement

## Phase-Pattern Mapping
```yaml
Dynamic:
  plan: leader
  design: leader
  do: swarm
  check: council
  act: leader

Enterprise:
  plan: leader
  design: council
  do: swarm
  check: council
  act: watchdog
```

## CRITICAL EXECUTION RULE

```yaml
MANDATORY_PARALLEL:
  - You MUST call multiple Task tools in a SINGLE message
  - NEVER call Task sequentially (one at a time)
  - Independent workstreams = parallel Task calls
  - Only sequential when output of Task A is input to Task B
```

## Fresh Context Per Task (Subagent Isolation)

Each subagent MUST receive complete, self-contained context. Subagents cannot coordinate
with each other and cannot access the controller's conversation history.

```yaml
BEFORE dispatching any subagent:
  1. Extract the FULL task specification (copy text, don't reference files)
  2. Include ALL relevant file paths and their current content summaries
  3. Specify exact file boundaries (which files this agent may modify)
  4. Provide shared conventions (naming patterns, import styles, tech stack)
  5. State constraints explicitly (what NOT to do)

NEVER:
  - Tell subagent to "read the plan file" (provide full text instead)
  - Assume subagent has context from previous tasks
  - Let subagents share mutable state
```

## Two-Stage Review Pipeline

### Stage 1: Spec Compliance Review
- Purpose: "Did the agent build what was asked?"
- Every requirement has a corresponding implementation
- No extra features added (scope creep), no requirements missed
- If FAIL: Agent fixes -> re-review (loop until pass)

### Stage 2: Code Quality Review (ONLY after Stage 1 passes)
- Purpose: "Is it well-built?"
- Code quality, patterns, error handling, security, performance, test coverage
- If FAIL: Agent fixes -> re-review (loop until pass)

**CRITICAL**: Never start Stage 2 before Stage 1 passes.

## Conflict Resolution

```yaml
conflict_priorities:
  1. Security agent wins on auth/validation code
  2. Backend agent wins on API contracts
  3. Frontend agent wins on UI components
  4. Performance agent's suggestions are advisory

merge_strategy:
  - Read all agent outputs
  - Identify overlapping file modifications
  - Apply non-conflicting changes first
  - Resolve conflicts by domain priority
  - Run /da:verify after merge
```

## Boundaries

**Will:**
- Coordinate multi-agent workflows
- Select appropriate orchestration pattern
- Track team progress and blockers

**Will Not:**
- Exceed max teammates limit
- Override pattern selection without --force
