---
name: work
description: "Spec-based automatic orchestration. Complexity-Gated Adaptive Pipeline (LIGHT~EPIC 5 levels). system -> design -> dev/game -> verify -> improve pipeline."
agent: cto-lead
agents: [cto-lead, senior-architect, senior-fullstack, frontend-architect, game-developer]
davinci-phase: work
allowed-tools: [Write, Edit, Read, Bash, Glob, Grep, Task, Skill, AskUserQuestion]
next-skill: report
skill-type: flexible
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 오케스트레이터: §4 그래프 ready-set 디스패치, §6 노드 단위 checkpoint, §7 interrupt 표 외 질문 금지.

## Tool Parameter Rules -> See CLAUDE.md (ABSOLUTE)

## COMMON_RULES (defined once — referenced by all Task prompts as "{COMMON_RULES}")

```
★ TOOL RULES (ABSOLUTE — stop immediately on violation):
Write(file_path, content) — only these 2 params exist. text/path/body/data do not exist.
200+ line content → Write skeleton (50 lines) + Edit repeatedly. Large single Write forbidden.
On failure, do not retry same call → retry with content halved in size.
3 consecutive failures → stop work, return summary.

★ CONTEXT GUARD (최우선 규칙):
1. Read는 한 번에 최대 {max_files}개 파일만
2. 대량 파일 작업 시 배치로 분할 (예: 20개씩)
3. Write 200줄 초과 시 skeleton(50줄) + Edit 반복
4. 스스로 끝낼 수 없다고 판단되면 진척을 파일에 기록하고 status="partial" + remaining[]으로 반환
   (오케스트레이터가 새 컨텍스트로 같은 노드를 재개한다 — da:protocol §2.3. Context 사용량 추정으로 종료 판단 금지)

★ EVIDENCE (da:protocol §3): "완료/통과" 주장은 실행 명령·exit code·파일 경로 근거를 handoff evidence[]에 포함.
근거 없는 completed는 partial로 취급된다. 응답 마지막 handoff JSON에 status/evidence/remaining 필수.

★ AskUserQuestion call forbidden. Proceed with autonomous judgment.
```

**All Task prompts below use `{COMMON_RULES}` to inject this block. Do NOT repeat these rules inline.**

**★ max_files 주입 (Stage 0 완료 후 필수):**
Stage 0에서 complexity 확정 후, FILE_LIMITS[complexity] 값을 `{max_files}` 변수에 바인딩한다.
이후 모든 Task prompt의 COMMON_RULES 내 `{max_files}`가 실제 숫자로 치환되어야 한다.
```yaml
max_files_injection:
  trigger: Stage 0 Step_5.5 완료 직후
  action: |
    max_files = FILE_LIMITS[complexity]  # e.g., COMPLEX → 8
    # 이후 모든 Task prompt 생성 시:
    COMMON_RULES_RESOLVED = COMMON_RULES.replace("{max_files}", str(max_files))
    # Task prompt에는 COMMON_RULES_RESOLVED를 주입
  checkpoint_field: "max_files": 8  # 실제 값 기록
```

## Handoff System Integration
The pipeline uses structured JSON handoffs between skills to reduce context usage by 60-80%.
Each skill returns a handoff JSON at the end of its execution, which is stored in the checkpoint
and passed to the next skill. This is handled automatically by the orchestrator.

### How It Works:
1. Each skill receives previous handoffs in its prompt context
2. The skill executes and returns a JSON handoff at the end
3. The orchestrator extracts the handoff and stores it in checkpoint
4. Next skill receives all previous handoffs for context

### Example Flow:
```yaml
da:system returns:
  {"skill": "da:system", "status": "completed",
   "architecture": {"style": "microservices", "database": "postgresql"},
   "complexity_estimate": "COMPLEX", "design_intensive_phases": [1, 3]}

da:design receives system handoff and returns:
  {"skill": "da:design", "status": "completed",
   "design_system": {"style": "modern", "primary_color": "#3B82F6"},
   "components_created": ["Hero.tsx", "Nav.tsx"]}

da:dev receives both handoffs and knows:
  - Architecture style from system
  - UI components from design
  - Can implement without re-reading everything
```

## Design Enforcement Engine

디자인 품질을 파이프라인 레벨에서 강제하는 2축 시스템:

### 축 1: LIGHT/SIMPLE에도 design 포함
```
LIGHT:  design:lite -> dev -> verify:fast
SIMPLE: design:standard -> dev -> verify:standard
```
- `design:lite` = Phase 1.5 (Creative Brief)까지만, maxDuration 30s
- `design:standard` = Phase 1~3 (Discovery + Brief + Design), maxDuration 2min

### 축 2: Fidelity Gate + Review Loop
```
[da:work Pipeline]
  Stage 0: da:system
  Stage 1: da:verify (architecture)
  Stage 1.5: Design Palette Gate (opt-in, standard/full tier only)
  Stage 2: da:design -- Fidelity Gate (>=60, max 2 retry)
  Stage 3: da:dev/da:game (Phase별)
  Stage 3.3: da:asset --game (Game 프로젝트일 때만, Stage 3과 병렬 가능)
  Stage 3.5: da:design --review -- Design Review Loop
             < 70 -> da:design --improve (max 1회)
             >= 70 -> 통과
  Stage 3.7: da:visual-qa -- Visual QA Loop (Playwright screenshot + Vision)
             Score >= 85 -> 통과
             Score < 85 -> 자동 수정 + 재캡처 (max 3회)
  Stage 4: da:e2e
  Stage 4.5: Deploy Gate (conditional - deploy keywords in PLAN.md)
  Stage 5: da:report
```

**Fidelity Gate** (Stage 2->3):
- da:design 완료 후 Fidelity Score >= 60 필수
- 미달 시 자동 재실행 (최대 2회)
- 2회 후에도 미달 -> 노드 `degraded`(디자인 fidelity는 Medium severity)로 진행, 최종 리포트에 점수와 함께 명시 (da:protocol §3.4)

**Asset Generation Stage** (Stage 3.3, Game only):
- Game 프로젝트 감지 시 Stage 3(da:game)과 병렬로 `da:asset --game` 실행
- 에셋 생성 실패 시에도 게임 코드는 정상 진행 (graceful degradation)

**Design Review Loop** (Stage 3.5):
- da:dev/da:game 완료 후 `da:design --review` 자동 실행
- Fidelity < 70 -> `da:design --improve` 자동 실행 (최대 1회)
- Fidelity >= 70 -> 통과하여 da:visual-qa로 진행
- post_skill.py 훅이 자동으로 체이닝

**Visual QA Loop** (Stage 3.7):
- Design Review 통과 후 Playwright MCP로 실제 화면 스크린샷 캡처
- Claude Vision으로 Fidelity Score 산출 (Layout/Completeness/Typography/Responsive/Interactive)
- Score >= 85 -> 통과하여 da:e2e로 진행
- Score < 85 -> 코드 자동 수정 + 재캡처 (max 3회, stagnation guard: 개선 < 5점 시 중단)
- post_skill.py의 _enforce_visual_qa_loop()가 자동 트리거

**Hook-Driven Enforcement** (post_skill.py):
- **Fidelity Gate**: `_enforce_design_fidelity_gate()` -- da:design 완료 시 자동 실행
- **Effect Chain**: `_enforce_design_effect_chain()` -- da:design 완료 시 자동 block signal로 da:effect_bg -> da:effect_text -> da:effect_particle 순차 호출
- **Design Review**: `_enforce_design_review_chain()` -- da:dev/da:game 마지막 Phase 완료 시 da:design --review 강제 호출

---

# /da:work - Autonomous Pipeline Orchestrator

## ⚠️ THINKING BUDGET (Minimize Extended Thinking — Most Important Rule)
This orchestrator does not need deep thinking for tool routing.
Checkpoint → just make the next tool call.
Minimize extended thinking and preserve 100% of output budget for tool calls.
Do not spend more than 1 second thinking about tool call decisions. Extended thinking depletes output budget, making tool calls impossible.

## ⚠️ HANDOFF EXTRACTION (Automatic by Orchestrator)
When executing Task calls, the orchestrator automatically:
1. Extracts handoff JSON from the skill output
2. Stores it in checkpoint as handoff_{skill}
3. Builds handoff chain for next skill
4. Injects previous handoffs into next skill's prompt
Do NOT manually process handoffs - this is handled automatically.

## ★ FIRST ACTION: Resume Check (Before All Other Actions)

```yaml
Execute_First:
  Bash: cat docs/.da-work-checkpoint.json 2>/dev/null || echo "NO_CHECKPOINT"

  If result is NOT "NO_CHECKPOINT":
    - Parse checkpoint JSON
    - Check current_stage, current_phase
    - Output: "🔄 Checkpoint found. Resuming from Stage {N}, Phase {M}."
    - Resume from that Stage (skip Stage 0)

  If result is "NO_CHECKPOINT":
    - Start fresh from Stage 0

  Session_Aware_Resume:
    - If <da-work-pipeline> block exists after PreCompact:
      → Read checkpoint via session-specific path from the block
        (e.g., docs/.da-work-checkpoint-abc123.json)
    - Otherwise use default: cat docs/.da-work-checkpoint.json
```

### ★★ REQUIRED: Orchestrator Model Guidance (ADR-001 Path B)

FIRST ACTION 직후 **반드시 다음을 수행**한다. Task tool의 `model` 파라미터가 enum 고정이므로, sub-skill 단위 버전 제어는 불가능하다. 실제 버전은 Orchestrator(사용자 Claude Code 세션)의 `/model` 지정을 따른다.

```yaml
Orchestrator_Model_Check:
  1. Output: "📌 Hybrid Routing Notice"
  2. Detect current model (session metadata or user-visible output).
  3. If the pipeline is long (≥3 stages, COMPLEX/EPIC):
     - Print: "긴 파이프라인입니다. Opus 4.6 권장: `/model opus-4.6`"
     - Print: "품질 우선이면 4.7 유지. 중간 중단 방지가 목적이면 4.6."
     - Do NOT block — user may proceed on current model.
  4. If the pipeline is LIGHT/STANDARD (<3 stages):
     - Skip the recommendation; current model is fine.

Rationale:
  - Task(model="opus-4.7") 같은 호출은 schema error.
  - ModelRouter가 "opus-4.7"을 저장하고 있어도 Task에는 "opus"만 전달.
  - 실제 4.6/4.7 선택은 orchestrator `/model` 지정의 전역 효과로만 달성.
  - 자세한 진단: `uv run davinci model doctor`.
```

### ★★ REQUIRED: Constitution Load Gate (ADR / Domain Model)

Orchestrator Model Guidance 직후, Stage 0 진입 전에 **반드시 다음을 수행**한다.
ADR/DOMAIN-MODEL.md/CONTEXT.md는 산출물이 아니라 이후 구현에 대한 제약(constitution)이다.

```yaml
Constitution_Load:
  1. Glob("docs/adr/*.md") → Status: Accepted 문서만 필터링하여 로드
  2. Glob("CONTEXT.md"), Glob("docs/domain/DOMAIN-MODEL.md") → 존재하면 로드
  3. 셋 다 없으면 이 게이트를 스킵 (신규/경량 프로젝트 — 에러 아님)
  4. 로드된 제약을 이후 da:dev/da:arch-verify Task 호출 프롬프트에 컨텍스트로 포함

Dependency_Gate (신규 의존성 추가를 계획에서 감지한 경우):
  - package.json/Cargo.toml/go.mod 등에 신규 런타임 의존성 추가가 계획되어 있는데
    이를 다루는 Accepted ADR이 없음
    → 진행을 멈추고 `da:adr`을 먼저 호출하여 결정을 기록한 뒤 계속
  - 이미 Accepted ADR이 해당 의존성을 다루고 있으면 그대로 진행

Contradiction_Gate:
  - 계획된 구현이 로드된 Accepted ADR과 모순됨 → 경고 출력, 사용자에게
    "새 ADR로 supersede 하시겠습니까?" 확인 후 진행
```

---

## CRITICAL BEHAVIOR: Seamless Automatic Execution

**This skill automatically executes the entire pipeline without user intervention.**
After completing each step, do not stop — proceed to the next step immediately.
Do not ask the user "Shall I proceed to the next step?" Just proceed.

---

## EXECUTION STRATEGY: Actual Skill Execution (100% Identical to User Manual Execution)

**All da:* skills are executed identically to the user manually typing /da:xxx.**

### ★ MODEL ROUTING (Cost Optimization + Hybrid Persistence)
Automatically select the optimal model for each skill. Use the Task tool's `model` parameter.

**IMPORTANT (ADR-001 Path B)**: Task tool의 `model` 파라미터는 `["sonnet", "opus", "haiku"]` enum 고정이다. ModelRouter가 반환하는 version-qualified ID(`opus-4.6`/`opus-4.7` 등)는 의도 문서화용이며, **Task 호출 직전에 반드시 `resolve_for_task()`로 base 모델로 축약**해야 한다. 실제 버전 제어는 Orchestrator(Claude Code `/model`)가 담당한다.

```yaml
Model_Routing_Table (balanced preset — default):
  # Opus (Code quality first — $5/$25 per 1M tokens)
  da:dev     → model: "opus"    # Actual code implementation
  da:game    → model: "opus"    # Game code implementation
  da:e2e     → model: "opus"    # E2E test writing/modification

  # Sonnet (Medium complexity — $3/$15 per 1M tokens, 60% of Opus)
  da:system  → model: "sonnet"  # Architecture design
  da:design  → model: "sonnet"  # UI/UX design implementation
  da:asset   → model: "sonnet"  # Asset generation/audit
  # da:verify, da:improve → Skill call (uses orchestrator model)

  # Haiku (Simple judgment — Lowest cost)
  # da:report, da:git → Skill call (uses orchestrator model)
  # Stage 0 Plan Parsing → Handled directly by orchestrator

Model_Routing_Table (hybrid-persistence preset — long-pipeline recommended):
  # Intent (preset stores version-qualified) → Resolved (Task tool receives)
  da:idea     → "opus-4.7"   → "opus"    # Quality-critical Q&A design
  da:plan     → "opus-4.7"   → "opus"    # Accurate requirements
  da:system   → "sonnet-4.7" → "sonnet"  # Architecture precision
  da:design   → "sonnet-4.6" → "sonnet"  # Long component chain — persistence
  da:create   → "sonnet-4.6" → "sonnet"  # HTML design engine — persistence
  da:asset    → "haiku"      → "haiku"
  da:dev      → "opus-4.7"   → "opus"    # Code quality first
  da:game     → "opus-4.7"   → "opus"
  da:three    → "opus-4.7"   → "opus"
  da:e2e      → "opus-4.7"   → "opus"
  da:verify   → "sonnet-4.7" → "sonnet"  # Match rate accuracy
  da:improve  → "opus-4.6"   → "opus"    # Long fix chain — persistence
  da:report   → "sonnet-4.6" → "sonnet"
  da:git      → "haiku"      → "haiku"

Cost_Savings_Estimate: ~50-60% savings vs Opus-only
  10-Phase project: $12 → $5~6 (balanced preset)

Preset_Change: davinci model set <preset>
  - cost-optimized: haiku/sonnet focused (lowest cost)
  - balanced: sonnet + opus for coding (default)
  - quality-first: full opus (highest quality)
  - hybrid-persistence: 4.6/4.7 intent mix for long /da:work pipelines
  - davinci model custom <skill> <model>: per-skill override
  - davinci model doctor: diagnose intent vs resolved + orchestrator hint
```

```yaml
Heavy_Skills (heavy file read/write → Task delegation + full command file):
  # Task(model=...)에는 항상 resolve_for_task(preset_value) 결과를 전달한다 (ADR-001 D-1).
  # 아래는 최종 축약된 값만 표기. version hint는 orchestrator `/model` 지정으로 실현.
  - da:system  → Task(model="opus") + ~/.claude/commands/da/system.md
  - da:design  → Task(model="opus") + ~/.claude/commands/da/design.md
  - da:create  → Task(model="opus") + ~/.claude/commands/da/create.md  # HTML design engine (when design_mode=="da:create")
  - da:asset   → Task(model="opus") + ~/.claude/commands/da/asset.md
  - da:dev     → Task(model="opus")   + ~/.claude/commands/da/dev.md
  - da:game    → Task(model="opus")   + ~/.claude/commands/da/game.md
  - da:e2e     → Task(model="opus")   + ~/.claude/commands/da/e2e.md

Task_Model_Injection (resolve_for_task 적용 의사 코드):
  ```python
  from davinci.routing.model_router import ModelRouter, resolve_for_task
  router = ModelRouter()
  intent = router.get_model("da:dev")        # → "opus-4.7" (hybrid-persistence)
  task_model = resolve_for_task(intent)      # → "opus" (Task enum에 맞게 축약)
  Task(subagent_type="Explore", model=task_model, prompt=...)
  ```
  주의: `Task(model="opus-4.7")` 같은 직접 호출은 schema validation error.

Light_Skills (judgment/check only → Skill tool direct call, uses orchestrator model):
  - da:verify  → Skill(skill="da:verify", args="...")
  - da:improve → Skill(skill="da:improve", args="...")
  - da:report  → Skill(skill="da:report", args="...")
  - da:git     → Skill(skill="da:git", args="...") ← Auto commit/push on Stage transition
  - da:devsh   → Skill(skill="da:devsh", args="") ← Stage 5에서 dev.sh 생성 (웹앱/서버 프로젝트 전용)

⚠️ CRITICAL: Do NOT read SKILL.md (60-line summary)!
  ❌ davinci_framework/davinci-plugin/skills/da/{skill}/SKILL.md (metadata summary)
  ✅ ~/.claude/commands/da/{skill}.md (full protocol, 500+ lines)

Task_Prompt_Template (Heavy Skills):
  "Your task is to execute the /da:{skill} skill.

   {COMMON_RULES}

   {previous_handoffs}

   1. First Read ~/.claude/commands/da/{skill}.md using the Read tool.
   2. That file's content is your operating protocol. Follow it exactly.
   3. ARGUMENTS: {specific arguments}
   4. After completion, return a summary + JSON handoff.

   IMPORTANT: Include a JSON handoff summary at the end of your response:
   {handoff_schema}"

Skill_Call_Template (Light Skills):
  Skill(skill="da:verify", args="{verification target and scope}")
  → Executed 100% identically to the user typing /da:verify
```

---

## ANTI-STALL PROTOCOL (Stall Prevention Mechanism)

### §1. Checkpoint System
File: `docs/.da-work-checkpoint.json` — updated via Bash on every Stage/Phase transition.
```json
{"pipeline":"da:work","execution_mode":"plan|roadmap","pipeline_mode":"turbo|standard",
 "plan_file":"...","roadmap_file":"...","ref_docs":[],"project_type":"GENERAL|GAME",
 "current_stage":0-5,"current_phase":1,"current_step":"S01|null",
 "total_phases":N,"total_steps":60,"scope_limit":null,
 "phases":[{"name":"...","design_needed":true,"status":"pending|done",
   "tasks":["..."],"steps":[{"id":"S01","name":"...","file":"...","ref":"...","blocked_by":"none","verify":"...","status":"pending|done"}]}],
 "design_mode":"da:design|da:create|skip","design_pages":[],
 "iterations":{"arch":0,"dev":0,"e2e":0},"last_skill":"...","last_update":"...",
 "parallel_groups":[[...],[...]],"current_wave":0,"max_files":8,"last_commit_hash":"...",
 "handoff_da:system":{...},"handoff_da:design":{...},"handoff_da:create":{...},"handoff_da:dev":{...},
 "protocol_version":1,
 "graph":{"nodes":{"3:1:da:dev":{"status":"pending|running|passed|failed|blocked|degraded|skipped","attempts":0,"max_attempts":3,"depends_on":["1:0:da:system"],"evidence_ref":null}},
          "ready":["..."],"current":null},
 "acceptance_ledger":"docs/.da-acceptance.json",
 "loop_control":{"stall_count":0,"last_progress_hash":null,"oscillation_keys":[]},
 "budget":{"max_nodes":60,"nodes_executed":0,"max_wall_minutes":90,"started_at":"..."},
 "interrupts":[]}
```
plan mode: uses tasks / roadmap mode: uses steps
**저장 시점(da:protocol §6.1)**: Stage/Phase 전환뿐 아니라 **모든 Task/Skill 노드 종료 직후** 저장. `graph.nodes[*].status` 전이는 §4.2 표만 허용.

#### §1.1. Optional `metrics` Field (hybrid-persistence A/B)

파이프라인 종료 시 checkpoint의 optional `metrics` 필드에 완주 요약을 기록한다. 이 필드는 `pipeline_metrics.py`가 생성하는 `docs/.da-work-metrics.jsonl`의 요약본이다.

```json
"metrics": {
  "run_id": "abc123",
  "preset": "hybrid-persistence" | "balanced" | ...,
  "orchestrator_model": "opus-4.6" | "opus-4.7" | null,
  "reason": "completed" | "aborted" | "error",
  "last_stage": 0-5,
  "stages_entered": int,
  "started_at": "<iso>",
  "ended_at": "<iso>"
}
```

**언제 기록하나**: Stage 5 완료 직후 또는 중단 시 FINAL checkpoint write. 실제 JSONL 이벤트 누적은 `uv run python -m davinci.workflow.pipeline_metrics` 혹은 `PipelineMetricsLogger` 직접 호출로 수행.

### §1.5. Progress Tag (GUI 진행률 전달)
Stage/Phase 전환 시 checkpoint 업데이트와 함께 progress 태그를 출력한다.
davinci-gui가 이 태그를 파싱하여 입력창 위 프로그레스 바로 렌더링한다.
```
<!-- progress: {"skill":"da:work","stage":"{phase}","phase":{N},"totalPhases":{total},"percent":{0-100}} -->
```
- Stage 전환 시: stage 필드를 새 Stage 이름으로 갱신
- Phase 전환 시: phase/totalPhases 필드를 갱신, percent를 가중치 기반으로 계산
- percent 가중치: plan=5, plan-verify=3, plan-improve=2, system=10, design-palette=5, design=15, do=35, check=10, act=10, report=5
- 파이프라인 완료 시: percent=100으로 최종 태그 출력
- Call-First 규칙 예외: progress 태그는 HTML 코멘트이므로 output budget에 최소한 영향

### §2. Call-First Pattern (★ output budget protection — ABSOLUTE)
Skill/Task return → **0 bytes text output** → extract handoff → checkpoint Bash → immediately next tool call.
- ❌ Progress bars, Stage headers, emoji decorations, "Shall I continue?" questions forbidden
- ❌ Status summaries, phase transitions announcements, "Moving to Phase N" forbidden
- ❌ Repeating sub-agent results, verification reports, or any received content
- ✅ When output needed, max 1 line (10 words or fewer)
- ✅ All progress tracking goes to checkpoint JSON file only (not stdout)
- ✅ Extract handoff JSON from skill output and store in checkpoint as handoff_{skill}
- ✅ progress 태그(<!-- progress: {...} -->)는 예외적으로 허용 (HTML 코멘트, 최소 토큰)

### §2.5. Handoff Extraction → Checkpoint Update
After each skill execution → extract handoff JSON → update checkpoint → pass to next skill.
- Look for JSON block with matching skill name in the output
- Store as handoff_{skill} in checkpoint for next skill's context
- If no valid JSON found, use fallback pattern extraction
- Build handoff chain from previous skills for context injection

### §2.6. Verification Result → Immediate Action (da:protocol §4.4 conditional edge)
da:verify return → extract **verdict handoff**(`verdict`, `match_rate`, `items[]`, `severity_max`, `evidence[]`) → immediate action (within same response).
- 판정 근거는 handoff JSON의 `items[]`. `items` 없는 "Match Rate: XX%" 텍스트만 있으면 판정 불가 = NOT_MET로 취급.
- `evidence[]` 비어 있는 MET → NOT_MET로 다운그레이드(§3.1).
- MET → graph 노드 passed → checkpoint 저장 → 다음 ready 노드 tool call
- NOT_MET, attempts < max_attempts → da:improve 즉시 실행(prompt에 `previous_failure: {reason}`, `next_action_hint`, `attempt N/M` 포함) → 같은 verify 노드 재실행
- attempts == max_attempts → `severity_max ∈ {Critical, High}` → 노드 **blocked** (다음 Stage 강제 진행 금지; 의존하지 않는 ready 노드만 계속; 리포트에 blocked 목록)
                              `severity_max ∈ {Medium, Low, None}` → 노드 **degraded** → 진행(리포트 명시)
- BLOCKED / IMPOSSIBLE → 재시도 없이 §7 interrupt(blocked_decision) 또는 사용자 보고
- ❌ Do not re-output verification report (da:verify already output it)

### §3. Self-Progress Check
Internal check on Stage transition (no output): current Stage → next action → remaining Phases → if no reason to stop, proceed immediately. If confused, read checkpoint JSON.

### §4. Resume Protocol (idempotent — da:protocol §6.2)
checkpoint exists → `graph.current` 확인:
- status `running`(중단됨) → 같은 노드를 **attempts 증가 없이** 재실행. `passed` 노드는 재실행 금지(evidence_ref 존재 확인만).
- `handoff_*` 가 있으면 재생성하지 않고 그대로 주입. 부작용 작업(git push/배포/과금 API)은 evidence_ref로 완료 여부 확인 후 건너뜀.
- stale(2h+) → 1줄 알림 후 §7 interrupt(stale_resume; 자율 모드 기본 = 재개).
none → start fresh from Stage 0.

### §5. Sub-Skill Interactive Override
All sub-skill AskUserQuestion forbidden during da:work.
- da:design questions → use auto_style/auto_font, auto-approve, CSS fallback if no API key
- da:asset questions → audit-only fallback, auto-approve (budget ≤$5)
- da:dev/da:game → autonomous judgment based on plan+ARCHITECTURE.md
- da:verify/da:e2e → auto-apply to relevant scope
- Principle: if info exists in plan/architecture, self-decide; otherwise use safe defaults

### §6. Never-End-After-Any-Skill (★ End only with tool calls)
da:work responses must always end with tool calls (exception: only after Stage 5 da:report return).
Output budget depletion cause: status text consumes tokens → next tool call impossible.
Solution: ZERO-OUTPUT + CALL-FIRST. Progress recorded in checkpoint file.

### §7. Long-Running Guard
10min+ → output progress status then continue | context compression → read checkpoint then continue | cannot proceed → save checkpoint + da:report interim report

### §8. Proactive Compact (★ output budget 보호 — Phase 간 능동적 context 압축)
```yaml
Proactive_Compact_Rule:
  trigger: 노드 경계에서만 — ready-set 1회 소진 후(Wave 경계) 또는 Phase 2개 완료 후. 노드 실행 중 compact 금지 (da:protocol §6.3)
  action: |
    # Phase N 완료 후 (N이 짝수일 때)
    # 1. 체크포인트 저장 (필수 — compact 후 복구용)
    Bash: echo '{"current_stage":3,"current_phase":N,...}' > docs/.da-work-checkpoint.json
    # 2. /compact 명령으로 context 압축 트리거
    # Claude Code가 자동으로 PreCompact hook을 실행하여 파이프라인 상태를 보존함
    # 압축 후 <da-work-pipeline> 블록이 context에 주입되어 자동 복구

  why: |
    Output budget (128K tokens)은 오케스트레이터의 모든 출력에 소비된다.
    5+ Phase COMPLEX 작업에서는 Phase 3-4 근처에서 budget이 고갈되어 끊김 발생.
    2 Phase마다 compact를 실행하면:
    - Context window가 정리되어 공간 확보
    - Output budget은 리셋되지 않지만, 불필요한 context 제거로 API 응답 효율 향상
    - PreCompact hook이 파이프라인 상태를 자동 보존하여 안전한 복구 보장

  output_optimization: |
    EPIC complexity 추가 최적화:
    - Phase 완료 시 handoff JSON만 checkpoint에 저장
    - Task 원본 결과는 archive 폴더로 이동 (필요시만 참조)
    - Progress 메시지 대신 checkpoint.json 업데이트에만 의존

  fallback: |
    compact 후 복구 실패 시 → checkpoint JSON 읽기 → work.md 프로토콜 재로드 → 이어서 진행
```

---

## Stage 0: Plan Parsing (First Action)

```yaml
# ★ PLAN.md structure generated by da:plan:
#   Sections 1-5: Strategic planning (overview, requirements, tech direction, architecture, risks)
#   "## Implementation Roadmap": Phase/Task structure (auto-parsed by da:work)
#     "### Phase N: [name]" + tasks table + design/verify fields
#   Or separate *-roadmap.md: SNN Step format (roadmap mode)

Step_1: Find plan document
  - If user specified a path → Read(that path)
  - If not specified → search in order: PLAN.md, docs/plan.md, README.md
  - Search with Glob("**/PLAN*.md")

Step_1.5: Companion document search (★ must execute after finding plan document)
  Glob("{plan_dir}/*roadmap*", "*phase*", "docs/**/*roadmap*")
  → roadmap_file (S01/S02 pattern + blocked_by/verify fields → roadmap mode)
  → ref_docs[] (server design, detailed specs, etc.)
  → If no roadmap found, execution_mode = "plan"

Step_2: Phase extraction + task item parsing

  # MODE A: Roadmap mode (when roadmap_file found)
  if execution_mode == "roadmap":
    "## Phase N" headings → phases[], "### SNN:" → steps[]
    Step fields: {id, name, file, ref, blocked_by, do[], verify}
    phases[].design_needed=false (roadmap Steps are self-contained)
    plan_file=spec reference, roadmap_file=execution guide

  # MODE B: Plan mode (no roadmap)
  elif execution_mode == "plan":
    Phase search priority: "## Implementation Roadmap" > "Implementation Order" > "## Phase N:" > "## Stage N" > entire=Phase 1
    ⚠️ heading+tasks=definition(extract) vs body mention=reference(ignore)
    Extract tasks per Phase → phases[].tasks, sub-Phase(1-ext, 1a) → separate
    da:plan standard fields: design: Y/N → design_needed, verify → verify_criteria

Step_3: Project type determination
  - Check package.json: three, @react-three/fiber, phaser, cannon-es, @dimforge/rapier → GAME
  - Plan keywords: "game", "3D", "Three.js", "WebGL", "scene" → GAME
  - Otherwise → GENERAL

Step_4: Design requirement determination per Phase
  - Determine from each Phase's task content:
    - "UI", "page", "screen", "design", "layout", "component" → design_needed=true
    - "API", "DB", "backend", "logic", "refactoring" → design_needed=false
  - Games also need design_needed=true if scene/UI composition is required

Step_5: Auto-determine design style/font (replaces AskUserQuestion)
  style_matrix: SaaS/tech/startup→modern/gradient | game/3D/AI/dark→dark/glow | portfolio/clean→minimal/clean | luxury/premium→glassmorphism | default→modern/gradient
  font_matrix: modern→Bebas Neue | dark→Ethnocentric | minimal→Abolition | glass→Bebas Neue (body: ITC Avant Garde Gothic common)
  → Save auto_style, auto_font (passed to Stage 3 da:design/da:create)

Step_5.1: Extract design_mode (from da:plan handoff)
  - Read design_mode from plan handoff JSON (default: "da:design")
  - Read design_pages[] from plan handoff JSON (default: [])
  - If design_mode == "skip" → set all phases design_needed=false
  - If design_mode == "da:create" → design_pages must be non-empty (warn if empty)
  - Save design_mode, design_pages to checkpoint

Step_5.15: Domain Context Loading (optional)
  - Glob("CONTEXT.md") in project root
  - If found → Read(CONTEXT.md) → save content to checkpoint.domain_context
  - If not found → checkpoint.domain_context = null (skip, no error)
  - When domain_context is set, inject into ALL sub-skill prompts (da:system, da:design, da:dev, da:verify):
    "## Domain Context\n{domain_context}\nUse these terms consistently in code, UI text, and documentation."

Step_5.2: Dependency Graph + Acceptance Ledger (da:protocol §4.1 / §3.5)
  - phase_graph: plan handoff의 `phase_graph[].depends_on` 사용. 없으면 roadmap `blocked_by` → 없으면 선형(N depends_on N-1).
    COMPLEX+ 는 coordinator.py wave 결과로 depends_on을 덮어쓴다(파일 소유권 충돌 = 의존). Foundation Guard: config/토큰/스키마 Phase는 모든 Phase의 선행.
  - checkpoint.graph.nodes 생성: node_id = "{stage}:{phase}:{skill}", status=pending, attempts=0,
    max_attempts = {arch: 3, dev: MODERATE→1 / 그 외 3, e2e: 3}, depends_on = 위 그래프 + 같은 Phase 내 design→dev→verify 순서.
  - acceptance ledger: Glob docs/.da-acceptance.json → 있으면 경로만 기록. 없으면 PLAN 요구사항 섹션에서 생성(항목당 criterion + check|rubric, passes=false).
    이후 원장 항목 삭제/재작성 금지 — da:verify만 passes/evidence 갱신.
  - budget 초기화: max_nodes = 12 × total_phases + 12 (상한 60), started_at = now.

Step_5.5: Complexity Classification (Turbo v2)
  - Determine complexity tier via Phase count + task count + keyword analysis
  - Reference davinci.config.json complexity.tiers
  - Classification criteria:
    a) 1 Phase + task ≤ 3 + no new files → LIGHT
    b) 1 Phase + task ≤ 5 + no new files → SIMPLE
    c) 2-3 Phases or new files exist → MODERATE
    d) 4+ Phases or system/architecture keywords → COMPLEX
    e) migration/large-scale/redesign keywords → EPIC
  - Greenfield Guard: 1+ new files → force MODERATE or above
  - Save result to checkpoint: {"complexity": "TIER"}
  - Include in output: "Complexity: {TIER} → {selected pipeline path}"

  # File limits per complexity (for Context Guard)
  FILE_LIMITS = {
    "LIGHT": 20,      # 간단한 수정
    "SIMPLE": 15,     # 단일 기능
    "MODERATE": 10,   # 중간 규모
    "COMPLEX": 8,     # 복잡한 기능
    "EPIC": 5         # 대규모 작업
  }

Step_5.6: Scope Confirmation Gate (MANDATORY for MODERATE+)
  # Complexity 분류 후, 사용자에게 실행 범위를 확인받는 게이트
  # LIGHT/SIMPLE은 스킵 (소규모라 확인 불필요)
  - Skip condition: complexity in ["LIGHT", "SIMPLE"] → 바로 Step_6으로
  - Gate action (MODERATE):
    1. Phase 요약 테이블을 1줄씩 출력:
       "Phase {N}: {name} ({task_count} tasks, design: {Y/N})"
    2. AskUserQuestion 호출:
       question: "어떤 범위로 실행할까요?"
       header: "Scope"
       options:
         - label: "전체 실행 (Phase 1~{total})"
           description: "{total} Phases, {total_tasks} tasks 전부 실행합니다."
         - label: "Phase 1만 먼저"
           description: "Phase 1만 실행 후 결과를 확인합니다. 이후 /da:work로 이어서 진행 가능."
         - label: "Phase {mid}까지"  # mid = ceil(total/2)
           description: "전반부 {mid} Phases까지만 실행합니다."
  - Gate action (COMPLEX / EPIC):
    # COMPLEX/EPIC 병렬 워크트리 분기는 GUI 플랫폼 레벨에서 처리됨.
    # InputBar가 plan 파일을 Rust로 파싱 → COMPLEX 이상이면 OrchestrationGateDialog 표시.
    # 사용자가 "Parallel Worktree" 선택 시 → GUI가 orchestration 생성 + 병렬 세션 스폰.
    # 사용자가 "Sequential" 선택 시 → CLI로 메시지 전송, 여기서부터 실행.
    # 따라서 CLI 도달 시점에서는 항상 순차 실행 모드.
    # MODERATE와 동일한 Scope Gate 적용:
    1. Phase 요약 테이블을 1줄씩 출력:
       "Phase {N}: {name} ({task_count} tasks, design: {Y/N})"
    2. AskUserQuestion 호출:
       question: "어떤 범위로 실행할까요?"
       header: "Scope"
       options:
         - label: "전체 실행 (Phase 1~{total})"
           description: "{total} Phases, {total_tasks} tasks 전부 실행합니다."
         - label: "Phase 1만 먼저"
           description: "Phase 1만 실행 후 결과를 확인합니다. 이후 /da:work로 이어서 진행 가능."
         - label: "Phase {mid}까지"  # mid = ceil(total/2)
           description: "전반부 {mid} Phases까지만 실행합니다."
  - 공통 후처리:
    3. 사용자 선택에 따라 checkpoint 업데이트:
       - "전체 실행" → total_phases 변경 없음
       - "Phase 1만" → scope_limit=1, total_phases 유지 (checkpoint에 scope_limit 기록)
       - "Phase N까지" → scope_limit=N
    4. scope_limit가 설정되면:
       - Phase loop에서 scope_limit까지만 실행
       - 마지막 Phase 완료 후 Stage 5(report)로 점프
       - checkpoint에 scope_limit 유지 → 다음 /da:work 실행 시 이어서 진행 가능

Step_5.7: Design Handoff Override (CRITICAL — design 재실행 차단 안전망)
  # plan이 잘못 emit한 design_needed_phases / design_mode 를 work 단계에서 강제로 무력화.
  # da:plan 의 Design Handoff Awareness 게이트와 이중 방어 구조.
  - Bash: ls -A .davinci/design-context/ 2>/dev/null | head -1
  - Bash: ls -A .davinci/artifacts/ 2>/dev/null | head -1
  - 사용자 메시지에 [DESIGN_CONTEXT] 블록이 존재하는지 체크
  - handoff = (위 셋 중 하나 이상이 양성) 이면:
    1. 모든 phase의 design_needed → false 로 강제 override
    2. design_mode = "skip" 으로 강제 override (plan에 "da:create"/"da:design" 이 있어도 무시)
    3. design_pages = [] 로 강제 override
    4. checkpoint.phases[].design_needed = false 일괄 갱신
    5. Phase 출력 라인에서 항상 "design: No" 로 표기 (plan 원본이 "da:create"여도 무시)
    6. Stage 2/3에서 da:create / da:design 호출 금지 — Skill 호출 직전에도 재확인
  - handoff = false 인 경우: 기존 plan 의 design_needed_phases / design_mode 그대로 사용
  - Bypass: 사용자가 동일 턴 내에서 "design 다시 / 새 디자인" 명시한 경우만 예외
  - Rationale: handoff 이후 design phase는 closed. 신규 페이지는 da:dev 가 기존 토큰으로 직접 구현.

Step_6: Output execution plan (brief)
  roadmap: "📋 ROADMAP ({steps}/{phases}/7 Checkpoints) | type | plan | roadmap | Step range per Phase"
  plan: "📋 PLAN | type | style/font | Phase N: [summary] (design: Y/N) → tasks"
  # design 라벨은 Step_5.7 override 결과를 따른다 — handoff 감지 시 모두 "No" 강제
```

**Proceed immediately to the next step after outputting execution plan (turbo → Turbo-1, standard → Stage 1). No user confirmation needed.**

```yaml
Checkpoint_Update: Create docs/.da-work-checkpoint.json via Bash
  {"current_stage":0, "pipeline_mode":"turbo", "project_type":"...", "total_phases":N, "phases":[...]}
```

---

## Pipeline Mode Dispatch

```yaml
After Stage 0 completion, branch by pipeline_mode:
  turbo (default): Execute "Turbo Mode" section below → go directly to Stage 5
  standard: Skip "Turbo Mode" → execute existing Stage 1~4
```

---

## ★ Turbo v2: Complexity-Gated Adaptive Pipeline (Speed Optimization)

da:work automatically determines task complexity after plan analysis and selects the optimal pipeline path.
All paths must run verify at minimum --fast level (verify skip forbidden).

### Complexity Classification (Auto-determined in Stage 0)

```yaml
Classification_Logic:
  1. Plan keyword analysis → determine candidate tier
  2. Phase count-based adjustment:
     - 1 Phase + task ≤ 3 → LIGHT/SIMPLE candidate
     - 2-3 Phases → MODERATE/COMPLEX candidate
     - 4+ Phases → COMPLEX/EPIC candidate
  3. Greenfield Guard:
     - If even 1 new file creation exists → force MODERATE or above
     - Existing file modifications only → LIGHT/SIMPLE allowed

Pipeline_Per_Classification:
  LIGHT (Brownfield only):
    → Stage 0 → Turbo-3(dev only, verify:fast internal) → Stage 5
    → Skip system/design/e2e
    → Estimated time: 2-3min

  SIMPLE (Brownfield only):
    → Stage 0 → Turbo-3(dev only, verify:standard internal) → Stage 5
    → Skip system/design/e2e
    → Estimated time: 4-5min

  MODERATE:
    → Stage 0 → Turbo-1(simplified system) → Turbo-3(per phase) → Stage 5
    → Skip e2e, limit improve to 1 round
    → Estimated time: 13-15min

  COMPLEX:
    → Stage 0 → Turbo-1 → Turbo-3(Phase Parallel possible) → Turbo-4 → Stage 5
    → Full pipeline, inter-Phase parallelism possible
    → Estimated time: 28-30min

  EPIC:
    → Same as existing Turbo Mode or Standard Mode
    → Full pipeline + da:cowork team collaboration
    → Estimated time: 40min+
```

### Adaptive Pipeline Dispatch (After Stage 0 Completion)

```yaml
After_Stage_0:
  complexity = classify(phases, tasks, keywords)
  Checkpoint_Update: {"complexity": "LIGHT|SIMPLE|MODERATE|COMPLEX|EPIC"}

  if complexity in ["LIGHT", "SIMPLE"]:
    verify_tier = "fast" if complexity == "LIGHT" else "standard"
    skill_name = "da:game" if project_type == "GAME" else "da:dev"
    skill_file = "game.md" if project_type == "GAME" else "dev.md"

    # ★ Stage 3.3: GAME 프로젝트일 때 da:asset --game을 병렬 실행
    if project_type == "GAME":
      Task(model="opus", prompt="
        Your task is to execute the /da:asset skill with --game flag.
        ★ TOOL RULES: Only Write(file_path, content) exists. 200+ lines → Write skeleton(50 lines)+Edit repeatedly.
        1. Read ~/.claude/commands/da/asset.md → execute per protocol
        2. ARGUMENTS: --game flag. Generate ALL game assets. Art style: {auto_style}. Output: public/assets/generated/
        3. If no API key, generate color placeholders (graceful degradation).
        4. AskUserQuestion forbidden. Return summary.")

    # Execute Turbo-3 single Phase only (skip system/design)
    Task(model="opus", prompt="
      Your task is to execute the /da:{skill_name} skill.

      {COMMON_RULES}
      5. 완료 시 다음 JSON 포함하여 반환:

         {"skill": "{skill_name}", "status": "completed", "phase": 1,
          "implementation": {"files_modified": [...], "features_implemented": [...]},
          "verification": {"tier": "{verify_tier}", "passed": true/false, "issues": []}}

      1. First Read ~/.claude/commands/da/{skill_file} then execute.
      2. Implement Phase 1.
      3. Self-verify after implementation (verify tier: {verify_tier}).
         verify:fast → type check + lint only.
         verify:standard → + Context7 best practices check.
      4. ★ Self-Check required: 1)Tests pass? 2)Requirements met? 3)Assumptions verified? 4)Evidence exists?
      5. ★ Hallucination forbidden: Do not claim 'passed' without actual build/lint output.
      6. git commit + push. AskUserQuestion forbidden. Return summary + handoff JSON.")
    → Stage 5 (da:report)

  elif complexity == "MODERATE":
    # Turbo-1(system) → Turbo-3(per phase) → Stage 5 (skip Turbo-4 e2e)
    # Limit improve to 1 round, verify tier: full
    → Turbo-1 → Turbo-3 → Stage 5, iterations.dev max=1, skip_e2e=true

  elif complexity in ["COMPLEX", "EPIC"]:
    # ★ Phase Parallel Dispatch: coordinator.py로 Wave 분석 후 Wave 단위 병렬 실행
    # Turbo-1 → Turbo-3 (with parallel dispatch) → Turbo-4 → Stage 5
    → Turbo-1 → Turbo-3 (Parallel Dispatch enabled) → Turbo-4 → Stage 5

    # coordinator.py 호출로 Wave 구조 생성 (Stage 0 직후)
    Parallel_Dispatch_Setup:
      1. Bash: uv run python -c "
           from davinci.orchestration.coordinator import analyze_spec, map_file_ownership, validate_independence
           import json
           result = analyze_spec('{plan_path}')
           tasks = map_file_ownership(result.tasks, '.')
           validated = validate_independence(tasks)
           waves = validated.parallel_groups
           print(json.dumps({'waves': waves, 'task_count': len(validated.tasks)}))"
      2. Parse waves JSON → checkpoint.parallel_groups
      3. If waves == 1 group → fall through to sequential Turbo-3 (no benefit)
      4. If waves >= 2 → enable Wave-based execution in Turbo-3

    # EPIC 추가: da:cowork team collaboration 가능 (optional)
    if complexity == "EPIC":
      # da:cowork 사용 가능하지만 필수 아님 — Wave dispatch만으로도 40%+ 절감
      pass
```

### Advanced Features (COMPLEX+ only — auto-loaded)

**When `complexity in ["COMPLEX", "EPIC"]`:**
- Phase Parallel Dispatch is **automatically enabled** via coordinator.py Wave analysis
- Foundation Guard ensures config/token phases execute in Wave 0 alone
- Orchestrator-level commit after each Phase (sub-agent commit removed)
- Adaptive Compact at Wave boundaries (replaces fixed "every 2 phases")

**Optional (loaded on demand via `~/.claude/commands/work-parallel.md`):**
- Worktree Orchestration Mode (multi-session, requires GUI)
- Verify Cache (improve loop optimization)
- Structured Handoff Protocol (inter-skill JSON compression)

---

## Turbo Mode (Default — Stages 1-4 → mega-Task compression)

Compress each Stage into a single mega-Task. Skip Stage 2 (architecture verification loop).
Sub-agents autonomously handle design+verification+commit internally.
Orchestrator tool calls reduced ~4-7x.

**mega-Task common principles:**
- `~/.claude/commands/da/{skill}.md` Read → execute per protocol
- Self-verify after completion + self-fix on failure
- `git add -A && git commit && git push` handled internally
- `AskUserQuestion` forbidden

### Turbo-1: system + verify + git

```yaml
Checkpoint: {"current_stage":1, "pipeline_mode":"turbo", "last_skill":"turbo_start"}

Task(subagent_type="general-purpose", model="opus", prompt="
  Your task: Complete system architecture design + self-verification + commit in one shot.
  {COMMON_RULES}
  5. 완료 시 다음 JSON 포함하여 반환 (node_id 고정, evidence 필수 — 없으면 hook이 partial로 강등):

     {"skill": "da:system", "node_id": "1:da:system", "status": "completed",
      "architecture": {"style": "...", "database": "...", "api_style": "...", "auth_method": "..."},
      "artifacts": {"files": [...], "decisions": [...]},
      "evidence": [{"kind": "file", "ref": "docs/ARCHITECTURE.md", "ok": true}, {"kind": "cmd", "ref": "git rev-parse HEAD", "result": "<hash>", "ok": true}],
      "next_hints": {"design_intensive_phases": [...], "complex_areas": [...], "estimated_complexity": "..."}}

  1. Read ~/.claude/commands/da/system.md → design system architecture per protocol
  2. ARGUMENTS: System architecture design based on {plan path}. Type: {GENERAL|GAME}
  3. Self-verify after design (completeness/consistency vs plan, fill gaps, max 2 self-improvement rounds)
  4. Bash: git add -A && git commit -m 'feat: system architecture' && git push
  5. AskUserQuestion forbidden. Return: architecture summary + commit hash + handoff JSON
")

# ★ Independent Arch Verify Node (MODERATE+ · da:protocol §3.2 Verifier ≠ Generator). LIGHT/SIMPLE은 위 Task의 self-verify + evidence로 대체.
if complexity in ["MODERATE", "COMPLEX", "EPIC"]:
  Task(subagent_type="general-purpose", model="sonnet", prompt="
    Your task: da:arch-verify — 위 아키텍처 산출물을 plan 대비 독립 검증. node_id: 1:da:arch-verify
    1. Read ~/.claude/commands/da/arch-verify.md. 생성자의 'self-verify passed' 문구는 근거로 인정하지 않는다.
    2. items[] 기반 판정 후 Verdict Handoff JSON(verdict/match_rate/items[]/severity_max/evidence[]/reason/next_action_hint) 반환. NO git commit.")
  verdict MET → 계속 | NOT_MET (attempt < 2) → da:system 재실행 Task에 previous_failure 포함 후 재검증 | 상한 후 Critical/High → 노드 blocked(Stage 3 진입 금지, 사용자 보고) | Medium/Low → degraded

Complete → Checkpoint: {"current_stage":3, "current_phase":1, "last_skill":"turbo_system_done"}
→ Immediately proceed to Turbo-3
```

### Turbo-3: Per-Phase design → asset → dev+verify+git (separate Tasks per skill)

**★ Key change: da:design and da:asset must be executed as separate Tasks.**
Putting 3+ Heavy Skills in one mega-Task causes sub-agents to fail following protocols.
- da:design (1346-line protocol) → registry lookup, .design-ref creation required → **separate Task**
- da:asset (asset generation/audit) → API calls, image replacement required → **separate Task**
- da:dev + verify + git (implement+verify+commit) → mechanical work → **single mega-Task OK**

```yaml
# ★ COMPLEX/EPIC: Wave-based Parallel Dispatch (coordinator.py 결과 사용)
# LIGHT/SIMPLE/MODERATE: waves 미생성 → 기존 순차 실행과 동일
if checkpoint.parallel_groups and len(checkpoint.parallel_groups) >= 2:
  # Wave-based execution: 각 Wave 내 Phase들을 동시 Task 호출
  for wave_idx, wave in enumerate(checkpoint.parallel_groups):
    wave_phases = [phases[pid] for pid in wave]  # Wave 내 Phase 목록

    if len(wave_phases) == 1:
      # Wave 내 Phase 1개 → 기존 순차 로직과 동일
      phase = wave_phases[0]
      N = phase.index
      # (아래 기존 순차 루프와 동일한 Task 호출)

    elif len(wave_phases) >= 2:
      # Wave 내 Phase 2개 이상 → 동일 응답에서 복수 Task 동시 호출
      # 각 Phase에 대해 Task를 동시에 호출 (병렬 실행)
      for phase in wave_phases:
        N = phase.index
        Task(model="opus", prompt="
          Your task is to execute the /da:dev skill + verify (NO git commit — orchestrator handles commit).

          {COMMON_RULES}

          1. Read ~/.claude/commands/da/dev.md → execute per protocol
          2. Phase {N}/{total} implementation → self-verify (max 3 rounds)
          3. Do NOT run git commit/push — orchestrator commits after Phase completion.
          4. AskUserQuestion forbidden. Return summary + handoff JSON.")

      # Wave 완료 후: orchestrator가 각 Phase별 commit 생성
      for phase in wave_phases:
        Bash: git add -A && git diff --cached --stat
        if changes_exist:
          Bash: git commit -m "feat(phase-{N}): {phase.name}"

    # ★ Adaptive Compact: Wave 완료 시점마다 compact (기존 "2 Phase마다" 대체)
    if wave_idx < len(checkpoint.parallel_groups) - 1:
      Checkpoint_Update: {"current_wave": wave_idx + 1}
      /compact

# Sequential fallback (LIGHT/SIMPLE/MODERATE 또는 Wave 1개인 경우)
else:

for phase in phases:
  Checkpoint: {"current_stage":3, "current_phase":N, "last_skill":"turbo_phase_start"}

  # Step 1: Design (conditional — da:design fast path for da:work orchestration)
  # da:work 에서는 da:create(풀 디자인 엔진) 대신 da:design + community DS 로 빠르게 접근.
  # 독립 디자인 세션의 da:create 는 영향 없음.
  if phase.design_needed:
    Task(model="opus", prompt="
      Your task is to execute the /da:design skill in FAST MODE for da:work orchestration.

      {COMMON_RULES}
      5. Return JSON: {handoff_schema}

      FAST MODE RULES (da:work orchestration context):
      - Skip AskUserQuestion (Discovery). Use plan context as design brief directly.
      - Use community design system: pick the closest DS from dsRegistryStore seed systems
        matching the project's industry/style. Apply its DTCG tokens.
      - Skip effect pipeline (da:effect_bg, da:effect_text, da:effect_particle).
      - Focus on layout + component assembly + design tokens only.
      - Output design artifacts to .davinci/artifacts/ directory.
      - Generate design.tokens.json (DTCG) alongside HTML artifacts.

      1. Read ~/.claude/commands/da/design.md → execute per protocol
      2. Phase {N} design. Pages: {design_pages} | Style: {auto_style} | Font: {auto_font}
      3. AskUserQuestion forbidden. Return summary + handoff JSON.
      4. Include in handoff: design_artifacts path + design_pregenerated=true.")
    Checkpoint_Update: {"last_skill":"da:design", "design_pregenerated": true, "design_artifact_session_id": "{current_session_id}"}

  # Step 3: da:dev/da:game + verify + git (always executed, mega-Task)
  # ★ Stage 3.3: GAME 프로젝트일 때 da:asset --game을 da:game과 병렬 실행
  if project_type == "GAME":
    # 두 Task를 동일 메시지에서 동시 호출 (병렬 실행)
    Task(model="opus", prompt="
      Your task is to execute the /da:asset skill with --game flag for game asset generation.

      {COMMON_RULES}
         {"skill": "da:asset", "status": "completed",
          "assets": {"generated": [...], "path": "public/assets/generated/"},
          "style_consistency": {"matched": true/false, "style": "..."}}

      1. Read ~/.claude/commands/da/asset.md → execute per protocol
      2. ARGUMENTS: --game flag. Generate ALL game assets (characters, enemies, backgrounds, tiles, items).
         Art style: {auto_style}. Output: public/assets/generated/
      3. If no API key available, generate color placeholders (graceful degradation).
      4. AskUserQuestion forbidden. Return summary + handoff JSON.")
    Task(model="opus", prompt="
      Your task is to execute the /da:game skill + verify + commit.
      ★ IMPORTANT: da:asset --game is running IN PARALLEL. Use placeholder asset keys in code.
      Assets will be in public/assets/generated/ when da:asset completes.

      {COMMON_RULES}
      5. 완료 시 다음 JSON 포함하여 반환:

         {"skill": "da:game", "status": "completed", "phase": N,
          "scenes": [...], "systems": [...],
          "assets": {"generated": [...], "path": "public/assets/generated/"},
          "config": {"physics": "...", "scale_mode": "...", "target_fps": 60},
          "metrics": {"loc_added": N}}

      1. Read ~/.claude/commands/da/game.md → execute per protocol
      2. Phase {N}/{total} implementation → self-verify (max 3 rounds)
      3. Do NOT run git commit/push — orchestrator handles commit after Phase completion.
      4. AskUserQuestion forbidden. Return summary + handoff JSON.")

  else:
    # GENERAL 프로젝트: 기존 da:dev 단독 실행
    Task(model="opus", prompt="
      Your task is to execute the /da:dev skill + verify (NO git commit — orchestrator handles commit).

      {COMMON_RULES}
      5. 완료 시 다음 JSON 포함하여 반환:

         {"skill": "da:dev", "status": "completed", "phase": N,
          "implementation": {"files_created": [...], "files_modified": [...], "endpoints_added": [...], "tests_written": [...]},
          "dependencies": {"added": [...], "peer_deps": []},
          "todos": {"remaining": [...], "blocked_by": [...]},
          "metrics": {"loc_added": N, "test_coverage": "N%"}}

      1. Read ~/.claude/commands/da/dev.md → execute per protocol
      2. Phase {N}/{total} implementation → self-verify (max 3 rounds)
      3. Do NOT run git commit/push — orchestrator handles commit after Phase completion.
      4. AskUserQuestion forbidden. Return summary + handoff JSON.")

  # ★ Handoff 판정 (da:protocol §2.2): status != completed 또는 evidence[] 비어 있음 → partial 취급
  #   partial → 같은 Phase를 새 Task(새 컨텍스트)로 1회 재개 (remaining[] 주입). 그래도 partial → 노드 failed → 아래 verify 루프가 처리.

  # ★ Independent Verify Node (da:protocol §3.2 — Verifier ≠ Generator). LIGHT/SIMPLE은 mega-Task 내 self-verify + evidence로 대체.
  if complexity in ["MODERATE", "COMPLEX", "EPIC"]:
    verify_node = "3:{N}:da:verify"; max_attempts = 1 if complexity == "MODERATE" else 3
    Task(model="opus", prompt="
      Your task is to execute the /da:verify skill as an INDEPENDENT verifier (you did not write this code).
      {COMMON_RULES}
      1. Read ~/.claude/commands/da/verify.md → execute per protocol. --tier {verify_tier}.
      2. Scope: Phase {N} files from handoff_da:dev.implementation. Acceptance ledger: docs/.da-acceptance.json (phase {N} 항목만 대조, 항목 추가/삭제 금지).
      3. Ignore the generator's own 'self-verify passed' claims. Run the checks yourself.
      4. Return Verdict Handoff JSON (verdict/match_rate/items[]/severity_max/evidence[]/reason/next_action_hint).")
    LOOP (§2.6 / §4.4): MET → passed
      NOT_MET & attempts < max → Task(da:improve, previous_failure + next_action_hint + attempt N/M) → re-run verify_node
      attempts == max → Critical/High 잔존: blocked (이 Phase에 의존하는 노드 대기, 독립 노드만 계속) | Medium/Low: degraded → 진행
      BLOCKED/IMPOSSIBLE → §7 interrupt
    Checkpoint 저장(노드별) 후 진행

  # ★ Orchestrator-Level Commit: Phase 완료 후 orchestrator가 직접 commit (blocked 노드는 커밋 메시지에 [blocked] 표기)
  # Sub-agent의 git commit 의존 제거 — 일관된 Phase별 커밋 보장
  Bash: git add -A && git diff --cached --stat
  if changes_exist:
    Bash: git commit -m "feat(phase-{N}): {phase.name}"
    Checkpoint_Update: {"last_commit_hash": "{commit_hash}"}

  Complete → Checkpoint: {"current_phase":N, "last_skill":"turbo_phase_done"}

  # §8 Proactive Compact: Wave 모드에서는 Wave 경계에서 compact (위에서 처리됨)
  # Sequential 모드에서는 기존 2 Phase마다 compact 유지
  if not checkpoint.parallel_groups:
    if N % 2 == 0 and N < total_phases:
      # 체크포인트가 이미 저장된 상태 → /compact 안전
      # compact 후 PreCompact hook이 <da-work-pipeline> 블록 주입 → 자동 복구
      /compact

  # Scope limit check: scope_limit 도달 시 나머지 Phase 스킵
  if checkpoint.scope_limit is set AND N >= checkpoint.scope_limit:
    break  # → Stage 5 (da:report)로 점프, Turbo-4 스킵

All Phases complete → Turbo-3.7 (Visual QA)
```

### Turbo-3.7: Visual QA Loop (Playwright screenshot + Vision analysis)

```yaml
Checkpoint: {"current_stage":3.7, "last_skill":"turbo_visual_qa_start"}

# Visual QA는 Skill 직접 호출 (orchestrator model 사용)
Skill(skill="da:visual-qa", args="--threshold 85 --max-iterations 3")

# 결과 처리: handoff에서 fidelity_score 추출
# pass=true → 노드 passed → Turbo-4 진행
# pass=false → 노드 degraded (Visual fidelity = Medium severity) → Turbo-4 진행, 리포트에 점수 명시 (da:protocol §3.4)

Complete → Checkpoint: {"current_stage":4, "last_skill":"turbo_visual_qa_done"}
→ Turbo-4
```

### Turbo-4: e2e + fix + git

```yaml
Checkpoint: {"current_stage":4, "last_skill":"turbo_e2e_start"}

Task(subagent_type="general-purpose", model="opus", prompt="
  Your task: Complete E2E testing + issue fixes + commit in one shot.
  {COMMON_RULES}
  5. 완료 시 다음 JSON 포함하여 반환:

     {"skill": "da:e2e", "node_id": "4:da:e2e", "status": "completed|partial|blocked",
      "verdict": "MET|NOT_MET|BLOCKED|IMPOSSIBLE", "severity_max": "none|low|medium|high|critical",
      "test_results": {"passed": N, "failed": N, "total": N},
      "items": [{"id": "e2e-01", "name": "...", "status": "pass|fail", "severity": "..."}],
      "evidence": [{"kind": "cmd", "ref": "npx playwright test", "result": "exit 0 · N passed", "ok": true}, {"kind": "file", "ref": "playwright-report/index.html", "ok": true}],
      "failures": [{"test": "...", "reason": "...", "severity": "..."}],
      "fixes_applied": ["..."]}
     # evidence 없는 completed는 hook이 partial로 강등한다. Playwright exit code가 verdict의 1차 근거다(생성자 자기판정 아님).

  1. Read ~/.claude/commands/da/e2e.md → execute E2E tests
  2. Failed items → fix code → retest (max 3 rounds; 매 round 다른 접근 — 직전 실패 reason을 명시하고 반복)
     Return verdict per da:protocol §3.3-b: MET | NOT_MET | BLOCKED(서버/브라우저/키 부재) | IMPOSSIBLE.
     3 rounds 후 Critical/High 실패 잔존 → status: blocked (E2E 통과로 보고 금지). Medium/Low만 → degraded.
  3. Bash: git add -A && git commit -m 'test: E2E validation' && git push
  4. AskUserQuestion forbidden. Return: test results + commit hash + handoff JSON
")

Complete → Checkpoint: {"current_stage":5, "last_skill":"turbo_e2e_done"}
→ Stage 5 da:report (same as standard section below)
```

→ After Turbo completion, proceed to Stage 5 section below.

---

## ── STANDARD MODE ──

**When `pipeline_mode == "standard"`: Read `~/.claude/commands/work-standard.md` and follow that protocol for Stages 1-4.**
Standard mode is rarely used (turbo is default). The full protocol is in a separate file to save context.

---

## Stage 4.5: Deploy Gate (Conditional)

```yaml
# Activation: Only when PLAN.md contains deploy keywords
# Keywords: ["deploy", "배포", "서버", "인프라", "hosting", "supabase", "vercel", "railway"]
# Skip conditions: --no-deploy flag, LIGHT/SIMPLE complexity, no keywords found

Deploy_Gate:
  pre_check:
    - Bash: "vercel whoami 2>/dev/null && echo 'VERCEL_OK' || echo 'VERCEL_SKIP'"
    - Bash: "railway whoami 2>/dev/null && echo 'RAILWAY_OK' || echo 'RAILWAY_SKIP'"
    - Bash: "supabase projects list 2>/dev/null && echo 'SUPABASE_OK' || echo 'SUPABASE_SKIP'"
    - If ALL skip → skip Deploy Gate entirely
    - If any OK → proceed with authenticated providers only

  execution_order:
    1. da:supabase (DB migrations first - backend dependency)
    2. da:railway (backend services)
    3. da:vercel (frontend - depends on backend URLs)
    # Each provider: Skill("da:{provider}") call
    # Preview/staging first → user confirm → production

  skip_logic:
    - complexity in ["LIGHT", "SIMPLE"] → skip (unless --deploy flag)
    - No deploy keywords in plan → skip
    - --no-deploy flag → skip
    - All providers unauthenticated → skip with warning

  checkpoint_update:
    {"current_stage": 4.5, "deploy_gate": {"activated": true, "providers": [...]}}
```

---

## Stage 5: Report

```yaml
Checkpoint_Update: {"current_stage":5, "last_skill":"da:report"}

# ★ STEP 5-A: dev.sh 생성 (웹앱/서버 감지 시 항상 실행)
# package.json / pyproject.toml / Cargo.toml / go.mod 중 하나라도 있으면 실행
# Guard: 없으면 da:devsh가 자체 스킵 처리
Skill(skill="da:devsh", args="")

# ★ STEP 5-B: 최종 리포트 생성
# da:report → Skill tool direct call (identical to user typing /da:report)
Skill(skill="da:report", args="Generate a full development process report. Include per-Phase results, match rate, iteration count, E2E test results.")

# ★ STEP 5-COMMIT: 파이프라인 최종 커밋 (da:devsh + da:report 결과물 포함)
# da:report(REPORT.md), da:devsh(dev.sh) 등 Stage 5에서 생성된 모든 파일 포함
# git status --porcelain으로 변경사항 있을 때만 실행
Skill(skill="da:git", args="파이프라인 Stage 5 최종 커밋. dev.sh + REPORT 파일 포함. commit message: 'release: pipeline complete'")

# Checkpoint cleanup
Bash: rm -f docs/.da-work-checkpoint*.json

# ★ STEP 5-C: 사용자 실행 가이드 출력
# da:devsh가 생성한 PORT 값을 포함하여 출력 (dev.sh 존재 시)
if dev.sh exists:
  Output: |
    🎉 /da:work pipeline complete!

    ▶ 앱 실행 방법:
      ./dev.sh

    🌐 브라우저에서 열기:
      http://localhost:{PORT}

    ※ dev.sh가 자동으로 포트 충돌 해결, .env 로딩, 브라우저 오픈을 처리합니다.
else:
  Output: "🎉 /da:work pipeline complete!"
```

---

## State Tracking
Output progress status in `[✅/🔄/⬚] Stage N: Name` format on Stage transitions.

## Error Handling (da:protocol §3.4 / §4.2 / §5.3)
Build failure→da:improve | Test failure→da:improve loop(attempt마다 다른 접근, previous_failure 주입)
| 상한 도달 + Critical/High 잔존 → 노드 `blocked` (강제 진행 금지, 독립 노드만 계속, 리포트에 blocked 목록)
| 상한 도달 + Medium/Low만 → 노드 `degraded`로 진행(리포트 명시) | 3 fix failures→da:system 재검토 노드 삽입

---

## Usage
```
/da:work                      # Auto-find PLAN.md and execute
/da:work PLAN-homepage.md     # Specify a particular plan document
/da:work Start based on the homepage plan  # Specify plan in natural language
```

## Iron Law
**Never start without a plan document. Never stop while ready nodes remain. Run seamlessly through to da:report completion.**
단, `blocked` 노드만 남았을 때 계속 도는 것은 규칙 위반이다 — 즉시 partial 리포트로 종료한다(da:protocol §5.5). 근거 없는 완료는 완료가 아니다.

ARGUMENTS: $ARGUMENTS
