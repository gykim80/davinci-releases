/**
 * ios-frame.jsx - iOS Device Frame
 *
 * Provides: IosFrame component with status bar, notch, home indicator.
 * Default: iPhone 15 Pro dimensions (393x852 logical).
 */

function IosFrame({ children, width = 393, statusBarTime = "9:41", dark = false }) {
  const bg = dark ? "#000" : "#fff";
  const fg = dark ? "#fff" : "#000";
  const height = Math.round(width * (852 / 393));

  const frameStyles = {
    width, height,
    borderRadius: width * 0.12,
    border: `3px solid ${dark ? "#333" : "#d1d5db"}`,
    background: bg,
    position: "relative",
    overflow: "hidden",
    boxShadow: "0 25px 60px rgba(0,0,0,0.3)",
    margin: "0 auto",
  };

  const statusBarStyles = {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "12px 28px 0",
    fontSize: 15,
    fontWeight: 600,
    fontFamily: "-apple-system, BlinkMacSystemFont, sans-serif",
    color: fg,
    height: 54,
    position: "relative",
    zIndex: 10,
  };

  const notchStyles = {
    position: "absolute",
    top: 0,
    left: "50%",
    transform: "translateX(-50%)",
    width: width * 0.35,
    height: 34,
    background: "#000",
    borderRadius: "0 0 20px 20px",
    zIndex: 20,
  };

  const homeIndicatorStyles = {
    position: "absolute",
    bottom: 8,
    left: "50%",
    transform: "translateX(-50%)",
    width: width * 0.36,
    height: 5,
    borderRadius: 100,
    background: dark ? "rgba(255,255,255,0.3)" : "rgba(0,0,0,0.2)",
    zIndex: 10,
  };

  const contentStyles = {
    position: "absolute",
    top: 54,
    left: 0,
    right: 0,
    bottom: 34,
    overflow: "auto",
  };

  return (
    <div style={frameStyles}>
      <div style={notchStyles} />
      <div style={statusBarStyles}>
        <span>{statusBarTime}</span>
        <div style={{ display: "flex", gap: 5, alignItems: "center" }}>
          {/* Signal + WiFi + Battery icons (minimal) */}
          <svg width="17" height="12" viewBox="0 0 17 12" fill={fg}><rect x="0" y="6" width="3" height="6" rx="1"/><rect x="5" y="3" width="3" height="9" rx="1"/><rect x="10" y="0" width="3" height="12" rx="1"/></svg>
          <svg width="16" height="12" viewBox="0 0 16 12" fill={fg}><path d="M8 3C5.5 3 3.2 4 1.5 5.5L0 4C2.1 2.2 4.9 1 8 1s5.9 1.2 8 3l-1.5 1.5C12.8 4 10.5 3 8 3z"/><circle cx="8" cy="10" r="2"/></svg>
          <svg width="27" height="13" viewBox="0 0 27 13" fill={fg}><rect x="0" y="1" width="23" height="11" rx="2.5" stroke={fg} strokeWidth="1" fill="none"/><rect x="2" y="3" width="18" height="7" rx="1" fill={fg}/><rect x="24.5" y="4.5" width="2" height="4" rx="1"/></svg>
        </div>
      </div>
      <div style={contentStyles}>
        {children}
      </div>
      <div style={homeIndicatorStyles} />
    </div>
  );
}

window.IosFrame = IosFrame;
