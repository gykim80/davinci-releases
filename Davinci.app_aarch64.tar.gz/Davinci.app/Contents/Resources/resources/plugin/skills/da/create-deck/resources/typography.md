<!--
Source: op7418/guizang-ppt-skill (Apache-2.0)
Original: https://github.com/op7418/guizang-ppt-skill
Copyright (c) op7418. Licensed under Apache-2.0.
Modifications: Adapted for davinci-framework — Korean comments + PPTX Iron Law conflict notes.
-->

# 타이포그래피 시스템 (Typography System)

> 원본: op7418/guizang-ppt-skill `references/components.md` 타이포그래피 섹션 + `template.html` CSS
>
> **3-tier 폰트 분공 원칙**: 세리프(제목) / 비세리프(본문) / 모노스페이스(메타)
> 폰트 분공을 어기면 즉시 잡지풍이 무너집니다.

---

## Tier 1 — Headline Serif (제목 세리프)

대제목, 강조 인용, 숫자 대자에 사용합니다.

### 주요 폰트

| 폰트 | 용도 | Google Fonts |
|------|------|-------------|
| **Noto Serif SC** | 한국어/중국어 대제목 | `Noto+Serif+SC:wght@300;400;500;600;700;900` |
| **Playfair Display** | 영문 디스플레이 제목 | `Playfair+Display:ital,wght@0,400;0,700;0,900;1,400;1,700` |
| **Source Serif 4** | 영문 본문 세리프 | `Source+Serif+4:ital,opsz,wght@0,8..60,300;0,8..60,600` |

### CSS 클래스

```css
/* 최대 영문 디스플레이 (hero 전용) */
.display     { font-size: 11vw; font-family: var(--serif-en); font-weight: 700; }

/* 한국어 대제목 계층 */
.h-hero      { font-size: 10vw;  font-family: var(--serif-zh); font-weight: 900; }
.h-xl        { font-size: 6.2vw; font-family: var(--serif-zh); font-weight: 700; }
.h-sub       { font-size: 3.1vw; font-family: var(--serif-zh); font-weight: 500; opacity: .7; }
.h-md        { font-size: 2.3vw; font-family: var(--serif-zh); font-weight: 600; }

/* 영문 제목 오버라이드 */
.h-xl-en, .h-hero-en { font-family: var(--serif-en); letter-spacing: -.025em; }

/* 인용 본문 세리프 */
.body-serif  { font-size: max(15px, 1.3vw); font-family: var(--serif-zh); }
.lead        { font-size: 1.75vw; font-family: var(--serif-zh); opacity: .86; }
```

### 사용 규칙

- `h-hero`: hero 페이지 전용, **최대 5자** (글자 수 초과 시 1자 1행 줄바꿈 위험)
- `h-xl`: 일반 섹션 대제목. 긴 제목은 `<br>` 수동 줄바꿈
- 세리프는 제목/인용구에만 — 설명 텍스트에 세리프 사용 금지

---

## Tier 2 — Body Sans (본문 비세리프)

일반 본문, 설명, 파이프라인 단계, UI 레이블에 사용합니다.

### 주요 폰트

| 폰트 | 용도 | Google Fonts |
|------|------|-------------|
| **Noto Sans SC** | 한국어/중국어 본문 | `Noto+Sans+SC:wght@300;400;500;700;900` |
| **Inter** | 영문 본문 / UI 텍스트 | `Inter:wght@300;400;500;600;700` (필요 시 추가) |

### CSS 클래스

```css
/* 한국어 일반 본문 */
.body-zh     { font-size: max(15px, 1.22vw); font-family: var(--sans-zh); line-height: 1.75; opacity: .82; }

/* 파이프라인 단계 */
.step-title  { font-family: var(--sans-zh); font-weight: 700; font-size: 1.55vw; }
.step-desc   { font-family: var(--sans-zh); font-size: max(12px, .95vw); opacity: .72; }
```

### 사용 규칙

- 설명, 부연, 파이프라인 단계명은 무조건 비세리프
- 세리프 제목 아래 비세리프 본문 조합이 기본 패턴
- line-height: 1.75 (한국어 가독성 최적값)

---

## Tier 3 — Metadata Mono (메타데이터 모노스페이스)

레이블, 날짜, 페이지 번호, 출처, kicker에 사용합니다.

### 주요 폰트

| 폰트 | 용도 | Google Fonts |
|------|------|-------------|
| **IBM Plex Mono** | 기본 모노스페이스 | `IBM+Plex+Mono:wght@300;400;500;600` |
| **JetBrains Mono** | 코드 / 기술 레이블 (선택) | 별도 CDN 추가 시 사용 |

### CSS 클래스

```css
/* kicker — 페이지 상단 레이블 */
.kicker      { font-family: var(--mono); font-size: 12px; letter-spacing: .3em; text-transform: uppercase; opacity: .6; }

/* 메타 정보 */
.meta        { font-family: var(--mono); font-size: max(11px, .88vw); letter-spacing: .16em; text-transform: uppercase; }

/* 메타 행 */
.meta-row    { font-family: var(--mono); font-size: max(12px, .92vw); letter-spacing: .16em; }

/* chrome / foot */
.chrome, .foot { font-family: var(--mono); }

/* stat-label */
.stat-label  { font-family: var(--mono); letter-spacing: .24em; text-transform: uppercase; }
```

### 사용 규칙

- `letter-spacing: .2em~.3em` + `text-transform: uppercase` 조합 필수
- kicker는 이 페이지 고유 인트로 (chrome 번역/반복 금지)
- 모든 숫자 표시: `font-feature-settings: "tnum"` (고정폭 숫자)

---

## 폰트 로드 (Google Fonts CDN)

`template.html`에 사전 포함된 CDN 링크:

```html
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;0,900;1,400;1,700&family=Source+Serif+4:ital,opsz,wght@0,8..60,300;0,8..60,400;0,8..60,600;1,8..60,400&family=IBM+Plex+Mono:wght@300;400;500;600&family=Noto+Serif+SC:wght@300;400;500;600;700;900&family=Noto+Sans+SC:wght@300;400;500;700;900&display=swap" rel="stylesheet">
```

---

## PPTX Export 주의사항

> ⚠️ PPTX Iron Law #9: `fontFace` 에 등록된 폰트만 PPTX에 임베드됩니다.
> 위 Google Fonts는 web preview에서만 보장됩니다.
> PPTX export 시 pptxgenjs의 `addSection` > `fontFace` 설정에 폰트 등록 필요.

```javascript
// pptxgenjs 폰트 등록 예시
pptx.defineFontFace({
  name: "Noto Serif SC",
  data: fs.readFileSync("./fonts/NotoSerifSC-Regular.ttf").toString("base64"),
  size: 400
});
```

---

## 폰트 분공 요약표

| 역할 | 폰트 | 클래스 |
|------|------|--------|
| 한국어/중국어 대제목 | Noto Serif SC | `.h-hero`, `.h-xl`, `.h-sub`, `.h-md` |
| 영문 디스플레이 제목 | Playfair Display | `.display`, `.h-xl-en` |
| 영문 본문 세리프 | Source Serif 4 | `.body-serif`, `.lead` |
| 한국어 일반 본문 | Noto Sans SC | `.body-zh`, `.step-*` |
| 메타/레이블/kicker | IBM Plex Mono | `.kicker`, `.meta`, `.chrome`, `.foot` |
