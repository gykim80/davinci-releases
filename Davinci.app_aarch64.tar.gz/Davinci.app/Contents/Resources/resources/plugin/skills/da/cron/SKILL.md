---
name: cron
description: Create and manage cron jobs via natural language
skill: da:cron
usage: /da:cron [command|natural language]
examples:
  - /da:cron 5분마다 서버 상태 확인해줘
  - /da:cron list
  - /da:cron cancel abc123
  - /da:cron pause abc123
  - /da:cron resume abc123
  - /da:cron status
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 유틸리티: 부작용(외부 API/배포/삭제) 전 §7 destructive/cost_gate 규칙을 확인한다.

# /da:cron

Create and manage cron jobs for Alan CronService using natural language.

## Commands

| Command | Description |
|---------|-------------|
| `/da:cron <natural language>` | Create a new cron job from natural language |
| `/da:cron list` | List all registered cron jobs |
| `/da:cron cancel <id>` | Cancel (delete) a cron job |
| `/da:cron pause <id>` | Pause a cron job |
| `/da:cron resume <id>` | Resume a paused cron job |
| `/da:cron status` | Show CronService health and job summary |

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `DAVINCI_CRON_HOST` | `localhost:8080` | Alan CronService host:port |
| `DAVINCI_CRON_JOBS_PATH` | `~/.openclaw/workspace/cron/jobs.json` | Path to jobs.json |
| `DAVINCI_AGENT_ID` | (none) | Default agent ID for job payloads |
