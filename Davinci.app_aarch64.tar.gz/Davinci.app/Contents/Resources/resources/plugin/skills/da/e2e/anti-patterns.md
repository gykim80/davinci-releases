# E2E Testing Anti-Patterns

Common mistakes in end-to-end testing that lead to flaky, slow, or unmaintainable test suites. Each anti-pattern includes detection rules, bad/good code examples, and prevention strategies.

## Test Interdependencies

Tests that depend on the execution order of other tests. If test B requires test A to run first (e.g., test A creates data that test B reads), reordering or running tests in isolation will cause failures.

### Why It Is Bad

- Tests cannot run in parallel or in isolation.
- A single test failure cascades into multiple false failures.
- Sharding becomes impossible since shard assignment is non-deterministic.

**Detect:** Test file where a later test references a variable or state set by an earlier test (e.g., `let createdId` shared across `test()` blocks).

```typescript
// Bad: Tests share mutable state and depend on execution order
let createdItemId: string;

test('create item', async ({ page }) => {
  await page.goto('/items/new');
  await page.getByLabel('Name').fill('Test Item');
  await page.getByRole('button', { name: 'Create' }).click();
  createdItemId = page.url().split('/').pop()!; // Shared state
});

test('edit item', async ({ page }) => {
  await page.goto(`/items/${createdItemId}/edit`); // Depends on previous test
  await page.getByLabel('Name').fill('Updated Item');
  await page.getByRole('button', { name: 'Save' }).click();
});

// Good: Each test is fully independent with its own setup
test('create and verify item', async ({ page }) => {
  await page.goto('/items/new');
  await page.getByLabel('Name').fill('Test Item');
  await page.getByRole('button', { name: 'Create' }).click();
  await expect(page.getByText('Test Item')).toBeVisible();
});

test('edit item', async ({ page, request }) => {
  // Create test data independently via API
  const response = await request.post('/api/items', {
    data: { name: 'Item to Edit' },
  });
  const { id } = await response.json();

  await page.goto(`/items/${id}/edit`);
  await page.getByLabel('Name').fill('Updated Item');
  await page.getByRole('button', { name: 'Save' }).click();
  await expect(page.getByText('Updated Item')).toBeVisible();
});
```

### Prevention Strategy

- Each test must create its own preconditions (via API calls or fixtures).
- Use `test.describe` with `beforeEach` for shared setup, not shared variables.
- Run tests with `--fully-parallel` to expose hidden dependencies.

## Hardcoded Waits

Using `waitForTimeout()`, `setTimeout()`, or `sleep()` instead of waiting for specific conditions. Hardcoded waits are either too short (causing flakiness) or too long (wasting CI time).

### Why It Is Bad

- Too short: test fails on slow CI runners.
- Too long: every test wastes seconds of wall-clock time.
- Non-deterministic: timing depends on machine load, network, and server performance.

**Detect:** `page.waitForTimeout()` or `setTimeout` or `sleep` in any test file.

```typescript
// Bad: Hardcoded wait -- too short or too long, always wrong
test('shows notification', async ({ page }) => {
  await page.getByRole('button', { name: 'Save' }).click();
  await page.waitForTimeout(3000); // Arbitrary 3 seconds
  await expect(page.getByText('Saved')).toBeVisible();
});

// Good: Wait for the specific condition using auto-retrying assertion
test('shows notification', async ({ page }) => {
  await page.getByRole('button', { name: 'Save' }).click();
  await expect(page.getByText('Saved')).toBeVisible(); // Auto-retries until visible
});

// Good: Wait for network idle if needed
test('data loads after action', async ({ page }) => {
  await page.getByRole('button', { name: 'Refresh' }).click();
  await page.waitForResponse('**/api/data'); // Wait for specific response
  await expect(page.getByTestId('data-table')).toBeVisible();
});
```

### Prevention Strategy

- Use Playwright auto-retrying assertions (`toBeVisible`, `toHaveText`, `toHaveURL`).
- Use `waitForResponse()` or `waitForRequest()` for network-dependent operations.
- Use `waitForLoadState('networkidle')` only as a last resort.
- Lint rule: ban `waitForTimeout` in test files.

## Screenshot-Based Verification

Using visual comparison (screenshot matching) as the primary assertion method instead of DOM-based assertions. Screenshots are environment-dependent and create maintenance overhead.

### Why It Is Bad

- Pixel differences across OS, browser versions, and font rendering cause false failures.
- Screenshot baselines must be updated for every visual change, even unrelated ones.
- Provides no semantic information about what is wrong when a test fails.

**Detect:** `page.screenshot()` followed by `toMatchSnapshot()` or `expect(screenshot)` as the primary assertion in a test.

```typescript
// Bad: Screenshot as primary verification
test('dashboard renders correctly', async ({ page }) => {
  await page.goto('/dashboard');
  await expect(page).toHaveScreenshot('dashboard.png'); // Fragile
});

// Good: DOM-based assertions that verify structure and content
test('dashboard renders correctly', async ({ page }) => {
  await page.goto('/dashboard');
  await expect(page.getByRole('heading', { name: 'Dashboard' })).toBeVisible();
  await expect(page.getByTestId('stats-card')).toHaveCount(4);
  await expect(page.getByText('Total Revenue')).toBeVisible();
  await expect(page.getByRole('navigation')).toBeVisible();
});

// Acceptable: Screenshot for specific visual regression (supplement, not primary)
test('chart renders with correct colors', async ({ page }) => {
  await page.goto('/dashboard');
  await expect(page.getByTestId('revenue-chart')).toBeVisible(); // DOM first
  await expect(page.getByTestId('revenue-chart')).toHaveScreenshot({
    maxDiffPixels: 100, // Tolerance for rendering differences
  });
});
```

### Prevention Strategy

- Use screenshots only for visual regression of specific components, not full pages.
- Always pair screenshots with DOM assertions as the primary check.
- Set `maxDiffPixels` or `maxDiffPixelRatio` tolerance for acceptable rendering differences.
- Run visual tests on a single browser/OS combination to reduce variance.

## Fragile Selectors

Using CSS class names, XPath expressions, or positional selectors (`nth-child`) that break when styling or layout changes.

### Why It Is Bad

- CSS classes change with design updates, CSS module hash changes, or Tailwind refactors.
- XPath is verbose, hard to read, and tightly coupled to DOM structure.
- Positional selectors break when elements are added, removed, or reordered.

**Detect:** CSS class selector (`.btn-primary`, `.card-title`) in test files. XPath expression (`//div`, `//span[@class]`) in test files. `nth-child`, `nth-of-type`, or `locator('div > span:first-child')` in test files.

```typescript
// Bad: CSS class selectors -- break on style changes
test('click submit', async ({ page }) => {
  await page.locator('.btn-primary.submit-form').click();
});

// Bad: XPath -- verbose, fragile, hard to maintain
test('find heading', async ({ page }) => {
  await page.locator('//div[@class="container"]/h1').click();
});

// Bad: Positional selectors -- break on DOM reorder
test('select first item', async ({ page }) => {
  await page.locator('.list-item:nth-child(1)').click();
});

// Good: Role-based selectors (accessible, stable)
test('click submit', async ({ page }) => {
  await page.getByRole('button', { name: 'Submit' }).click();
});

// Good: Label-based selectors
test('fill email', async ({ page }) => {
  await page.getByLabel('Email address').fill('user@example.com');
});

// Good: Test ID selectors (when role/label is not feasible)
test('select first item', async ({ page }) => {
  await page.getByTestId('product-card').first().click();
});
```

### Prevention Strategy

- Follow the selector priority: `getByRole` > `getByLabel` > `getByTestId` > `getByText`.
- Add `data-testid` attributes for complex components that lack accessible roles.
- Never use CSS class selectors or XPath in tests.
- Lint rule: ban `.locator('.')` patterns that match CSS class selectors.

## Shared Mutable State

Tests that share database rows, global variables, or external service state. When tests run in parallel, they corrupt each other's data.

### Why It Is Bad

- Parallel execution causes race conditions and intermittent failures.
- Test isolation is violated -- one test's side effects affect another.
- Debugging is difficult because failures depend on execution order.

**Detect:** `global` or module-level `let`/`var` assignments in test files. Direct database queries without cleanup in `afterEach`. Shared API state (e.g., creating a user in `beforeAll` that multiple tests modify).

```typescript
// Bad: Shared database row modified by multiple tests
test.beforeAll(async () => {
  await db.users.create({ id: 'shared-user', name: 'Test User' });
});

test('update user name', async ({ page }) => {
  // Modifies the shared user -- other tests see the change
  await page.goto('/users/shared-user/edit');
  await page.getByLabel('Name').fill('New Name');
  await page.getByRole('button', { name: 'Save' }).click();
});

test('verify user name', async ({ page }) => {
  // Expects original name but gets "New Name" if previous test ran first
  await page.goto('/users/shared-user');
  await expect(page.getByText('Test User')).toBeVisible(); // FAILS
});

// Good: Each test creates and cleans up its own data
test('update user name', async ({ page, request }) => {
  // Create isolated test data
  const res = await request.post('/api/users', {
    data: { name: 'Original Name' },
  });
  const { id } = await res.json();

  await page.goto(`/users/${id}/edit`);
  await page.getByLabel('Name').fill('New Name');
  await page.getByRole('button', { name: 'Save' }).click();
  await expect(page.getByText('New Name')).toBeVisible();

  // Cleanup
  await request.delete(`/api/users/${id}`);
});
```

### Prevention Strategy

- Each test creates its own data via API or fixture and cleans up in `afterEach`.
- Use unique identifiers (UUIDs, timestamps) for test data to avoid collisions.
- Use database transactions that roll back after each test.
- Run tests with `--fully-parallel` to expose shared state issues.

## Over-Mocking in E2E

Mocking too many dependencies in E2E tests defeats the purpose of end-to-end testing. E2E tests should exercise the full stack.

### Why It Is Bad

- Mocked code paths are not tested end-to-end, creating false confidence.
- Mocks can drift from actual API behavior, hiding real integration bugs.
- Tests pass in CI but the application fails in production.

**Detect:** More than 3 `page.route()` mocks in a single E2E test. All API calls mocked in an E2E test file. Mock response shapes that do not match actual API schemas.

```typescript
// Bad: Mocking everything -- this is a unit test disguised as E2E
test('dashboard shows data', async ({ page }) => {
  await page.route('**/api/user', (route) =>
    route.fulfill({ json: { name: 'Mock User' } })
  );
  await page.route('**/api/stats', (route) =>
    route.fulfill({ json: { revenue: 1000 } })
  );
  await page.route('**/api/notifications', (route) =>
    route.fulfill({ json: [] })
  );
  await page.route('**/api/settings', (route) =>
    route.fulfill({ json: { theme: 'dark' } })
  );

  await page.goto('/dashboard');
  await expect(page.getByText('Mock User')).toBeVisible(); // Proves nothing
});

// Good: Use real backend, mock only external third-party services
test('dashboard shows real data', async ({ page }) => {
  // Only mock external services you do not control
  await page.route('**/api.stripe.com/**', (route) =>
    route.fulfill({ json: { status: 'active' } })
  );

  await page.goto('/dashboard');
  await expect(page.getByRole('heading', { name: 'Dashboard' })).toBeVisible();
  await expect(page.getByTestId('stats-card')).toHaveCount(4);
});
```

### Prevention Strategy

- Mock only external third-party services (Stripe, SendGrid, analytics).
- Use a test database with seed data instead of mocking your own API.
- If you need controlled data, use API endpoints to seed data before the test.
- Keep mock count under 2 per test as a guideline.

## Flaky Test Syndrome

Tests that pass or fail randomly without any code change. Flaky tests erode confidence in the test suite and cause teams to ignore failures.

### Why It Is Bad

- Developers start ignoring test failures ("it's just a flaky test").
- Real bugs slip through because failures are dismissed.
- CI retries waste time and money.
- Team confidence in the test suite degrades.

**Detect:** Test has `retries` configured but no investigation into root cause. Test uses `waitForTimeout` as a workaround for timing issues. Test has a comment containing "flaky" or "intermittent" or "sometimes fails".

```typescript
// Bad: Working around flakiness with retries and waits
test('submit form', async ({ page }) => {
  await page.goto('/form');
  await page.getByLabel('Email').fill('test@example.com');
  await page.getByRole('button', { name: 'Submit' }).click();
  await page.waitForTimeout(2000); // "Sometimes it needs more time"
  // test.retry(3) configured because it "sometimes fails"
  await expect(page.getByText('Success')).toBeVisible();
});

// Good: Deterministic test with proper waiting
test('submit form', async ({ page }) => {
  await page.goto('/form');
  await page.getByLabel('Email').fill('test@example.com');

  // Wait for the submit button to be enabled (form validation complete)
  await expect(page.getByRole('button', { name: 'Submit' })).toBeEnabled();
  await page.getByRole('button', { name: 'Submit' }).click();

  // Wait for the specific network response
  await page.waitForResponse((resp) =>
    resp.url().includes('/api/submit') && resp.status() === 200
  );

  await expect(page.getByText('Success')).toBeVisible();
});
```

### Prevention Strategy

- Investigate every flaky test immediately -- do not add retries as a workaround.
- Use `waitForResponse` or `waitForRequest` instead of arbitrary waits.
- Ensure test data is isolated (no shared mutable state).
- Run tests in `--repeat-each=5` mode locally to detect flakiness before merge.
- Track flaky test rate as a team metric (target: <1%).

## Test Data Pollution

Tests that create data but do not clean up after themselves, causing test database or environment to accumulate garbage data over time.

### Why It Is Bad

- Test database grows unbounded, slowing down queries and CI.
- Stale data causes unexpected test interactions.
- Database constraints (unique emails, IDs) cause failures over time.
- Local development environment becomes polluted.

**Detect:** `request.post()` or database insert operations in tests without corresponding cleanup in `afterEach` or `afterAll`. No database reset or truncation between test runs.

```typescript
// Bad: Creating data without cleanup
test('create user', async ({ request }) => {
  await request.post('/api/users', {
    data: { email: 'test@example.com', name: 'Test' },
  });
  // Data persists forever, eventually causes unique constraint errors
});

// Good: Create with cleanup using fixture
import { test as base } from '@playwright/test';

type TestFixtures = {
  testUser: { id: string; email: string };
};

export const test = base.extend<TestFixtures>({
  testUser: async ({ request }, use) => {
    // Setup: create test data
    const email = `test-${Date.now()}@example.com`;
    const response = await request.post('/api/users', {
      data: { email, name: 'Test User' },
    });
    const user = await response.json();

    // Provide to test
    await use(user);

    // Teardown: cleanup test data
    await request.delete(`/api/users/${user.id}`);
  },
});

test('edit user profile', async ({ page, testUser }) => {
  await page.goto(`/users/${testUser.id}/edit`);
  await page.getByLabel('Name').fill('Updated Name');
  await page.getByRole('button', { name: 'Save' }).click();
  await expect(page.getByText('Updated Name')).toBeVisible();
  // testUser is automatically cleaned up after this test
});
```

### Prevention Strategy

- Use Playwright fixtures with teardown for all test data creation.
- Use unique identifiers (timestamps, UUIDs) to avoid collisions.
- Implement a global teardown that resets the test database.
- Use database transactions that roll back after each test when possible.

## Mega Tests

Single test functions that perform too many actions (more than 15 interactions), making them slow, hard to debug, and difficult to maintain.

### Why It Is Bad

- A failure at step 20 of 30 gives no information about which feature broke.
- Tests take minutes to run, slowing the feedback loop.
- Any change to the flow requires updating the entire mega test.
- Debugging requires reproducing the entire 30-step sequence.

**Detect:** A single `test()` block with more than 15 user interactions (`click`, `fill`, `goto`). Test function body longer than 80 lines. Test name that describes multiple distinct operations ("create, edit, delete, and verify item").

```typescript
// Bad: Mega test doing everything in one function
test('full user lifecycle', async ({ page }) => {
  // Register (5 actions)
  await page.goto('/register');
  await page.getByLabel('Name').fill('Test User');
  await page.getByLabel('Email').fill('test@example.com');
  await page.getByLabel('Password').fill('password123');
  await page.getByRole('button', { name: 'Register' }).click();

  // Create item (5 actions)
  await page.goto('/items/new');
  await page.getByLabel('Title').fill('My Item');
  await page.getByLabel('Description').fill('Description');
  await page.getByLabel('Category').selectOption('electronics');
  await page.getByRole('button', { name: 'Create' }).click();

  // Edit item (4 actions)
  await page.getByRole('link', { name: 'Edit' }).click();
  await page.getByLabel('Title').fill('Updated Item');
  await page.getByRole('button', { name: 'Save' }).click();
  await expect(page.getByText('Updated Item')).toBeVisible();

  // Delete item (3 actions)
  await page.getByRole('button', { name: 'Delete' }).click();
  await page.getByRole('button', { name: 'Confirm' }).click();
  await expect(page.getByText('Item deleted')).toBeVisible();

  // Logout (2 actions)
  await page.getByRole('button', { name: 'Logout' }).click();
  await expect(page).toHaveURL('/login');
  // Total: 19 actions, impossible to pinpoint failure
});

// Good: Split into focused tests with shared setup via fixtures
test.describe('item management', () => {
  test('create item', async ({ page, testUser }) => {
    await page.goto('/items/new');
    await page.getByLabel('Title').fill('My Item');
    await page.getByLabel('Description').fill('Description');
    await page.getByLabel('Category').selectOption('electronics');
    await page.getByRole('button', { name: 'Create' }).click();
    await expect(page.getByText('My Item')).toBeVisible();
  });

  test('edit item', async ({ page, testItem }) => {
    await page.goto(`/items/${testItem.id}/edit`);
    await page.getByLabel('Title').fill('Updated Item');
    await page.getByRole('button', { name: 'Save' }).click();
    await expect(page.getByText('Updated Item')).toBeVisible();
  });

  test('delete item', async ({ page, testItem }) => {
    await page.goto(`/items/${testItem.id}`);
    await page.getByRole('button', { name: 'Delete' }).click();
    await page.getByRole('button', { name: 'Confirm' }).click();
    await expect(page.getByText('Item deleted')).toBeVisible();
  });
});
```

### Prevention Strategy

- One test should verify one behavior or one user flow.
- Use fixtures to set up preconditions (authenticated user, existing data).
- Target 5-10 interactions per test as a guideline.
- If a test exceeds 15 actions, split it into multiple focused tests.

## Missing Error Path Tests

Only testing the happy path (success scenarios) and ignoring error states, validation failures, and edge cases.

### Why It Is Bad

- Error handling code is never verified, often hiding bugs.
- Users experience unhandled errors in production.
- Error messages, retry buttons, and fallback UIs are never validated.
- Edge cases like empty states, rate limits, and network errors go untested.

**Detect:** Test file where all tests have only success assertions (no error message checks, no error state verification). No test names containing "error", "invalid", "fail", or "empty" in a test file with more than 3 tests.

```typescript
// Bad: Only happy path tested
test('submit form', async ({ page }) => {
  await page.goto('/contact');
  await page.getByLabel('Email').fill('valid@example.com');
  await page.getByLabel('Message').fill('Hello');
  await page.getByRole('button', { name: 'Send' }).click();
  await expect(page.getByText('Message sent')).toBeVisible();
});

// Good: Test both success and error paths
test('submit form with valid data', async ({ page }) => {
  await page.goto('/contact');
  await page.getByLabel('Email').fill('valid@example.com');
  await page.getByLabel('Message').fill('Hello');
  await page.getByRole('button', { name: 'Send' }).click();
  await expect(page.getByText('Message sent')).toBeVisible();
});

test('show validation error for invalid email', async ({ page }) => {
  await page.goto('/contact');
  await page.getByLabel('Email').fill('not-an-email');
  await page.getByLabel('Message').fill('Hello');
  await page.getByRole('button', { name: 'Send' }).click();
  await expect(page.getByText('Please enter a valid email')).toBeVisible();
});

test('show error on server failure', async ({ page }) => {
  await page.route('**/api/contact', (route) =>
    route.fulfill({ status: 500 })
  );
  await page.goto('/contact');
  await page.getByLabel('Email').fill('valid@example.com');
  await page.getByLabel('Message').fill('Hello');
  await page.getByRole('button', { name: 'Send' }).click();
  await expect(page.getByText(/something went wrong/i)).toBeVisible();
});

test('show empty state when no messages', async ({ page }) => {
  await page.goto('/messages');
  await expect(page.getByText('No messages yet')).toBeVisible();
});
```

### Prevention Strategy

- For every success test, write at least one failure test.
- Test validation errors, server errors (500), network errors, and empty states.
- Use `page.route()` to simulate server failures.
- Include error path coverage in code review checklists.

## Environment Coupling

Tests that only work on specific machines, operating systems, or network configurations. These tests pass locally but fail in CI, or vice versa.

### Why It Is Bad

- Tests cannot be run reliably across different environments.
- New team members cannot run tests without environment-specific setup.
- CI/CD failures are hard to reproduce locally.
- Environment-specific workarounds accumulate over time.

**Detect:** Hardcoded `localhost` URLs or specific port numbers in test files (not in config). File system paths using backslashes or absolute paths. Environment-specific commands (`open`, `pbcopy`) in test helpers. Tests that skip with `test.skip` based on `process.platform`.

```typescript
// Bad: Hardcoded environment-specific values
test('load homepage', async ({ page }) => {
  await page.goto('http://localhost:3000'); // Hardcoded URL
  const data = JSON.parse(
    fs.readFileSync('/Users/dev/project/fixtures/data.json', 'utf8') // Absolute path
  );
  expect(data).toBeTruthy();
});

// Bad: Platform-specific skip
test('copy to clipboard', async ({ page }) => {
  test.skip(process.platform !== 'darwin', 'macOS only');
  // ...
});

// Good: Use configuration and relative paths
test('load homepage', async ({ page, baseURL }) => {
  await page.goto('/'); // Uses baseURL from config
  const data = JSON.parse(
    fs.readFileSync(path.join(__dirname, 'fixtures', 'data.json'), 'utf8')
  );
  expect(data).toBeTruthy();
});

// Good: Platform-independent clipboard test
test('copy to clipboard', async ({ page }) => {
  await page.getByRole('button', { name: 'Copy' }).click();

  // Read clipboard via the browser API, works on all platforms
  const clipboardText = await page.evaluate(() => navigator.clipboard.readText());
  expect(clipboardText).toBe('Expected text');
});
```

### Prevention Strategy

- Use `baseURL` from Playwright config instead of hardcoded URLs.
- Use `path.join()` and `__dirname` for file paths.
- Configure `webServer` in `playwright.config.ts` to auto-start the server.
- Test in Docker containers to ensure environment independence.
- Run tests in CI on every PR to catch environment coupling early.

## Auto-Detection Summary

```
Detect: Module-level `let`/`var` shared across `test()` blocks
  --> Flag test interdependency; suggest isolated test data via fixtures.

Detect: `page.waitForTimeout()` or `setTimeout` in test files
  --> Flag hardcoded wait; suggest auto-retrying assertion or waitForResponse.

Detect: `toHaveScreenshot()` or `toMatchSnapshot()` as sole assertion
  --> Flag screenshot dependency; suggest adding DOM-based assertions.

Detect: `.locator('.')` with CSS class, XPath, or `nth-child` in test files
  --> Flag fragile selector; suggest getByRole, getByLabel, or getByTestId.

Detect: `let`/`var` at module scope or `beforeAll` creating data without `afterAll` cleanup
  --> Flag shared mutable state; suggest fixture with teardown.

Detect: More than 3 `page.route()` mocks in a single test
  --> Flag over-mocking; suggest using real backend with test database.

Detect: Comment containing "flaky", "intermittent", or "sometimes" in test files
  --> Flag flaky test; suggest root cause investigation.

Detect: `request.post()` or data creation without `afterEach`/fixture cleanup
  --> Flag test data pollution; suggest fixture with teardown.

Detect: Single `test()` block with more than 15 user interactions
  --> Flag mega test; suggest splitting into focused tests.

Detect: Test file with >3 tests and zero error/failure assertions
  --> Flag missing error paths; suggest adding validation and error tests.

Detect: Hardcoded `localhost` URL or absolute file path in test files
  --> Flag environment coupling; suggest config-based baseURL and relative paths.
```

## Quick Reference

| Anti-Pattern | Severity | Detection Signal | Fix |
|---|---|---|---|
| Test Interdependencies | Critical | Shared `let`/`var` across tests | Isolated fixtures per test |
| Hardcoded Waits | High | `waitForTimeout`, `setTimeout` | Auto-retrying assertions |
| Screenshot Verification | Medium | `toHaveScreenshot` as sole assertion | DOM assertions + optional screenshot |
| Fragile Selectors | High | CSS class, XPath, `nth-child` | `getByRole` > `getByLabel` > `getByTestId` |
| Shared Mutable State | Critical | Module-level variables, shared DB rows | Fixture with setup/teardown |
| Over-Mocking in E2E | High | >3 `page.route()` mocks per test | Real backend, mock only third-party |
| Flaky Test Syndrome | Critical | "flaky" comments, retry workarounds | Root cause investigation |
| Test Data Pollution | Medium | Create without cleanup | Fixtures with teardown, unique IDs |
| Mega Tests | Medium | >15 actions in single test | Split into focused tests (5-10 actions) |
| Missing Error Paths | High | No error assertions in test file | Error test for every success test |
| Environment Coupling | High | Hardcoded URLs, absolute paths | Config-based baseURL, relative paths |
