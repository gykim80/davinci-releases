# Web Prototype Checklist

Run before emitting the artifact. P0 = must pass; P1 = should pass; P2 = nice to have.

## P0 -- must pass

- [ ] **No raw color values outside `:root` token block.** Every color is `var(--bg)` / `var(--fg)` / `var(--muted)` / `var(--border)` / `var(--accent)` / `var(--surface)` or a `color-mix()` of those. No hex/rgb/hsl/oklch literals outside `:root`.
- [ ] **No purple/violet gradient backgrounds.** No `linear-gradient(... purple / violet ...)` on backgrounds. The seed has no gradients on backgrounds -- keep it that way.
- [ ] **No emoji used as feature icons.** Use inline SVG monoline marks from Layout 3, or a single-character glyph in `--font-mono`.
- [ ] **No invented metrics.** Every number came from the user/brief or is clearly labelled `[REPLACE]`. "10x faster", "99.9% uptime" without source = remove.
- [ ] **No filler copy.** Zero "Feature One / Feature Two", lorem ipsum. If a section feels empty, delete it.
- [ ] **`data-screen-label` on every top-level `<section>`.** Required for davinci-gui comment mode targeting.
- [ ] **TWEAK_DEFAULTS block present.** `/*EDITMODE-BEGIN*/` and `/*EDITMODE-END*/` markers wrap the tweaks object.
- [ ] **Font banned list respected.** No Inter, Roboto, Arial, Fraunces, or bare system-ui/sans-serif as primary display font.
- [ ] **Mobile reflow works.** All grid classes collapse to 1 column at <=920px via the seed media query. No horizontal scroll.

## P1 -- should pass

- [ ] **Accent appears at most twice per screen.** Eyebrow + primary CTA already use it. Budget any third usage carefully.
- [ ] **File under 1000 lines.** If over, split into per-page files.
- [ ] **Heading hierarchy intact.** h1 -> h2 -> h3, no skips.
- [ ] **Body text contrast >= 4.5:1.** oklch lightness difference between `--fg` and `--bg` must be sufficient.
- [ ] **Section rhythm alternates.** No two stat rows, feature triplets, or quote blocks in a row.
- [ ] **Headlines under 14 words.** If longer, the writing is doing the design's job.
- [ ] **CTA buttons say what happens.** "Start free" beats "Get Started". "Read the story" beats "Learn More".
- [ ] **Numerics use `.num` class.** Prices, stats, version numbers, dates.

## P2 -- nice to have

- [ ] **Dark mode toggle** via TWEAK_DEFAULTS `dark` key, swapping `:root` variables.
- [ ] **Print stylesheet** (`@media print`) hiding nav, footer, reducing padding.
- [ ] **`text-wrap: pretty / balance`** already in seed on `<p>` and `h*`.
- [ ] **Sticky topnav has frosted glass** (already in seed via `backdrop-filter: blur()`).
