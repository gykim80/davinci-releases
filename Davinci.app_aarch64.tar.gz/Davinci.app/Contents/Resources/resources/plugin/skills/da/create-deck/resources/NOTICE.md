<!--
Source: op7418/guizang-ppt-skill (Apache-2.0)
Original: https://github.com/op7418/guizang-ppt-skill
Copyright (c) op7418. Licensed under Apache-2.0.
Modifications: Adapted for davinci-framework — Korean comments + PPTX Iron Law conflict notes.
-->

# NOTICE — Third-Party Attribution

## Apache-2.0 License Preservation

This resource bundle is derived from **op7418/guizang-ppt-skill**, released under the Apache License, Version 2.0.

- **Original repository**: https://github.com/op7418/guizang-ppt-skill
- **Copyright holder**: op7418
- **License**: Apache-2.0 (full text in `LICENSE-APACHE-2.0` in this directory)
- **Original license file**: https://github.com/op7418/guizang-ppt-skill/blob/main/LICENSE

The Apache-2.0 license text is preserved verbatim in `LICENSE-APACHE-2.0`.

---

## Files Derived from op7418/guizang-ppt-skill

| 파일 (File) | 원본 경로 (Original Path) | 변경 내역 (Modifications) |
|---|---|---|
| `themes.md` | `references/themes.md` | 한국어 번역 병기 추가; HEX 값 명시; davinci 5-lock 정책 메모 |
| `layouts.md` | `references/layouts.md` | 한국어 주석 추가; PPTX Iron Law 충돌 항목 명시 (`gradient`, `svg`, `canvas` 금지) |
| `components.md` | `references/components.md` | 한국어 설명 추가; PPTX export 호환성 메모 추가 |
| `checklist.md` | `references/checklist.md` | P0/P1/P2/P3 원문 보존; davinci PPTX Iron Law 충돌 섹션 추가 (P0 항목으로 삽입) |
| `template.html` | `assets/template.html` | PPTX export 경고 주석 추가; WebGL hero PPTX 우회 메모 추가 |

---

## Modifications Log (davinci-framework Integration)

### 1. 한국어 주석 및 설명 추가
- 모든 파일에 한국어 번역 및 설명 추가 (한국어 사용자 대상)
- 원문(중국어/영어) 보존 후 한국어 병기

### 2. davinci PPTX Iron Law 충돌 항목 표기

원본 guizang-ppt-skill은 단일 HTML 수평 스와이프 출력을 위해 설계되었습니다.
davinci-framework는 PPTX export(pptxgenjs)를 지원하므로 다음 Iron Law 충돌 항목을 명시합니다:

**Iron Law 위반 — guizang 원본에서 PPTX export 불가 요소:**
- `linear-gradient()`, `radial-gradient()` — PPTX export 금지 (Iron Law #4)
- `<svg>`, `<canvas>` 요소 — PPTX export 금지 (Iron Law #6)
- WebGL hero (`<canvas id="bg-dark/light">`) — PPTX export 정적 이미지로 우회 필수 (Iron Law #6)
- `transform: skew()`, `scale()` — PPTX export 금지 (Iron Law #5)
- CSS `background-image` — PPTX export 금지, `<img>` 태그 사용 필수

**PPTX 호환 우회 방법 (Wave 3 캡처 자동화 예정):**
- WebGL hero → 정적 스크린샷 이미지로 대체
- gradient 배경 → solid color 대체
- SVG 아이콘 → `<img>` 태그로 래스터화

### 3. 5-lock 테마 정책
- 원본: 자유 HEX 커스텀 불가 (5개 선택만 허용)
- davinci: 동일 정책 유지 + Iron Law #15 (Theme/Layout Determinism)

### 4. Attribution 헤더
- 각 인용 파일 상단에 5-line attribution HTML comment 추가 (Apache-2.0 요건)

---

## Original NOTICE (if any)

The original repository does not include a separate NOTICE file.
This NOTICE.md serves as the combined attribution record for this derivative bundle.

---

*Generated: 2026-05-01 | davinci-framework Track B — Resource Bundle*
