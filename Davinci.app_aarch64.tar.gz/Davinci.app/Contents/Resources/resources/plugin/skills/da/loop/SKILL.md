---
name: da:loop
description: "Iterative completion system v2 — Evidence-gated loop. Repeatedly re-executes a prompt via Stop hook until a completion_check command passes, progress stalls, or max_iterations is reached. No self-reported completion."
agent: cto-lead
agents: [davinci-iterator]
davinci-phase: any
allowed-tools: [Read, Write, Edit, Bash, Grep, Glob, Task, WebSearch, WebFetch]
next-skill: null
skill-type: utility
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 오케스트레이터: §4 그래프 ready-set 디스패치, §6 노드 단위 checkpoint, §7 interrupt 표 외 질문 금지.

# /da:loop v2 — Evidence-Gated Iteration

Stop hook(`on_stop.py` Loop Guard)이 세션 종료를 가로채 같은 프롬프트를 재주입하는 반복 시스템.
v1의 `<promise>` 자기보고 완료를 폐기하고, **환경에서 얻은 근거**로만 종료한다(da:protocol §5.4).
da:improve(구조화된 PDCA)와 달리 자유 형식 반복이며, da:super(7-Lens 메타 사이클)의 하위 도구로도 쓰인다.

## Usage
```
/da:loop <prompt>                                    # 기본: max 10회, completion_check 없음(stall/max로만 종료)
/da:loop --check "npm test" <prompt>                 # npm test exit 0 이면 완료
/da:loop --check "npx tsc --noEmit && npm test" --max 20 <prompt>
/da:loop --evaluator <prompt>                        # 매 반복 끝에 독립 evaluator(Task, haiku)가 MET/NOT_MET 판정
/da:loop status | cancel
```

> `--check` 명령은 Stop hook 안에서 실행된다. 180초 상한(`LOOP_CHECK_TIMEOUT_SEC`)을 넘기면 실패(exit 1)로 간주되므로 빠른 검증 명령(단위 테스트 서브셋·타입체크 등)을 지정한다.

## Step 0: 상태 파일 생성 (첫 호출 시 필수 — 이 파일이 없으면 Stop hook은 개입하지 않는다)
```bash
mkdir -p docs && cat > docs/.davinci-loop.json <<'EOF'
{"protocol_version": 1, "status": "running", "prompt": "<원본 프롬프트>",
 "iteration": 0, "max_iterations": 10,
 "completion_check": "<--check 값 또는 null>", "evaluator": false,
 "stall_count": 0, "last_progress_hash": null, "history": []}
EOF
```
- `--max N` → max_iterations. `--check CMD` → completion_check(셸 명령, exit 0 = 완료). `--evaluator` → evaluator=true.
- 이미 `status: running` 파일이 있으면 새로 만들지 말고 `/da:loop status`로 안내 후 종료.

## Step 1: 반복 본문 (매 iteration)
1. `docs/.davinci-loop.json` Read → `iteration`, `history[-1].reason`(직전 실패 사유) 확인.
2. 직전 사유가 있으면 **다른 접근**을 먼저 1줄로 정한다(같은 시도 반복 금지, §5.1).
3. 프롬프트 수행. 작업 단위마다 파일 저장.
4. 근거 수집: `completion_check`가 있으면 Bash로 실행하고 exit code·요약을 기록. 없으면 변경 파일 목록(`git diff --stat`)을 기록.
5. `--evaluator`이면 `Task(model="haiku", prompt="프롬프트 목표 + 아래 evidence만 보고 MET/NOT_MET/BLOCKED/IMPOSSIBLE + reason 1줄로 판정")` 호출.
6. history에 append(Bash): `{"iteration": N, "check_exit": 0|1|null, "verdict": "...", "reason": "...", "diff_stat_hash": "<sha1>"}`.
7. 응답 마지막에 handoff JSON(§2.2) 반환 후 **텍스트 없이 종료** → Stop hook이 종료 판정(Step 2).

## Step 2: 종료 판정 (Stop hook `_check_loop_guard`가 수행 — 모델이 결정하지 않는다)
우선순위: ① `completion_check` exit 0 → `completed` ② `history[-1].verdict in {BLOCKED, IMPOSSIBLE}` → `stopped`(사유 기록)
③ `progress hash`(HEAD + git diff --stat) 2회 연속 동일 → `stopped: no_progress` ④ `iteration >= max_iterations` → `stopped: max_iterations`
⑤ 사용자 정지 신호(그만해/stop) → `stopped: user` ⑥ 그 외 → iteration+1 후 프롬프트 재주입(직전 reason 포함).

- `<promise>` 태그는 completion_check가 **null이고 evaluator가 false일 때만** 보조 신호로 인정된다. 이때 history 마지막 항목에 `"promise_claimed": true`와 `"evidence": [...]`(1개 이상)를 함께 기록해야 hook이 인정한다.
- Claude Code는 Stop hook 연속 block을 제한한다. 반복 횟수의 진실은 항상 상태 파일이다.

## Special Commands
- `/da:loop status` — iteration/max, 마지막 verdict·reason, stall_count 1줄 출력.
- `/da:loop cancel` — `status: "stopped"`, `stop_reason: "user"` 기록. 파일은 삭제하지 않는다(재개 참조용).

## Iron Law
**근거 없는 완료 선언 금지. 진척 없는 반복 2회면 멈춘다. 종료 판정은 모델이 아니라 상태 파일과 hook이 한다.**

ARGUMENTS: $ARGUMENTS
