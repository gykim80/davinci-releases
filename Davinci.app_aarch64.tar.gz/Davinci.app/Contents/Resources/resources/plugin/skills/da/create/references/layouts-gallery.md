# Multi-Device Gallery Layouts

Paste-ready HTML snippets for composing device frames into gallery layouts.
Use these in `da:create` artifacts when showcasing multi-device or multi-screen designs.

---

## 3-Device Gallery (iPhone + iPad + MacBook)

```html
<section data-screen-label="Device Gallery" style="
  display: flex;
  align-items: flex-end;
  justify-content: center;
  gap: 48px;
  padding: 64px 32px;
  background: #f5f5f0;
  min-height: 100vh;
">
  <!-- iPhone -->
  <iframe
    src="assets/frames/iphone-15-pro.html?screen=screens/mobile-home.html"
    width="390" height="844"
    style="border:0; flex-shrink:0; transform:scale(0.55); transform-origin:bottom center;"
    loading="lazy"
  ></iframe>

  <!-- iPad -->
  <iframe
    src="assets/frames/ipad-pro.html?screen=screens/tablet-home.html"
    width="584" height="836"
    style="border:0; flex-shrink:0; transform:scale(0.65); transform-origin:bottom center;"
    loading="lazy"
  ></iframe>

  <!-- MacBook -->
  <iframe
    src="assets/frames/macbook.html?screen=screens/desktop-home.html"
    width="880" height="560"
    style="border:0; flex-shrink:0; transform:scale(0.7); transform-origin:bottom center;"
    loading="lazy"
  ></iframe>
</section>
```

---

## 2-Device Comparison (iPhone + Android)

```html
<section data-screen-label="Platform Comparison" style="
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 64px;
  padding: 64px 32px;
  background: #1a1a1a;
  min-height: 100vh;
">
  <!-- iPhone 15 Pro -->
  <div style="text-align:center;">
    <iframe
      src="assets/frames/iphone-15-pro.html?screen=screens/ios-home.html"
      width="390" height="844"
      style="border:0; transform:scale(0.7); transform-origin:top center;"
      loading="lazy"
    ></iframe>
    <p style="color:#888; font-size:14px; margin-top:-40px;">iOS</p>
  </div>

  <!-- Pixel 8 Pro -->
  <div style="text-align:center;">
    <iframe
      src="assets/frames/android-pixel.html?screen=screens/android-home.html"
      width="412" height="900"
      style="border:0; transform:scale(0.7); transform-origin:top center;"
      loading="lazy"
    ></iframe>
    <p style="color:#888; font-size:14px; margin-top:-40px;">Android</p>
  </div>
</section>
```

---

## Single Device Hero Shot

```html
<section data-screen-label="Hero Device" style="
  display: grid;
  place-items: center;
  padding: 80px 32px;
  background: linear-gradient(to bottom, #0a0a0a, #1a1a1c);
  min-height: 100vh;
">
  <iframe
    src="assets/frames/iphone-15-pro.html?screen=screens/hero.html"
    width="390" height="844"
    style="border:0;"
    loading="lazy"
  ></iframe>
</section>
```

---

## Notes

- Adjust `transform: scale()` to fit frames within the available viewport.
- `transform-origin: bottom center` aligns devices at a shared baseline.
- Each `?screen=` path is relative to the artifact HTML file location.
- For browser mockups, add `&url=app.example.com` for realistic URL bar text.
