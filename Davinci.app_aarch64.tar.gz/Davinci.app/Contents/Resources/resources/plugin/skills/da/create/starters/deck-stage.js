/**
 * deck-stage.js - Slide Deck Web Component
 *
 * A custom element <deck-stage> that provides:
 * - Aspect-ratio scaling (default 16:9 at 1920x1080)
 * - Keyboard navigation (ArrowLeft/Right, Space)
 * - localStorage position persistence
 * - Print-to-PDF support (@media print)
 * - Speaker notes via postMessage to opener window
 *
 * Usage: <deck-stage> <section>Slide 1</section> <section>Slide 2</section> </deck-stage>
 */

class DeckStage extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: "open" });
    this._current = 0;
    this._storageKey = "deck-stage-slide";
  }

  connectedCallback() {
    const saved = localStorage.getItem(this._storageKey);
    if (saved) this._current = parseInt(saved, 10) || 0;

    this.shadowRoot.innerHTML = `
      <style>
        :host { display: block; width: 100vw; height: 100vh; overflow: hidden; background: #000; }
        .viewport {
          width: 1920px; height: 1080px;
          transform-origin: top left;
          position: relative;
        }
        ::slotted(section) {
          width: 1920px; height: 1080px;
          position: absolute; top: 0; left: 0;
          opacity: 0; pointer-events: none;
          transition: opacity 0.4s ease;
          display: grid; place-items: center;
          padding: 80px;
          box-sizing: border-box;
        }
        ::slotted(section.active) { opacity: 1; pointer-events: auto; }
        .controls {
          position: fixed; bottom: 20px; right: 20px; z-index: 100;
          display: flex; gap: 8px; align-items: center;
          font-family: system-ui; color: #888; font-size: 14px;
        }
        .controls button {
          background: rgba(255,255,255,0.1); border: none; color: #ccc;
          padding: 6px 14px; border-radius: 6px; cursor: pointer; font-size: 14px;
        }
        .controls button:hover { background: rgba(255,255,255,0.2); }
        @media print {
          :host { width: auto; height: auto; overflow: visible; }
          .viewport { transform: none !important; }
          ::slotted(section) { opacity: 1; position: relative; page-break-after: always; }
          .controls { display: none; }
        }
      </style>
      <div class="viewport"><slot></slot></div>
      <div class="controls">
        <button class="prev">Prev</button>
        <span class="indicator">1 / 1</span>
        <button class="next">Next</button>
      </div>
    `;

    this._viewport = this.shadowRoot.querySelector(".viewport");
    this._indicator = this.shadowRoot.querySelector(".indicator");
    this._resize();
    this._update();

    window.addEventListener("resize", () => this._resize());
    window.addEventListener("keydown", (e) => this._onKey(e));
    this.shadowRoot.querySelector(".prev").addEventListener("click", () => this.prev());
    this.shadowRoot.querySelector(".next").addEventListener("click", () => this.next());
  }

  get slides() { return [...this.querySelectorAll("section")]; }
  get total() { return this.slides.length; }

  _resize() {
    const scale = Math.min(window.innerWidth / 1920, window.innerHeight / 1080);
    this._viewport.style.transform = `scale(${scale})`;
  }

  _update() {
    this.slides.forEach((s, i) => s.classList.toggle("active", i === this._current));
    this._indicator.textContent = `${this._current + 1} / ${this.total}`;
    localStorage.setItem(this._storageKey, this._current);
    // Speaker notes postMessage
    if (window.opener) {
      const notes = this.slides[this._current]?.dataset.notes || "";
      window.opener.postMessage({ type: "speaker-notes", slide: this._current, notes }, "*");
    }
  }

  next() { if (this._current < this.total - 1) { this._current++; this._update(); } }
  prev() { if (this._current > 0) { this._current--; this._update(); } }
  goTo(n) { this._current = Math.max(0, Math.min(n, this.total - 1)); this._update(); }

  _onKey(e) {
    if (e.key === "ArrowRight" || e.key === " ") { e.preventDefault(); this.next(); }
    if (e.key === "ArrowLeft") { e.preventDefault(); this.prev(); }
    if (e.key === "Home") { e.preventDefault(); this.goTo(0); }
    if (e.key === "End") { e.preventDefault(); this.goTo(this.total - 1); }
  }
}

customElements.define("deck-stage", DeckStage);
