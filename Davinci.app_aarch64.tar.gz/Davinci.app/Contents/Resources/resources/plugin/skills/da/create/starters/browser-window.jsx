/**
 * browser-window.jsx - Browser Window Chrome
 *
 * Provides: BrowserWindow with tab bar, address bar, navigation buttons.
 */

function BrowserWindow({ url = "https://example.com", title = "Example", width = 1024, height = 640, dark = false, children }) {
  const bgChrome = dark ? "#202124" : "#dee1e6";
  const bgTab = dark ? "#35363a" : "#fff";
  const bgAddress = dark ? "#35363a" : "#fff";
  const bgContent = dark ? "#1e1e1e" : "#fff";
  const textColor = dark ? "#e8eaed" : "#202124";
  const mutedColor = dark ? "#9aa0a6" : "#5f6368";

  const windowStyles = {
    width,
    maxWidth: "100%",
    borderRadius: 10,
    overflow: "hidden",
    boxShadow: "0 20px 60px rgba(0,0,0,0.2)",
    margin: "0 auto",
  };

  const chromeStyles = {
    background: bgChrome,
    padding: "8px 8px 0",
  };

  const tabBarStyles = {
    display: "flex",
    gap: 0,
    alignItems: "flex-end",
    height: 34,
  };

  const activeTabStyles = {
    background: bgTab,
    padding: "6px 16px",
    borderRadius: "8px 8px 0 0",
    fontSize: 12,
    color: textColor,
    fontFamily: "system-ui, sans-serif",
    maxWidth: 200,
    overflow: "hidden",
    textOverflow: "ellipsis",
    whiteSpace: "nowrap",
    display: "flex",
    alignItems: "center",
    gap: 8,
  };

  const addressBarStyles = {
    background: bgTab,
    padding: "0 8px",
    display: "flex",
    alignItems: "center",
    gap: 8,
    height: 36,
  };

  const urlBarStyles = {
    flex: 1,
    background: bgAddress,
    border: dark ? "1px solid #5f6368" : "1px solid #dfe1e5",
    borderRadius: 18,
    padding: "4px 14px",
    fontSize: 13,
    color: mutedColor,
    fontFamily: "system-ui, sans-serif",
  };

  const navBtnStyles = {
    background: "none",
    border: "none",
    color: mutedColor,
    fontSize: 18,
    cursor: "pointer",
    padding: "2px 6px",
    lineHeight: 1,
  };

  return (
    <div style={windowStyles}>
      <div style={chromeStyles}>
        <div style={tabBarStyles}>
          <div style={activeTabStyles}>
            <span style={{ width: 14, height: 14, borderRadius: 2, background: mutedColor, opacity: 0.3, flexShrink: 0 }} />
            {title}
          </div>
        </div>
      </div>
      <div style={addressBarStyles}>
        <button style={navBtnStyles}>&#8592;</button>
        <button style={navBtnStyles}>&#8594;</button>
        <button style={navBtnStyles}>&#8635;</button>
        <div style={urlBarStyles}>{url}</div>
      </div>
      <div style={{ background: bgContent, height: height - 78, overflow: "auto" }}>
        {children}
      </div>
    </div>
  );
}

window.BrowserWindow = BrowserWindow;
