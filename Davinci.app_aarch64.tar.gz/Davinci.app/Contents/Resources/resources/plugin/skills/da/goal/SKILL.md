---
name: goal
description: Goal Composer — 거친 작업 설명을 Claude/Codex의 `/goal` 자율 모드용 "검증 가능한 종료 상태(verifiable end state)" 프롬프트로 변환한다. 장기 자율 실행이 빙빙 돌지 않고 실제로 끝나도록 만드는 게이트.
agent: senior-architect
davinci-phase: null
allowed-tools: [Read, Glob, Grep, AskUserQuestion]
triggers:
  - "goal 써줘"
  - "goal 프롬프트"
  - "자율 모드 목표"
  - "codex goal"
  - "claude goal"
  - "long-running goal"
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 오케스트레이터: §4 그래프 ready-set 디스패치, §6 노드 단위 checkpoint, §7 interrupt 표 외 질문 금지.

# /da:goal — Goal Composer

`/goal` 자율 모드(Claude Code / Codex CLI)는 **"검증 가능한 종료 상태"** 를 주면 그 지점까지
스스로 돌고, 평가 모델이 도달을 확인하면 멈춘다. 이 스킬은 사용자의 거친 한 줄을
**끝날 수 있는 goal**로 바꿔준다.

## Iron Law
**"무엇을 원하는가(end state)"를 쓴다. "어떻게 할지(steps)"를 받아쓰지 않는다.**
종료 상태가 측정 불가능하면 goal은 영원히 돌거나 랜덤하게 망가진다.

## 4-Component Contract
모든 goal은 아래 4개를 반드시 포함한다. 하나라도 비면 작성하지 않는다.

| # | 요소 | 정의 | 나쁜 예 → 좋은 예 |
|---|------|------|------------------|
| 1 | **Objective** | 달성할 결과(스텝 아님) | "코드 개선" → "Supabase를 Postgres+Drizzle로 마이그레이션" |
| 2 | **Stopping condition** | 측정 가능한 종료 상태 | "잘 되면" → "테스트 통과 + build exit 0 + any 타입 0개" |
| 3 | **Validation method** | 도달을 증명하는 방법 | (없음) → "Aside MCP(`dv.shot`/`dv.report`)로 화면 동일성·런타임 에러 0 확인" |
| 4 | **Constraints** | 바뀌면 안 되는 것 | (없음) → "기존 스키마/시드 데이터 보존, UI 시각적 변화 금지" |

추가 권장: **Turn/Time limit** ("또는 20턴 후 정지"), **명시한 파일/문서**(PLAN.md 등).

## 4-Phase Protocol

### Phase 1 — Intake
1. 사용자 입력에서 진짜 목표(WHY)와 대상 CLI를 파악한다.
2. 4-Component 중 빠진 것을 찾는다. **종료 상태가 모호하면 추정하지 말고 `AskUserQuestion`으로 1회 확인.**
   - 특히 "done"의 정의: 어떤 명령/테스트/지표가 통과해야 끝인가?
3. 대상 CLI 미지정 시 작업 성격으로 추론:
   - 기획/설계/리서치 → **Claude** (세션 스코프, 턴마다 평가 모델이 reason 반환)
   - 프론트엔드/UI 마이그레이션·리팩토링 → **Codex** (프로세스 재시작에도 survive, worktree 격리)
   - 백엔드/스키마/데이터 → **Gemini** (goal 모드 없음 → Phase 3-G 참고)

### Phase 2 — Compose
대상별 포맷으로 goal을 합성한다. 공통 골격:

```
/goal <Objective>.
Success: <측정 가능한 종료 상태, AND로 나열>.
Verify: <증명 방법 — 명령/테스트/스크린샷>.
Constraints: <바뀌면 안 되는 것>.
Stop after <N> turns if not done.
```

#### Claude Code 변형
- 평가자(checker)는 매 턴 종료 상태를 검사하므로 **종료 상태를 한 문장 측정값**으로.
- 비용 제어: 평가자 모델 Haiku 권장 멘트 부가.
- 예:
  > `/goal Refactor this repo to TypeScript strict mode. Success: zero "any" types, all tests pass, build exit 0. Verify: run \`npm test && tsc --noEmit\`. Constraints: no public API signature changes. Stop after 25 turns.`

#### Codex CLI 변형
- 장기 실행 → **worktree 격리** + `--approval-mode` 명시.
- 검증면은 live mutation보다 **dry-run** 선호.
- 진행 보고 요청 문구 부가("compact update: checkpoint / verified / remaining / blockers").
- 예:
  > `/goal Migrate this app from Supabase to Postgres + Drizzle. Success: schema parity, all queries working, seed data preserved, tests pass. Verify: \`npm run test\` + drizzle dry-run migration. Constraints: keep UI visually identical. Run in worktree, approval-mode on-shell. Stop after 40 turns. Report compact status each checkpoint.`

### Phase 3 — Self-Audit (출력 전 필수)
아래 체크리스트를 통과하지 못하면 Phase 2로 되돌아간다.
- [ ] 종료 상태가 **이진 판정 가능**한가? (통과/실패가 명확한 명령·지표인가)
- [ ] Objective가 "스텝"이 아니라 "결과"인가?
- [ ] 검증 방법이 실제 실행 가능한 명령/도구인가?
- [ ] 제약(바뀌면 안 되는 것)이 1개 이상 명시됐는가?
- [ ] 턴/시간 한도가 있는가? (무한 루프 방지)

#### Phase 3-G — Gemini(백엔드) 대상일 때
Gemini CLI에는 `/goal` 자율 모드가 없다. 대신 동일 4-Component를
**작업 지시문 + 완료 정의(DoD)** 형태로 변환하고, 검증은 Davinci `da:verify`로 위임하도록 안내한다.

### Phase 4 — Emit
1. 최종 goal 명령을 **복사 가능한 코드블록**으로 출력.
2. 바로 아래 3줄 요약:
   - **End state**: (한 문장)
   - **Verify**: (명령)
   - **Risk**: (무한루프/비용/파괴적 변경 중 해당 항목)
3. 멀티-CLI 작업이면 CLI별 goal을 분리 출력하고 Davinci handoff 순서를 한 줄로 제안.

## Anti-Patterns (즉시 거부)
- "make it better" / "코드 정리해줘" 류 — 종료 상태 없음 → AskUserQuestion으로 측정값 요구.
- 서로 무관한 작업의 나열(체크리스트) — goal 1개당 결과 1개 원칙.
- 스텝 받아쓰기("먼저 X하고 그다음 Y") — 결과로 재서술.
- 한도 없는 unattended 실행 — turn/time limit 강제 삽입.

## Output Handoff (선택)
GUI/파이프라인 호출 시 마지막 줄에 JSON:
```json
{ "skill": "da:goal", "status": "completed", "target_cli": "codex",
  "end_state": "...", "verify_cmd": "...", "has_limit": true }
```
