# Design System: CrossToken (NEXUS)

## 1. Visual Theme & Atmosphere

CrossToken NEXUS is a blockchain analytics cockpit built for radical data clarity on a dark canvas. The design philosophy treats every pixel as signal — numbers are kings, charts are context, labels are servants. A near-black blue-tinted background (`#0A0B0F`) provides the foundational surface, while neon violet-to-cyan gradients (`#7C3AED` to `#06B6D4`) pulse through KPI cards, chart fills, and live indicators to signal real-time data urgency.

The typographic system employs extreme scale contrast: Bebas Neue at 96px for hero KPI numbers creates billboard-scale data impact, while Inter handles all body and label text with quiet efficiency. JetBrains Mono renders wallet addresses and transaction hashes in the truncated `first6...last4` pattern native to blockchain UIs. The three-font stack — display condensed, humanist sans, developer mono — mirrors the three audiences: executives scanning KPIs, analysts reading charts, and developers inspecting on-chain data.

A five-color semantic glow system (violet, cyan, green, amber, red) maps directly to data states: brand identity, real-time activity, healthy trends, whale alerts, and critical warnings. Glow effects (`box-shadow: 0 0 Xpx rgba(...)`) replace traditional elevation shadows, giving the interface a bioluminescent quality where interactive and live elements literally radiate from the dark surface.

**Key Characteristics:**
- Dark-only interface — `#0A0B0F` background, no light mode
- Bebas Neue display font at extreme scale (64–96px) for KPI numbers
- Violet-cyan brand gradient (`135deg, #7C3AED → #2563EB → #06B6D4`)
- Five-color semantic glow system replacing traditional shadows
- JetBrains Mono for all blockchain addresses and hashes (truncated)
- 3px colored left-border on KPI cards encoding positive/negative trend
- Pulsing cyan dot (`animate-pulse`) for all live/real-time indicators
- `tabular-nums` font variant on all numeric table columns

## 2. Color Palette & Roles

### Base (Dark Theme)
- **Background** (`#0A0B0F`): Page base — near-black with subtle blue tint
- **Surface** (`#111318`): Card and panel backgrounds
- **Surface Elevated** (`#181B22`): Modals, dropdowns, tooltips
- **Foreground** (`#E8EAF0`): Primary text color
- **Muted Foreground** (`#6B7280`): Labels, secondary text, chart axis ticks

### Brand & Accent
- **Primary Violet** (`#7C3AED`): CROSS brand identity, gradient start, chart series 1
- **Secondary Blue** (`#2563EB`): Data blue, gradient midpoint
- **Accent Cyan** (`#06B6D4`): Real-time indicators, live dots, gradient end

### Semantic
- **Success** (`#10B981`): Positive trend, healthy status, green glow
- **Warning** (`#F59E0B`): Whale alerts, caution badges, amber glow
- **Destructive** (`#EF4444`): Critical alerts, negative trend, red glow
- **Info** (`#3B82F6`): Neutral informational states

### Border
- **Border Default** (`#1E2330`): Subtle dividers, chart grid lines
- **Border Strong** (`#2A3044`): Active separators, hover borders

### Chart Series
- Series 1: `#7C3AED` | Series 2: `#06B6D4` | Series 3: `#10B981` | Series 4: `#F59E0B`
- Series 5: `#EF4444` | Series 6: `#8B5CF6` | Series 7: `#EC4899` | Series 8: `#14B8A6`

### Gradient System
- **Primary Gradient**: `linear-gradient(135deg, #7C3AED 0%, #2563EB 50%, #06B6D4 100%)` — brand identity, hero backgrounds
- **Accent Gradient**: `linear-gradient(135deg, #F59E0B 0%, #EF4444 100%)` — alert emphasis
- **Background Glow**: `radial-gradient(ellipse at top, rgba(124,58,237,0.15) 0%, transparent 70%)` — subtle page-level atmosphere

## 3. Typography Rules

### Font Families
- **Display**: `Bebas Neue` — KPI numbers, hero stats, page headers (weight 400)
- **Body / UI**: `Inter` — All body text, labels, descriptions (weights 400–700)
- **Mono**: `JetBrains Mono` — Wallet addresses, tx hashes, table numbers (weights 400–500)

### Hierarchy

| Role | Font | Size | Weight | Line Height | Notes |
|------|------|------|--------|-------------|-------|
| Display Hero | Bebas Neue | 96px | 400 | 1.00 | Maximum KPI impact, tracking -0.02em |
| Display KPI | Bebas Neue | 64px | 400 | 1.00 | Standard KPI card value, tracking -0.01em |
| Heading XL | Inter | 36px | 700 | 1.20 | Page titles, tracking -0.025em |
| Heading L | Inter | 28px | 700 | 1.25 | Section headers, tracking -0.02em |
| Heading M | Inter | 22px | 600 | 1.30 | Sub-section titles |
| Body L | Inter | 16px | 400 | 1.60 | Standard reading text |
| Body M | Inter | 14px | 400 | 1.50 | Secondary descriptions |
| Caption | Inter | 11px | 500 | 1.40 | UPPERCASE, tracking 0.05em, muted labels |
| Mono | JetBrains Mono | 13px | 400 | 1.50 | Addresses, hashes, numeric tables |

### Principles
- KPI values use Bebas Neue at large scale; unit suffixes (K/M/B) render in Inter 500 at 60% of the value size
- Wallet addresses always truncated: `0xAbCd...Ef12` pattern in JetBrains Mono
- Chart axis labels: Inter 400 11px in Muted Foreground
- All numeric table columns use `font-variant-numeric: tabular-nums`
- Caption text is always UPPERCASE with wide tracking (0.05em)

## 4. Component Stylings

### KPI Card
- Layout: Icon + label (top) | Bebas Neue 64px KPI value (center) | trend badge (bottom)
- Background: Surface (`#111318`), border `1px solid #1E2330`
- Positive variant: `3px solid #10B981` left border
- Negative variant: `3px solid #EF4444` left border
- Live variant: pulsing cyan dot + `box-shadow: 0 0 12px rgba(6,182,212,0.3)`
- Hover: `translateY(-2px)`, shadow deepens, `border-color: #2A3044`
- Transition: `all 200ms ease-out`
- Maximum 4 KPI cards per row

### Sidebar Navigation
- Width: 240px expanded / 72px collapsed (icon-only)
- Background: Surface (`#111318`) with `backdrop-filter: blur(4px)`
- Active item: gradient pill background at 10% opacity + `2px solid` left accent border
- Hover: `background: rgba(255,255,255,0.04)`, `translateX(2px)`
- Icons: lucide-react 20px | Font: Inter 500 14px
- Group labels: Inter 500 11px UPPERCASE, `letter-spacing: 0.05em`, Muted Foreground
- Collapse transition: `width 240ms cubic-bezier(0.4,0,0.2,1)`

### Chart Panel
- Container: Surface background, `1px solid #1E2330`, `border-radius: 12px`, `padding: 24px`
- Header: Inter 600 16px title + shadcn Tabs for time periods (1H / 24H / 7D / 30D)
- Grid lines: `stroke: #1E2330`, `strokeDasharray: "3 3"`
- Axis: `stroke: transparent`, tick fill Muted Foreground 11px
- Tooltip: Surface Elevated background, border, `shadow: 0 8px 32px rgba(0,0,0,0.5)`
- Area fill: primary color at 30% opacity gradient to transparent
- Area stroke: 2px, `animationDuration: 300ms`

### Data Table
- Row height: 52px | Header: Inter 500 11px UPPERCASE muted, `border-bottom: 1px solid #1E2330`
- Row hover: `background: rgba(255,255,255,0.02)`, `border-bottom: 1px solid #1E2330`
- Rank column: Bebas Neue 20px muted
- Address column: JetBrains Mono 13px, truncated `first6...last4`
- Value columns: Inter 600 14px `tabular-nums`
- Sort indicators: ChevronUp/Down lucide icons, accent color when active

### Realtime Ticker
- Horizontal marquee scroll, pause on hover
- Item: address (mono) + amount (Inter 600) + game badge + time-ago label
- Live dot: 8px circle, `background: #06B6D4`, `animation: pulse 2s infinite`
- Whale item: warning background tint + bold amount + whale lucide icon

### Alert Badge
- Whale: `background: rgba(245,158,11,0.15)`, `border-color: #F59E0B`, text Warning
- Critical: `background: rgba(239,68,68,0.15)`, `border-color: #EF4444`, text Destructive
- Info: `background: rgba(59,130,246,0.15)`, `border-color: #3B82F6`, text Info
- Status dot: 6px circle in matching semantic color, pulse animation

### Buttons
- Primary: gradient background (violet-to-cyan), Foreground text, `border-radius: 9999px`
- Secondary: Surface background, `1px solid #1E2330`, Foreground text, `border-radius: 8px`
- Ghost: transparent background, Muted Foreground text, hover `rgba(255,255,255,0.04)`
- All buttons: Inter 500 14px, `padding: 8px 16px`, `transition: all 150ms ease-out`

## 5. Layout Principles

### Grid System
- Sidebar: 240px fixed left (collapses to 72px on tablet)
- Content area: `calc(100vw - 240px)`, padding 24px desktop / 16px tablet / 12px mobile
- Grid: 12-column CSS Grid, 16px gutters

### Spacing Scale
- Base: 8px
- Scale: 4px, 8px, 12px, 16px, 24px, 32px, 48px
- Card internal padding: 24px
- Section gaps: 16–24px between card rows

### Page Layout Templates

**Overview Dashboard**
- Row 1: KPI Cards x4 (3col each)
- Row 2: DAU Chart (8col) + Realtime Feed (4col)
- Row 3: Top Games Table (12col full-width)
- Row 4: Realtime Ticker marquee (12col)

**Analytics Pages (Users / Tokens / Ecosystem)**
- Row 1: Hero stat + time filter bar (full width)
- Row 2: Primary chart (full or 8col + 4col secondary)
- Row 3: Secondary charts 2x6col
- Row 4: Data table full width

**Games Pages**
- Ranking: filter + search | ranked table (rank/game/DAU/Tx/vol/sparkline)
- Detail: hero header + 4 KPIs + primary chart + tx feed table

### Border Radius Scale
- Small (6px): Badges, small inline elements
- Standard (8px): Secondary buttons, small cards
- Medium (12px): Chart panels, standard cards
- Large (16px): Featured containers
- Pill (9999px): Primary CTA buttons, tags

## 6. Depth & Elevation

### Elevation Scale

| Level | Shadow | Use |
|-------|--------|-----|
| Level 0 (base) | None | Page background `#0A0B0F` |
| Level 1 (surface) | `0 1px 3px rgba(0,0,0,0.3)` | Cards, panels |
| Level 2 (raised) | `0 4px 16px rgba(0,0,0,0.4)` | Hover/active cards |
| Level 3 (overlay) | `0 8px 32px rgba(0,0,0,0.5)` | Dropdowns, tooltips |
| Level 4 (modal) | `0 20px 60px rgba(0,0,0,0.6)` | Dialogs, modals |

### Glow Effects
- **Primary Glow**: `box-shadow: 0 0 20px rgba(124,58,237,0.25)` — brand violet halo
- **Accent Glow**: `box-shadow: 0 0 12px rgba(6,182,212,0.3)` — live/real-time cyan
- **Success Glow**: `box-shadow: 0 0 8px rgba(16,185,129,0.2)` — positive trend
- **Warning Glow**: `box-shadow: 0 0 8px rgba(245,158,11,0.3)` — whale alert
- **Critical Glow**: `box-shadow: 0 0 8px rgba(239,68,68,0.3)` — alert/danger

### Border System
- Default: `1px solid #1E2330` — subtle, near-invisible dividers
- Active: `1px solid #2A3044` — hover/active emphasis
- Focus ring: `0 0 0 2px rgba(124,58,237,0.5)` — violet focus indicator
- Gradient border: `::before` pseudo-element with brand gradient background

**Depth Philosophy**: Glow effects replace traditional drop shadows in this dark-first interface. Interactive and live elements literally radiate color from the dark canvas, creating a bioluminescent quality. The five semantic glow colors map 1:1 to the five semantic states, making elevation and status inseparable.

## 7. Do's and Don'ts

### Do
- Use dark backgrounds (`#0A0B0F`) for all major surfaces — dark-only, no exceptions
- Apply Bebas Neue exclusively for numeric KPI values at large scale (64px+)
- Show trend indicators (up/down arrow + percentage) alongside every KPI metric
- Use neon cyan (`#06B6D4`) sparingly for live/real-time indicators only
- Truncate wallet addresses: first 6 + ... + last 4 characters in JetBrains Mono
- Apply `tabular-nums` font variant on all numeric table columns
- Animate chart data updates with 300ms ease transitions
- Add loading skeleton states matching content shape exactly
- Include "Last updated: Xm ago" timestamps on all data panels
- Use gradient left-border (3px) to encode positive/negative KPI cards
- Abbreviate large values with K/M/B suffixes when exceeding 9,999

### Don't
- Never use white backgrounds or light mode elements
- Never show full wallet addresses — always truncate
- Never use more than 3 chart types per page
- Never animate background gradients continuously (GPU cost)
- Never use red for anything except critical alerts or negative trends
- Never stack more than 4 KPI cards in a single row
- Never use placeholder lorem ipsum — use blockchain-native copy
- Never use thin fonts (weight below 400) on dark backgrounds
- Never omit time period selector from time-series charts
- Never show raw CROSS values without K/M/B abbreviation when exceeding 9,999

## 8. Responsive Behavior

### Breakpoints

| Name | Width | Key Changes |
|------|-------|-------------|
| Mobile | < 768px | Sidebar hidden, bottom tab bar (5 routes), 2x2 KPI grid, Bebas 48px |
| Tablet | 768–1024px | Sidebar 72px icon-only, 2-column grid, 6 table columns max |
| Desktop | 1024–1440px | Sidebar 240px expanded, full 12-column grid |
| Wide | > 1440px | Sidebar 240px, content max-width 1400px centered |

### Mobile Adaptations
- Navigation: bottom tab bar with 5 routes (Overview / Users / Tokens / Games / Ecosystem)
- KPI cards: 2x2 compact grid, Bebas Neue 48px (reduced from 64px)
- Charts: full width, height 200px (reduced from 320px)
- Tables: horizontal scroll, sticky rank + name columns
- Ticker: pause on scroll, reduced animation speed

### Tablet Adaptations
- Sidebar: 72px icon-only with tooltip labels on hover
- Charts: full available width
- Tables: maximum 6 columns, hide low-priority columns
- KPIs: 2x2 or 4x1 depending on page density

## 9. Agent Prompt Guide

### Quick Color Reference
- Brand Violet: `#7C3AED`
- Accent Cyan: `#06B6D4`
- Background: `#0A0B0F`
- Surface: `#111318`
- Surface Elevated: `#181B22`
- Foreground: `#E8EAF0`
- Muted: `#6B7280`
- Border: `#1E2330`
- Success: `#10B981`
- Warning: `#F59E0B`
- Destructive: `#EF4444`

### Example Component Prompts
- "Create a KPI card on Surface (#111318) with 1px solid #1E2330 border. Label in Inter 500 11px UPPERCASE muted. Value in Bebas Neue 64px #E8EAF0. Add a TrendBadge with green arrow and +12.5% in #10B981. Left border 3px solid #10B981."
- "Build an area chart panel on Surface (#111318) with 12px radius. Title in Inter 600 16px. Add Tabs (1H/24H/7D/30D). CartesianGrid stroke #1E2330 dasharray 3 3. Area fill gradient from #7C3AED 30% to transparent. Stroke 2px #7C3AED."
- "Design a data table with 52px rows. Header: Inter 500 11px UPPERCASE #6B7280. Rank column: Bebas Neue 20px. Address: JetBrains Mono 13px truncated. Values: Inter 600 14px tabular-nums. Row hover: rgba(255,255,255,0.02)."
- "Create sidebar navigation 240px wide on #111318. Active item: gradient pill at 10% opacity + 2px left violet border. Group labels: 11px UPPERCASE tracking-widest #6B7280. Icons: lucide 20px."
- "Build a whale alert badge: background rgba(245,158,11,0.15), border #F59E0B, text #F59E0B. Add 6px pulsing dot. Include whale icon from lucide-react."

### Recharts Dark Theme Config
```tsx
<ResponsiveContainer width="100%" height={320}>
  <AreaChart data={data} margin={{top:8,right:16,left:0,bottom:0}}>
    <defs>
      <linearGradient id="grad" x1="0" y1="0" x2="0" y2="1">
        <stop offset="5%" stopColor="#7C3AED" stopOpacity={0.3}/>
        <stop offset="95%" stopColor="#7C3AED" stopOpacity={0}/>
      </linearGradient>
    </defs>
    <CartesianGrid strokeDasharray="3 3" stroke="#1E2330"/>
    <XAxis stroke="transparent" tick={{fill:'#6B7280',fontSize:11}}/>
    <YAxis stroke="transparent" tick={{fill:'#6B7280',fontSize:11}}/>
    <Tooltip contentStyle={{background:'#181B22',border:'1px solid #1E2330',
                            borderRadius:'8px',fontSize:13}}/>
    <Area type="monotone" dataKey="value" stroke="#7C3AED"
          fill="url(#grad)" strokeWidth={2} animationDuration={300}/>
  </AreaChart>
</ResponsiveContainer>
```

### lucide-react Icon Mapping
- Activity: DAU / live metrics | Users: wallet / user counts | Zap: TPS / speed
- TrendingUp/TrendingDown: positive/negative trend | AlertTriangle: whale alert
- BarChart3: volume / charts | Globe: ecosystem | Gamepad2: games section
- Radio: live / realtime | Wallet: address / balance | Clock: time ago
- Flame: hot / trending | Shield: security / bot filter
