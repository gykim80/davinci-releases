---
name: fix
description: "Surgical bug fix v4.0 — Adaptive Turbo Fix. Intent Expansion + Symptom Classifier + Blame-Driven Context + 3-Layer Verification. 10s~70s."
agent: bug-surgeon
agents: [senior-fullstack]
davinci-phase: act
allowed-tools: [Write, Edit, Read, Bash, Glob, Grep, Task]
next-skill: null
skill-type: flexible
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 생성자: 자기 검증은 사전 점검일 뿐이다. 최종 판정은 독립 verify 노드가 낸다. 미완료 시 partial + remaining.

# /da:fix v4.0 - Adaptive Turbo Fix

## Purpose
Adaptive-speed bug fixing with Intent Expansion, Symptom Classification, and 3-Track pipeline.
SIMPLE bugs in ~12s, MEDIUM in ~30s, COMPLEX in ~70s.
Self-contained skill -- no da:verify/da:improve chaining.

### Usage
```
/da:fix [target] [--description "error description"]
/da:fix --error "paste stack trace or error message here"
/da:fix (paste error message directly as argument)
/da:fix --no-cache (disable symbol map cache)
/da:fix --no-scan (disable post-fix pattern scan)
```

## Iron Laws

1. **NO FIX WITHOUT BLAST RADIUS ANALYSIS FIRST.**
2. **NO FIX WITHOUT INTENT DECOMPOSITION FIRST.**
3. **NO RETRY WITHOUT PROGRESSIVE CACHE INVALIDATION.**

Every fix -- Express, Standard, or Deep -- must have intent analysis and reference analysis before any code change.

## Workflow Overview

```
[Input]
   |
   v
Phase -1: INFRA DETECT (~2s, conditional)
   |
   v
Phase 0: BUG TRIAGE + SYMPTOM CLASSIFIER (~3s)
   |
   v
Phase 0.5: INTENT EXPANSION (~3-5s)
   |
   +-------+-------+
   |       |       |
[EXPRESS] [STANDARD] [DEEP]
 ~12s      ~30s      ~70s
SIMPLE    MEDIUM    COMPLEX
   |       |       |
   +-------+-------+
   |
   v
VERIFY (L1/L2/L3 Layers)
   |
   v
POST-FIX PATTERN SCAN (~3s)
   |
   v
[Done + Deliverables]
```

## Phase -1: INFRA-FIRST DIAGNOSIS (FR-06)

```yaml
goal: DB/네트워크/인프라 관련 에러일 때, 코드 수정 전에 인프라 상태부터 확인
trigger: 에러 메시지에 아래 키워드가 포함된 경우 자동 활성화

keywords:
  - "connection refused", "connection terminated", "connection reset"
  - "SSL", "TLS", "certificate"
  - "ECONNREFUSED", "ETIMEDOUT", "ENOTFOUND"
  - "502", "503", "504"
  - "database", "postgres", "mysql", "redis"
  - "timeout", "socket hang up"

provider_detection:
  description: "프로젝트 루트의 설정 파일로 인프라 provider 자동 감지"
  matrix:
    vercel:
      indicators: ["vercel.json", ".vercel/", "next.config.*"]
      health: ["vercel ls --limit 5 2>/dev/null", "vercel logs --limit 20 2>/dev/null"]
    railway:
      indicators: ["railway.toml", "railway.json", "Procfile"]
      health: ["railway status 2>/dev/null", "railway logs --limit 20 2>/dev/null"]
    supabase:
      indicators: ["supabase/config.toml", "supabase/.temp/"]
      health: ["supabase status 2>/dev/null", "supabase db status 2>/dev/null"]
    docker:
      indicators: ["docker-compose.yml", "docker-compose.yaml", "Dockerfile"]
      health: ["docker ps --format 'table {{.Names}}\\t{{.Status}}' 2>/dev/null"]
    local_dev:
      indicators: ["package.json"]
      health: ["lsof -i :{dev_port} 2>/dev/null"]

  execution:
    1. 프로젝트 루트에서 indicators 파일 존재 여부 확인
    2. 매칭된 provider의 health 명령 실행 (CLI 미설치 시 스킵)
    3. 복수 provider 감지 시 에러 키워드로 우선순위 결정
       - "502/503/504" → 프론트 + 백엔드 둘 다
       - "connection refused" → 백엔드 + DB
       - "database/postgres" → DB 우선
    4. provider 미감지 시 Phase -1 전체 스킵

when_detected:
  1. 인프라 상태 점검 (코드 수정 절대 금지):
     - 감지된 provider의 health 명령 실행
     - 로그에서 의도하지 않은 프로세스 실행 징후 확인 (예: DB 서비스에서 next start 실행)
     - 네트워크/DNS 연결 가능 여부 확인
  2. 인프라 이상 발견 시:
     - 코드 수정 시도 금지
     - 사용자에게 인프라 문제로 보고
     - 인프라 복구 방안 제시 (대시보드 조치 등)
  3. CLI 미설치 시:
     - "인프라 상태를 확인할 수 없습니다. {provider} 대시보드에서 직접 확인해주세요."
     - Phase 0으로 진행
  4. 인프라 정상 확인 후에만 Phase 0 (Bug Triage) 진행

anti_pattern:
  - "SSL 오류 -> pool.ts SSL 설정 변경" (실제 원인: 서비스 자체 손상)
  - "connection terminated -> 재시도 로직 추가" (실제 원인: DB 프로세스 미실행)
  - 로그에 이상 징후가 있는데 코드 레벨에서 해결하려는 모든 시도
```

## Phase 0: BUG TRIAGE + SYMPTOM CLASSIFIER (~3s)

```yaml
goal: Classify bug difficulty and route to correct track. Symptom-only inputs get classified by type, not auto-COMPLEX.
trigger: Always (first phase for every da:fix invocation)
tools: [] (pattern matching only, no tool calls)
steps:
  - Parse input: stack trace / error message / symptom description
  - If error message present: match against error_patterns below
  - If symptom-only: route to SYMPTOM CLASSIFIER (replaces auto-COMPLEX)
  - Assign track and confidence score
  - If confidence < 70%, default to MEDIUM (Standard track)

SIMPLE (-> Express track):
  error_patterns:
    - "TypeError: Cannot read properties of (undefined|null)"
    - "is not defined" / "Cannot find module" / "Cannot find name"
    - "expected ';'" / "Unexpected token"
    - "Property .* does not exist on type"
    - TS compiler errors: TS2345, TS2322, TS2339, TS2304, TS7006
    - "ImportError" / "ModuleNotFoundError"
    - "SyntaxError" (any language)
  signals:
    - Stack trace depth <= 2 frames
    - Single file mentioned in error
    - Compiler/linter error code present (not runtime)

MEDIUM (-> Standard track):
  error_patterns:
    - state + undefined/null combination
    - async/await related errors
    - "CORS" / HTTP 401/403/500
    - "timeout" / "connection refused" / "ECONNREFUSED"
    - Test failure messages (expect/assert)
  signals:
    - Stack trace depth 3-5 frames
    - 2-5 files mentioned
    - Runtime error (not compile-time)

COMPLEX (-> Deep track):
  error_patterns:
    - "Maximum call stack size exceeded"
    - "circular dependency" / "circular reference"
    - "deadlock" / "race condition"
    - Memory errors (heap, OOM, "out of memory")
  signals:
    - Stack trace depth > 5 frames
    - 6+ files mentioned
    - Keywords: "intermittent", "sometimes", "cannot reproduce"
  note: "symptom-only는 더 이상 자동 COMPLEX가 아님 → SYMPTOM CLASSIFIER로 분류"

SYMPTOM_CLASSIFIER:
  trigger: "에러 메시지/스택트레이스 없이 증상만 있을 때"
  taxonomy:
    VISUAL:
      keywords_ko: ["안 보여", "안 보임", "사라져", "깨져", "겹쳐", "잘려", "색이", "크기가", "위치가", "레이아웃", "정렬"]
      keywords_en: ["not visible", "overlapping", "misaligned", "cut off", "flickering"]
      default_track: SIMPLE
      escalate_to_MEDIUM: ["특정 화면 크기에서만", "특정 브라우저에서만", "조건부로", "가상화", "virtualizer"]
      search_strategy: "컴포넌트 → className/style/CSS 집중"
    INTERACTION:
      keywords_ko: ["클릭이 안 돼", "눌러도", "입력이", "드래그", "스크롤", "호버", "포커스"]
      keywords_en: ["not clickable", "unresponsive", "can't type", "can't scroll"]
      default_track: MEDIUM
      escalate_to_COMPLEX: ["가끔만", "빠르게 반복하면"]
      search_strategy: "이벤트 핸들러 → 상태 업데이트 체인"
    DATA:
      keywords_ko: ["값이 틀려", "저장이 안 돼", "목록이 비어", "데이터가 없어", "업데이트가 안 돼"]
      keywords_en: ["wrong value", "not saving", "empty list", "stale data"]
      default_track: MEDIUM
      escalate_to_COMPLEX: ["다른 사용자가 수정하면", "새로고침하면 복구"]
      search_strategy: "데이터 플로우 역추적: UI → store → API → DB"
    TIMING:
      keywords_ko: ["느려", "오래 걸려", "멈춰", "프리즈", "로딩이 안 끝나", "가끔", "간헐적"]
      keywords_en: ["slow", "freezes", "hangs", "intermittent", "sometimes"]
      default_track: COMPLEX
      downgrade_to_MEDIUM: ["항상 느려", "특정 페이지에서만"]
      search_strategy: "async/await 체인 + useEffect 의존성 + 리렌더링 패턴"
    NAVIGATION:
      keywords_ko: ["안 가", "이동이 안 돼", "리다이렉트", "뒤로 가기", "URL이", "페이지가 안 바뀌"]
      keywords_en: ["not redirecting", "wrong page", "routing broken"]
      default_track: MEDIUM
      search_strategy: "router 설정 → auth 미들웨어 → redirect/push 호출부"
  fallback: "어떤 카테고리에도 미매칭 → MEDIUM (COMPLEX가 아님)"

output: |
  TRIAGE: {SIMPLE|MEDIUM|COMPLEX} (confidence {N}%)
  SYMPTOM_TYPE: {ERROR_PATTERN|VISUAL|INTERACTION|DATA|TIMING|NAVIGATION}
  SEARCH_HINT: {search_strategy}
  → {Express|Standard|Deep}
```

## Phase 0.5: INTENT EXPANSION (~3-5s)

```yaml
goal: 사용자 의도를 3-Layer로 분해하고, 가설을 생성하고, 수정 범위를 확정
trigger: Always (Express는 경량 버전)
tools: [codegraph_search, codegraph_node]

step_1_DECOMPOSE:
  L1_literal:
    what: "사용자가 직접 말한 것"
    extract: [에러 메시지, 증상 키워드, 타겟 힌트]
    output: "{ error_msg?, symptom, target_hint? }"
  L2_scenario:
    what: "이 증상이 발생하는 UX flow"
    reasoning:
      - "사용자가 어떤 동작을 하다가 이 증상을 만났는가?"
      - "정상 결과는 무엇이어야 하는가?"
      - "정상 vs 실제의 gap은?"
    output: "{ user_action, expected_result, actual_result, gap }"
  L3_adjacent:
    what: "같은 코드 경로를 공유하는 기능들"
    action: "codegraph_search으로 동일 패턴 스캔 (5초 제한)"
    output: "{ related_features[], shared_symbols[] }"

step_2_HYPOTHESIS:
  minimum: 2 (Express는 1 + 대안 메모)
  format:
    H1_primary: "{ cause, target_symbol, confidence% }"
    H2_alternative: "{ cause, target_symbol, confidence% }"
  rules:
    - H1과 H2는 반드시 다른 심볼/파일을 타겟
    - H1 confidence < 60% → 사용자에게 확인 필수
    - Express: H1만 추구, H2는 메모 (실패 시 H2로 전환)

step_3_SCOPE_DECISION:
  L3_empty: "자동 진행"
  L3_found: |
    사용자에게 보고:
    "동일 패턴이 {N}곳에서 발견되었습니다. 함께 수정할까요?"
  user_confirms_expand: "FIX 범위에 연관 심볼 포함"
  user_confirms_narrow: "현재 증상만 수정, 연관 기능은 Deliverables에 '잠재 이슈' 기록"

express_lite:
  skip: [L3_adjacent, step_3_SCOPE_DECISION]
  keep: [L1_literal, L2_scenario(간소화), H1 only]
  duration: ~1s
```

## EXPRESS Track (SIMPLE bugs, ~12s)

For single-cause, single-file bugs with clear error messages.

```yaml
goal: Fix in 1 LLM reasoning pass + immediate verification
tools: [codegraph_node, codegraph_explore, Edit, Bash]
prerequisite: Phase 0.5 express_lite 완료 (H1 가설 확보)
steps:
  1_locate_and_fix:
    - Phase 0.5 H1 가설의 target으로 직행
    - codegraph_explore(target_file) to understand structure
    - codegraph_node(target, include_body=True) to read the buggy code
    - Generate fix in same reasoning pass (no separate DIAGNOSE phase)
    - Output: { target_file, target_symbol, fix_diff, confidence }
  2_blast_radius_lite:
    - codegraph_callers(target_symbol) -- direct references only (depth 0)
    - If 0-5 references: proceed
    - If 6+ references: ESCALATE to Standard track
  3_apply:
    - Edit to apply fix
    - Update direct references if signature changed
  4_verify:
    - L1_STATIC only: "tsc --noEmit {changed_file}" + lint
    - If PASS -> POST-FIX PATTERN SCAN -> Done
    - If FAIL -> ESCALATE to Standard track (H2 대안 가설 함께 전달)

escalation_conditions:
  - Verification (tsc/lint) fails
  - Fix confidence < 80%
  - Fix requires 5+ file changes
  - Blast Radius shows 6+ direct references
escalation_action: "EXPRESS failed. Escalating to STANDARD track with H2 hypothesis + collected context."
```

## STANDARD Track (MEDIUM bugs, ~30s)

For logic bugs, state issues, API integration problems requiring root cause analysis.

```yaml
goal: Parallel-optimized full pipeline with blame-driven context and semantic verification
tools: [codegraph_node, codegraph_callers, codegraph_explore,
        codegraph_search, Edit, Bash]
prerequisite: Phase 0.5 완료 (H1/H2 가설 + L3 범위 확보)

wave_1_parallel: # ~8s
  LOCATE:
    - Phase 0.5 H1 가설의 target으로 시작 (SYMPTOM_TYPE의 search_strategy 활용)
    - Parse stack trace if available (Python/JS/TS formats)
    - Hierarchical narrowing: L1 file -> L2 class/function -> L3 method -> L4 line
    - Confidence gate: < 80% -> ask user, >= 80% -> proceed
  CONTEXT_COLLECT_v2:
    layer_1_recent:
      - "git diff HEAD~3 --stat" (직접 최근 변경)
      - env info (node -v, python3 --version)
    layer_2_target_history:
      - "git log --oneline -10 -- {target_file}" (타겟 파일 변경 이력)
      - "git log --oneline -5 --diff-filter=M -- {target_directory}/" (같은 디렉토리 변경)
      - 커밋 메시지에서 "refactor", "fix", "breaking", "migration" 키워드 추출
      - 최근 2주 내 refactor/breaking 커밋 → regression 가능성 플래그
    layer_3_regression_detect:
      trigger: "사용자 입력에 '갑자기', '원래 됐는데', '어느 순간부터' 포함"
      - "git log --oneline --since='2 weeks' -- {target_file}"
      - 변경 없으면 → 의존성 변경 확인: "git log --oneline --since='2 weeks' -- package.json *.lock"
    layer_4_dependency_changes:
      trigger: "layer_3에서 타겟 파일 변경 없음 확인 시"
      - "git diff HEAD~20 -- package.json | head -40"
      - 메이저 버전 업그레이드 감지 → Context7으로 마이그레이션 가이드 조회
    budget: "max 4 git commands, max 30 lines output"

wave_2_sequential: # ~5s (depends on LOCATE)
  IDENTIFY:
    - codegraph_node(target, include_body=True)
    - If ambiguous: codegraph_search to narrow candidates
    - Confirm target with user if multiple matches
    - regression 커밋 발견 시 해당 diff를 DIAGNOSE 시작점으로 주입

wave_3_parallel: # ~8s
  DIAGNOSE:
    - Read target symbol body
    - Trace call chain: upstream (codegraph_callers) + downstream
    - Apply 5 Whys to reach root cause (regression 커밋이 있으면 거기서 시작)
    - Phase 0.5 H1/H2 가설과 교차 검증
    - Document root cause with evidence
  BLAST_RADIUS:
    - codegraph_callers(target) -- all direct references
    - For each direct reference: find its callers (depth 1 indirect)
    - Phase 0.5 L3_adjacent 결과와 병합 (이미 발견된 연관 심볼 포함)
    - Risk: Low (1-5 files), Medium (6-15), High (16+)
    - If 20+ files: require user confirmation

wave_4_sequential: # ~5s (depends on DIAGNOSE + BLAST)
  FIX:
    - Apply fix to root cause symbol (Edit)
    - Update references if signature/contract changed
    - Phase 0.5 scope_decision에서 확장 범위 포함 시 연관 심볼도 수정
    - Minimal changes -- no opportunistic refactoring

wave_5_sequential: # ~8s
  VERIFY:
    - L1_STATIC + L2_SEMANTIC (see Verification Layers section)
    - On PASS: POST-FIX PATTERN SCAN -> Done
    - On FAIL: enter retry loop (see Progressive Cache Invalidation)
```

## DEEP Track (COMPLEX bugs, ~70s)

For architectural issues, multi-file cascading bugs, concurrency problems.

```yaml
goal: Multi-patch candidates with isolated parallel verification for maximum success rate
tools: [all Standard tools + Agent(isolation=worktree)]
prerequisite: Phase 0.5 완료 (H1/H2 가설 + L3 범위 확보)

wave_1_to_3: "Same as STANDARD, except:"
  - CONTEXT_COLLECT: layer_4_dependency_changes 항상 실행
  - BLAST_RADIUS: depth 2 (2단계 간접 참조까지)
  - DIAGNOSE: Phase 0.5 H1/H2 가설을 독립적으로 검증

wave_4_multi_patch: # ~15s
  description: "Generate 2-3 fix candidates in parallel"
  candidate_A: "Conservative -- minimal direct fix to root cause symbol only"
  candidate_B: "Refactoring -- fix + clean up related code for robustness"
  candidate_C: "Alternative -- Phase 0.5 H2 가설 기반 다른 타겟/접근법"
  budget_check: "If token budget < 2000 remaining, generate only candidate A"

wave_5_isolated_verify: # ~15s
  description: "각 후보를 격리 환경에서 독립 검증"
  strategy_selection:
    if_candidates_gte_2:
      preferred: "Agent(isolation=worktree) -- 완벽한 파일시스템 격리, 병렬 실행"
      each_agent: |
        1. Apply candidate patch
        2. Run tsc + lint + related tests
        3. Return: { tsc_pass, lint_pass, test_pass, new_errors[], diff }
      fallback: "stash-based sequential (worktree 불가 시)"
        1. "git stash push -m 'da:fix-baseline'"
        2. Apply patch → verify → "git checkout -- {files}" → repeat
        3. "git stash pop" for final baseline restore
    if_candidates_eq_1:
      action: "직접 적용 후 검증 (격리 불필요)"

wave_6_select: # ~2s
  criteria:
    - Most tests passing (primary)
    - Fewest files changed (secondary)
    - Highest confidence score (tertiary)
  action: "Apply selected patch, discard others"
  verify_final: "L1_STATIC + L2_SEMANTIC + L3_PATTERN (see Verification Layers)"

three_fix_escalation: "Progressive Cache Invalidation rules apply"
```

## Verification Layers

```yaml
description: "3-Layer 검증 (트랙별 깊이 조절)"

L1_STATIC:
  tracks: [Express, Standard, Deep]
  always_run: true
  checks:
    - "tsc --noEmit {changed_files}" (TypeScript)
    - "eslint {changed_files}" or "ruff {changed_files}" (Python)
    - Build check if applicable
  on_fail: "즉시 FIX 재시도"
  duration: ~3s

L2_SEMANTIC:
  tracks: [Standard, Deep]
  trigger: "L1 통과 후"
  checks:
    contract_preservation:
      description: "수정된 심볼의 입출력 계약이 유지되는가?"
      method: |
        1. codegraph_callers(modified_symbol)
        2. 각 호출부에서 기대하는 입력/출력 확인
        3. 수정 후 심볼과 호출부 기대값 비교
      violations:
        - "반환 타입 확장 (T → T | null, T | undefined)"
        - "파라미터 추가 (optional이라도 기존 호출부에 영향)"
        - "예외 타입 변경 (catch 블록 불일치)"
      on_violation: "호출부 함께 수정 또는 반환 타입 변경 철회"
    state_consistency:
      description: "상태 업데이트 순서/원자성 보존되는가?"
      trigger: "수정된 심볼이 setState/dispatch/store 포함 시"
      checks: ["업데이트 순서", "트랜잭션 경계", "부분 실패 가능성"]
    test_coverage_check:
      description: "수정된 코드 경로에 테스트가 있는가?"
      method: "codegraph_search('{symbol_name}') in **/*.test.*, **/*.spec.*"
      test_found: "실행"
      test_not_found: "경고만 (자동 생성 안 함)"
  duration: ~5s

L3_PATTERN:
  tracks: [Deep]
  trigger: "L2 통과 후"
  checks:
    security_regression:
      patterns:
        - "SQL string interpolation (template literals in queries)"
        - "innerHTML/dangerouslySetInnerHTML에 사용자 입력"
        - "eval(), new Function()에 외부 입력"
        - "CORS: Access-Control-Allow-Origin: *"
        - "하드코딩된 비밀키/토큰"
      on_detection: "보안 위험 감지 보고 + 의도 확인"
    performance_regression:
      patterns:
        - "중첩 루프 (O(n^2)+ 가능성)"
        - "루프 내 await (N+1 쿼리 패턴)"
        - ".find()/.filter()가 Map.get()/Set.has() 대체"
        - "SELECT * 패턴"
      on_detection: "성능 위험 보고 + 수정 전후 복잡도 비교"
  duration: ~5s

layer_selection:
  EXPRESS: [L1_STATIC]
  STANDARD: [L1_STATIC, L2_SEMANTIC]
  DEEP: [L1_STATIC, L2_SEMANTIC, L3_PATTERN]
```

## Symbol Map Cache Strategy

```yaml
purpose: Eliminate redundant CodeGraph MCP calls across phases and retries
implementation: LLM context window retention (not external cache)

on_first_locate:
  - Run codegraph_explore on target directory ONCE
  - Store result mentally for reuse in BLAST RADIUS and retries

on_fix_applied:
  - Invalidate mental model of changed files only
  - Re-read changed symbols if needed for verification

no_cache_flag:
  - "--no-cache" forces fresh CodeGraph calls at every phase
  - Use when suspecting stale context or after external file changes
```

## Progressive Cache Invalidation (Three-Fix Escalation v2)

```yaml
description: "실패 횟수에 따라 점진적으로 캐시를 무효화하여 시야를 넓힘"

attempt_1_fail:
  invalidate: [DIAGNOSE]
  reuse: [LOCATE, IDENTIFY, BLAST_RADIUS, CONTEXT]
  strategy: "같은 타겟, 다른 진단"
  feedback_injection: |
    "이전 수정 내용: {previous_diff}
     실패 이유: {verify_error}
     이 접근이 틀린 이유를 먼저 분석한 후 다른 근본 원인을 찾으세요.
     이전 수정에 약간의 변형을 가하지 마세요."

attempt_2_fail:
  invalidate: [LOCATE, IDENTIFY, DIAGNOSE]
  reuse: [CONTEXT(참고용)]
  partially_reuse: [BLAST_RADIUS → "이전 분석은 참고만, 새 타겟 기준 재분석"]
  strategy: "다른 타겟 탐색"
  re_locate_rules:
    - exclude: [이전 시도 타겟들]
    - 스택 트레이스 중간 프레임 탐색 (가장 깊은 프레임 대신)
    - CONTEXT의 blame 정보에서 미탐색 파일 우선
    - 이전 BLAST_RADIUS의 호출자 측을 새 타겟 후보로 검토
    - Phase 0.5 H2 가설로 전환

attempt_3_fail:
  invalidate: [ALL]
  strategy: "STOP + 구조적 에스컬레이션"
  action: |
    "3회 수정 시도 실패. 구조적 문제로 판단합니다.
     시도 이력:
     #1: {target} — {diagnosis} — {fix} — {fail_reason}
     #2: {target} — {diagnosis} — {fix} — {fail_reason}
     #3: {target} — {diagnosis} — {fix} — {fail_reason}
     패턴 분석: {common_pattern} / {divergence}
     권장: /da:system으로 아키텍처 레벨 검토"
```

**Identical patch detection:**
- If RE-FIX generates the same diff as a previous attempt -> STOP immediately
- "You're stuck in a loop. The root cause is elsewhere."

**Track escalation (Express -> Standard only):**
- Express failure does NOT count toward the 3-attempt limit
- After escalation to Standard, the counter resets to 0 (H2 가설 전달)

**Escalation triggers:**
- Each fix reveals new issues elsewhere
- Fix scope keeps expanding (touching more files each iteration)
- Same logical error manifests in different forms
- Identical patch generated after failure (loop detection)

## Post-Fix Pattern Scan

```yaml
position: VERIFY 통과 후, Done 선언 전
trigger: 모든 트랙 (Express 포함)
opt_out: "--no-scan" 플래그
duration: ~3-5s

step_1_extract_signature:
  description: "수정한 버그의 패턴 시그니처 추출"
  types:
    NULL_ACCESS: "optional chaining/null check 추가 → 동일 객체 직접 접근 탐색"
    MISSING_ERROR_HANDLING: "try-catch/.catch() 추가 → 같은 함수 호출부 에러 처리 탐색"
    MISSING_AWAIT: "await 추가 → 같은 async 함수의 await 없는 호출 탐색"
    WRONG_TYPE: "타입 변환 추가 → 같은 소스 데이터의 미변환 사용 탐색"
    API_BREAKING_CHANGE: "라이브러리 API 변경 → 같은 라이브러리의 다른 사용처 탐색"
    GENERIC: "수정 전 코드의 핵심 구문을 정규식으로 변환하여 탐색"

step_2_scan:
  method: "codegraph_search(signature) -- 같은 디렉토리 우선, 전체 코드베이스 다음"
  filtering: "수정된 파일 제외, 테스트 파일 제외, node_modules 제외"
  limit: 최대 20개 결과

step_3_classify:
  IDENTICAL: "수정 전 코드와 동일한 패턴 → 거의 확실히 같은 버그"
  SIMILAR: "유사하지만 컨텍스트가 다름 → 가능성 있음"
  method: "각 매치를 codegraph_node로 컨텍스트 확인 (전체 파일 읽기 아님)"

step_4_report:
  found: |
    "{bug_type} 패턴이 {N}곳에서 추가 발견되었습니다:
     확실 (IDENTICAL): {file}:{line} - {context}
     가능성 (SIMILAR): {file}:{line} - {context}
     함께 수정하시겠습니까?"
  not_found: "유사 패턴 스캔 완료. 동일한 문제가 다른 곳에서는 발견되지 않았습니다."
  user_confirms: "각 IDENTICAL 매치에 동일 수정 적용 → VERIFY 재실행"
  user_declines: "Deliverables '잠재 이슈' 섹션에 기록"

express_lite: "step_2만 실행 (step_3 분류 생략), 간단 보고"
```

## Deliverables (All Tracks)

- Triage result (track + confidence + symptom_type)
- Intent Expansion (L1/L2/L3 분해 + 가설 H1/H2)
- Blame-Driven Context (regression 커밋, 의존성 변경)
- Root cause summary (what and why)
- Blast Radius report (direct/indirect files, risk level)
- Fix diff (minimal, surgical changes)
- Verification results (L1 static + L2 semantic + L3 pattern)
- Post-Fix Pattern Scan results (유사 패턴 발견 여부 + 잠재 이슈)
- Attempt history (patch + result + cache invalidation level per attempt)

## Anti-Rationalization Rules
- "One more fix should work" -- if 3 failed, the problem is structural.
- "I'm almost there" -- sunk cost fallacy. Step back and reassess.
- "This is just a small tweak" -- small tweaks without Blast Radius analysis cause cascading failures.
- "Same approach, slightly different" -- if the diff is identical, you're looping. STOP.
- "LOCATE said this file, so it must be right" -- confidence < 80% means ASK the user. Try H2 hypothesis.
- "Context collection is overkill for this" -- skipping blame-driven context leads to misdiagnosis.
- "It's SIMPLE, skip Blast Radius" -- Express still does depth-0 reference check. NO exceptions.
- "Standard is overkill, force Express" -- respect the Triage result. Don't downgrade tracks.
- "Skip Intent Expansion, the error is obvious" -- obvious errors can have non-obvious scope. NO skip.
- "Skip Pattern Scan, I only changed one line" -- one-line bugs often repeat across the codebase.
- "Retry with same LOCATE" -- attempt 2 must invalidate LOCATE. Progressive Cache Invalidation is mandatory.

## Red Flags -- STOP AND REASSESS
- About to skip Blast Radius analysis ("it's just a one-line change")
- About to skip Intent Expansion ("the error message is clear enough")
- About to attempt a 4th fix after 3 failures
- Using uncertainty language about fix effectiveness ("this should work", "probably fixes it")
- About to re-apply a patch that already failed
- LOCATE confidence < 80% but proceeding without user confirmation
- Reusing LOCATE on attempt 2+ without Progressive Cache Invalidation
- Skipping Blame-Driven Context on regression-type symptoms
- Downgrading from Standard/Deep to Express mid-execution

## Confidence Threshold
>=90% across all dimensions before declaring fix complete:
- **Intent understood** (10%): L1/L2 decomposition complete, hypothesis generated
- **Target correctly located** (15%): Triage confidence >= 70% + LOCATE confidence >= 80%
- **Root cause identified** (20%): Evidence-based root cause, not symptom (Express: inferred)
- **Blast Radius complete** (15%): Express depth-0, Standard depth-1, Deep depth-2
- **Fix passes verification** (20%): L1 static + L2 semantic (Standard+) + L3 pattern (Deep)
- **No new issues introduced** (10%): No regressions in related code
- **Pattern scan complete** (10%): Similar patterns identified and reported

## Handoff Contract (da:protocol §2.2 / §3)
Confidence 수치는 **evidence가 뒷받침될 때만** 유효하다. 응답 마지막 JSON:
```json
{"skill": "da:fix", "status": "completed|partial|blocked|failed", "track": "EXPRESS|STANDARD|DEEP",
 "root_cause": "...", "files_changed": ["..."], "attempt": 1,
 "evidence": [{"kind": "test", "ref": "npm test -- <scope>", "result": "N passed / exit 0", "ok": true},
              {"kind": "command", "ref": "npx tsc --noEmit", "result": "exit 0", "ok": true}],
 "remaining": [], "blockers": []}
```
- 재현 테스트가 없던 버그는 **재현 → 수정 → 재실행**의 3개 evidence가 있어야 `completed`. 재현 불가 → `blocked`(blockers: "cannot reproduce").
- attempt 2+는 Progressive Cache Invalidation과 함께 `previous_failure`를 받아 다른 접근을 명시한다. 3회 실패 → `blocked` + da:system 재검토 권고(§5.3).
- da:work 안에서 호출되면 최종 passed 판정은 후속 da:verify/da:e2e 노드가 낸다(§3.2).

## Transition
- **Next**: null (independent, self-contained)
- **Condition**: Fix verified with evidence, pattern scan complete, no new issues introduced
