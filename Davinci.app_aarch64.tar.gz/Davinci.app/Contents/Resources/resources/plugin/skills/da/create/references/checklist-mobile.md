# Mobile Prototype Checklist

Run before emitting the artifact. P0 = must pass; P1 = should pass; P2 = nice to have.

## P0 -- must pass

- [ ] **Viewport meta present.** `<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">` -- `viewport-fit=cover` is required for safe area insets.
- [ ] **No raw color values outside `:root`.** Every color uses CSS custom properties or `color-mix()` of those.
- [ ] **Touch targets >= 44x44px.** All buttons, links, and interactive elements meet Apple HIG minimum.
- [ ] **Safe area insets respected.** Use `env(safe-area-inset-top)`, `env(safe-area-inset-bottom)` for status bar and home indicator areas.
- [ ] **No emoji as icons.** Use inline SVG monoline marks or SF Symbol-style glyphs.
- [ ] **No invented metrics.** Numbers come from the brief or are `[REPLACE]` placeholders.
- [ ] **No filler copy.** Zero lorem ipsum, "Feature One / Feature Two".
- [ ] **`data-screen-label` on the main screen `<section>`.** Required for davinci-gui targeting.
- [ ] **TWEAK_DEFAULTS block present.** `/*EDITMODE-BEGIN*/` and `/*EDITMODE-END*/` markers.
- [ ] **Device frame intact.** Dynamic Island, status bar SVG icons, and home indicator must not be removed or re-implemented.

## P1 -- should pass

- [ ] **Single screen, single job.** No multi-tab tours or spliced flows in one artifact.
- [ ] **Accent budget = 2.** One active tab icon + one primary action button is the default.
- [ ] **Heading hierarchy intact.** h1 -> h2 -> h3, no skips.
- [ ] **Text legible at 393px width.** Minimum body text 14px, minimum label text 11px.
- [ ] **Tab bar has 4-5 items max.** Each with icon + label. Active state uses accent color.
- [ ] **Scroll area is the content zone only.** Status bar, Dynamic Island, and tab bar remain fixed.
- [ ] **No horizontal scroll.** Content fits within the 393px device viewport.

## P2 -- nice to have

- [ ] **Dark mode toggle** via TWEAK_DEFAULTS `dark` key.
- [ ] **Haptic feedback hints** via `data-haptic="light|medium|heavy"` attributes.
- [ ] **Swipe gesture indicators** for dismissible cards or navigation.
- [ ] **Reduced motion** respects `prefers-reduced-motion` media query.
