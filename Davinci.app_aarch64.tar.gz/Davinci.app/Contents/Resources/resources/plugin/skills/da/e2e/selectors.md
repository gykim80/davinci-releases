# Selectors

Stable, maintainable selector strategies for Playwright E2E tests.

## Selector Priority Hierarchy

Choose selectors in this order. Higher-priority selectors are more resilient to UI changes and closer to how users interact with the page.

```
1. getByRole()      -- Accessible role + name (most resilient)
2. getByLabel()     -- Form label association
3. getByTestId()    -- Explicit test identifier
4. getByText()      -- Visible text content
5. getByPlaceholder() -- Placeholder text
6. CSS selector     -- Last resort only
```

## Role-Based Selectors

Role selectors query the accessibility tree, matching how assistive technology and users perceive the page. They survive CSS refactors, class renames, and markup restructuring.

```typescript
// Buttons
page.getByRole('button', { name: 'Submit' });
page.getByRole('button', { name: /save/i });

// Links
page.getByRole('link', { name: 'Documentation' });

// Headings
page.getByRole('heading', { name: 'Dashboard', level: 1 });

// Form controls
page.getByRole('textbox', { name: 'Email' });
page.getByRole('checkbox', { name: 'Remember me' });
page.getByRole('combobox', { name: 'Country' });

// Navigation landmarks
page.getByRole('navigation');
page.getByRole('main');
```

### When to Use

- Buttons, links, headings, form inputs, and landmark regions.
- Any element with an implicit or explicit ARIA role.
- When the accessible name is stable and meaningful.

## Label-Based Selectors

Label selectors find form controls by their associated `<label>` element. They validate that the label-input relationship exists.

```typescript
// Input associated with <label for="email">Email</label>
page.getByLabel('Email');

// Textarea with label
page.getByLabel('Description');

// Checkbox group items
page.getByLabel('Accept terms');
```

### When to Use

- Form inputs that have associated labels.
- When the label text is stable and user-facing.

## Test ID Selectors

Test IDs provide stable anchors for elements that lack semantic roles or meaningful text content. They require adding `data-testid` attributes to the markup.

```typescript
// Element with data-testid="user-avatar"
page.getByTestId('user-avatar');

// Complex widget without clear role
page.getByTestId('chart-container');

// Dynamic content area
page.getByTestId('notification-badge');
```

### When to Use

- Non-semantic elements (decorative containers, custom widgets).
- Elements where role and text are ambiguous or unstable.
- Dynamic content that changes text frequently.

### Configuring the Test ID Attribute

```typescript
// playwright.config.ts
export default defineConfig({
  use: {
    testIdAttribute: 'data-testid', // default
  },
});
```

## Text Selectors

Text selectors match visible text content. Use them for static labels, messages, and content verification.

```typescript
// Exact text match
page.getByText('Welcome back');

// Regex for partial match
page.getByText(/items in cart/i);

// Specific element with text
page.getByText('No results found');
```

### When to Use

- Static display text, headings, and status messages.
- Content that does not change between sessions.
- Avoid for text that includes dynamic data (counts, dates, names).

## Bad/Good Patterns

### CSS Class Selectors

**Detect:** CSS class selector (`.btn-primary`, `.card-header`, `[class*="style"]`) in test file -- suggest `getByRole` or `getByTestId`.

```typescript
// Bad: CSS class is a styling concern, breaks on refactor
await page.locator('.btn-primary').click();

// Good: Role-based selector tied to semantics
await page.getByRole('button', { name: 'Save changes' }).click();
```

### XPath Expressions

**Detect:** XPath expression (`//div`, `//button[@class]`) in test file -- suggest role or label-based selector.

```typescript
// Bad: XPath is brittle, hard to read, breaks on DOM changes
await page.locator('//div[@class="sidebar"]//button[2]').click();

// Good: Semantic selector independent of DOM structure
await page.getByTestId('sidebar-settings-btn').click();
```

### Positional Selectors

**Detect:** `nth-child`, `nth-of-type`, `:first-child`, or `.nth()` in test file -- suggest explicit test ID or filter.

```typescript
// Bad: Position-dependent, breaks when items reorder
await page.locator('ul > li:nth-child(2)').click();

// Good: Explicit identifier or filter by content
await page.getByRole('listitem').filter({ hasText: 'Settings' }).click();
```

### Dynamic Class Names

**Detect:** CSS module hash pattern (`class*="style_"`, `class*="_hash"`) or Tailwind arbitrary class in selector -- suggest stable attribute.

```typescript
// Bad: CSS module class changes on every build
await page.locator('[class*="Button_primary__a3x2f"]').click();

// Good: Stable test ID unaffected by build tooling
await page.getByTestId('primary-action').click();
```

### ID Selectors with Generated Values

```typescript
// Bad: Auto-generated ID from framework
await page.locator('#radix-\\:r2\\:');

// Good: Explicit, stable locator
await page.getByRole('dialog', { name: 'Confirm deletion' });
```

## Chaining and Filtering

Combine locators to narrow down matches without resorting to fragile selectors.

```typescript
// Filter within a section
const sidebar = page.getByRole('navigation', { name: 'Main' });
await sidebar.getByRole('link', { name: 'Dashboard' }).click();

// Filter by child content
await page
  .getByRole('listitem')
  .filter({ hasText: 'Pro Plan' })
  .getByRole('button', { name: 'Select' })
  .click();

// Filter by another locator
await page
  .getByRole('row')
  .filter({ has: page.getByText('admin@example.com') })
  .getByRole('button', { name: 'Edit' })
  .click();
```

## Quick Reference

| Method | Target | Resilience | Example |
|---|---|---|---|
| `getByRole(role, { name })` | Accessible role + name | High | `getByRole('button', { name: 'Save' })` |
| `getByLabel(text)` | Label-associated input | High | `getByLabel('Email')` |
| `getByTestId(id)` | `data-testid` attribute | High | `getByTestId('user-avatar')` |
| `getByText(text)` | Visible text content | Medium | `getByText('Welcome')` |
| `getByPlaceholder(text)` | Placeholder attribute | Medium | `getByPlaceholder('Search...')` |
| `getByAltText(text)` | Image alt text | Medium | `getByAltText('Company logo')` |
| `getByTitle(text)` | Title attribute | Low | `getByTitle('Close')` |
| `locator(css)` | CSS selector | Low | `locator('.custom-widget')` |
| `.filter({ hasText })` | Narrow by text | -- | `.filter({ hasText: 'Pro' })` |
| `.filter({ has })` | Narrow by child locator | -- | `.filter({ has: getByText('X') })` |
| `.nth(index)` | Position in list | Low | `.nth(0)` (use as last resort) |
