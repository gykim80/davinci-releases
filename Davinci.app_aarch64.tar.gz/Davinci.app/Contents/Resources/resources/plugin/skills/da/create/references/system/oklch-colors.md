# oklch() Color System for Davinci + DaisyUI v5

> DaisyUI v5 uses oklch() color functions by default. Auto-loaded when da:design detects DaisyUI.

## oklch(Lightness, Chroma, Hue) Basics

```
oklch(L C H)
  L (Lightness): 0 = black, 1 = white (range 0-1)
  C (Chroma):    0 = achromatic, ~0.4 = max saturation (range 0-0.4)
  H (Hue):       0-360 degree color wheel
```

### Color Reference Values

| Color | L | C | H | Example |
|------|---|---|---|------|
| Light red | 0.65 | 0.20 | 25 | `oklch(0.65 0.20 25)` |
| Orange | 0.75 | 0.18 | 60 | `oklch(0.75 0.18 60)` |
| Gold | 0.80 | 0.20 | 85 | `oklch(0.80 0.20 85)` |
| Green | 0.70 | 0.18 | 150 | `oklch(0.70 0.18 150)` |
| Cyan | 0.70 | 0.15 | 190 | `oklch(0.70 0.15 190)` |
| Blue | 0.60 | 0.20 | 250 | `oklch(0.60 0.20 250)` |
| Indigo | 0.50 | 0.22 | 270 | `oklch(0.50 0.22 270)` |
| Purple | 0.55 | 0.20 | 290 | `oklch(0.55 0.20 290)` |
| Pink | 0.70 | 0.18 | 340 | `oklch(0.70 0.18 340)` |

---

## DaisyUI Default Theme Color Tokens

DaisyUI manages theme colors via CSS variables. All values are in oklch() format.

### Semantic Colors (meaning-based)

| Token | Purpose | Default (light) |
|------|------|---------------|
| `primary` | Main actions, CTA buttons | `oklch(0.62 0.19 264)` |
| `primary-content` | Text on primary | `oklch(0.98 0.01 264)` |
| `secondary` | Secondary actions | `oklch(0.70 0.17 330)` |
| `secondary-content` | Text on secondary | `oklch(0.98 0.01 330)` |
| `accent` | Emphasis, highlights | `oklch(0.76 0.18 170)` |
| `accent-content` | Text on accent | `oklch(0.15 0.02 170)` |
| `neutral` | Neutral, default elements | `oklch(0.32 0.02 260)` |
| `neutral-content` | Text on neutral | `oklch(0.93 0.01 260)` |

### State Colors

| Token | Purpose | Default |
|------|------|--------|
| `info` | Information alerts | `oklch(0.72 0.14 230)` |
| `success` | Success state | `oklch(0.72 0.19 155)` |
| `warning` | Warning state | `oklch(0.82 0.17 80)` |
| `error` | Error state | `oklch(0.65 0.22 25)` |

### Base Colors (background/surface)

| Token | Purpose | Light | Dark |
|------|------|-------|------|
| `base-100` | Default background | `oklch(1 0 0)` | `oklch(0.20 0.02 260)` |
| `base-200` | Slightly darker background | `oklch(0.96 0 0)` | `oklch(0.17 0.02 260)` |
| `base-300` | Even darker background | `oklch(0.92 0 0)` | `oklch(0.14 0.02 260)` |
| `base-content` | Default text | `oklch(0.20 0.02 260)` | `oklch(0.93 0.01 260)` |

---

## Custom Theme Setup

### Define theme in tailwind.config.ts

```typescript
// tailwind.config.ts
import daisyui from "daisyui"

export default {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  plugins: [daisyui],
  daisyui: {
    themes: [
      {
        davinci: {
          "primary":          "oklch(0.62 0.19 264)",
          "primary-content":  "oklch(0.98 0.01 264)",
          "secondary":        "oklch(0.70 0.17 330)",
          "secondary-content":"oklch(0.98 0.01 330)",
          "accent":           "oklch(0.76 0.18 170)",
          "accent-content":   "oklch(0.15 0.02 170)",
          "neutral":          "oklch(0.32 0.02 260)",
          "neutral-content":  "oklch(0.93 0.01 260)",
          "base-100":         "oklch(0.20 0.02 260)",
          "base-200":         "oklch(0.17 0.02 260)",
          "base-300":         "oklch(0.14 0.02 260)",
          "base-content":     "oklch(0.93 0.01 260)",
          "info":             "oklch(0.72 0.14 230)",
          "success":          "oklch(0.72 0.19 155)",
          "warning":          "oklch(0.82 0.17 80)",
          "error":            "oklch(0.65 0.22 25)",
        },
      },
      "light",
      "dark",
    ],
  },
}
```

### Apply theme in layout.tsx

```tsx
// app/layout.tsx
<html data-theme="davinci">
  <body>{children}</body>
</html>
```

### Runtime Theme Switching

```tsx
function ThemeToggle() {
  const [theme, setTheme] = useState("light")

  const toggleTheme = () => {
    const next = theme === "light" ? "dark" : "light"
    setTheme(next)
    document.documentElement.setAttribute("data-theme", next)
  }

  return (
    <label className="swap swap-rotate">
      <input type="checkbox" onChange={toggleTheme} />
      <span className="swap-on">🌙</span>
      <span className="swap-off">☀️</span>
    </label>
  )
}
```

---

## Dark Theme Creation Guide

For dark themes, adjust the Lightness (L) value:

```yaml
Light_Theme:
  base-100: oklch(1 0 0)        # white background
  base-200: oklch(0.96 0 0)     # slightly gray
  base-300: oklch(0.92 0 0)     # more gray
  base-content: oklch(0.20 ...)  # dark text

Dark_Theme:
  base-100: oklch(0.20 0.02 260)  # dark background
  base-200: oklch(0.17 0.02 260)  # darker background
  base-300: oklch(0.14 0.02 260)  # darkest background
  base-content: oklch(0.93 ...)    # light text
```

### L-value Adjustment Formula

```
Light backgrounds → L: 0.92-1.0
Medium backgrounds → L: 0.50-0.70
Dark backgrounds → L: 0.14-0.25
Text (on light bg) → L: 0.15-0.30
Text (on dark bg) → L: 0.85-0.95
```

---

## Opacity Combinations

Apply opacity with DaisyUI + Tailwind using `/` syntax:

```html
<!-- Text opacity -->
<p class="text-base-content/60">60% opacity text</p>
<p class="text-primary/80">80% opacity primary text</p>

<!-- Background opacity -->
<div class="bg-base-100/80">80% opacity background</div>
<div class="bg-primary/10">10% opacity primary background</div>

<!-- Border opacity -->
<div class="border border-primary/30">30% opacity border</div>
```

---

## Color Utility Classes

```html
<!-- Text colors -->
<span class="text-primary">Primary text</span>
<span class="text-secondary">Secondary text</span>
<span class="text-accent">Accent text</span>
<span class="text-base-content">Default text</span>

<!-- Background colors -->
<div class="bg-primary">Primary background</div>
<div class="bg-base-100">Base background</div>
<div class="bg-base-200">Slightly darker</div>

<!-- Border colors -->
<div class="border border-primary">Primary border</div>
<div class="border border-base-300">Subtle border</div>
```
