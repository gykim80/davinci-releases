# Industry → Persona Mapping Table

> reasoning.csv의 Style_Priority 키워드를 기반으로 5개 페르소나에 매핑

## 매핑 규칙

| Style_Priority 키워드 | 추천 페르소나 | 근거 |
|----------------------|:----------:|------|
| Minimalism, Swiss, Clean, Whitespace | **minimal** | 절제된 시각 언어, 여백 활용 |
| Bold, Brutalist, Impact, Punk, Heavy | **bold** | 강렬한 시각 임팩트, 대담한 타이포 |
| Playful, Rounded, Fun, Illustrated, Cartoon | **playful** | 친근한 인터랙션, 둥근 형태 |
| Luxury, Elegant, Refined, Classic, Art Deco | **elegant** | 세련된 고급감, 황금비 |
| Terminal, Hacker, Code, Monospace, CLI | **terminal** | 개발자 에스테틱, 모노스페이스 |
| Glassmorphism, Frosted, Blur | minimal or elegant | 투명 레이어 기반 — 컨텍스트에 따라 |
| Neumorphism, Soft UI, 3D | elegant | 부드러운 입체감, 섬세한 그림자 |
| Retro, Vintage, 80s, Neon | bold or playful | 레트로 톤에 따라 |
| Dark Mode Focus, Cyberpunk | terminal or bold | 어두운 배경 기반 |
| Corporate, Enterprise, Professional | minimal or elegant | 비즈니스 맥락에 따라 |
| Editorial, Magazine, Typography-First | elegant | 타이포 중심 레이아웃 |
| Dashboard, Data-Heavy, Analytics | minimal | 정보 밀도 최적화 |
| E-commerce, Shop, Marketplace | playful or elegant | 전환율 최적화 목표에 따라 |
| SaaS, Product, Tool | minimal | 기능 중심 깔끔한 인터페이스 |
| Portfolio, Creative, Agency | bold or elegant | 크리에이티브 방향에 따라 |

## 사용법

1. products.csv에서 매칭된 Product Type의 Primary Style Recommendation 확인
2. reasoning.csv에서 해당 UI_Category의 Style_Priority 확인
3. 위 테이블에서 가장 근접한 키워드 매칭 → 추천 페르소나 도출
4. 복수 페르소나 후보 시 → reasoning.csv의 Color_Mood + Typography_Mood로 최종 결정

## 최종 결정 권한

- 이 테이블은 **추천**이지 **강제**가 아닙니다
- AI가 사용자 요구를 종합 판단하여 최종 페르소나를 선택합니다
- 매칭 실패 시 기존 방식(AI 판단)으로 폴백합니다
