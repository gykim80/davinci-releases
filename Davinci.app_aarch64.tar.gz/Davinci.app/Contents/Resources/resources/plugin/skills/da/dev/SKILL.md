---
name: dev
description: Implementation and development execution based on design specifications
agent: bkend-expert
agents: [senior-fullstack, senior-architect]
davinci-phase: do
allowed-tools: [Write, Edit, Read, Bash, Glob, Grep, Task]
next-skill: verify
skill-type: flexible
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 생성자: 자기 검증은 사전 점검일 뿐이다. 최종 판정은 독립 verify 노드가 낸다. 미완료 시 partial + remaining.

## Tool Parameter Rules -> See CLAUDE.md (ABSOLUTE)

## Domain Context Protocol
checkpoint.domain_context가 존재하면, 코드 변수명/함수명/주석/UI 텍스트에 CONTEXT.md에 정의된 용어를 사용하라. Avoid 목록의 용어는 사용 금지.

docs/domain/DOMAIN-MODEL.md가 존재하면 (da:domain 호출된 경우) 추가로:
- Aggregate Root 경계를 존중한다 — 하위 Entity/VO는 Root를 통해서만 접근/변경
- 각 Invariant를 구현 시 실제 가드(조건 분기/assert)로 반영한다
- Bounded Context 경계를 넘는 직접 참조를 피한다 — Context Map에 정의된 관계로만 통신
- DOMAIN-MODEL.md의 Directory Scaffold가 제안된 경우 해당 레이어 구조(domain/application/adapters/composition)를 따른다 (references/hexagonal-scaffold.md 규칙)

구현 완료 후, complexity_estimate가 MODERATE 이상이면 `da:arch-verify`를 호출하여 레이어 위반·ADR 준수 여부를 검증한다 (LIGHT/SIMPLE은 스킵 — 오버헤드 방지).

## PRD-Driven Task Execution (Brief-Gate Integration)

사용자 메시지에 `[PRD_CONTEXT]` 블록이 존재하면, da:dev는 PRD를 권위 있는 입력으로 사용해 다음 규칙에 따라 작업을 수행한다.

```yaml
PRD_Context_Detection:
  trigger: "사용자 메시지에 [PRD_CONTEXT] ~ [/PRD_CONTEXT] 블록이 존재"
  source: "davinci-gui brief-gate (PrdReviewPanel approve → context-bridge)"

PRD_Driven_Execution_Rules:
  1_Page_Section_to_Scope:
    - sub-PRD의 각 page section을 파일/컴포넌트 범위로 매핑
    - 예: "Login Page" section → src/app/(auth)/login/page.tsx + src/components/auth/LoginForm.tsx
    - 페이지가 컴포넌트 분해를 요구하면 components/ 하위 디렉토리에 배치
  2_AC_to_Verifiable_Check:
    - 각 acceptance criteria(AC)를 검증 가능한 테스트/체크로 변환
    - 검증 형태(우선순위 순):
      a) Vitest/Jest unit/integration test
      b) Playwright E2E test (UI 흐름 AC)
      c) 코드 내 assert/runtime check (런타임 invariant)
      d) 수동 체크리스트 (자동화 불가능 시 마지막 수단)
  3_AC_Tracking_Per_File:
    - 구현하는 각 파일별로 어떤 AC를 충족하는지 추적
    - 파일 상단 주석 또는 PR description에 "Covers: AC-1, AC-3" 형태로 기록
  4_Surface_Unimplemented_TODOs:
    - 미구현 AC는 handoff에 TODO로 명시
    - 사유 카테고리: blocked(외부 의존), deferred(범위 외), incomplete(시간 부족)

PRD_Handoff_Schema_Extension:
  acceptance_criteria_status:
    type: array
    items:
      ac: string                # AC 식별자 (예: "AC-1")
      page: string              # sub-PRD page section 이름
      status: enum              # "completed" | "partial" | "todo" | "blocked"
      evidence: string          # 검증 증거 (테스트 파일 경로, 커밋 SHA, 또는 설명)
  prd_source: string            # PRD 마크다운 경로 (da:plan에서 전달받음)
```

PRD_CONTEXT 블록이 없는 경우 기존 da:dev 흐름(Phase 0 ~ Phase 4)을 100% 그대로 유지한다. backward compatible.

# /da:dev - Feature Implementation

## da:clone Context Injection

da:clone v2 파이프라인에서 호출될 때 추가 컨텍스트를 받는다:
- **system-spec.json**: 유추된 앱 시스템, 데이터 모델, 화면 맵
- **element-map.json**: UI 요소 좌표/크기/z_index/레이아웃 정보
- **assets/**: 이미 생성된 에셋 PNG 파일

system-spec.json이 존재하면:
1. `inferred_systems` 기반으로 앱 로직 구현
2. `screen_map`의 `has_reference` 화면은 element-map.json 좌표로 레이아웃
3. `data_model` 기반으로 TypeScript 인터페이스 생성
4. assets/ PNG를 적절한 컴포넌트에 import (placeholder 금지)
5. React TSX + Tailwind 출력 (element-map.json palette 참조)

ultrathink

> **🧠 EXTENDED THINKING ACTIVATED**: This command uses Claude's maximum depth reasoning mode.
> Claude MUST think step-by-step with deep analysis before writing any code.

## Extended Thinking Protocol
- **Understand**: Fully understand the requirements
- **Plan**: Design optimal approach before implementation
- **Consider**: Consider edge cases and error handling
- **Implement**: Write code according to plan

---

## 🤖 16 SPECIALIZED AGENTS

### Agent Auto-Activation Matrix
```yaml
Trigger_Keywords → Agent_Activation:

Frontend_Development:
  Keywords: ["UI", "component", "React", "Vue", "CSS", "animation"]
  Agents: [frontend-architect]
  MCP: [aside]

Backend_Development:
  Keywords: ["API", "server", "database", "query", "REST", "GraphQL"]
  Agents: [backend-architect, python-expert]
  MCP: [sequential]

Security_Implementation:
  Keywords: ["auth", "login", "permission", "token", "encrypt", "secure"]
  Agents: [security-engineer]
  MCP: []

Performance_Critical:
  Keywords: ["optimize", "performance", "cache", "fast", "memory", "scale"]
  Agents: [performance-engineer]
  MCP: [sequential]

Infrastructure:
  Keywords: ["deploy", "docker", "kubernetes", "CI/CD", "pipeline"]
  Agents: [devops-architect]
  MCP: []

Refactoring:
  Keywords: ["refactor", "clean", "restructure", "improve", "legacy"]
  Agents: [refactoring-expert]
  MCP: [codegraph]

Full_Stack_Feature:
  Keywords: ["feature", "full-stack", "end-to-end", "complete"]
  Agents: [frontend-architect, backend-architect, security-engineer]
  MCP: [sequential, aside]
```

### Agent Profiles

#### Frontend Architect
```yaml
Expertise: Client-side architecture and UI patterns
Focus:
  - Component hierarchy and state management
  - React/Vue/Angular best practices via WebFetch(공식 문서)
  - Accessibility (WCAG 2.1 AA)
  - Performance: code splitting, lazy loading
Tools: WebFetch(공식 문서) for framework patterns, Aside MCP for browser debugging (da:protocol §11), Playwright test runner for E2E specs
```

#### Backend Architect
```yaml
Expertise: Server-side architecture and data layer
Focus:
  - API design (REST, GraphQL, gRPC)
  - Database optimization
  - Caching strategies
  - Async processing patterns
Tools: WebFetch(공식 문서) for framework patterns
```

#### Security Engineer
```yaml
Expertise: Security implementation and threat prevention
Focus:
  - Authentication/Authorization patterns
  - Input validation and sanitization
  - OWASP Top 10 prevention
  - Data encryption and protection
Mandatory_Checks:
  - SQL injection prevention
  - XSS protection
  - CSRF tokens
  - Secure headers
```

#### Performance Engineer
```yaml
Expertise: Optimization and scalability
Focus:
  - Algorithm optimization (Big O analysis)
  - Database query optimization
  - Memory management
  - Caching strategies
Tools: Sequential MCP for complex analysis
```

#### Quality Engineer
```yaml
Expertise: Testing and code quality
Focus:
  - Test strategy (unit, integration, E2E)
  - Code coverage optimization
  - Edge case identification
  - Error handling patterns
Tools: Aside MCP(`dv.open` → `dv.report()`) for runtime/UI debugging, `npx playwright test` for E2E specs
```

#### DevOps Architect
```yaml
Expertise: Infrastructure and deployment
Focus:
  - CI/CD pipeline implementation
  - Container configuration
  - Infrastructure as Code
  - Monitoring and alerting
```

#### Python Expert
```yaml
Expertise: Python-specific implementation
Focus:
  - Pythonic patterns and idioms
  - Type hints and mypy compliance
  - Async/await patterns
  - Package structure
```

#### Refactoring Expert
```yaml
Expertise: Code improvement and modernization
Focus:
  - Legacy code modernization
  - Design pattern application
  - Technical debt reduction
  - Safe incremental refactoring
Tools: CodeGraph MCP for symbol operations
```

#### PM Agent (Meta-Layer)
```yaml
Role: Continuous learning and documentation
Actions:
  - Post-implementation documentation
  - PDCA cycle monitoring
  - Pattern extraction
  - Mistake prevention
```

#### Self-Review Agent
```yaml
Role: Code quality self-assessment
Actions:
  - Pre-commit code review
  - Best practice verification
  - Security audit
  - Performance review
```

---

## 🚀 PARALLEL EXECUTION ENGINE

### Wave → Checkpoint → Wave Pattern
```yaml
Parallel_Triggers:
  - 3+ files to read → Batch Read calls
  - Multiple independent edits → Parallel Edit
  - Multi-directory scope → Task delegation

Execution_Pattern:
  Wave_1 (Parallel):
    - Read all relevant files concurrently
    - Gather context from multiple sources
    - Check existing implementations

  Checkpoint:
    - Analyze gathered information
    - Plan implementation strategy
    - Identify dependencies

  Wave_2 (Parallel):
    - Edit/Write files concurrently
    - Generate related tests
    - Update documentation

Performance:
  - 3.5x faster than sequential execution
  - Automatic dependency analysis
  - Smart batching of operations
```

### Parallel Execution Examples
```yaml
Example_1_Component_Implementation:
  Wave_1:
    - Read: existing component patterns
    - Read: design system tokens
    - Read: related components
  Checkpoint:
    - Analyze patterns
    - Plan component structure
  Wave_2:
    - Write: component file
    - Write: component tests
    - Write: storybook story

Example_2_API_Implementation:
  Wave_1:
    - Read: API spec
    - Read: existing endpoints
    - Read: database schema
  Checkpoint:
    - Plan endpoint structure
    - Design validation
  Wave_2:
    - Write: controller
    - Write: service layer
    - Write: tests
```

---

## 🎭 ORCHESTRATION MODE

`UI: WebFetch(공식 문서)+Skills | Patterns: WebFetch(공식 문서) | Symbols: CodeGraph | Logic: Sequential | Browser: Aside MCP | Testing: Playwright runner | Research: WebSearch`

---

## 🔄 PM AGENT INTEGRATION

### Implementation PDCA Cycle
```yaml
Plan (Before Implementation):
  Actions:
    - Document implementation plan
    - Define success criteria
    - Identify risks and edge cases
  Memory:
    - write_memory("impl_plan", plan)

Do (During Implementation):
  Actions:
    - Execute parallel waves
    - Checkpoint progress
    - Record decisions
  Memory:
    - write_memory("checkpoint", progress) every major milestone

Check (After Implementation):
  Actions:
    - think_about_task_adherence()
    - Verify against design spec
    - Run self-review agent
  Questions:
    - "Does implementation match design?"
    - "Are all edge cases handled?"
    - "Is security properly implemented?"

Act (Finalization):
  Success:
    - Document patterns in docs/patterns/
    - Update CLAUDE.md if global pattern
  Failure:
    - Create docs/mistakes/impl-issue-*.md
    - Document prevention checklist
```

---

## Triggers
- Feature development requests for components, APIs, or complete functionality
- Code implementation needs with framework-specific requirements
- Multi-domain development requiring coordinated expertise
- Implementation projects requiring testing and validation integration

## Usage
```
/da:dev [feature-description] [--type component|api|service|feature] [--framework react|vue|express] [--safe] [--with-tests] [--parallel]
```

---

## Behavioral Flow

### Phase 0: Template Bootstrap (조건부 실행)

```yaml
Trigger: PLAN.md (또는 프로젝트 계획 문서)에 "## Template Foundation" 섹션이 존재할 때
Skip_If: frontend_template == "none" AND backend_template 미지정
Skip_If: Template Foundation 섹션 자체가 없으면 → Phase 1로 직접 진행 (기존 방식 100% 유지)

Steps:
  0-1_Parse_Template_Foundation:
    - PLAN.md에서 ## Template Foundation 섹션 파싱
    - frontend_template, backend_template, strategy 값 추출

  0-2_Frontend_Copy:
    condition: frontend_template != "none" AND frontend_template 존재
    source: "{davinci-framework}/davinci-templates/nextjs/{frontend_template}/"
    target: "{project_dir}/" 또는 "{project_dir}/frontend/" (백엔드와 함께 사용 시)
    command: |
      rsync -a --exclude 'node_modules' --exclude '.next' --exclude '.git' \
        {source} {target}
    verify: "ls {target}/package.json"  # 복사 성공 확인

  0-3_Backend_Copy:
    condition: backend_template 존재
    source: "{davinci-framework}/davinci-templates/backend/{backend_template}/"
    target: "{project_dir}/backend/"
    command: |
      rsync -a --exclude 'node_modules' --exclude '__pycache__' \
        --exclude 'target' --exclude 'vendor' --exclude '.git' \
        {source} {target}
    verify: 언어별 매니페스트 파일 존재 확인
      - Node: "ls {target}/package.json"
      - Python: "ls {target}/pyproject.toml || ls {target}/requirements.txt"
      - Go: "ls {target}/go.mod"

  0-4_Dependency_Install:
    frontend: "cd {frontend_dir} && npm install"  # 또는 pnpm install
    backend: 언어별 설치
      - Node: "cd {backend_dir} && npm install"
      - Python: "cd {backend_dir} && uv pip install -r requirements.txt"
      - Go: "cd {backend_dir} && go mod download"

  0-5_Initial_Build_Verify:
    frontend: "cd {frontend_dir} && npm run build"
    backend: 언어별 빌드
      - Node: "cd {backend_dir} && npm run build"
      - Python: "cd {backend_dir} && uv run python -c 'import app'"  # 기본 임포트 테스트
      - Go: "cd {backend_dir} && go build ./..."
    on_failure: 에러 메시지 분석 → 수정 → 재시도 (최대 3회)

  0-6_Proceed:
    success: "Template Bootstrap 완료. Phase 1 (Analyze) 진행."
    failure_after_retries: "빌드 실패 보고 후 Phase 1 진행 (수동 수정 필요)"
```

### Phase 0.5: Design Artifact Loading (조건부 실행)

```yaml
Trigger: checkpoint에 design_pregenerated=true가 설정되어 있을 때
Skip_If: design_pregenerated가 false이거나 필드 자체가 없으면 → Phase 1로 직접 진행 (기존 흐름 100% 유지)

Steps:
  0.5-1_Check_Checkpoint:
    - checkpoint에서 design_pregenerated 값 확인
    - false 또는 미존재 → Phase 1로 직접 진행 (backward compatible)
    - true → design_artifact_session_id 값 추출

  0.5-2_Locate_Artifacts:
    - artifact_dir: ".davinci/artifacts/{design_artifact_session_id}/"
    - Glob("{artifact_dir}/*.tsx")로 모든 디자인 TSX 파일 목록 수집
    - 파일이 0개면 경고 출력 후 Phase 1로 진행

  0.5-3_Load_Design_TSX:
    - 각 TSX 파일을 Read로 로드
    - 컨텍스트에 다음 포맷으로 주입:
      "DESIGN_ARTIFACT[{filename}]: {tsx content}"
    - 예시: "DESIGN_ARTIFACT[Home.tsx]: export default function App() { ... }"
    - 예시: "DESIGN_ARTIFACT[Dashboard.tsx]: export default function App() { ... }"

  0.5-4_Load_Design_Tokens:
    - "{artifact_dir}/design.tokens.json" 존재 여부 확인
    - 존재 시 Read로 로드 → DTCG 토큰 파싱
    - 미존재 시 TSX 파일에서 색상값, 폰트명 등 토큰 추출 (fallback)

  0.5-5_Proceed:
    success: "Design Artifact {N}개 로드 완료. Phase 1 (Analyze) 진행."
    log: 로드된 파일 목록 + 토큰 존재 여부 출력
```

### Phase 0.5-A: TSX-to-Production Conversion Protocol

```yaml
Trigger: Phase 0.5에서 DESIGN_ARTIFACT가 1개 이상 로드되었을 때
Purpose: 디자인 TSX를 프로덕션 코드 베이스로 변환하는 규칙 정의

Conversion_Rules:

  Rule_1_Copy_and_Decompose:
    description: 디자인 TSX는 단일 export default function App() 형태 — 이를 분해
    steps:
      - 디자인 TSX를 프로젝트의 적절한 위치에 복사
        - Next.js App Router: src/app/{route}/page.tsx
        - Next.js Pages Router: src/pages/{route}.tsx
        - React Router: src/pages/{PageName}.tsx
        - Vite: src/pages/{PageName}.tsx
      - 단일 App() 컴포넌트를 분해:
        - 재사용 가능 컴포넌트 추출 → src/components/
          - Header, Footer, Navbar → src/components/layout/
          - Card, Hero, CTA → src/components/ui/
          - Form, Input, Button (프로젝트에 shadcn/ui 있으면 기존 것 사용)
        - 페이지 고유 레이아웃은 page 파일에 유지
      - 분해 판단 기준:
        - 2회 이상 반복되는 패턴 → 컴포넌트로 추출
        - 50줄 이상의 독립 섹션 → 컴포넌트로 추출
        - 다른 페이지에서 재사용 가능한 UI → 컴포넌트로 추출

  Rule_2_Add_Infrastructure:
    description: 디자인 TSX에 없는 프로덕션 인프라 추가
    steps:
      - 라우팅 연결:
        - Next.js: App Router file-based routing + Link 컴포넌트
        - React Router: Route 정의 + useNavigate/Link
      - 상태 관리:
        - zustand store 또는 React Context 연결
        - 페이지 간 공유 상태 식별 및 store 생성
      - API 통합:
        - fetch/SWR/React Query로 데이터 페칭 추가
        - 로딩/에러 상태 UI 추가 (디자인 TSX의 레이아웃 유지)
      - 폼 처리:
        - react-hook-form 또는 native form 핸들링
        - zod/yup 유효성 검증 추가

  Rule_3_Style_Migration:
    description: Tailwind CDN 클래스를 프로젝트 설정으로 전환
    steps:
      - Tailwind CDN 전용 클래스 → 프로젝트 tailwind.config 확인 후 동등 매핑
      - 커스텀 색상값 (hex/rgb 인라인) → tailwind.config.ts theme.extend 또는 CSS variable로 이동
      - iframe 전용 코드 제거:
        - postMessage 관련 코드 제거
        - EDITMODE 마커/조건부 렌더링 제거
        - window.parent 참조 제거

  Rule_4_Preservation:
    description: 원본 디자인 TSX 보존
    rules:
      - .davinci/artifacts/ 내 원본 파일 절대 삭제/수정 금지
      - 변환된 파일에 출처 주석 추가:
        "// Converted from design artifact: .davinci/artifacts/{session_id}/{filename}"
      - 디자인과 프로덕션 간 시각적 차이 최소화가 최우선 목표

  Priority_Order:
    1: 시각적 충실도 (Visual Fidelity) — 디자인 TSX의 레이아웃/스타일 최대한 보존
    2: 기능 추가 (Functionality) — 라우팅, 상태, API 연결
    3: 코드 품질 (Code Quality) — 컴포넌트 분해, 타입 안전성
```

### Phase 0.5-B: Design Token Injection Protocol

```yaml
Trigger: Phase 0.5에서 artifact 디렉토리가 확인되었을 때
Purpose: DTCG 디자인 토큰을 프로젝트 설정에 반영

Token_Source_Priority:
  1: "{artifact_dir}/design.tokens.json" (DTCG 표준 형식)
  2: TSX 파일 내 인라인 값 추출 (fallback)

DTCG_Token_Application:

  Target_1_Tailwind_Config:
    file: tailwind.config.ts (또는 tailwind.config.js)
    mapping:
      - "$type": "color" → theme.extend.colors
        - 예: "primary.500": "#3B82F6" → colors: { primary: { 500: "#3B82F6" } }
      - "$type": "fontFamily" → theme.extend.fontFamily
        - 예: "sans": ["Inter", "system-ui"] → fontFamily: { sans: ["Inter", "system-ui"] }
      - "$type": "dimension" / "spacing" → theme.extend.spacing
        - 예: "space.md": "16px" → spacing: { md: "16px" }
      - "$type": "borderRadius" → theme.extend.borderRadius
      - "$type": "shadow" → theme.extend.boxShadow

  Target_2_CSS_Variables:
    file: src/app/globals.css 또는 src/index.css
    format: |
      :root {
        --color-primary: {token_value};
        --font-sans: {token_value};
        --spacing-md: {token_value};
      }
    dark_mode: |
      .dark {
        --color-primary: {dark_token_value};
      }

  Target_3_Component_Constants:
    description: 컴포넌트 레벨 스타일 상수
    file: src/lib/design-tokens.ts (필요 시 생성)
    format: |
      export const tokens = {
        colors: { primary: "var(--color-primary)" },
        fonts: { sans: "var(--font-sans)" },
      } as const;

  Fallback_TSX_Extraction:
    description: design.tokens.json 미존재 시 TSX에서 토큰 추출
    extract:
      - 색상값: hex (#XXXXXX), rgb(), hsl() 패턴 수집 → 빈도순 정렬 → primary/secondary/accent 매핑
      - 폰트명: font-family, className의 font-* 클래스에서 추출
      - 간격값: p-*, m-*, gap-* 등 Tailwind spacing 클래스 패턴 분석
    output: 추출된 토큰을 tailwind.config + CSS variables에 반영 (Target_1, Target_2와 동일 절차)
```

### Phase 1: Analyze
```yaml
1. Context_Detection:
   - Detect technology stack from codebase
   - Identify relevant design documents
   - Check for existing patterns

2. Agent_Selection:
   - Match keywords to agent profiles
   - Activate relevant personas
   - Configure MCP servers
```

### Phase 2: Plan
```yaml
1. Implementation_Strategy:
   - Define file structure
   - Plan component/module boundaries
   - Identify parallel opportunities

2. PDCA_Initiation:
   - Create implementation plan
   - write_memory("impl_plan", plan)
```

### Phase 3: Execute
```yaml
1. Wave_Execution:
   - Run parallel operations where possible
   - Use Orchestration Mode tool selection
   - Apply agent expertise

2. Quality_Gates:
   - Security validation by security-engineer
   - Performance check by performance-engineer
   - Code review by self-review agent
```

### Phase 4: Complete
```yaml
1. Self_Check:
   - think_about_whether_you_are_done()
   - Verify all acceptance criteria

2. Documentation:
   - Update docs/patterns/ if new pattern
   - Record implementation decisions
   - write_memory("impl_session", summary)
```

---

## Examples

### React Component Development
```
/da:dev user profile component --type component --framework react --with-tests
# Agents: frontend-architect, quality-engineer
# MCP: WebFetch(공식 문서) (React patterns), Playwright (E2E)
# Parallel: component + tests + story in Wave 2
```

### Secure API Endpoint
```
/da:dev user authentication API --type api --safe --with-tests
# Agents: backend-architect, security-engineer, quality-engineer
# MCP: WebFetch(공식 문서) (framework), Sequential (auth logic)
# Security checks: OWASP Top 10 validation
```

### Full-Stack Feature
```
/da:dev payment processing system --type feature --parallel
# Agents: frontend-architect, backend-architect, security-engineer
# MCP: All (full coordination)
# Parallel execution across frontend/backend
```

### Legacy Refactoring
```
/da:dev modernize user service --type service
# Agents: refactoring-expert, backend-architect
# MCP: CodeGraph (symbol ops) (patterns)
```

---

## Boundaries

**Will:**
- Implement features with intelligent agent activation and MCP coordination
- Apply framework-specific best practices and security validation
- Execute parallel operations for optimal performance
- Document patterns and learnings

**Will Not:**
- Make architectural decisions without design specification
- Implement features conflicting with security policies
- Skip quality gates or bypass safety constraints

---

## COMPLETION CRITERIA

**Implementation is DONE when** (da:protocol §2.2 / §3.1 — 각 항목은 evidence 필수):
- Feature code is written and compiles → evidence: `tsc --noEmit`/빌드 명령 + exit code
- Tests written (if --with-tests) and executed → evidence: 러너 출력 passed/failed 카운트
- Acceptance ledger(docs/.da-acceptance.json) 해당 Phase 항목의 `check` 명령을 실행하고 결과를 evidence에 기록 (passes 갱신은 da:verify가 한다)
- Files saved → evidence: 파일 경로 목록

**Post-Implementation Self-Check** (사전 점검 — 최종 판정이 아니다, §3.2):
1. Code compiles without errors (명령 출력 첨부)
2. Basic functionality exercised (실행/호출 근거 첨부)
3. Security checks run (도구 출력 첨부)
4. PM Agent documentation updated
5. Handoff JSON 반환: `status`(completed | partial + remaining[] | blocked + blockers[]), `evidence[]`, `implementation{}`, `todos{}`

**Partial 규칙 (§2.3)**: 남은 작업이 있으면 "완료"라고 쓰지 말고 `status: partial` + `remaining[]`로 반환한다. 오케스트레이터가 새 컨텍스트로 같은 Phase를 재개한다. Context 사용량 추정으로 조기 종료하지 않는다.

**Next Step**: Use `/da:verify` to validate, then commit.

---

## 🎯 SKILL-BASED DEVELOPMENT

### Agent-Skills Integration
Davinci integrates with Vercel Engineering's agent-skills for framework-specific best practices.

```yaml
Skills_Location: agent-skills/skills/
Available_Skills:
  - react-best-practices: 69 rules (async, bundle, server, client, rerender, rendering, js, advanced)
  - composition-patterns: 8 rules (architecture, state, patterns, react19)
  - react-native-skills: 40+ rules (list-performance, animation, navigation, ui)
  - web-design-guidelines: External (WCAG, accessibility, UX)
  - react-view-transitions: View Transition API (<ViewTransition>, addTransitionType, CSS pseudo-elements)
```

### Framework → Skill Auto-Activation

```yaml
Framework_Detection:
  # Reads package.json to detect framework
  Dependencies_To_Check:
    - "next", "react" → react-best-practices + composition-patterns
    - "expo", "react-native" → react-native-skills
    - Web UI work → web-design-guidelines

Skill_Activation_Matrix:
  | Framework | Skills | Priority Rules |
  |-----------|--------|----------------|
  | React/Next.js | react-best-practices | async-parallel, bundle-dynamic-imports, rerender-memo |
  | React/Next.js | composition-patterns | architecture-avoid-boolean-props, architecture-compound-components |
  | React/Next.js | react-view-transitions | shared-element, directional-nav, suspense-reveal |
  | React Native | react-native-skills | list-performance-virtualize, animation-gpu-properties |
  | Web UI | web-design-guidelines | WCAG compliance, color contrast |
```

### Task-Based Rule Loading (Token Efficient)

```yaml
# Load only relevant rules based on task description

API_Development:
  Keywords: [API, endpoint, server, fetch, route]
  Categories: [async-, server-]
  Rules_Loaded: 12 (not 57)

Component_Development:
  Keywords: [component, UI, button, form, modal]
  Categories: [rerender-, rendering-, architecture-]
  Rules_Loaded: 25

List_Development:
  Keywords: [list, table, grid, virtualized, scroll]
  Categories: [list-performance-, rendering-]
  Rules_Loaded: 12

Animation_Development:
  Keywords: [animation, motion, transition, gesture]
  Categories: [animation-]
  Rules_Loaded: 5

View_Transition_Development:
  Keywords: [view transition, page transition, shared element, route animation, ViewTransition]
  Categories: [react-view-transitions/*]
  Rules_Loaded: 4 (implementation, patterns, css-recipes, nextjs)

Architecture_Work:
  Keywords: [refactor, architecture, pattern, structure]
  Categories: [architecture-, state-, patterns-]
  Rules_Loaded: 8
```

### Skill Application Flow

```yaml
Step_1_Framework_Detection:
  - Read package.json in project root
  - Identify: next, react, expo, react-native
  - Map to skill sets

Step_2_Task_Analysis:
  - Parse user request for keywords
  - Match keywords to rule categories
  - Determine which rules to load

Step_3_Rule_Loading:
  - Read agent-skills/skills/{skill}/SKILL.md (Quick Reference)
  - If detailed rules needed: Read agent-skills/skills/{skill}/rules/{rule}.md
  - Cache loaded rules for session

Step_4_Code_Generation:
  - Apply loaded rules during implementation
  - Cite applied rules in code comments
  - Report applied rules at completion
```

### Rule Citation Format

When applying a skill rule, cite it in generated code:

```typescript
// Applied: rerender-memo (react-best-practices)
// Prevents unnecessary re-renders by memoizing with stable comparison
const MemoizedItem = React.memo(ListItem, (prev, next) =>
  prev.id === next.id && prev.status === next.status
);

// Applied: async-parallel (react-best-practices)
// Uses Promise.all for independent operations to eliminate waterfalls
const [user, posts, comments] = await Promise.all([
  fetchUser(id),
  fetchPosts(id),
  fetchComments(id)
]);

// Applied: list-performance-virtualize (react-native-skills)
// Uses FlashList for optimal list performance
import { FlashList } from "@shopify/flash-list";
```

### Skill Rule Reference

For full rule details, read the agent-skills files:

```yaml
React_Best_Practices:
  SKILL.md: agent-skills/skills/react-best-practices/SKILL.md
  Rules: agent-skills/skills/react-best-practices/rules/*.md
  Categories:
    - async-*: Eliminating Waterfalls (CRITICAL)
    - async-suspense-*: Suspense Boundaries (CRITICAL)
    - bundle-*: Bundle Size Optimization (CRITICAL)
    - server-*: Server-Side Performance (HIGH)
    - server-after-*: Non-blocking Server Actions (HIGH)
    - client-*: Client-Side Data Fetching (MEDIUM-HIGH)
    - rerender-*: Re-render Optimization (MEDIUM)
    - rendering-*: Rendering Performance (MEDIUM)
    - rendering-activity-*: Activity API (MEDIUM)
    - rendering-usetransition-*: useTransition Loading (MEDIUM)
    - rendering-resource-*: Resource Preloading (MEDIUM)
    - js-*: JavaScript Performance (LOW-MEDIUM)
    - advanced-*: Advanced Patterns (LOW)
    - advanced-effect-*: Effect Optimization (LOW)

Composition_Patterns:
  SKILL.md: agent-skills/skills/composition-patterns/SKILL.md
  Rules: agent-skills/skills/composition-patterns/rules/*.md
  Categories:
    - architecture-*: Component Architecture (HIGH)
    - state-*: State Management (MEDIUM)
    - patterns-*: Implementation Patterns (MEDIUM)
    - react19-*: React 19 APIs (MEDIUM)

React_Native_Skills:
  SKILL.md: agent-skills/skills/react-native-skills/SKILL.md
  Rules: agent-skills/skills/react-native-skills/rules/*.md
  Categories:
    - list-performance-*: List Performance (CRITICAL)
    - animation-*: Animation (HIGH)
    - navigation-*: Navigation (HIGH)
    - ui-*: UI Patterns (HIGH)
    - react-state-*: State Management (MEDIUM)

Web_Design_Guidelines:
  SKILL.md: agent-skills/skills/web-design-guidelines/SKILL.md
  Source: https://github.com/vercel-labs/web-interface-guidelines

React_View_Transitions:
  SKILL.md: agent-skills/skills/react-view-transitions/SKILL.md
  AGENTS.md: agent-skills/skills/react-view-transitions/AGENTS.md
  References:
    - agent-skills/skills/react-view-transitions/references/implementation.md
    - agent-skills/skills/react-view-transitions/references/patterns.md
    - agent-skills/skills/react-view-transitions/references/css-recipes.md
    - agent-skills/skills/react-view-transitions/references/nextjs.md
  Patterns:
    - shared-element: Same-name VT morphing across views (HIGH)
    - directional-nav: Type-keyed forward/back slides (HIGH)
    - suspense-reveal: Enter/exit on data load (MEDIUM)
    - list-reorder: Per-item key identity animations (MEDIUM)
    - route-change: Layout-level page transitions (MEDIUM)
  Source: https://github.com/vercel-labs/agent-skills
```

### Examples with Skills

```bash
# React component with skill rules
/da:dev user profile card --type component --framework react
# Auto-applies:
#   - rerender-memo (prevent unnecessary re-renders)
#   - rendering-hoist-jsx (extract static JSX)
#   - architecture-avoid-boolean-props (use composition)

# React Native list with skill rules
/da:dev infinite scroll feed --type component --framework react-native
# Auto-applies:
#   - list-performance-virtualize (use FlashList)
#   - list-performance-item-memo (memoize items)
#   - animation-gpu-properties (transform/opacity only)

# API endpoint with skill rules
/da:dev user data API --type api --framework next
# Auto-applies:
#   - async-parallel (Promise.all for independent fetches)
#   - server-cache-react (React.cache for deduplication)
#   - server-parallel-fetching (restructure for parallelism)

# Page transitions with view transitions
/da:dev photo gallery with page transitions --type feature --framework next
# Auto-applies:
#   - react-view-transitions/shared-element (image morph list->detail)
#   - react-view-transitions/directional-nav (forward/back slides)
#   - react-view-transitions/css-recipes (ready-to-use animations)
```
