---
name: domain
description: "도메인 모델링 심화 -- 바운디드 컨텍스트 식별, 엔티티/VO/애그리게잇/불변식/컨텍스트 맵 추출, DOMAIN-MODEL.md 생성 (CONTEXT.md 상위 확장). da:plan Step 2.5에서 MODERATE+ 복잡도 또는 다중 바운디드 컨텍스트 감지 시 호출됨"
agent: senior-architect
agents: [senior-fullstack]
davinci-phase: plan
allowed-tools: [Write, Edit, Read, Glob, Grep]
next-skill: system
skill-type: flexible
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 생성자: 자기 검증은 사전 점검일 뿐이다. 최종 판정은 독립 verify 노드가 낸다. 미완료 시 partial + remaining.

## Tool Parameter Rules -> See CLAUDE.md (ABSOLUTE)
# /da:domain - 도메인 모델링 심화 (Domain Model Layer)

## Role in DAVINCI Workflow
```yaml
Position: da:plan Step 2.5 "Domain Context Gate"의 심화 경로.
  LIGHT/SIMPLE은 CONTEXT.md(용어 사전)만으로 충분하지만, MODERATE 이상이거나
  다중 바운디드 컨텍스트가 감지되면 da:domain으로 승격 호출된다.
Input: PLAN.md / REQUIREMENTS.md, 기존 CONTEXT.md (있으면)
Output: docs/domain/DOMAIN-MODEL.md -- CONTEXT.md의 상위 확장 (용어 → 엔티티/VO/불변식/컨텍스트맵)
Handoff_To: da:system (바운디드 컨텍스트 경계를 C4 컨테이너 경계 후보로 사용)
          da:dev (Domain Context Protocol이 DOMAIN-MODEL.md의 불변식을 구현 제약으로 사용)
```

## Escalation Trigger (CONTEXT.md -> DOMAIN-MODEL.md)

```yaml
Escalate_When (하나라도 해당):
  - 도메인 용어가 20개 초과 (CONTEXT.md 용량 제한 초과)
  - 서로 다른 소유권/라이프사이클을 가진 하위 도메인이 2개 이상 식별됨
  - 기획 문서에 "바운디드 컨텍스트", "마이크로서비스", "모듈 분리" 언급
  - Flagged Ambiguities(동일 용어의 다의성)가 3개 이상
  - complexity_estimate가 MODERATE 이상 (da:plan Complexity Pre-Classification 참조)

Skip_When:
  - LIGHT/SIMPLE 복잡도 & 바운디드 컨텍스트 1개 이하 -> CONTEXT.md만으로 충분
  - CLI/스크립트 전용 프로젝트
```

## Execution Steps

```yaml
1_Load_Existing:
  - Glob("CONTEXT.md") -> 있으면 Read, 없으면 da:plan Step 2.5의 Extract_Terms부터 재수행

2_Identify_Entities_VOs:
  Entity: 식별자(ID)를 가지고 생명주기 동안 상태가 변하는 개념 (예: Order, User)
  Value_Object: 식별자 없이 속성 값 자체로 동일성이 결정되는 불변 개념 (예: Money, Address)
  Aggregate: 하나의 Entity(Aggregate Root)가 관련 Entity/VO를 트랜잭션 일관성 경계로 묶은 단위

3_Extract_Invariants:
  - 각 Aggregate가 "항상" 지켜야 하는 규칙을 자연어 문장으로 기록
  - 예: "주문은 결제 완료 전에는 배송 상태로 전이할 수 없다"
  - 이 규칙은 이후 da:arch-verify의 검증 대상이 된다

4_Identify_Bounded_Contexts:
  - 서로 다른 유비쿼터스 언어/소유권/라이프사이클을 가진 용어 클러스터를 그룹핑
  - 각 클러스터에 컨텍스트 이름 부여 (예: "주문 컨텍스트", "결제 컨텍스트")

5_Build_Context_Map:
  - 컨텍스트 간 관계 패턴 명시: Shared Kernel / Customer-Supplier / Conformist /
    Anticorruption Layer / Partnership
  - 관계 방향(누가 누구에게 의존하는가)을 화살표로 기록

6_Propose_Directory_Scaffold (optional -- MODERATE+ & 사용자 동의 시):
  - references/hexagonal-scaffold.md 패턴 적용
  - src/features/<bounded-context>/{domain, application/ports, application/use-cases,
    adapters, composition}
  - 강제하지 않음 -- 제안 후 사용자 확인

7_Write:
  - references/DOMAIN-MODEL-FORMAT.md 포맷으로 docs/domain/DOMAIN-MODEL.md 작성

8_Sync_Context:
  - 기존 CONTEXT.md의 Language 섹션과 교차 검증
  - 불일치 발견 시 CONTEXT.md도 함께 Edit로 갱신 (단일 진실 공급원 유지)

9_Handoff: 아래 Handoff Output 참조
```

## Skip Conditions (반복 강조)
LIGHT/SIMPLE 복잡도 & 단일 바운디드 컨텍스트인 프로젝트에서는 이 스킬을 호출하지 않는다.
과도한 문서화는 완성도가 아니라 마찰이다.

## Handoff Output (MANDATORY)

```json
{
  "skill": "da:domain",
  "domain_model_file": "docs/domain/DOMAIN-MODEL.md",
  "context_file": "CONTEXT.md",
  "bounded_contexts": ["주문 컨텍스트", "결제 컨텍스트"],
  "scaffold_proposed": false
}
```
