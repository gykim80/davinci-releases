/**
 * animations.jsx - Timeline Animation Starter
 *
 * Provides: Stage, Sprite, Scrubber, Easing, useTime(), interpolate()
 * Usage: Copy into <script type="text/babel"> section of your HTML artifact.
 */

const { useState, useEffect, useRef, useCallback } = React;

// --- Easing Functions ---
const Easing = {
  linear: (t) => t,
  easeInOut: (t) => t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t,
  easeOut: (t) => t * (2 - t),
  easeIn: (t) => t * t,
  spring: (t) => 1 - Math.cos(t * Math.PI * 0.5) * Math.exp(-t * 3),
  bounce: (t) => {
    const n = 7.5625, d = 2.75;
    if (t < 1 / d) return n * t * t;
    if (t < 2 / d) return n * (t -= 1.5 / d) * t + 0.75;
    if (t < 2.5 / d) return n * (t -= 2.25 / d) * t + 0.9375;
    return n * (t -= 2.625 / d) * t + 0.984375;
  },
};

// --- interpolate: maps [0,1] progress to any value range ---
function interpolate(progress, inputRange, outputRange, easing = Easing.linear) {
  const t = easing(Math.max(0, Math.min(1, progress)));
  if (inputRange.length !== outputRange.length) throw new Error("Range mismatch");
  for (let i = 0; i < inputRange.length - 1; i++) {
    if (t >= inputRange[i] && t <= inputRange[i + 1]) {
      const segmentT = (t - inputRange[i]) / (inputRange[i + 1] - inputRange[i]);
      return outputRange[i] + segmentT * (outputRange[i + 1] - outputRange[i]);
    }
  }
  return outputRange[outputRange.length - 1];
}

// --- useTime: returns 0..1 progress over durationMs, loops if loop=true ---
function useTime(durationMs = 2000, loop = false, autoPlay = true) {
  const [progress, setProgress] = useState(0);
  const [playing, setPlaying] = useState(autoPlay);
  const startRef = useRef(null);
  const rafRef = useRef(null);

  const tick = useCallback((timestamp) => {
    if (!startRef.current) startRef.current = timestamp;
    const elapsed = timestamp - startRef.current;
    let p = Math.min(elapsed / durationMs, 1);
    if (loop && p >= 1) { startRef.current = timestamp; p = 0; }
    setProgress(p);
    if (p < 1 || loop) rafRef.current = requestAnimationFrame(tick);
  }, [durationMs, loop]);

  useEffect(() => {
    if (playing) { rafRef.current = requestAnimationFrame(tick); }
    return () => { if (rafRef.current) cancelAnimationFrame(rafRef.current); };
  }, [playing, tick]);

  return { progress, playing, play: () => setPlaying(true), pause: () => setPlaying(false), reset: () => { startRef.current = null; setProgress(0); } };
}

// --- Stage: animation container with aspect ratio ---
function Stage({ width = 800, height = 600, bg = "#0a0a0a", children }) {
  return (
    <div style={{ width: "100%", maxWidth: width, aspectRatio: `${width}/${height}`, background: bg, position: "relative", overflow: "hidden", borderRadius: 12, margin: "0 auto" }}>
      {children}
    </div>
  );
}

// --- Sprite: positioned element inside Stage ---
function Sprite({ x = 0, y = 0, rotation = 0, scale = 1, opacity = 1, children, style = {} }) {
  return (
    <div style={{ position: "absolute", left: `${x}%`, top: `${y}%`, transform: `rotate(${rotation}deg) scale(${scale})`, opacity, transition: "none", ...style }}>
      {children}
    </div>
  );
}

// --- Scrubber: timeline slider ---
function Scrubber({ progress, onScrub, playing, onToggle }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 0", maxWidth: 800, margin: "0 auto" }}>
      <button onClick={onToggle} style={{ background: "none", border: "1px solid #555", color: "#fff", borderRadius: 6, padding: "4px 12px", cursor: "pointer", fontSize: 14 }}>
        {playing ? "Pause" : "Play"}
      </button>
      <input type="range" min="0" max="1" step="0.001" value={progress} onChange={(e) => onScrub(parseFloat(e.target.value))}
        style={{ flex: 1, accentColor: "#3B82F6" }} />
      <span style={{ color: "#999", fontSize: 13, minWidth: 40 }}>{(progress * 100).toFixed(0)}%</span>
    </div>
  );
}

// Export for use in HTML artifacts
window.AnimationKit = { Stage, Sprite, Scrubber, Easing, useTime, interpolate };
