# shadcn/ui to DaisyUI Migration Cheatsheet

> Cheatsheet loaded automatically when Davinci da:design detects a migration.
> Reference when converting from shadcn/ui to DaisyUI.

## Migration Overview

```yaml
Key_Changes:
  - shadcn/ui: React component import approach (JSX wrappers)
  - DaisyUI: CSS class approach (native HTML + className)

Advantages:
  - Reduced bundle size (JS components → CSS classes)
  - Cleaner code by removing imports
  - Direct use of native HTML elements
  - Seamless integration with Tailwind CSS

Caveats:
  - Radix UI accessibility features require manual implementation
  - Complex stateful components need custom code
  - Some compound components (Combobox, etc.) are not available in DaisyUI
```

---

## Step 1: Change Dependencies

```bash
# Remove shadcn/ui related packages
npm uninstall @radix-ui/react-dialog @radix-ui/react-dropdown-menu \
  @radix-ui/react-select @radix-ui/react-tabs @radix-ui/react-tooltip \
  @radix-ui/react-accordion @radix-ui/react-avatar @radix-ui/react-checkbox \
  @radix-ui/react-switch @radix-ui/react-separator @radix-ui/react-progress \
  @radix-ui/react-alert-dialog class-variance-authority

# Install DaisyUI
npm install -D daisyui@latest
```

## Step 2: Tailwind Configuration

```typescript
// tailwind.config.ts
import type { Config } from "tailwindcss"
import daisyui from "daisyui"

const config: Config = {
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
  ],
  plugins: [daisyui],
  daisyui: {
    themes: ["light", "dark"],
  },
}
export default config
```

## Step 3: Imports to Remove

Remove all of the following import statements:

```typescript
// Remove all of these
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Dialog, DialogContent, DialogTrigger, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Checkbox } from "@/components/ui/checkbox"
import { Switch } from "@/components/ui/switch"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Separator } from "@/components/ui/separator"
import { Skeleton } from "@/components/ui/skeleton"
import { Progress } from "@/components/ui/progress"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
```

---

## Component Conversion Table

### Button

```tsx
// BEFORE (shadcn/ui)
<Button variant="default">Click</Button>
<Button variant="ghost" size="sm">Small Ghost</Button>
<Button variant="outline">Outline</Button>
<Button variant="destructive">Delete</Button>
<Button variant="secondary">Secondary</Button>
<Button variant="link">Link</Button>
<Button size="icon"><Icon /></Button>
<Button disabled>Disabled</Button>

// AFTER (DaisyUI)
<button className="btn btn-primary">Click</button>
<button className="btn btn-ghost btn-sm">Small Ghost</button>
<button className="btn btn-outline">Outline</button>
<button className="btn btn-error">Delete</button>
<button className="btn btn-secondary">Secondary</button>
<button className="btn btn-link">Link</button>
<button className="btn btn-square btn-sm"><Icon /></button>
<button className="btn btn-disabled" disabled>Disabled</button>
```

### Card

```tsx
// BEFORE (shadcn/ui)
<Card>
  <CardHeader>
    <CardTitle>Title</CardTitle>
  </CardHeader>
  <CardContent>
    <p>Content</p>
  </CardContent>
  <CardFooter>
    <Button>Action</Button>
  </CardFooter>
</Card>

// AFTER (DaisyUI)
<div className="card bg-base-100 shadow-xl">
  <div className="card-body">
    <h2 className="card-title">Title</h2>
    <p>Content</p>
    <div className="card-actions justify-end">
      <button className="btn btn-primary">Action</button>
    </div>
  </div>
</div>
```

### Badge

```tsx
// BEFORE
<Badge>Default</Badge>
<Badge variant="secondary">Secondary</Badge>
<Badge variant="destructive">Error</Badge>
<Badge variant="outline">Outline</Badge>

// AFTER
<span className="badge">Default</span>
<span className="badge badge-secondary">Secondary</span>
<span className="badge badge-error">Error</span>
<span className="badge badge-outline">Outline</span>
```

### Dialog / Modal

```tsx
// BEFORE (shadcn/ui - Radix)
<Dialog>
  <DialogTrigger asChild>
    <Button>Open</Button>
  </DialogTrigger>
  <DialogContent>
    <DialogHeader>
      <DialogTitle>Title</DialogTitle>
    </DialogHeader>
    <p>Content</p>
  </DialogContent>
</Dialog>

// AFTER (DaisyUI - native dialog)
<button className="btn" onClick={() => document.getElementById('my_modal').showModal()}>
  Open
</button>
<dialog id="my_modal" className="modal">
  <div className="modal-box">
    <h3 className="text-lg font-bold">Title</h3>
    <p className="py-4">Content</p>
    <div className="modal-action">
      <form method="dialog">
        <button className="btn">Close</button>
      </form>
    </div>
  </div>
  <form method="dialog" className="modal-backdrop">
    <button>close</button>
  </form>
</dialog>
```

### Input / Textarea / Select

```tsx
// BEFORE
<Input placeholder="Email" />
<Textarea placeholder="Message" />
<Select>
  <SelectTrigger><SelectValue placeholder="Choose" /></SelectTrigger>
  <SelectContent>
    <SelectItem value="a">Option A</SelectItem>
  </SelectContent>
</Select>

// AFTER
<input className="input input-bordered w-full" placeholder="Email" />
<textarea className="textarea textarea-bordered w-full" placeholder="Message" />
<select className="select select-bordered w-full">
  <option disabled selected>Choose</option>
  <option value="a">Option A</option>
</select>
```

### Checkbox / Switch

```tsx
// BEFORE
<Checkbox checked={checked} onCheckedChange={setChecked} />
<Switch checked={on} onCheckedChange={setOn} />

// AFTER
<input type="checkbox" className="checkbox checkbox-primary"
  checked={checked} onChange={(e) => setChecked(e.target.checked)} />
<input type="checkbox" className="toggle toggle-primary"
  checked={on} onChange={(e) => setOn(e.target.checked)} />
```

### Tabs

```tsx
// BEFORE
<Tabs defaultValue="tab1">
  <TabsList>
    <TabsTrigger value="tab1">Tab 1</TabsTrigger>
    <TabsTrigger value="tab2">Tab 2</TabsTrigger>
  </TabsList>
  <TabsContent value="tab1">Content 1</TabsContent>
  <TabsContent value="tab2">Content 2</TabsContent>
</Tabs>

// AFTER
<div role="tablist" className="tabs tabs-bordered">
  <input type="radio" name="tabs" role="tab" className="tab" aria-label="Tab 1" defaultChecked />
  <div role="tabpanel" className="tab-content p-6">Content 1</div>
  <input type="radio" name="tabs" role="tab" className="tab" aria-label="Tab 2" />
  <div role="tabpanel" className="tab-content p-6">Content 2</div>
</div>
```

### Accordion

```tsx
// BEFORE
<Accordion type="single" collapsible>
  <AccordionItem value="item-1">
    <AccordionTrigger>Question 1</AccordionTrigger>
    <AccordionContent>Answer 1</AccordionContent>
  </AccordionItem>
</Accordion>

// AFTER
<div className="join join-vertical w-full">
  <div className="collapse collapse-arrow join-item border border-base-300">
    <input type="radio" name="accordion" defaultChecked />
    <div className="collapse-title text-xl font-medium">Question 1</div>
    <div className="collapse-content"><p>Answer 1</p></div>
  </div>
</div>
```

### Alert

```tsx
// BEFORE
<Alert variant="destructive">
  <AlertDescription>Something went wrong.</AlertDescription>
</Alert>

// AFTER
<div role="alert" className="alert alert-error">
  <span>Something went wrong.</span>
</div>
```

### Tooltip

```tsx
// BEFORE
<TooltipProvider>
  <Tooltip>
    <TooltipTrigger>Hover</TooltipTrigger>
    <TooltipContent>Tooltip text</TooltipContent>
  </Tooltip>
</TooltipProvider>

// AFTER
<div className="tooltip" data-tip="Tooltip text">
  <button className="btn">Hover</button>
</div>
```

### Avatar

```tsx
// BEFORE
<Avatar>
  <AvatarImage src="/avatar.jpg" />
  <AvatarFallback>JD</AvatarFallback>
</Avatar>

// AFTER
<div className="avatar">
  <div className="w-12 rounded-full">
    <img src="/avatar.jpg" alt="JD" />
  </div>
</div>
// Fallback (when no image)
<div className="avatar placeholder">
  <div className="bg-neutral text-neutral-content w-12 rounded-full">
    <span>JD</span>
  </div>
</div>
```

### Separator

```tsx
// BEFORE
<Separator />
<Separator orientation="vertical" />

// AFTER
<div className="divider"></div>
<div className="divider divider-horizontal"></div>
```

### Progress

```tsx
// BEFORE
<Progress value={60} />

// AFTER
<progress className="progress progress-primary w-full" value="60" max="100"></progress>
```

### Sheet (Drawer)

```tsx
// BEFORE
<Sheet>
  <SheetTrigger>Open</SheetTrigger>
  <SheetContent>Side panel content</SheetContent>
</Sheet>

// AFTER
<div className="drawer">
  <input id="my-drawer" type="checkbox" className="drawer-toggle" />
  <div className="drawer-content">
    <label htmlFor="my-drawer" className="btn btn-ghost">Open</label>
  </div>
  <div className="drawer-side">
    <label htmlFor="my-drawer" className="drawer-overlay"></label>
    <div className="p-4 w-80 min-h-full bg-base-200">
      Side panel content
    </div>
  </div>
</div>
```

### Table

```tsx
// BEFORE
<Table>
  <TableHeader>
    <TableRow>
      <TableHead>Name</TableHead>
      <TableHead>Email</TableHead>
    </TableRow>
  </TableHeader>
  <TableBody>
    <TableRow>
      <TableCell>John</TableCell>
      <TableCell>john@mail.com</TableCell>
    </TableRow>
  </TableBody>
</Table>

// AFTER
<div className="overflow-x-auto">
  <table className="table">
    <thead>
      <tr>
        <th>Name</th>
        <th>Email</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>John</td>
        <td>john@mail.com</td>
      </tr>
    </tbody>
  </table>
</div>
```

### Skeleton

```tsx
// BEFORE
<Skeleton className="h-4 w-[250px]" />
<Skeleton className="h-12 w-full rounded-xl" />

// AFTER
<div className="skeleton h-4 w-64"></div>
<div className="skeleton h-12 w-full rounded-xl"></div>
```

---

## Quick Reference: Variant Mapping

```
shadcn variant        → DaisyUI class
─────────────────────────────────────
variant="default"     → btn-primary
variant="ghost"       → btn-ghost
variant="outline"     → btn-outline
variant="secondary"   → btn-secondary
variant="destructive" → btn-error
variant="link"        → btn-link
size="sm"             → btn-sm
size="lg"             → btn-lg
size="icon"           → btn-square btn-sm
```

## Post-Migration Cleanup

```yaml
1. Delete components/ui/ directory (no longer needed)
2. cn() function in lib/utils.ts can be replaced with clsx()
3. Remove shadcn CSS variables from globals.css
4. Migrate @layer base custom styles to DaisyUI themes
5. Clean up unused @radix-ui/* packages from package.json
```
