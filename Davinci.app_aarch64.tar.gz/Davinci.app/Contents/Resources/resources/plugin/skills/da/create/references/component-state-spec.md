# Component State Specification Patterns

<!-- DESIGN.md Section 4 작성 시 참고하는 컴포넌트 상태 패턴 가이드 -->

## Purpose

This reference defines the standard format for specifying interactive component
states in DESIGN.md Section 4 (Component Stylings). Every interactive element
must declare concrete CSS values for each applicable state.

---

## 1. Button States

<!-- 버튼: 5가지 상태별 속성 정의 -->

| State | Background | Text Color | Padding | Border Radius | Shadow | Transition |
|-------|-----------|------------|---------|---------------|--------|------------|
| Default | `#2563EB` | `#FFFFFF` | `12px 24px` | `8px` | `0 1px 2px rgba(0,0,0,0.05)` | all 150ms ease |
| Hover | `#1D4ED8` | `#FFFFFF` | `12px 24px` | `8px` | `0 4px 6px rgba(0,0,0,0.1)` | all 150ms ease |
| Focus | `#2563EB` | `#FFFFFF` | `12px 24px` | `8px` | `0 0 0 3px rgba(37,99,235,0.4)` | all 150ms ease |
| Active | `#1E40AF` | `#FFFFFF` | `12px 24px` | `8px` | `0 1px 2px rgba(0,0,0,0.05)` | all 50ms ease |
| Disabled | `#E5E7EB` | `#9CA3AF` | `12px 24px` | `8px` | none | none |

**Variants**: primary, secondary, ghost, destructive -- each needs its own table.

---

## 2. Card States

<!-- 카드: 3가지 상태별 속성 정의 -->

| State | Border | Shadow | Border Radius | Transform |
|-------|--------|--------|---------------|-----------|
| Default | `1px solid #E5E7EB` | `0 1px 3px rgba(0,0,0,0.1)` | `12px` | none |
| Hover | `1px solid #D1D5DB` | `0 10px 15px rgba(0,0,0,0.1)` | `12px` | `translateY(-2px)` |
| Focus | `1px solid #2563EB` | `0 0 0 3px rgba(37,99,235,0.3)` | `12px` | none |

---

## 3. Input States

<!-- 인풋: 4가지 상태별 속성 정의 -->

| State | Border | Background | Shadow | Text Color | Placeholder |
|-------|--------|------------|--------|------------|-------------|
| Default | `1px solid #D1D5DB` | `#FFFFFF` | none | `#111827` | `#9CA3AF` |
| Focus | `1px solid #2563EB` | `#FFFFFF` | `0 0 0 3px rgba(37,99,235,0.2)` | `#111827` | `#9CA3AF` |
| Error | `1px solid #EF4444` | `#FEF2F2` | `0 0 0 3px rgba(239,68,68,0.2)` | `#111827` | `#9CA3AF` |
| Disabled | `1px solid #E5E7EB` | `#F9FAFB` | none | `#9CA3AF` | `#D1D5DB` |

**Note**: Error state includes a helper text slot below the input in `#EF4444`.

---

## 4. Navigation / Link States

<!-- 네비게이션 링크: 4가지 상태 -->

| State | Color | Text Decoration | Opacity | Border Bottom |
|-------|-------|----------------|---------|---------------|
| Default | `#2563EB` | none | `1` | none |
| Hover | `#1D4ED8` | underline | `1` | none |
| Active | `#1E40AF` | underline | `1` | `2px solid currentColor` |
| Visited | `#7C3AED` | none | `0.9` | none |

---

## 5. General Transition Patterns

<!-- 트랜지션 공통 패턴: 타이밍/이징/대상 속성 -->

| Category | Duration | Easing | Properties |
|----------|----------|--------|------------|
| Color changes | `150ms` | `ease` | background-color, color, border-color |
| Shadow/elevation | `200ms` | `ease-out` | box-shadow |
| Transform | `200ms` | `cubic-bezier(0.4, 0, 0.2, 1)` | transform |
| Layout shifts | `300ms` | `cubic-bezier(0.4, 0, 0.2, 1)` | width, height, padding |
| Opacity | `150ms` | `ease` | opacity |
| Focus ring | `0ms` | -- | box-shadow (instant for a11y) |

### Guidelines

- **Never animate**: `display`, `visibility` changes (use opacity + pointer-events)
- **Focus ring**: Must appear instantly (0ms) for accessibility compliance
- **Reduced motion**: Wrap transforms and animations in `@media (prefers-reduced-motion: no-preference)`
- **Max duration**: Keep all UI transitions under `400ms` to feel responsive

---

## 6. Format Rules for DESIGN.md Section 4

<!-- DESIGN.md에 작성할 때 따라야 할 포맷 규칙 -->

1. Use **markdown tables** with pipe separators (LLM-parseable)
2. Every value must be a **concrete CSS value** (no "lighter" or "subtle")
3. Include **transition** column in every state table
4. Group by component, one table per component
5. Declare **all applicable states** -- omitting disabled or focus is not allowed
6. For dark mode, add a separate table or a "Dark" column per property
7. Reference color values from Section 2 palette (use semantic names + hex)
