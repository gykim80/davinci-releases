# Editorial Layout Reference

> Editorial-design-level experimental and unconventional layout system.
> Referenced during da:design Phase 3 (Section_Diversity_Plan) and Phase 4 (implementation).
> Difficulty: ★★★ (upper-tier superset of the existing Section_Diversity_Plan Pattern_Pool)

---

## Core Principles

Editorial design creates **intentional tension**. When all elements are aligned, it's boring;
when all elements are chaotic, it's confusing. **90% order + 10% disruption** is the optimal ratio.

---

## 1. Mathematical Proportion System

### Golden Ratio (1:1.618)

```tsx
/* Golden ratio split layout */
export function GoldenSplit({ left, right }: { left: React.ReactNode; right: React.ReactNode }) {
  return (
    <div className="grid gap-8" style={{ gridTemplateColumns: "1fr 1.618fr" }}>
      <div>{left}</div>
      <div>{right}</div>
    </div>
  );
}

/* Inverse golden ratio: larger side on the left */
export function GoldenSplitReverse({ left, right }: { left: React.ReactNode; right: React.ReactNode }) {
  return (
    <div className="grid gap-8" style={{ gridTemplateColumns: "1.618fr 1fr" }}>
      <div>{left}</div>
      <div>{right}</div>
    </div>
  );
}
```

### Root-2 Ratio (√2 ≈ 1:1.414 — A4/B5 paper ratio)

```tsx
/* Root-2 based card — stable proportions like paper */
export function Root2Card({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <div
      className={`overflow-hidden ${className ?? ""}`}
      style={{ aspectRatio: "1 / 1.414" }}
    >
      {children}
    </div>
  );
}
```

### Proportion Application Rules

| Ratio | Use Case | Feel |
|------|------|------|
| 1:1.618 (Golden ratio) | Text-image splits, hero layouts | Natural and comfortable |
| 1:1.414 (√2) | Cards, image frames | Paper/print feel |
| 1:2 | Extreme asymmetry, sidebar-content | Bold and modern |
| 2:3 | Vertical images, poster ratios | Editorial design tradition |
| 16:9 | Horizontal hero, video frames | Cinematic |

---

## 2. Editorial Design Patterns

### Pull Quote

```tsx
import { motion, useScroll, useTransform } from "motion/react";
import { useRef } from "react";

/* A quote that breaks out of the body flow at a larger scale */
export function PullQuote({ quote, author }: { quote: string; author?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start 0.8", "start 0.3"],
  });
  const x = useTransform(scrollYProgress, [0, 1], [-40, 0]);
  const opacity = useTransform(scrollYProgress, [0, 0.3, 1], [0, 1, 1]);

  return (
    <motion.blockquote
      ref={ref}
      style={{ x, opacity }}
      className="relative my-16 -ml-8 border-l-4 border-primary pl-8 md:-ml-16 md:pl-12"
    >
      <p
        className="font-display leading-[1.1] tracking-tight text-foreground"
        style={{ fontSize: "clamp(1.5rem, 1rem + 3vw, 3.5rem)" }}
      >
        "{quote}"
      </p>
      {author && (
        <cite className="mt-4 block font-mono text-sm tracking-wider text-muted-foreground">
          — {author}
        </cite>
      )}
    </motion.blockquote>
  );
}
```

### Drop Cap (enlarged first letter)

```tsx
/* Hallmark of editorial design: first letter enlarged to 3 lines tall */
export function DropCap({ children }: { children: string }) {
  const first = children.charAt(0);
  const rest = children.slice(1);

  return (
    <p className="text-base leading-relaxed text-foreground">
      <span
        className="float-left mr-3 font-display leading-[0.8] text-primary"
        style={{ fontSize: "clamp(3rem, 2rem + 4vw, 5.5rem)" }}
      >
        {first}
      </span>
      {rest}
    </p>
  );
}
```

### Bleed Section (extends to screen edges)

```tsx
/* Breaks out of content area to use full viewport width */
export function FullBleed({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`relative w-screen -ml-[50vw] left-1/2 ${className ?? ""}`}>
      {children}
    </div>
  );
}

/* Partial bleed: extends on one side only */
export function HalfBleed({
  children,
  side = "right",
  className,
}: {
  children: React.ReactNode;
  side?: "left" | "right";
  className?: string;
}) {
  return (
    <div
      className={`relative ${
        side === "right"
          ? "ml-0 mr-[calc(-50vw+50%)]"
          : "mr-0 ml-[calc(-50vw+50%)]"
      } ${className ?? ""}`}
    >
      {children}
    </div>
  );
}
```

### Running Header (repeating section label)

```tsx
/* Editorial running header — section name repeats on the side */
export function RunningHeader({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="relative">
      {/* Vertical text on left side */}
      <span
        className="absolute -left-12 top-0 hidden origin-top-left font-mono text-[10px] tracking-[0.2em] text-muted-foreground/50 lg:block"
        style={{ writingMode: "vertical-lr", transform: "rotate(180deg)" }}
      >
        {label}
      </span>
      {children}
    </div>
  );
}
```

### Marginal Note (side note)

```tsx
/* Small annotations next to body text — academic/editorial design technique */
export function MarginalNote({ children, note }: { children: React.ReactNode; note: string }) {
  return (
    <div className="grid grid-cols-[1fr_200px] gap-8 lg:grid-cols-[1fr_240px]">
      <div>{children}</div>
      <aside className="hidden border-l border-border/40 pl-6 pt-2 md:block">
        <p className="font-mono text-xs leading-relaxed text-muted-foreground">{note}</p>
      </aside>
    </div>
  );
}
```

---

## 3. Intentional Grid Breaking (Grid-Breaking Breakouts)

### Breakout Element

```tsx
import { motion } from "motion/react";

/* A single element that crosses grid boundaries within an aligned grid */
export function Breakout({
  children,
  offset = "right",
  amount = "4rem",
}: {
  children: React.ReactNode;
  offset?: "left" | "right" | "both";
  amount?: string;
}) {
  const margin =
    offset === "left"
      ? { marginLeft: `calc(-1 * ${amount})` }
      : offset === "right"
        ? { marginRight: `calc(-1 * ${amount})` }
        : { marginLeft: `calc(-1 * ${amount})`, marginRight: `calc(-1 * ${amount})` };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.97 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
      style={margin}
    >
      {children}
    </motion.div>
  );
}
```

### Offset Grid

```tsx
/* Odd rows shift horizontally within a regular grid */
export function OffsetGrid({
  children,
  cols = 3,
  offset = "2rem",
}: {
  children: React.ReactNode[];
  cols?: number;
  offset?: string;
}) {
  return (
    <div className={`grid grid-cols-${cols} gap-6`}>
      {children.map((child, i) => {
        const row = Math.floor(i / cols);
        const isOdd = row % 2 === 1;
        return (
          <div key={i} style={{ transform: isOdd ? `translateX(${offset})` : undefined }}>
            {child}
          </div>
        );
      })}
    </div>
  );
}
```

### Overlapping Layers

```tsx
import { motion } from "motion/react";

/* Cards/images intentionally overlap to create depth */
export function OverlapStack({ items }: { items: { content: React.ReactNode; zIndex: number }[] }) {
  return (
    <div className="relative" style={{ height: `${items.length * 80 + 200}px` }}>
      {items.map((item, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: i * 0.12, duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
          className="absolute left-0 right-0 rounded-2xl border border-border/40 bg-card p-6"
          style={{
            top: `${i * 80}px`,
            zIndex: item.zIndex,
            marginLeft: `${i * 20}px`,
            marginRight: `${(items.length - i) * 20}px`,
          }}
        >
          {item.content}
        </motion.div>
      ))}
    </div>
  );
}
```

---

## 4. Extreme Typographic Scale

### Scale Contrast (8px ↔ 200px)

```tsx
/* Emphasize visual hierarchy through extreme size differences */
export function ExtremeScale({
  overline,
  headline,
  body,
}: {
  overline: string;
  headline: string;
  body: string;
}) {
  return (
    <div className="space-y-4">
      {/* Tiny overline */}
      <span className="block font-mono text-[10px] tracking-[0.25em] uppercase text-muted-foreground">
        {overline}
      </span>

      {/* Massive headline */}
      <h2
        className="font-display leading-[0.85] tracking-tighter text-foreground"
        style={{ fontSize: "clamp(3rem, 2rem + 8vw, 12rem)" }}
      >
        {headline}
      </h2>

      {/* Body — dramatic contrast with headline */}
      <p className="max-w-md text-base leading-relaxed text-muted-foreground">
        {body}
      </p>
    </div>
  );
}
```

### Mixed Weight Headlines

```tsx
/* Create rhythm by mixing extreme weights within a single sentence */
export function MixedWeight({ thin, bold }: { thin: string; bold: string }) {
  return (
    <h2
      className="font-display leading-[0.9] tracking-tight"
      style={{ fontSize: "clamp(2rem, 1.5rem + 4vw, 6rem)" }}
    >
      <span className="font-light text-muted-foreground">{thin}</span>{" "}
      <span className="font-black text-foreground">{bold}</span>
    </h2>
  );
}
```

### Numbered Section (oversized numbers)

```tsx
/* Editorial technique where section numbers appear as large background elements */
export function NumberedSection({
  number,
  title,
  children,
}: {
  number: string;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div className="relative">
      {/* Background number */}
      <span
        className="pointer-events-none absolute -left-4 -top-8 select-none font-display text-muted/30 lg:-left-12"
        style={{ fontSize: "clamp(6rem, 4rem + 10vw, 16rem)", lineHeight: "0.8" }}
      >
        {number}
      </span>

      {/* Actual content */}
      <div className="relative z-10">
        <h3
          className="font-display tracking-tight text-foreground"
          style={{ fontSize: "clamp(1.5rem, 1rem + 2vw, 3rem)" }}
        >
          {title}
        </h3>
        <div className="mt-4">{children}</div>
      </div>
    </div>
  );
}
```

---

## 5. Text-Image Interplay

### Text Over Image (text-image overlap)

```tsx
/* Text overlaps the image and integrates via mix-blend-mode */
export function TextOverImage({
  imageSrc,
  imageAlt,
  headline,
  className,
}: {
  imageSrc: string;
  imageAlt: string;
  headline: string;
  className?: string;
}) {
  return (
    <div className={`relative overflow-hidden ${className ?? ""}`}>
      <img src={imageSrc} alt={imageAlt} className="h-full w-full object-cover" />
      <div className="absolute inset-0 flex items-end p-8">
        <h2
          className="font-display leading-[0.9] tracking-tighter text-background mix-blend-difference"
          style={{ fontSize: "clamp(2rem, 1.5rem + 5vw, 7rem)" }}
        >
          {headline}
        </h2>
      </div>
    </div>
  );
}
```

### Cutout Text

```tsx
/* Effect where the background appears cut through the text shape */
export function CutoutText({ text, className }: { text: string; className?: string }) {
  return (
    <div
      className={`relative flex items-center justify-center bg-foreground py-16 ${className ?? ""}`}
    >
      <h2
        className="font-display tracking-tighter"
        style={{
          fontSize: "clamp(3rem, 2rem + 8vw, 10rem)",
          lineHeight: 0.85,
          WebkitBackgroundClip: "text",
          WebkitTextFillColor: "transparent",
          backgroundImage: "linear-gradient(135deg, hsl(var(--primary)), hsl(var(--accent)))",
          backgroundClip: "text",
        }}
      >
        {text}
      </h2>
    </div>
  );
}
```

---

## 6. Viewport-Aware Layouts

### Viewport Width Bleed (100vw expansion)

```tsx
/* Ignores max-width container and uses full viewport */
export function ViewportBleed({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <div
      className={`relative ${className ?? ""}`}
      style={{
        width: "100vw",
        marginLeft: "calc(-50vw + 50%)",
      }}
    >
      {children}
    </div>
  );
}
```

### Negative Margin Breakout

```tsx
/* Element intentionally extends beyond its container */
export function NegativeBreakout({
  children,
  side = "right",
  amount = "8rem",
}: {
  children: React.ReactNode;
  side?: "left" | "right";
  amount?: string;
}) {
  return (
    <div
      style={{
        [side === "right" ? "marginRight" : "marginLeft"]: `calc(-1 * ${amount})`,
        [side === "right" ? "paddingRight" : "paddingLeft"]: amount,
      }}
    >
      {children}
    </div>
  );
}
```

---

## Application Protocol (da:design Phase 3/4)

```yaml
Phase_3_Section_Diversity_Plan:
  Required_Proportions: Apply golden ratio or root-2 ratio to at least 1 section
  Required_Editorial_Patterns: Use at least 2 editorial patterns (PullQuote, DropCap, Bleed, MarginalNote)
  Required_Grid_Breaking: At least 1 breakout element (element breaking alignment)
  Required_Scale_Contrast: Apply ExtremeScale to hero or key sections

Phase_4_Implementation:
  1. Create editorial components in src/components/editorial/
  2. Import and apply in section components
  3. Responsive: Remove bleed/breakout on mobile, simplify proportions
  4. Accessibility: Maintain proper contrast even for large text

Fidelity_Score_Impact:
  Golden ratio/root-2 ratio 1+ used: +3 points (Layout dimension)
  Editorial patterns 2+ used: +4 points (Section_Layout_Variety dimension)
  Grid-breaking element present: +3 points (Visual_Coherence dimension)
  Extreme scale contrast: +2 points (Typography dimension)
  None used: -8 points (layout monotony penalty)
```

---

## Tier Classification

| Tier | Patterns | Examples | When to Use |
|------|------|------|----------|
| S | Editorial design essentials | PullQuote, ExtremeScale, FullBleed, CutoutText | Hero/key sections (1-2) |
| A | Structural differentiation | GoldenSplit, OffsetGrid, OverlapStack, NumberedSection | Major sections (2-3) |
| B | Detail techniques | DropCap, RunningHeader, MarginalNote, MixedWeight | Scattered throughout |
