# Anti-Generic Rules + Design Secrets

Phase 4 구현 시 강제 적용. LLM이 자주 하는 "제네릭" 실수를 구체적 코드 예시로 차단.

## Anti-Generic Rules (14 Rules)

### Rule 1: no_transition_all
```yaml
WRONG: className="transition-all duration-300"
RIGHT: className="transition-transform duration-150 ease-out"
```
이유: transition-all은 불필요한 프로퍼티까지 전환. property-specific으로 한정.

### Rule 2: multi_layer_shadow
```yaml
WRONG: className="shadow-md"
RIGHT: |
  style={{ boxShadow: "0 1px 2px hsl(var(--shadow-color)/0.07),
    0 4px 8px hsl(var(--shadow-color)/0.04),
    0 12px 24px hsl(var(--shadow-color)/0.03)" }}
```
이유: 단일 레이어 그림자는 flat. 3단계 multi-layer로 깊이감 생성.

### Rule 3: tinted_gray
```yaml
WRONG: className="text-gray-500 bg-gray-100"
RIGHT: className="text-muted-foreground bg-muted"
```
이유: 순수 gray는 차갑고 제네릭. 시맨틱 토큰으로 tinted gray 사용.

### Rule 4: fluid_type
```yaml
WRONG: className="text-4xl"
RIGHT: style={{ fontSize: "clamp(2rem, 1.5rem + 2vw, 3.5rem)" }}
```
이유: 고정 사이즈는 반응형에서 부자연스러움. fluid clamp()로 자연스러운 스케일링.

### Rule 5: no_pure_black_white
```yaml
WRONG: className="bg-black text-white"
RIGHT: className="bg-foreground text-background"
```
이유: 순수 검정/흰색은 대비가 너무 강함. 시맨틱 토큰으로 tinted dark/light.
예외: terminal persona에서는 순수 black 배경 허용.

### Rule 6: letter_spacing_headlines
```yaml
WRONG: <h1 className="text-4xl font-bold">
RIGHT: <h1 className="text-4xl font-bold tracking-tight">
```
이유: 큰 텍스트의 기본 letter-spacing은 너무 넓음. tracking-tight(-0.02em)으로 전문성.

### Rule 7: texture_over_flat
```yaml
WRONG: <div className="bg-primary">
RIGHT: |
  <div className="bg-primary relative">
    <svg className="absolute inset-0 w-full h-full opacity-[0.03]" ...>
      <filter id="noise"><feTurbulence baseFrequency="0.65" /></filter>
      <rect width="100%" height="100%" filter="url(#noise)" />
    </svg>
    {children}
  </div>
```
이유: 플랫 서페이스는 디지털 느낌. SVG noise 오버레이 3-5%로 물리적 질감.

### Rule 8: asymmetric_hover_timing
```yaml
WRONG: className="transition-transform duration-200 hover:scale-105"
RIGHT: className="transition-transform duration-[125ms] hover:scale-105
  hover:duration-[125ms] duration-[450ms]"
```
이유: enter는 빠르게(125ms), exit는 느리게(450ms). 비대칭 타이밍이 프리미엄 느낌.

### Rule 9: overlap_for_depth
```yaml
WRONG: 모든 요소가 정렬된 박스 안에 배치
RIGHT: negative margin (-mt-8, -ml-4) + z-index layering으로 요소 겹침
```
이유: 오버랩은 시각적 깊이와 역동성 생성. 모든 것이 정렬되면 제네릭.

### Rule 10: no_placeholder_images
```yaml
WRONG: <div className="bg-gray-200 h-48 rounded" />
RIGHT: lucide-react 아이콘 조합 또는 CSS gradient/pattern으로 의미 있는 비주얼
```
이유: 빈 placeholder는 미완성 느낌. 항상 의미 있는 시각 요소로 채움.

### Rule 11: no_css_only_hero
```yaml
WRONG: |
  <div className="relative overflow-hidden">
    <div className="absolute -inset-[100px] opacity-30 blur-[100px]">
      <div className="absolute top-0 left-1/4 w-96 h-96 rounded-full bg-primary/40" />
    </div>
    <h1>Title</h1>
  </div>
RIGHT: |
  <div className="relative overflow-hidden">
    <ParticleBackground />  {/* @tsparticles/react */}
    <h1>Title</h1>
  </div>
```
이유: CSS blur blob은 모든 AI 도구가 생성하는 제네릭 패턴. 외부 라이브러리로 차별화.

### Rule 12: section_layout_diversity
```yaml
WRONG: |
  모든 섹션이 동일한 구조:
  <section><span label/><h2/><p/><div className="grid grid-cols-3">...</div></section>
  <section><span label/><h2/><p/><div className="grid grid-cols-3">...</div></section>
RIGHT: |
  각 섹션이 고유한 레이아웃:
  <section>{/* full-bleed hero with particles */}</section>
  <section>{/* split-layout 40:60 with overlap */}</section>
  <section>{/* bento-grid asymmetric */}</section>
  <section>{/* sticky-scroll with timeline */}</section>
```
이유: 동일 구조 반복은 "AI가 만든 티"의 가장 큰 원인.

### Rule 13: reference_component_integration
```yaml
WRONG: Component Registry에서 Vortex, GlassRefractionHero를 찾았지만 미사용
RIGHT: Discovery에서 찾은 핵심 패턴(Canvas 물리, glass refraction)을 실제 코드에 반영
```
이유: 레퍼런스를 찾는 것만으로는 가치 없음. 실제 구현에 반영해야 Discovery의 의미가 있음.

### Rule 14: hero_differentiation
```yaml
WRONG: <section><h1>Title</h1><p>Subtitle</p><button>CTA</button></section>
RIGHT: |
  <section className="relative min-h-screen">
    <FlowField />  {/* Canvas 배경 효과 */}
    <div className="relative z-10">
      <TextReveal text="Title" />  {/* 글자 단위 등장 애니메이션 */}
      <p>Subtitle</p>
      <button className="group ...">
        CTA<ArrowUpRight className="group-hover:translate-x-0.5" />
      </button>
    </div>
  </section>
```
이유: 히어로는 첫인상. 텍스트+버튼만으로는 어떤 AI 도구든 동일한 결과를 만듦.

---

## 14 NEVER DO Items (절대 금지)

1. **NEVER**: 추상적 장식 도형 (그라데이션 원, 블러 사각형, 장식 blob) — 의미 없는 장식 제거
2. **NEVER**: 보라색 기본 사용 — 프로젝트 primary 색상 사용 (보라색이 primary면 OK)
3. **NEVER**: placeholder 이미지 방치 — 실제 콘텐츠 또는 의미 있는 아이콘
4. **NEVER**: 단일 폰트 패밀리로 전체 페이지 — display + body + mono 3종 필수
5. **NEVER**: 5색 초과 팔레트 — primary + accent + neutrals 내에서 해결
6. **NEVER**: transition: all 또는 transition-all — property-specific 전환만
7. **NEVER**: 단일 레이어 box-shadow — 최소 2단계 multi-layer
8. **NEVER**: 순수 gray (tint 없는) — 시맨틱 토큰 또는 tinted gray
9. **NEVER**: bg-black, bg-white, text-white 직접 사용 — 시맨틱 토큰만
10. **NEVER**: CSS-only 히어로 배경 — 외부 효과 라이브러리 필수
11. **NEVER**: 섹션 레이아웃 반복 (연속 2+ 동일 구조) — 각 섹션 고유 패턴 필수
12. **NEVER**: Component Registry 레퍼런스 미사용 — Discovery 결과 실제 구현 반영 필수
13. **NEVER**: 전체 페이지 text-center 정렬만 — 다양한 정렬 혼합 필수
14. **NEVER**: 히어로에 단순 텍스트+버튼만 — 외부 효과/인터랙티브 요소 1개+ 필수

---

## Design Engineering Secrets (14가지 전문가 기법)

Phase 4 구현 시 자동 적용. Awwwards 수상작 분석에서 추출.

### Secret 1: Multi-Layer Tinted Shadows
- **기법**: 단일 shadow-md 대신 3단계 multi-layer + 색상 tint
- **코드**: `boxShadow: '0 1px 2px hsl(var(--primary)/0.07), 0 4px 8px hsl(var(--primary)/0.04), 0 12px 24px hsl(var(--primary)/0.03)'`
- **적용**: 모든 카드, 모달, 드롭다운

### Secret 2: SVG Noise Texture
- **기법**: 플랫 배경에 SVG feTurbulence 노이즈 오버레이 (opacity 3-5%)
- **적용**: hero 섹션, CTA 배경, 카드 배경

### Secret 3: Tinted Grays
- **기법**: 순수 gray 대신 primary 색상으로 tinted gray 사용
- **규칙**: --muted, --muted-foreground 시맨틱 토큰 사용

### Secret 4: Fluid Typography
- **기법**: clamp() 기반 fluid sizing
- **코드**: `fontSize: clamp(2rem, 1.5rem + 2vw, 3.5rem)`
- **추가**: headline tracking-tight(-0.02em), overline tracking-widest(+0.1em)

### Secret 5: Property-Specific Transitions
- **기법**: transition-all 금지. property별로 duration/easing 분리
- **코드**: `transition-transform duration-150 ease-out`
- **추가**: enter 빠르게(125ms), exit 느리게(450ms) 비대칭 타이밍

### Secret 6: Blend Modes
- **기법**: mix-blend-mode로 레이어 간 색상 블렌딩
- **적용**: 히어로 이미지 오버레이, 텍스트 효과, 배경 레이어링

### Secret 7: Overlap & Negative Margins
- **기법**: negative margin + z-index로 요소 겹침 — 시각적 깊이 생성
- **적용**: 프로필 카드 스택, 이미지-텍스트 오버랩, 섹션 전환

### Secret 8: Gradient Borders
- **기법**: border-image 또는 background-clip으로 그라데이션 보더
- **적용**: 프리미엄 카드, CTA 버튼, 하이라이트 요소

### Secret 9: Selective Animations
- **기법**: 고빈도 인터랙션(버튼, 토글)은 모션 없음. 저빈도(페이지 진입, 스크롤 reveal)에만 모션
- **원칙**: "frequency reduces ceremony" (Rauno Freiberg)

### Secret 10: Custom Scrollbar
- **기법**: webkit-scrollbar 커스터마이즈 — 얇고 투명한 스크롤바
- **적용**: 사이드바, 코드 블록, 드롭다운 목록

### Secret 11: Dark Mode ≠ Inversion
- **기법**: 다크 모드는 라이트 반전이 아님. 별도 색상 체계, 낮은 대비, 미묘한 차이
- **규칙**: .dark 블록의 CSS 변수는 독립적으로 디자인

### Secret 12: Container Queries
- **기법**: 미디어 쿼리 대신 container query로 컴포넌트 수준 반응형
- **적용**: 카드 그리드, 사이드바 내 컴포넌트

### Secret 13: Focus Visible Only
- **기법**: :focus-visible로 키보드 네비게이션만 포커스 링 표시
- **적용**: 모든 인터랙티브 요소

### Secret 14: Refactoring UI Principles
- **기법**: Adam Wathan의 Refactoring UI 핵심 원칙
- **규칙**:
  - 컬러 가중치로 시각적 위계 (진한 = 중요, 연한 = 보조)
  - 선 대신 간격으로 구분 (border 줄이고 spacing 늘림)
  - 요소 크기로 중요도 표현 (큰 = 주목, 작은 = 보조)
