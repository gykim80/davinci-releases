# Social Carousel Layout

**Multi-slide swipeable card-news layout** for Instagram, LinkedIn, X carousel.

Pair with: `assets/template-social-carousel.html` (working HTML skeleton, 6 slides).

## Pre-flight

1. **Read `assets/template-social-carousel.html`** — every class/section below already exists.
2. **One idea per slide.** Do not pack two messages into one frame.
3. **Brand mark on every slide.** Footer area, low-key, consistent position.
4. **Large typography only.** Body text below 40px is forbidden at 1080×1080.

## Trigger keywords

- Korean: `카드뉴스`, `캐러셀`, `슬라이드 카드`, `인스타`, `인스타그램`, `SNS 카드`, `링크드인 카드`
- English: `social`, `carousel`, `instagram`, `IG carousel`, `linkedin carousel`, `card news`

When matched, set `vertical=social-carousel` and load this file + `assets/template-social-carousel.html`.

## Aspect ratio variants

- **1:1 (1080×1080)** — Instagram default. Center-safe area: 1080×1080 with 80px padding all sides.
- **4:5 (1080×1350)** — Instagram portrait, more vertical real estate.
- Pick ONE per project. Do not mix in same carousel.

## Token spec (oklch — high chroma for thumb-stopping)

```css
:root {
  --bg: oklch(0.12 0.04 280);          /* deep brand bg */
  --fg: oklch(0.99 0 0);
  --accent: oklch(0.78 0.24 60);       /* high-chroma accent */
  --accent-2: oklch(0.65 0.22 320);    /* secondary punch */
  --muted: oklch(0.70 0.04 280);
  --rule: oklch(0.25 0.04 280);
  --slide-pad: 80px;                   /* center-safe padding */
}
```

High chroma > 0.18 is required on accent so the post stops thumbs in feed.

## Section archetype (6 slides)

1. **Cover** — Hook headline (1 sentence, ≥56px), eyebrow tag, brand mark.
2. **Problem** — "이런 적 있지 않나요?" framing. Pain point stated bluntly.
3. **Insight** — The shift / new perspective. The "aha" moment.
4. **Proof** — Number, quote, screenshot, or before/after. Concrete evidence.
5. **CTA** — Single action. "저장하세요", "프로필 링크", "댓글로 알려주세요".
6. **Handle** — Account handle + brand. Final visual signature.

## P0 Checklist (must pass)

- [ ] Each slide self-contained — readable without context of other slides.
- [ ] One idea per slide. No double-packing.
- [ ] Body text ≥56px on 1080×1080 canvas (≥40px absolute minimum for tertiary).
- [ ] Brand mark / handle visible on every slide.
- [ ] Center-safe area respected (80px padding all sides).
- [ ] Aspect ratio consistent across all slides in one carousel.

## P1 Checklist (should pass)

- [ ] Consistent slide template — same heading position, same brand-mark placement, same color rhythm.
- [ ] Swipe affordance on slide 1 (small ">" arrow or "1/6" counter).
- [ ] Slide counter (`1/6`, `2/6`...) in same corner on each slide.
- [ ] Color rhythm: cover punchy → middle slides quieter → CTA punchy again.
- [ ] Text contrast ≥ 7:1 on the dominant background (WCAG AAA, large type).

## P2 Checklist (nice to have)

- [ ] Save-able quote slide (insight slide doubles as a screenshot-worthy quote card).
- [ ] Share-friendly: hook line works as caption pull-quote.
- [ ] Optional `4:5` variant produced alongside `1:1`.
- [ ] Alt text guidance comment in HTML for accessible Instagram posting.

## Anti-patterns (do NOT)

- Body type below 40px on 1080 canvas.
- Two competing headlines on one slide.
- Brand mark missing on intermediate slides.
- Low-chroma muted palette — Instagram feed will eat it.
- Inconsistent slide template — looks like 6 different posts.
