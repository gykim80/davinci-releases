# Industry Data Source

## 출처
- **패키지**: ui-ux-pro-max-skill (MIT License)
- **저자**: nextlevelbuilder
- **원본 경로**: `ui-ux-pro-max-skill/src/ui-ux-pro-max/data/`
- **흡수일**: 2026-04-01

## 파일 매핑

| 원본 파일명 | 흡수 파일명 | 행 수 (헤더 포함) | 설명 |
|------------|-----------|:---------:|------|
| products.csv | products.csv | 162 | 산업별 제품 유형 + 스타일 추천 |
| ui-reasoning.csv | reasoning.csv | 162 | 산업별 UI 추론 규칙 + 조건부 로직 |
| colors.csv | colors.csv | 161 | shadcn/ui 호환 색상 팔레트 |
| styles.csv | styles.csv | 85 | UI 스타일 정의 + 이펙트 + 체크리스트 |
| ux-guidelines.csv | ux-rules.csv | 99 | UX 모범 사례 Do/Don't |

## 버전 관리
- 업스트림 변경은 수동 검토 후 선별 반영
- 자동 동기화 없음 (one-time absorption)
