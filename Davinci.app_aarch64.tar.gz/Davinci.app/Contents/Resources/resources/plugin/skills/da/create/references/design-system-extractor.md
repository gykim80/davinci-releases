# Design System Extractor

> Reference document for da:create Phase 2A.
> Procedures for extracting design tokens from an existing codebase.

## Extraction Order

Search these files in order. Stop early if a comprehensive source is found.

### 1. Tailwind Config
```
Files: tailwind.config.{js,ts,mjs,cjs}
Extract: theme.extend.colors, spacing, borderRadius, fontFamily, fontSize
Format: Map Tailwind tokens to CSS custom properties
```

### 2. CSS Custom Properties
```
Files: globals.css, variables.css, app.css, index.css, theme.css
Pattern: --{category}-{name}: {value}
Examples: --color-primary, --space-lg, --font-heading, --radius-md
```

### 3. Programmatic Tokens
```
Files: theme.ts, colors.ts, tokens.ts, design-tokens.json
Pattern: export const colors = { primary: '#...' }
Format: Direct mapping to DTCG format
```

### 4. Component Patterns
```
Dir: components/, ui/, shared/
Analyze: Button, Card, Input, Modal, Badge patterns
Extract: recurring style patterns, spacing conventions, border treatments
```

### 5. Package Dependencies
```
File: package.json
Check: shadcn/ui, MUI, Ant Design, Chakra UI, Mantine
Action: Infer token system from library choice
```

## Output Format (DTCG)

```json
{
  "color": {
    "primary": {
      "$value": "oklch(65% 0.25 250)",
      "$type": "color",
      "$description": "Primary brand color"
    },
    "primary-light": {
      "$value": "oklch(85% 0.12 250)",
      "$type": "color"
    }
  },
  "spacing": {
    "xs": { "$value": "0.25rem", "$type": "dimension" },
    "sm": { "$value": "0.5rem", "$type": "dimension" },
    "md": { "$value": "1rem", "$type": "dimension" },
    "lg": { "$value": "1.5rem", "$type": "dimension" },
    "xl": { "$value": "2rem", "$type": "dimension" }
  },
  "borderRadius": {
    "sm": { "$value": "4px", "$type": "dimension" },
    "md": { "$value": "8px", "$type": "dimension" },
    "lg": { "$value": "12px", "$type": "dimension" },
    "full": { "$value": "9999px", "$type": "dimension" }
  },
  "fontFamily": {
    "heading": { "$value": "Space Grotesk, sans-serif", "$type": "fontFamily" },
    "body": { "$value": "Plus Jakarta Sans, sans-serif", "$type": "fontFamily" }
  },
  "fontSize": {
    "xs": { "$value": "0.75rem", "$type": "dimension" },
    "sm": { "$value": "0.875rem", "$type": "dimension" },
    "base": { "$value": "1rem", "$type": "dimension" },
    "lg": { "$value": "1.125rem", "$type": "dimension" },
    "xl": { "$value": "1.25rem", "$type": "dimension" },
    "2xl": { "$value": "1.5rem", "$type": "dimension" },
    "3xl": { "$value": "2rem", "$type": "dimension" },
    "4xl": { "$value": "2.5rem", "$type": "dimension" }
  }
}
```

## Color Space: oklch (MANDATORY)

All extracted colors MUST be converted to oklch():

```
oklch(L% C H)
  L = Lightness (0-100%)
  C = Chroma (0-0.4, typically 0.05-0.3)
  H = Hue angle (0-360)
```

### Conversion from hex/rgb:
1. Parse hex to sRGB
2. Convert sRGB to OKLab
3. Convert OKLab to OKLCH
4. Round: L to 1%, C to 0.01, H to integer

### Palette Extension Rules
- **NEVER** invent new brand colors
- Extend by adjusting L (lightness) within same H (hue)
- Create tint/shade scales: L from 20% to 95%, same C and H
- For neutral variants: reduce C toward 0 while keeping H

## No Codebase Fallback

If no codebase exists:
1. Ask user for brand colors, font preferences, personality
2. Derive a minimal token set from their answers
3. Use oklch harmonic relationships for palette generation
4. Document the derived system in the Visual System Declaration
