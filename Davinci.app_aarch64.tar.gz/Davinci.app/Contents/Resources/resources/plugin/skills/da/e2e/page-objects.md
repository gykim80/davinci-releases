# Page Objects

Page Object Model (POM) pattern for Playwright, using fixture-based registration and lazy locators.

## When to Create a Page Object

Apply the **3+ interactions rule**: if a test interacts with the same page or component in 3 or more distinct ways (navigation, form filling, assertion), extract a page object.

Signs you need a POM:

- The same locator string appears in 3+ test files.
- Multiple tests navigate to the same page and perform similar setup.
- A page has complex interaction sequences (multi-step forms, wizards).

**Detect:** Same locator string repeated 3+ times across test files -- suggest Page Object extraction.

## Page Object Structure

A page object encapsulates all interactions with a single page or major component. It exposes action methods and assertion methods, keeping locators private.

```typescript
// tests/page-objects/login.page.ts
import { type Page, type Locator, expect } from '@playwright/test';

export class LoginPage {
  constructor(private readonly page: Page) {}

  // -- Lazy locator methods (not constructor properties) --

  private emailInput(): Locator {
    return this.page.getByLabel('Email');
  }

  private passwordInput(): Locator {
    return this.page.getByLabel('Password');
  }

  private submitButton(): Locator {
    return this.page.getByRole('button', { name: 'Sign in' });
  }

  private errorMessage(): Locator {
    return this.page.getByRole('alert');
  }

  // -- Action methods --

  async goto(): Promise<void> {
    await this.page.goto('/login');
  }

  async login(email: string, password: string): Promise<void> {
    await this.emailInput().fill(email);
    await this.passwordInput().fill(password);
    await this.submitButton().click();
  }

  // -- Assertion methods --

  async expectError(message: string): Promise<void> {
    await expect(this.errorMessage()).toHaveText(message);
  }

  async expectRedirectTo(path: string): Promise<void> {
    await expect(this.page).toHaveURL(new RegExp(path));
  }
}
```

## Lazy Locator Methods vs Constructor Properties

Locators should be defined as methods, not as properties assigned in the constructor. This avoids stale references when the DOM changes between interactions.

```typescript
// Bad: Locators assigned in constructor become stale after navigation
export class DashboardPage {
  private readonly title: Locator;
  private readonly logoutBtn: Locator;

  constructor(private readonly page: Page) {
    this.title = page.getByRole('heading', { name: 'Dashboard' });
    this.logoutBtn = page.getByRole('button', { name: 'Logout' });
  }
}

// Good: Lazy methods return fresh locators on each call
export class DashboardPage {
  constructor(private readonly page: Page) {}

  private title(): Locator {
    return this.page.getByRole('heading', { name: 'Dashboard' });
  }

  private logoutButton(): Locator {
    return this.page.getByRole('button', { name: 'Logout' });
  }
}
```

Note: Playwright locators are inherently lazy (they do not query the DOM until an action is performed), so constructor-assigned locators work in many cases. However, method-based locators make this guarantee explicit and avoid confusion when the page navigates or re-renders between interactions.

## Action Methods vs Assertion Methods

Keep action methods (what the user does) separate from assertion methods (what we verify). Never place assertions inside action methods.

```typescript
// Bad: Assertion mixed into action method
export class CheckoutPage {
  constructor(private readonly page: Page) {}

  async submitOrder(): Promise<void> {
    await this.page.getByRole('button', { name: 'Place order' }).click();
    // Assertion should not live here
    await expect(this.page.getByText('Order confirmed')).toBeVisible();
  }
}

// Good: Separate action and assertion methods
export class CheckoutPage {
  constructor(private readonly page: Page) {}

  async submitOrder(): Promise<void> {
    await this.page.getByRole('button', { name: 'Place order' }).click();
  }

  async expectOrderConfirmed(): Promise<void> {
    await expect(this.page.getByText('Order confirmed')).toBeVisible();
  }
}
```

This separation allows tests to decide what to assert and when, and it keeps action methods reusable across tests with different verification needs.

## Fixture-Based POM Registration

Register page objects as Playwright fixtures to inject them into tests automatically.

```typescript
// tests/fixtures/auth.fixture.ts
import { test as base } from '@playwright/test';
import { LoginPage } from '../page-objects/login.page';
import { DashboardPage } from '../page-objects/dashboard.page';

interface AuthFixtures {
  loginPage: LoginPage;
  dashboardPage: DashboardPage;
}

export const test = base.extend<AuthFixtures>({
  loginPage: async ({ page }, use) => {
    await use(new LoginPage(page));
  },
  dashboardPage: async ({ page }, use) => {
    await use(new DashboardPage(page));
  },
});

export { expect } from '@playwright/test';
```

### Using Fixtures in Tests

```typescript
// tests/e2e/login.spec.ts
import { test, expect } from '../fixtures/auth.fixture';

test('successful login redirects to dashboard', async ({ loginPage, dashboardPage }) => {
  await loginPage.goto();
  await loginPage.login('user@example.com', 'password123');
  await loginPage.expectRedirectTo('/dashboard');
});

test('invalid credentials show error', async ({ loginPage }) => {
  await loginPage.goto();
  await loginPage.login('user@example.com', 'wrong');
  await loginPage.expectError('Invalid email or password');
});
```

## Composing Page Objects

For complex pages with distinct regions (header, sidebar, main content), compose smaller page objects.

```typescript
// tests/page-objects/header.component.ts
export class HeaderComponent {
  constructor(private readonly page: Page) {}

  private userMenu(): Locator {
    return this.page.getByRole('button', { name: 'User menu' });
  }

  private logoutLink(): Locator {
    return this.page.getByRole('menuitem', { name: 'Logout' });
  }

  async logout(): Promise<void> {
    await this.userMenu().click();
    await this.logoutLink().click();
  }
}

// tests/page-objects/dashboard.page.ts
export class DashboardPage {
  readonly header: HeaderComponent;

  constructor(private readonly page: Page) {
    this.header = new HeaderComponent(page);
  }

  async goto(): Promise<void> {
    await this.page.goto('/dashboard');
  }

  async expectWelcomeMessage(name: string): Promise<void> {
    await expect(
      this.page.getByRole('heading', { name: `Welcome, ${name}` })
    ).toBeVisible();
  }
}
```

## Inline Selectors vs POM Abstraction

```typescript
// Bad: Inline selectors repeated across test files
test('login success', async ({ page }) => {
  await page.goto('/login');
  await page.getByLabel('Email').fill('user@example.com');
  await page.getByLabel('Password').fill('pass123');
  await page.getByRole('button', { name: 'Sign in' }).click();
  await expect(page).toHaveURL('/dashboard');
});

test('login failure', async ({ page }) => {
  await page.goto('/login');
  await page.getByLabel('Email').fill('user@example.com');
  await page.getByLabel('Password').fill('wrong');
  await page.getByRole('button', { name: 'Sign in' }).click();
  await expect(page.getByRole('alert')).toHaveText('Invalid email or password');
});

// Good: POM abstracts repeated interactions
test('login success', async ({ loginPage }) => {
  await loginPage.goto();
  await loginPage.login('user@example.com', 'pass123');
  await loginPage.expectRedirectTo('/dashboard');
});

test('login failure', async ({ loginPage }) => {
  await loginPage.goto();
  await loginPage.login('user@example.com', 'wrong');
  await loginPage.expectError('Invalid email or password');
});
```

## Quick Reference

| Concept | Rule |
|---|---|
| When to create POM | 3+ interactions with the same page across tests |
| Locator definition | Lazy methods, not constructor properties |
| Action methods | Perform user actions only, no assertions |
| Assertion methods | Verify state only, prefixed with `expect` |
| Fixture registration | `base.extend<Fixtures>({ ... })` pattern |
| Composition | Embed component POMs as properties |
| Naming convention | `[page-name].page.ts`, `[component].component.ts` |
| Constructor parameter | `private readonly page: Page` |
| Return types | Action methods return `Promise<void>` |
| Test imports | Import `test` and `expect` from fixture file |
