/**
 * chart-kit.jsx - Lightweight Chart Components (No Dependencies)
 *
 * Provides: BarChart, LineChart, PieChart, AreaChart
 * Pure SVG-based, no external chart library needed.
 * For complex charts, use Recharts CDN instead.
 */

const { useMemo } = React;

// --- Shared utilities ---
function scaleLinear(domain, range) {
  const [d0, d1] = domain;
  const [r0, r1] = range;
  return (v) => r0 + ((v - d0) / (d1 - d0)) * (r1 - r0);
}

// --- BarChart ---
function BarChart({ data = [], width = 400, height = 250, color = "oklch(65% 0.2 250)", label = true }) {
  const max = Math.max(...data.map((d) => d.value), 1);
  const barWidth = (width - 60) / data.length - 8;
  const yScale = scaleLinear([0, max], [height - 40, 10]);

  return (
    <svg width={width} height={height} style={{ fontFamily: "system-ui" }}>
      {data.map((d, i) => {
        const x = 50 + i * (barWidth + 8);
        const y = yScale(d.value);
        const barH = height - 40 - y;
        return (
          <g key={i}>
            <rect x={x} y={y} width={barWidth} height={barH} fill={color} rx={4} />
            {label && <text x={x + barWidth / 2} y={height - 24} textAnchor="middle" fontSize={11} fill="#888">{d.label}</text>}
            <text x={x + barWidth / 2} y={y - 6} textAnchor="middle" fontSize={11} fill="#aaa">{d.value}</text>
          </g>
        );
      })}
    </svg>
  );
}

// --- LineChart ---
function LineChart({ data = [], width = 400, height = 250, color = "oklch(65% 0.2 250)", fill = true }) {
  const max = Math.max(...data.map((d) => d.value), 1);
  const xScale = scaleLinear([0, data.length - 1], [50, width - 20]);
  const yScale = scaleLinear([0, max], [height - 40, 10]);

  const points = data.map((d, i) => `${xScale(i)},${yScale(d.value)}`).join(" ");
  const areaPoints = `50,${height - 40} ${points} ${width - 20},${height - 40}`;

  return (
    <svg width={width} height={height} style={{ fontFamily: "system-ui" }}>
      {fill && <polygon points={areaPoints} fill={color} opacity={0.15} />}
      <polyline points={points} fill="none" stroke={color} strokeWidth={2.5} strokeLinejoin="round" strokeLinecap="round" />
      {data.map((d, i) => (
        <circle key={i} cx={xScale(i)} cy={yScale(d.value)} r={3.5} fill={color} />
      ))}
      {data.map((d, i) => (
        <text key={`l${i}`} x={xScale(i)} y={height - 24} textAnchor="middle" fontSize={10} fill="#888">{d.label}</text>
      ))}
    </svg>
  );
}

// --- PieChart ---
function PieChart({ data = [], size = 200, colors = ["oklch(65% 0.2 250)", "oklch(65% 0.2 150)", "oklch(65% 0.2 50)", "oklch(65% 0.2 320)"] }) {
  const total = data.reduce((s, d) => s + d.value, 0) || 1;
  const cx = size / 2, cy = size / 2, r = size * 0.38;
  let cumulative = 0;

  const slices = data.map((d, i) => {
    const start = cumulative;
    cumulative += d.value / total;
    const end = cumulative;
    const startAngle = start * Math.PI * 2 - Math.PI / 2;
    const endAngle = end * Math.PI * 2 - Math.PI / 2;
    const largeArc = end - start > 0.5 ? 1 : 0;
    const path = [
      `M ${cx} ${cy}`,
      `L ${cx + r * Math.cos(startAngle)} ${cy + r * Math.sin(startAngle)}`,
      `A ${r} ${r} 0 ${largeArc} 1 ${cx + r * Math.cos(endAngle)} ${cy + r * Math.sin(endAngle)}`,
      `Z`
    ].join(" ");
    return <path key={i} d={path} fill={colors[i % colors.length]} />;
  });

  return (
    <svg width={size} height={size}>
      {slices}
    </svg>
  );
}

window.ChartKit = { BarChart, LineChart, PieChart };
