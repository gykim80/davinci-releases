---
name: effect_text
description: Anime.js text animation effect generation with scroll/hover interactions.
agent: effect-composer
agents: [frontend-architect]
davinci-phase: design
allowed-tools: [Write, Edit, Read, Bash, Glob, Grep, Task]
next-skill: verify
skill-type: flexible
thinking: ultra
mcp-servers: [context7, codegraph]
skills-ref:
  - davinci_framework/agent-skills/skills/mengto-masked-reveal
  - davinci_framework/agent-skills/skills/mengto-staggered-word-reveal
  - davinci_framework/agent-skills/skills/mengto-gsap
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 생성자: 자기 검증은 사전 점검일 뿐이다. 최종 판정은 독립 verify 노드가 낸다. 미완료 시 partial + remaining.

# /da:effect_text -- Anime.js Text Animation Engine

## MengTo Reference Skills (on-demand — 필요 시에만 Read)
> 경로: `~/.claude/plugin/agent-skills/skills/<name>/SKILL.md`
- `mengto-masked-reveal`: 마스크 word-by-word 리빌
- `mengto-staggered-word-reveal`: 에디토리얼 스태거 워드 리빌
- `mengto-gsap`: GSAP stagger/timeline 기본기
## Tool Parameter Rules -> See CLAUDE.md (ABSOLUTE)


ultrathink

> Independent skill. No dependency on da:effect_bg or da:effect_particle.

## Execution Protocol

### Step 1: Context Detection
```yaml
1. Check invocation mode:
   - ARGUMENTS contains persona info -> da:design delegation mode
   - ARGUMENTS contains only tone/prompt -> standalone mode
2. Read package.json -> verify required dependencies
   - animejs
3. Missing packages -> run pnpm add
```

### Step 2: Tone Selection
```yaml
When delegated from da:design:
  persona -> automatic tone mapping (refer to tone-presets.md)

When invoked standalone:
  Analyze prompt keywords -> select optimal tone
```

### Step 3: Implementation
```yaml
1. Layer 2 (Text Animation):
   - anime-text-effects.md -> Create TextAnimation component
   - splitText + createScope pattern required
   - scope.revert() cleanup required

2. Layer 4 (Interaction, built-in):
   - scroll:fade (IntersectionObserver text entrance)
   - hover:3d-tilt (text container perspective tilt)

3. Font Loading Gate:
   - Wait for document.fonts.ready before animation start
```

### Step 4: Validation
```yaml
1. tsc --noEmit (type check)
2. Verify splitText + createScope usage (NOT innerHTML)
3. Verify scope.revert() in cleanup
4. Verify prefers-reduced-motion support
```

## Iron Rules

### Common (C1-C3)
- C1: prefers-reduced-motion -> CSS fallback only
- C2: cleanup function required (scope.revert())
- C3: "use client" required
- NOTE: C4 (EffectLoader) does NOT apply -- Anime.js splitText is synchronous

### Text-Specific (T1-T4)
- T1: splitText + createScope required (NOT manual innerHTML split)
- T2: innerHTML direct manipulation forbidden (text disappears in strict mode)
- T3: scope.revert() cleanup required (React strict mode safe)
- T4: Wait for font loading before animation start (layout shift prevention)

### Bundler Compatibility
- animejs static import required: import { animate, stagger } from "animejs"
- Dynamic import forbidden (scope.add() errors not caught by async catch)
- Initial opacity:0 and visible state gating forbidden
- background-clip: text + splitText incompatible (gradient text forbidden)
- Vite optimizeDeps include: ["animejs", "animejs/text", "animejs/scope"]

## Deliverables
- TextAnimation component
- ScrollFadeHero component
- TiltContainer component
