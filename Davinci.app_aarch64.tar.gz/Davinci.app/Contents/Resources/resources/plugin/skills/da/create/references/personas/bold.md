# Persona: Bold

## Visual Identity
- **Philosophy**: "Bold impact" — large typography, strong contrast, color blocks
- **Spacing**: Medium. High content density
- **Colors**: Strong primary emphasis + complementary accent. Color block sections allowed
- **Typography**: Display fonts (Bebas Neue, Clash Display). Extreme size differences
- **Borders**: Thick borders (2-4px) as design accents

## Motion Strategy
- **Speed**: fast/snappy (100-200ms)
- **Types**: Scale + translate combinations. Bounce easing
- **Frequency**: Active. Scroll reveal + hover + stagger
- **Easing**: spring (elastic)

## Component Overrides
- Cards: Large padding, high-contrast backgrounds, thick borders
- Buttons: Large and filled style. scale(1.05) on hover
- Headings: Increase clamp() max values. Can occupy more than half the screen
- Grids: Asymmetry allowed. One column large, rest small

## Anti-Patterns (forbidden for this persona)
- No small, thin text
- No passive hover (opacity-only changes)
- No uniform grids (all cells same size)
- No gray-tone dominant pages

## Token Adjustments
```css
:root { /* bold persona overrides */
  --motion-duration-fast: 100ms;
  --motion-spring: cubic-bezier(0.34, 1.8, 0.64, 1); /* stronger bounce */
}
```
