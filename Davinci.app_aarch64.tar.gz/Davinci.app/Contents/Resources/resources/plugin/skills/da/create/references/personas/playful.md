# Persona: Playful

## Visual Identity
- **Philosophy**: "Fun and friendly" — bright colors, curves, characters
- **Spacing**: Medium-wide. Relaxed feel
- **Colors**: Bright and warm palette. Pastel + vivid accent combinations
- **Typography**: Rounded fonts (Nunito, Quicksand). Large line-height
- **Borders**: rounded-xl to rounded-full. Soft curves

## Motion Strategy
- **Speed**: medium (200-300ms)
- **Types**: Bounce, wiggle, rotate. Playful motions
- **Frequency**: Active but not excessive. Fun elements on hover
- **Easing**: spring + bounce

## Component Overrides
- Cards: rounded-2xl, colorful shadows, slight rotation on hover
- Buttons: Pill shape (rounded-full), bright colors, hover bounce
- Badges: Colorful, rounded corners, include icons
- Images: rounded-2xl, overlapping placement

## Anti-Patterns (forbidden for this persona)
- No sharp corners (rounded-none, rounded-sm)
- No monochrome palette
- No rigid grid (perfect alignment)
- No heavy shadows (shadow-xl alone)
- No serif fonts

## Token Adjustments
```css
:root { /* playful persona overrides */
  --radius: 1rem; /* more rounded corners */
  --motion-spring: cubic-bezier(0.34, 2.0, 0.64, 1); /* bouncier */
}
```
