# Motion Presets Reference

> Selected and applied according to the Creative Brief's Motion_Strategy during da:design Phase 4 implementation.
> Required installation: `pnpm add motion tailwindcss-motion`

## P0: Core Presets (applied by default to all projects)

### 1. Scroll Reveal (on section entry)
```tsx
import { motion } from "motion/react"

// Fade-in + slide-up on scroll
<motion.div
  initial={{ opacity: 0, y: 24 }}
  whileInView={{ opacity: 1, y: 0 }}
  viewport={{ once: true, margin: "-100px" }}
  transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
>
  {children}
</motion.div>
```

### 2. Stagger (list/grid items)
```tsx
import { motion } from "motion/react"

// Parent container
<motion.div
  initial="hidden"
  whileInView="visible"
  viewport={{ once: true }}
  variants={{
    visible: { transition: { staggerChildren: 0.08 } }
  }}
>
  {items.map(item => (
    <motion.div
      key={item.id}
      variants={{
        hidden: { opacity: 0, y: 16 },
        visible: { opacity: 1, y: 0, transition: { duration: 0.4, ease: [0.16, 1, 0.3, 1] } }
      }}
    >
      {item.content}
    </motion.div>
  ))}
</motion.div>
```

### 3. Hover Spring (interactive elements)
```tsx
<motion.button
  whileHover={{ scale: 1.03 }}
  whileTap={{ scale: 0.97 }}
  transition={{ type: "spring", stiffness: 400, damping: 17 }}
>
  Click me
</motion.button>
```

### 4. Exit Fade (on element removal)
```tsx
import { AnimatePresence, motion } from "motion/react"

<AnimatePresence>
  {isVisible && (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0, transition: { duration: 0.15 } }}
    >
      {content}
    </motion.div>
  )}
</AnimatePresence>
```

### 5. Layout Morph (layout transitions)
```tsx
<motion.div layout layoutId="unique-id">
  {/* Auto-animates on position/size changes */}
</motion.div>
```

### 6. Number Counter (numeric counting)
```tsx
import { motion, useMotionValue, useTransform, animate } from "motion/react"
import { useEffect } from "react"

function Counter({ target }: { target: number }) {
  const count = useMotionValue(0)
  const rounded = useTransform(count, (v) => Math.round(v))

  useEffect(() => {
    const controls = animate(count, target, { duration: 2 })
    return controls.stop
  }, [target])

  return <motion.span>{rounded}</motion.span>
}
```

## Tailwind Motion Classes (CSS-only alternative)

```html
<!-- Basic fade in -->
<div class="motion-preset-fade motion-duration-500">

<!-- slide up + fade -->
<div class="motion-translate-y-in-[24px] motion-opacity-in-0 motion-duration-500">

<!-- stagger children (apply to parent) -->
<div class="motion-delay-[--stagger]" style="--stagger: calc(var(--index) * 80ms)">

<!-- spring hover -->
<button class="hover:motion-scale-in-[1.03] motion-duration-150">
```

## Usage Conditions

| Preset | Apply When | Do Not Apply When |
|--------|-----------|-------------------|
| scroll-reveal | First section entry | Already visible elements |
| stagger | Lists with 3+ identical elements | 2 or fewer items |
| hover-spring | CTAs, cards, links | Inline links within text |
| exit-fade | Modal/toast closing | Page transitions |
| layout-morph | Tab/accordion switching | Initial render |
| number-counter | Statistics/metrics | Regular text |
