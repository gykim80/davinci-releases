# Senior-Level Effects Reference

> Interactive effects at the level of a senior designer spending a month of dedicated work.
> Superset of premium-effects.md. Referenced during da:design Phase 2/4.
> Difficulty: ★★★ (existing premium-effects.md is ★ to ★★ level)

---

## Tier Classification

| Tier | Description | Examples | When to Use |
|------|------|------|----------|
| S | Wow-factor, portfolio-grade | Shaders, cursor magnetic field, scroll morphing | Hero section only (1 max) |
| A | Polished, professional feel | Parallax layers, mouse tracking, text masking | Key sections (2-3) |
| B | Refined details | 3D tilt, stagger reveal, spring physics | Cards/lists throughout |

---

## S-Tier: Cursor Magnetic Field

Elements subtly shift as if attracted to the cursor. Used by 80% of Awwwards sites.

```tsx
import { motion, useMotionValue, useSpring } from "motion/react";
import { useRef } from "react";

interface MagneticProps {
  children: React.ReactNode;
  strength?: number;  /* pull strength 0-1, default 0.3 */
  radius?: number;    /* detection radius in px, default 150 */
}

export function Magnetic({ children, strength = 0.3, radius = 150 }: MagneticProps) {
  const ref = useRef<HTMLDivElement>(null);
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const springX = useSpring(x, { stiffness: 150, damping: 15 });
  const springY = useSpring(y, { stiffness: 150, damping: 15 });

  const handleMouse = (e: React.MouseEvent) => {
    const el = ref.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const dx = e.clientX - cx;
    const dy = e.clientY - cy;
    const dist = Math.sqrt(dx * dx + dy * dy);

    if (dist < radius) {
      const pull = (1 - dist / radius) * strength;
      x.set(dx * pull);
      y.set(dy * pull);
    }
  };

  const reset = () => { x.set(0); y.set(0); };

  return (
    <motion.div
      ref={ref}
      style={{ x: springX, y: springY }}
      onMouseMove={handleMouse}
      onMouseLeave={reset}
    >
      {children}
    </motion.div>
  );
}
```

### Usage: Wrap around CTA buttons, logos, navigation icons
```tsx
<Magnetic strength={0.4}>
  <button className="...">Get Started</button>
</Magnetic>
```

---

## S-Tier: Scroll-Driven Parallax Layers

Each layer moves at a different speed based on scroll progress. Maximizes depth perception.

```tsx
import { motion, useScroll, useTransform } from "motion/react";
import { useRef } from "react";

interface ParallaxLayerProps {
  children: React.ReactNode;
  speed: number;       /* -1 to 1. Positive=slower, negative=reversed */
  className?: string;
}

export function ParallaxLayer({ children, speed, className }: ParallaxLayerProps) {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  });
  const y = useTransform(scrollYProgress, [0, 1], [speed * -120, speed * 120]);

  return (
    <motion.div ref={ref} style={{ y }} className={className}>
      {children}
    </motion.div>
  );
}

/* Usage: Text and background move at different speeds in hero */
export function ParallaxHero() {
  return (
    <section className="relative min-h-screen overflow-hidden">
      <ParallaxLayer speed={0.5} className="absolute inset-0">
        <BackgroundEffect />
      </ParallaxLayer>
      <ParallaxLayer speed={-0.1} className="relative z-10 flex items-center justify-center min-h-screen">
        <h1>Headline</h1>
      </ParallaxLayer>
      <ParallaxLayer speed={0.3} className="absolute bottom-0 left-0">
        <DecorativeElement />
      </ParallaxLayer>
    </section>
  );
}
```

---

## S-Tier: Scroll Progress Section

Section stays pinned while internal content transforms based on scroll progress.

```tsx
import { motion, useScroll, useTransform } from "motion/react";
import { useRef } from "react";

export function ScrollProgressSection({ items }: { items: { title: string; desc: string }[] }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end end"],
  });

  return (
    <div ref={containerRef} style={{ height: `${items.length * 100}vh` }} className="relative">
      <div className="sticky top-0 h-screen flex items-center overflow-hidden">
        {/* Left: Progress bar */}
        <div className="w-1 h-64 bg-border rounded-full overflow-hidden mx-8">
          <motion.div
            className="w-full bg-primary rounded-full origin-top"
            style={{ scaleY: scrollYProgress }}
          />
        </div>

        {/* Right: Content stack */}
        <div className="flex-1 relative">
          {items.map((item, i) => {
            const start = i / items.length;
            const end = (i + 1) / items.length;
            return (
              <ScrollItem key={i} item={item} progress={scrollYProgress} start={start} end={end} />
            );
          })}
        </div>
      </div>
    </div>
  );
}
```

---

## A-Tier: Cursor Trail / Spotlight

A smooth light/gradient follows the mouse position. Used on card or hero backgrounds.

```tsx
import { useMotionValue, useSpring, motion } from "motion/react";

export function CursorSpotlight({ children, className }: { children: React.ReactNode; className?: string }) {
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);
  const springX = useSpring(mouseX, { stiffness: 200, damping: 40 });
  const springY = useSpring(mouseY, { stiffness: 200, damping: 40 });

  const handleMouse = (e: React.MouseEvent) => {
    const rect = e.currentTarget.getBoundingClientRect();
    mouseX.set(e.clientX - rect.left);
    mouseY.set(e.clientY - rect.top);
  };

  return (
    <div className={`relative overflow-hidden ${className ?? ""}`} onMouseMove={handleMouse}>
      <motion.div
        className="pointer-events-none absolute -inset-px opacity-0 group-hover:opacity-100 transition-opacity duration-300"
        style={{
          background: `radial-gradient(300px circle at ${springX}px ${springY}px, hsl(var(--primary) / 0.12), transparent 60%)`,
        }}
      />
      {children}
    </div>
  );
}
```

### Usage: Wrap around cards to make light follow the mouse
```tsx
<CursorSpotlight className="group rounded-2xl border bg-card p-6">
  <h3>Feature Title</h3>
  <p>Description</p>
</CursorSpotlight>
```

---

## A-Tier: Text Clip Mask

Effect where gradients/images/video are visible through the text shape.

```tsx
/* Gradient text — animated */
export function GradientText({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <span
      className={`bg-clip-text text-transparent bg-[length:200%_auto] animate-[gradient-shift_3s_ease-in-out_infinite] ${className ?? ""}`}
      style={{
        backgroundImage: "linear-gradient(90deg, hsl(var(--primary)), hsl(var(--accent)), hsl(var(--primary)))",
      }}
    >
      {children}
    </span>
  );
}

/* Add to globals.css */
// @keyframes gradient-shift { 0%,100% { background-position: 0% center; } 50% { background-position: 200% center; } }
```

```tsx
/* Scroll-driven text reveal — per-word opacity */
import { motion, useScroll, useTransform } from "motion/react";
import { useRef } from "react";

export function ScrollTextReveal({ text }: { text: string }) {
  const ref = useRef<HTMLParagraphElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start 0.9", "start 0.3"],
  });

  const words = text.split(" ");

  return (
    <p ref={ref} className="flex flex-wrap gap-x-2">
      {words.map((word, i) => {
        const start = i / words.length;
        const end = start + 1 / words.length;
        return <Word key={i} word={word} progress={scrollYProgress} range={[start, end]} />;
      })}
    </p>
  );
}

function Word({ word, progress, range }: { word: string; progress: any; range: [number, number] }) {
  const opacity = useTransform(progress, range, [0.15, 1]);
  return <motion.span style={{ opacity }} className="text-foreground">{word}</motion.span>;
}
```

---

## A-Tier: Smooth Image Reveal (curtain effect)

Image gradually reveals from one side on scroll.

```tsx
import { motion, useScroll, useTransform } from "motion/react";
import { useRef } from "react";

export function ImageReveal({ src, alt, direction = "left" }: {
  src: string; alt: string; direction?: "left" | "right" | "top" | "bottom";
}) {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start 0.85", "start 0.35"],
  });

  const clipMap = {
    left: (p: number) => `inset(0 ${100 - p * 100}% 0 0)`,
    right: (p: number) => `inset(0 0 0 ${100 - p * 100}%)`,
    top: (p: number) => `inset(0 0 ${100 - p * 100}% 0)`,
    bottom: (p: number) => `inset(${100 - p * 100}% 0 0 0)`,
  };

  const clipPath = useTransform(scrollYProgress, [0, 1], [clipMap[direction](0), clipMap[direction](1)]);

  return (
    <div ref={ref} className="overflow-hidden">
      <motion.img
        src={src}
        alt={alt}
        className="w-full h-full object-cover"
        style={{ clipPath }}
      />
    </div>
  );
}
```

---

## B-Tier: Stagger Grid Reveal (grid item cascade)

Grid items appear sequentially in a diagonal direction.

```tsx
export function StaggerGrid({ children, cols = 3 }: { children: React.ReactNode[]; cols?: number }) {
  return (
    <motion.div
      className={`grid grid-cols-${cols} gap-4`}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, margin: "-50px" }}
      variants={{ visible: { transition: { staggerChildren: 0.06 } } }}
    >
      {children.map((child, i) => {
        const row = Math.floor(i / cols);
        const col = i % cols;
        const diagonalDelay = (row + col) * 0.06; /* diagonal order */
        return (
          <motion.div
            key={i}
            variants={{
              hidden: { opacity: 0, scale: 0.85, y: 20 },
              visible: {
                opacity: 1, scale: 1, y: 0,
                transition: { duration: 0.5, delay: diagonalDelay, ease: [0.16, 1, 0.3, 1] },
              },
            }}
          >
            {child}
          </motion.div>
        );
      })}
    </motion.div>
  );
}
```

---

## B-Tier: Elastic Hover Card

Elastic effect where the card compresses then expands on hover.

```tsx
export function ElasticCard({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <motion.div
      className={className}
      whileHover={{
        scale: 1.04,
        transition: { type: "spring", stiffness: 400, damping: 10 },
      }}
      whileTap={{ scale: 0.96 }}
    >
      {children}
    </motion.div>
  );
}
```

---

## Application Protocol (da:design Phase 2/4)

```yaml
Phase_2_Effect_Selection:
  Required_S_Tier: At least 1 S-Tier effect for hero (Magnetic CTA or Parallax or ScrollProgress)
  Required_A_Tier: A-Tier at 2-3 key sections (CursorSpotlight, TextClipMask, ImageReveal)
  Optional_B_Tier: B-Tier for cards/lists (StaggerGrid, ElasticCard)

Phase_4_Integration:
  1. Create effect components in src/components/effects/
  2. Import and apply in section components
  3. Performance guard: Deactivate outside viewport with IntersectionObserver
  4. Mobile: Disable cursor effects, reduce parallax sensitivity by 50%

Fidelity_Score_Impact:
  1+ S-Tier used: +5 points (Background_Effects dimension)
  2+ A-Tier used: +3 points (Animation_Patterns dimension)
  Cursor-responsive effect present: +3 points (Visual_Coherence dimension)
  None used: -10 points (existing penalty maintained)
```
