# Accessibility Testing

Automated WCAG 2.1 AA compliance testing using axe-core with Playwright, keyboard navigation validation, ARIA attribute checks, and focus management verification.

## axe-core Integration

### Setup

Install the axe-core Playwright integration and use it to run automated accessibility scans against rendered pages.

```bash
npm install -D @axe-core/playwright
```

```typescript
// Bad: relying on visual inspection or screenshots for accessibility
test('homepage is accessible', async ({ page }) => {
  await page.goto('/');
  const screenshot = await page.screenshot();
  // manually inspect screenshot for accessibility issues
  // this catches nothing programmatically
});
```

```typescript
// Good: automated axe-core scan with Playwright
import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

test('homepage has no accessibility violations', async ({ page }) => {
  await page.goto('/');

  const results = await new AxeBuilder({ page })
    .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
    .analyze();

  expect(results.violations).toEqual([]);
});
```

**Detect:** Test file imports `@playwright/test` but has no `@axe-core/playwright` import -- suggest adding axe-core accessibility assertions.

### WCAG 2.1 AA Tag Filtering

axe-core supports tag-based rule filtering to target specific WCAG conformance levels.

| Tag | WCAG Level | Description |
|---|---|---|
| `wcag2a` | 2.0 A | Minimum conformance |
| `wcag2aa` | 2.0 AA | Standard conformance (most common target) |
| `wcag21a` | 2.1 A | Includes mobile and cognitive criteria |
| `wcag21aa` | 2.1 AA | Full modern conformance target |
| `best-practice` | N/A | Non-WCAG recommendations from axe |

```typescript
// Good: target WCAG 2.1 AA specifically
const results = await new AxeBuilder({ page })
  .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
  .analyze();
```

### Scanning Specific Page Regions

Scope axe-core to a specific region instead of the full page to isolate issues or test individual components.

```typescript
// Good: scan only the main content area
const results = await new AxeBuilder({ page })
  .include('#main-content')
  .withTags(['wcag2a', 'wcag2aa'])
  .analyze();

expect(results.violations).toEqual([]);
```

```typescript
// Good: scan a modal dialog in isolation
test('settings modal is accessible', async ({ page }) => {
  await page.goto('/dashboard');
  await page.getByRole('button', { name: 'Settings' }).click();
  await expect(page.getByRole('dialog')).toBeVisible();

  const results = await new AxeBuilder({ page })
    .include('[role="dialog"]')
    .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
    .analyze();

  expect(results.violations).toEqual([]);
});
```

### Disabling Specific Rules

Disable rules for known exceptions that are intentional or handled by other means. Always use targeted exclusion rather than broad disabling.

```typescript
// Bad: disabling many rules broadly without justification
const results = await new AxeBuilder({ page })
  .disableRules(['color-contrast', 'image-alt', 'link-name', 'label'])
  .analyze();
```

```typescript
// Good: disable a single rule with a documented reason
const results = await new AxeBuilder({ page })
  // Decorative SVG background intentionally has no alt text
  .disableRules(['svg-img-alt'])
  .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
  .analyze();

expect(results.violations).toEqual([]);
```

**Detect:** `.disableRules()` call with more than 2 rules -- suggest reviewing whether each exclusion is justified.

## Keyboard Navigation Testing

### Tab Order and Focus

Verify that interactive elements are reachable and in logical order via Tab and Shift+Tab.

```typescript
// Good: verify tab order through navigation
test('tab order follows logical reading order', async ({ page }) => {
  await page.goto('/');

  await page.keyboard.press('Tab');
  await expect(page.getByRole('link', { name: 'Skip to content' })).toBeFocused();

  await page.keyboard.press('Tab');
  await expect(page.getByRole('link', { name: 'Home' })).toBeFocused();

  await page.keyboard.press('Tab');
  await expect(page.getByRole('link', { name: 'Products' })).toBeFocused();

  await page.keyboard.press('Tab');
  await expect(page.getByRole('link', { name: 'About' })).toBeFocused();
});
```

### Key Interactions

Test that keyboard shortcuts and key-based interactions work for menus, dropdowns, and custom widgets.

```typescript
// Good: test dropdown menu keyboard interaction
test('dropdown menu is operable via keyboard', async ({ page }) => {
  await page.goto('/');

  // Focus the dropdown trigger
  await page.getByRole('button', { name: 'Account menu' }).focus();
  await page.keyboard.press('Enter');

  // Menu should open
  await expect(page.getByRole('menu')).toBeVisible();

  // Navigate items with arrow keys
  await page.keyboard.press('ArrowDown');
  await expect(page.getByRole('menuitem', { name: 'Profile' })).toBeFocused();

  await page.keyboard.press('ArrowDown');
  await expect(page.getByRole('menuitem', { name: 'Settings' })).toBeFocused();

  // Select with Enter
  await page.keyboard.press('Enter');
  await expect(page).toHaveURL('/settings');
});
```

### Escape Key Behavior

```typescript
// Good: Escape closes overlays and returns focus
test('Escape closes modal and returns focus to trigger', async ({ page }) => {
  await page.goto('/dashboard');

  const openButton = page.getByRole('button', { name: 'Open dialog' });
  await openButton.click();
  await expect(page.getByRole('dialog')).toBeVisible();

  await page.keyboard.press('Escape');
  await expect(page.getByRole('dialog')).not.toBeVisible();
  await expect(openButton).toBeFocused();
});
```

## Focus Management

### Focus Trap in Modals

When a modal is open, Tab and Shift+Tab must cycle only within the modal, not escape to background content.

```typescript
// Good: verify focus trap within a dialog
test('focus is trapped inside modal dialog', async ({ page }) => {
  await page.goto('/dashboard');
  await page.getByRole('button', { name: 'Delete account' }).click();

  const dialog = page.getByRole('dialog');
  await expect(dialog).toBeVisible();

  // Collect all focusable elements in the dialog
  const focusableElements = dialog.locator(
    'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
  );
  const count = await focusableElements.count();

  // Tab through all focusable elements and verify focus stays in dialog
  for (let i = 0; i < count + 1; i++) {
    await page.keyboard.press('Tab');
    const focused = page.locator(':focus');
    await expect(dialog).toContainText(await focused.textContent() ?? '');
  }
});
```

### Skip Links

```typescript
// Good: verify skip link navigates to main content
test('skip link moves focus to main content', async ({ page }) => {
  await page.goto('/');

  await page.keyboard.press('Tab');
  const skipLink = page.getByRole('link', { name: 'Skip to content' });
  await expect(skipLink).toBeFocused();

  await page.keyboard.press('Enter');
  await expect(page.locator('#main-content')).toBeFocused();
});
```

## ARIA Attribute Validation

### Required ARIA Labels

Interactive elements must have accessible names. Test that buttons, links, and form controls have proper labels.

```typescript
// Good: verify ARIA attributes on interactive elements
test('all interactive elements have accessible names', async ({ page }) => {
  await page.goto('/dashboard');

  // Buttons with icon-only content must have aria-label
  const iconButtons = page.locator('button:has(svg):not(:has-text(""))');
  const buttonCount = await iconButtons.count();
  for (let i = 0; i < buttonCount; i++) {
    const button = iconButtons.nth(i);
    const ariaLabel = await button.getAttribute('aria-label');
    const ariaLabelledBy = await button.getAttribute('aria-labelledby');
    expect(ariaLabel || ariaLabelledBy, `Icon button at index ${i} missing accessible name`).toBeTruthy();
  }
});
```

**Detect:** `<button>` element containing only an SVG or `<img>` with no `aria-label` or `aria-labelledby` attribute -- suggest adding an accessible name.

### Live Regions

```typescript
// Good: verify aria-live regions announce dynamic content
test('status message is announced via aria-live', async ({ page }) => {
  await page.goto('/tasks');

  await page.getByRole('button', { name: 'Save' }).click();

  const statusRegion = page.locator('[aria-live="polite"]');
  await expect(statusRegion).toBeVisible();
  await expect(statusRegion).toHaveText('Changes saved successfully');
});
```

### Described By

```typescript
// Good: verify form fields have descriptive help text
test('password field has description for requirements', async ({ page }) => {
  await page.goto('/register');

  const passwordInput = page.getByLabel('Password');
  const describedBy = await passwordInput.getAttribute('aria-describedby');
  expect(describedBy).toBeTruthy();

  const description = page.locator(`#${describedBy}`);
  await expect(description).toContainText('At least 8 characters');
});
```

## Color Contrast Verification

axe-core checks color contrast automatically when included in the WCAG 2.0 AA tag set. For additional confidence, verify contrast on specific elements.

```typescript
// Good: dedicated contrast check on specific content regions
test('main content passes color contrast check', async ({ page }) => {
  await page.goto('/');

  const results = await new AxeBuilder({ page })
    .include('#main-content')
    .withRules(['color-contrast'])
    .analyze();

  expect(results.violations).toEqual([]);
});
```

## Screen Reader Testing Considerations

Automated tests cannot fully replace manual screen reader testing, but they can validate the underlying markup that screen readers consume.

- Verify all images have `alt` attributes (empty string for decorative images).
- Verify heading hierarchy (`h1` through `h6`) follows a logical, non-skipping order.
- Verify landmark regions (`main`, `nav`, `banner`, `contentinfo`) are present.
- Verify form inputs have associated `<label>` elements.

```typescript
// Good: validate heading hierarchy
test('page has correct heading hierarchy', async ({ page }) => {
  await page.goto('/');

  const headings = page.locator('h1, h2, h3, h4, h5, h6');
  const headingLevels: number[] = [];
  const count = await headings.count();

  for (let i = 0; i < count; i++) {
    const tag = await headings.nth(i).evaluate((el) => el.tagName);
    headingLevels.push(parseInt(tag.replace('H', ''), 10));
  }

  // First heading should be h1
  expect(headingLevels[0]).toBe(1);

  // No heading should skip more than one level
  for (let i = 1; i < headingLevels.length; i++) {
    const jump = headingLevels[i] - headingLevels[i - 1];
    expect(jump, `Heading level jumped from h${headingLevels[i - 1]} to h${headingLevels[i]}`).toBeLessThanOrEqual(1);
  }
});

// Good: validate landmark regions exist
test('page has required landmark regions', async ({ page }) => {
  await page.goto('/');

  await expect(page.locator('main')).toHaveCount(1);
  await expect(page.locator('nav')).toBeVisible();
  await expect(page.locator('header, [role="banner"]')).toBeVisible();
  await expect(page.locator('footer, [role="contentinfo"]')).toBeVisible();
});
```

## Full Example: Comprehensive Accessibility Test Suite

```typescript
// tests/e2e/accessibility.spec.ts
import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

const pages = ['/', '/about', '/products', '/contact', '/login'];

for (const path of pages) {
  test.describe(`Accessibility: ${path}`, () => {
    test(`${path} passes axe-core WCAG 2.1 AA`, async ({ page }) => {
      await page.goto(path);

      const results = await new AxeBuilder({ page })
        .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
        .analyze();

      expect(results.violations).toEqual([]);
    });

    test(`${path} has correct heading hierarchy`, async ({ page }) => {
      await page.goto(path);

      const headings = page.locator('h1, h2, h3, h4, h5, h6');
      const count = await headings.count();

      if (count > 0) {
        const firstTag = await headings.first().evaluate((el) => el.tagName);
        expect(firstTag).toBe('H1');
      }
    });

    test(`${path} has required landmark regions`, async ({ page }) => {
      await page.goto(path);

      await expect(page.locator('main')).toHaveCount(1);
    });

    test(`${path} images have alt attributes`, async ({ page }) => {
      await page.goto(path);

      const images = page.locator('img');
      const count = await images.count();

      for (let i = 0; i < count; i++) {
        const alt = await images.nth(i).getAttribute('alt');
        expect(alt, `Image at index ${i} missing alt attribute`).not.toBeNull();
      }
    });
  });
}

test.describe('Keyboard Navigation', () => {
  test('skip link is present and functional', async ({ page }) => {
    await page.goto('/');

    await page.keyboard.press('Tab');
    const skipLink = page.getByRole('link', { name: /skip/i });
    await expect(skipLink).toBeFocused();

    await page.keyboard.press('Enter');
    const main = page.locator('main, #main-content');
    await expect(main.first()).toBeFocused();
  });

  test('modal focus trap works correctly', async ({ page }) => {
    await page.goto('/dashboard');
    const trigger = page.getByRole('button', { name: 'Settings' });
    await trigger.click();

    const dialog = page.getByRole('dialog');
    await expect(dialog).toBeVisible();

    // First focusable element in dialog should receive focus
    const firstFocusable = dialog.locator(
      'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
    ).first();
    await expect(firstFocusable).toBeFocused();

    // Escape should close and return focus
    await page.keyboard.press('Escape');
    await expect(dialog).not.toBeVisible();
    await expect(trigger).toBeFocused();
  });
});
```

## Quick Reference

| Criterion | Test Approach | axe-core Tag/Rule |
|---|---|---|
| WCAG 2.0 Level A | `withTags(['wcag2a'])` | Minimum baseline |
| WCAG 2.0 Level AA | `withTags(['wcag2a', 'wcag2aa'])` | Standard target |
| WCAG 2.1 Level AA | `withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])` | Modern full target |
| Color contrast | `withRules(['color-contrast'])` | 4.5:1 normal, 3:1 large text |
| Image alt text | `withRules(['image-alt'])` or manual `getAttribute('alt')` | Non-decorative images |
| Form labels | `withRules(['label'])` | All inputs need labels |
| Link names | `withRules(['link-name'])` | All links need text |
| Keyboard tab order | `page.keyboard.press('Tab')` + `toBeFocused()` | Manual assertion |
| Focus trap (modals) | Tab cycle within `[role="dialog"]` | Manual assertion |
| Skip links | Tab to first link + verify `#main-content` focus | Manual assertion |
| ARIA labels | `getAttribute('aria-label')` or `getAttribute('aria-labelledby')` | Manual assertion |
| ARIA live regions | `locator('[aria-live]')` + `toHaveText()` | Manual assertion |
| Heading hierarchy | Evaluate `h1`-`h6` tag sequence | `withRules(['heading-order'])` |
| Landmark regions | `locator('main')`, `locator('nav')` | `withRules(['landmark-one-main'])` |
| Scoped scan | `.include('#selector')` on AxeBuilder | Isolate component |
| Rule exclusion | `.disableRules(['rule-id'])` | Documented exceptions only |
