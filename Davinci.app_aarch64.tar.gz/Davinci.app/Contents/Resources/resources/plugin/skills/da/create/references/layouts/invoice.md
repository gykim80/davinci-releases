# Invoice Layout (R12 mitigation)

**Print-first invoice / 청구서 / 세금계산서 / receipt layout.**

Pair with: `assets/template-invoice.html` (A4-print-ready, default 한국형 with US placeholders).

> **R12 (Invoice 한국형 미반영)** — 이 레이아웃은 한국 사업자번호 / 부가세 / 세금계산서 형식과 US tax-id / Net 30 형식을 둘 다 정의해 위험을 해소한다.

## Pre-flight

1. **Read `assets/template-invoice.html`** — A4 page setup + Korean default + US comments.
2. **Pick variant first.** 한국형 vs US — never mix in one document.
3. **Print-friendly first.** PDF is the primary delivery. Screen view is a courtesy.
4. **All numbers right-aligned with `tabular-nums`.** Reading totals at a glance is the whole point.

## Trigger keywords

- Korean: `인보이스`, `세금계산서`, `청구서`, `견적서`, `영수증`, `거래명세서`
- English: `invoice`, `bill`, `quote`, `quotation`, `receipt`, `statement`

When matched, set `vertical=invoice` and load this file + `assets/template-invoice.html`.

## Variant A — 한국형 (default)

**Required fields (legal / customary):**

| Field | Korean | Notes |
|---|---|---|
| 발행자 | 공급자 | 상호 / 사업자등록번호 / 대표자 / 사업장소재지 / 업태 / 종목 |
| 수신자 | 공급받는자 | 상호 / 사업자등록번호 / 대표자 / 사업장소재지 |
| 문서번호 | INV-YYYY-NNN | 일련번호 누락 금지 |
| 발행일 | 작성일자 | YYYY-MM-DD 형식 |
| 공급가액 | Subtotal (VAT 제외) | 원화(₩) |
| 부가세 | VAT 10% | 자동 계산, 별도 표시 |
| 합계 | 공급가액 + 부가세 | 굵게, 큰 글씨 |
| 입금정보 | 은행 / 계좌번호 / 예금주 | 명시 필수 |
| 비고 | 결제기한, 지연 이자 등 | 선택 |

세금계산서 모드 추가 필드: `공급자 / 공급받는자 / 작성일자 / 공급가액 / 세액 / 비고` (국세청 표준).

## Variant B — US

**Required fields:**

| Field | Notes |
|---|---|
| Bill From | Company name, EIN/Tax ID, address, phone, email |
| Bill To | Client name, address, contact email |
| Invoice # | INV-2026-0001 sequential |
| Invoice Date | MM/DD/YYYY (US) or YYYY-MM-DD (ISO) |
| Due Date | Payment terms, e.g., **Net 30** |
| Subtotal | USD ($) |
| Tax | State tax % (varies by state) |
| Total | Subtotal + Tax |
| Payment Terms | Net 15 / Net 30 / Net 60 / Due on receipt |
| Payment Methods | Wire / ACH / Stripe link / Check |
| Late Fee Policy | e.g., 1.5% per month after due date |

## Token spec (print-friendly)

```css
:root {
  --ink: #111111;          /* near-black for high-contrast print */
  --paper: #ffffff;
  --rule: #d1d5db;
  --muted: #4b5563;
  --accent: #1e3a8a;       /* corporate-safe deep blue */
  --total-bg: #f3f4f6;
}
@page { size: A4; margin: 20mm; }
@media print {
  body { background: white; }
  .no-print { display: none; }
  table tr { page-break-inside: avoid; }
}
```

System fonts only: `-apple-system, "Pretendard", "Malgun Gothic", "Apple SD Gothic Neo", Arial, sans-serif`.

## Section archetype

1. **Header** — Logo placeholder (left) + 문서명 (`청구서 / INVOICE`) + 문서번호 + 작성일자 (right).
2. **Bill-From / Bill-To** — 2-column grid. 공급자 좌, 공급받는자 우.
3. **Line items table** — 항목 / 수량 / 단가 / 금액 (Korean) or Item / Qty / Unit price / Amount (US).
4. **Totals block** — 공급가액 → 부가세 → 합계 (Korean) / Subtotal → Tax → Total (US). Right-aligned, tabular-nums.
5. **Payment instructions** — 입금정보 (은행/계좌/예금주) or Payment terms + methods.
6. **Footer / Notes** — 비고, 약관, 서명란.

## P0 Checklist (must pass — R12)

- [ ] **All required fields present** for the chosen variant (한국형 사업자번호 / US Tax ID).
- [ ] All currency uses `font-variant-numeric: tabular-nums` for column alignment.
- [ ] `page-break-inside: avoid` on every line-item `<tr>`.
- [ ] `@page { size: A4; margin: 20mm }` for 한국형 or `Letter` for US.
- [ ] Document number (INV-...) and date both present and unambiguous.
- [ ] Total row visually distinct (background fill or top border 2px).
- [ ] Currency symbol consistent (₩ for Korean, $ for US — never mixed).

## P1 Checklist (should pass)

- [ ] **PDF print stylesheet** — print preview matches sent PDF byte-for-byte (no viewport-only styles).
- [ ] Signature block (서명란 / Signature) at footer.
- [ ] Multi-currency display where applicable (e.g., USD primary + KRW reference).
- [ ] Bilingual labels for cross-border invoices (`청구서 / INVOICE`, `합계 / Total`).
- [ ] Payment due date prominently displayed (red or accent color near total).

## P2 Checklist (nice to have)

- [ ] **QR code for payment link** (Toss / Stripe / KakaoPay) in payment instructions area.
- [ ] **JSON metadata** in `<script type="application/json" id="invoice-meta">` for accounting software import.
- [ ] **세금계산서 PDF 출력** mode (국세청 표준 템플릿 분기).
- [ ] Repeat header on multi-page (`thead` with `display: table-header-group`).

## Anti-patterns (do NOT)

- Sans-only number alignment without `tabular-nums` (columns wobble).
- Currency mixing in one doc (₩ subtotal + $ total).
- Web-only fonts that fail in PDF export.
- Background images on totals block (fails in print).
- Missing 사업자등록번호 in Korean variant (legally insufficient).
- Color-only emphasis on total (fails in B&W print).
