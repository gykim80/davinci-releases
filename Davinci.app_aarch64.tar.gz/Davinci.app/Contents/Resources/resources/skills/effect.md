---
name: effect
description: 5 Layer hero/banner effect generation. Vanta WebGL background + Anime.js text + tsParticles + Motion interaction + CSS finishing.
agent: effect-composer
agents: [frontend-architect, ux-designer]
davinci-phase: design
allowed-tools: [Write, Edit, Read, Bash, Glob, Grep, Task]
next-skill: verify
skill-type: flexible
thinking: ultra
mcp-servers: [context7, serena]
---

## Tool Parameter Rules -> See CLAUDE.md (ABSOLUTE)

# /da:effect — 5 Layer Hero Effect Engine

ultrathink

## Execution Protocol

### Step 1: Context Detection
```yaml
1. Check invocation mode:
   - ARGUMENTS contains persona info → da:design delegation mode
   - ARGUMENTS contains only tone/prompt → standalone mode
2. Read package.json → verify required dependencies
   - motion, animejs, @tsparticles/react, @tsparticles/slim
   - three, vanta (when using Vanta backgrounds)
3. Missing packages → run pnpm add
4. Verify src/components/effects/ directory creation
```

### Step 2: Tone Selection
```yaml
When delegated from da:design:
  persona → automatic tone mapping (refer to tone-presets.md)
  minimal→minimal, bold→dark, playful→playful, elegant→luxury, terminal→cyber

When invoked standalone:
  Analyze prompt keywords → select optimal tone
  "dark/moody/serious" → dark
  "neon/cyberpunk/glow" → neon
  "minimal/simple/Apple" → minimal
  "natural/organic/warm" → organic
  "luxury/premium/elegant" → luxury
  "corporate/business/SaaS" → corporate
  "fun/lively/party" → playful
  "terminal/hacker/matrix" → cyber
```

### Step 3: Config Generation
```yaml
1. Load the 5 Layer config for the selected tone from tone-presets.md
2. Apply Harmony Validator (check 7 forbidden combinations)
3. Verify Complexity Budget (max 5 points)
4. Auto-downgrade on budget exceeded: hover → particle → mouse → scroll
5. Apply Layer Override Protocol (user customizations, see below)
```

### Step 3.5: Layer Override Protocol (사용자 커스터마이징)
```yaml
Purpose: |
  8 Tone Preset은 기본 출발점. 사용자가 특정 Layer만 변경하고 싶을 때
  Preset 기반 + 개별 Layer override로 하이브리드 조합을 지원한다.

Override_Detection:
  # 사용자 요청에서 Layer Override 키워드 감지
  Layer_1_Override: "background을 waves로", "배경을 fog로 변경", "halo 대신 net"
  Layer_2_Override: "텍스트를 glitch로", "타이핑 효과", "neon-flicker"
  Layer_3_Override: "파티클 추가해", "confetti 넣어", "gold-dust"
  Layer_4_Override: "3D tilt 추가", "커서 따라다니는 효과", "follower"
  Layer_5_Override: "스캔라인 추가", "grain 빼줘", "vignette"

Override_Execution:
  1. Base: 선택된 Tone Preset의 5 Layer 기본 구성 로드
  2. Override: 사용자가 언급한 Layer만 교체
     예시: "neon 톤인데 background은 waves로"
       → base_tone: neon (Layer 2-5 유지: neon-flicker, null, follower, glow+scanlines)
       → Layer 1만 override: vanta/net → vanta/waves
  3. Harmony 재검증: Override 적용 후 7 forbidden combinations 재체크
     → 위반 시: 위반 사실 + Auto-Fix 제안 알림
     → 예: waves(organic) + glitch(digital) = Rule #3 위반 → text를 split-fade로 대체 제안
  4. Complexity 재계산: Override 후 총점 5점 초과 여부 체크
     → 초과 시: 기존 Auto-downgrade 로직 적용 (hover → particle → mouse → scroll 순 제거)
  5. 결과 확인: Override 적용된 최종 5 Layer 구성을 사용자에게 1줄 요약 출력

Override_Examples:
  "luxury인데 파티클도 넣고 싶어":
    → base: luxury (clouds/horizontal-split/gold-dust/parallax/grain+vignette) = 5점
    → gold-dust 이미 있음 → "이미 gold-dust 파티클이 포함되어 있습니다" 안내
    → 다른 파티클 원하면: gold-dust → confetti (변경), 총점 변동 없음 (1→1)

  "minimal인데 좀 더 화려하게":
    → base: minimal (solid/spring/null/scroll:fade/null) = 0점
    → 자동 업그레이드 제안: background → vanta/dots(+1), text → split-fade(+1), particle → stars(+1) = 3점
    → "minimal 기반으로 dots 배경 + split-fade 텍스트 + stars 파티클을 추가합니다 (3/5점)"

  "dark인데 scanlines 넣어줘":
    → base: dark (halo/split-fade/stars/parallax+fade/grain+vignette+glow) = 5점
    → scanlines 추가 → finishing에 scanlines 추가 (finishing은 score 0이므로 예산 OK)
    → Harmony check: scanlines + dark(luxury 아님) → Rule #5 미해당 → 통과

da:work_Pipeline_Mode:
  # da:work에서 자동 실행 시 AskUserQuestion 금지
  # Override 감지가 불가능하므로 Tone Preset 100% 적용 (override 없음)
  # 사용자가 standalone에서 /da:effect 직접 호출 시에만 Override 활성
```

### Step 4: Implementation

> **Iron Rule**: Implementation MUST be based **exactly on** the React Integration Patterns from references/ files.
> **Forbidden** to arbitrarily reinterpret or replace reference code structure, import, and cleanup patterns with custom implementations.

```yaml
Load code snippets for each layer from references/ files and apply to project:

1. Layer 1 (Background):
   - vanta-backgrounds.md → Create VantaBackground component
   - Include CSS fallback
   ⚠️ Required: VantaBackground must use {children} pattern
     - Content must be wrapped as children (Vanta auto-assigns z-index:1 to children)
     - Absolutely forbidden to separate Vanta as a sibling element
     - Refer to vanta-backgrounds.md "Layer Integration" section

2. Layer 2 (Text):
   - anime-text-effects.md → Create TextAnimation component
   ⚠️ Required: Use splitText + createScope pattern
     - import { splitText } from "animejs/text" required
     - import { createScope } from "animejs/scope" required
     - scope.revert() cleanup required (React strict mode compatibility)
     - Absolutely forbidden to use manual innerHTML/textContent-based split
     - Refer to anime-text-effects.md "Next.js / React 19 Caveats" section

3. Layer 3 (Particle):
   - tsparticles-presets.md → Create ParticleOverlay component
   - Apply density mapping

4. Layer 4 (Interaction):
   - interactions-finishing.md → Create interaction hooks/components
   - Mobile: disable cursor effects, reduce parallax by 50%
   ⚠️ Required: useMouseParallax must use useMotionValue + useSpring pattern
     - Forbidden to use useState-based mouse tracking (no spring effect)
     - Use the useMouseParallax hook code from interactions-finishing.md as-is

5. Layer 5 (Finishing):
   - interactions-finishing.md → Create CSS overlay component

6. Loading State (필수):
   - effect-loading.md → useEffectReady 훅 + EffectLoader 컴포넌트 생성
   ⚠️ 필수: 모든 비동기 레이어에 onReady 콜백 연결
     - VantaBackground: onReady → setReady("background")
     - TextAnimation: onReady → setReady("text")
     - ParticleOverlay: onReady → setReady("particle")
   - EffectLoader는 allReady 전까지 tone 색상 프로그레스 바 표시
   - allReady 시 AnimatePresence exit으로 fade-out
   - 로딩 없이 빈 화면 표시 절대 금지

7. Integration Component (EffectHero):
   - Use VantaBackground as the outermost wrapper
   - Place all other layers as children of VantaBackground
   - EffectLoader를 VantaBackground children 최상단에 배치
   - Timeline orchestration (energy-based)
   - Device Tier detection + automatic downgrade

   Enforced structure:
   <VantaBackground effect={...} onReady={...}>    ← Layer 1 (outermost)
     <EffectLoader ready={allReady} tone={tone} /> ← Loading state
     <TextAnimation onReady={...} />               ← Layer 2
     <ParticleOverlay onReady={...} />              ← Layer 3
     <InteractionLayer ... />                       ← Layer 4
     <FinishingOverlay ... />                       ← Layer 5
   </VantaBackground>
```

### Step 5: Validation
```yaml
1. tsc --noEmit (type check)
2. Verify generated component import paths
3. Verify prefers-reduced-motion support
4. Verify WebGL fallback paths
```

## Iron Law
- CSS-only hero backgrounds forbidden → Vanta/tsParticles required
- Complexity Budget must not exceed 5 points
- Harmony forbidden combination violations prohibited
- prefers-reduced-motion must be respected
- **references/ code pattern compliance required** → re-implementation via custom interpretation forbidden
- **Vanta children pattern required** → sibling separation forbidden (z-index conflict)
- **splitText + createScope required** → manual DOM split forbidden (text disappears in strict mode)
- **useMotionValue + useSpring required** → useState-based mouse tracking forbidden

## Bundler Compatibility Iron Law (Vite/Webpack)
- **THREE static import 필수** → `import * as THREE from "three"` + `window.THREE = THREE` 패턴 강제
- **`await import("three")` 금지** → namespace object가 Vanta에 전달되면 WebGL 초기화 실패
- **Vanta import 경로**: `vanta/dist/vanta.{effect}.min` 은 package.json exports 미등록 → `/node_modules/vanta/dist/vanta.{effect}.min.js` 절대경로 사용
- **animejs static import 필수** → `import { animate, stagger } from "animejs"` (dynamic import 금지)
- **animejs dynamic import 금지 이유** → scope.add() 내부 에러가 async catch에 안 잡혀서 opacity:0 상태로 텍스트 영구 안 보임
- **초기 opacity:0 및 visible state 게이팅 절대 금지** → scope.add() 내부 에러는 외부 try/catch에 전파 안 됨 → setVisible(true) 영원히 미호출 → 텍스트 영구 숨김. 텍스트는 항상 보이는 상태로 렌더링하고 애니메이션은 progressive enhancement로만 적용
- **Vite optimizeDeps 필수** → `include: ["three", "animejs", "animejs/text", "animejs/scope"]` 설정
- **`background-clip: text` + splitText 비호환** → splitText가 `<span>` 분리 후 부모의 gradient background가 span 텍스트에 적용 안 됨 + `-webkit-text-fill-color: transparent` 상속으로 텍스트 영구 투명. hero-title에 gradient text 효과 금지, solid color 사용

## Loading Iron Law
- **EffectLoader 필수** → WebGL 초기화 중 빈 화면 금지
- **모든 비동기 레이어에 onReady 콜백 필수** → VantaBackground, TextAnimation, ParticleOverlay
- **useEffectReady 훅으로 통합 추적** → allReady 전까지 로딩 표시
- **AnimatePresence exit transition** → 로딩→콘텐츠 전환 시 부드러운 fade-out

## Performance Iron Law
- **Vanta DPR cap required** → `renderer.setPixelRatio(Math.min(dpr, 2))` — prevent Retina 4x rendering
- **Device Tier detection required** → classify high/medium/low, then auto-downgrade per layer
- **tsParticles fpsLimit ≤ 30** → 60fps forbidden when running concurrently with Vanta WebGL
- **GrainOverlay SVG filter forbidden** → use static CSS background-image (GPU compositing)
- **mousemove rAF throttle required** → calling set() on every event forbidden
- **prefers-reduced-motion disables WebGL** → CSS fallback only
- **WebGLRenderer powerPreference: "default"** → "high-performance" 금지 (배터리 소모 + 발열)
- **stencil: false** → Vanta가 stencil 미사용, 불필요 GPU 메모리 할당 방지
- **Visibility API 탭 비활성 시 렌더 중지** → document.hidden 감지 후 setAnimationLoop(null)

## Deliverables
- 5+ components under src/components/effects/
- EffectHero integration component
- Device tier detection utility
