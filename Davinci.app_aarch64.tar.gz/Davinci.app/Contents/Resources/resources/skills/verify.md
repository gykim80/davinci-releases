---
name: verify
description: "Testing, validation, and quality assurance. 3-Tier system: --fast (Static only), --standard (Static+Semantic), --full (all phases). Turbo v2 adaptive depth."
agent: qa-strategist
agents: [e2e-testing-patterns, senior-fullstack]
davinci-phase: check
allowed-tools: [Write, Edit, Read, Bash, Glob, Grep, Task, AskUserQuestion]
next-skill: improve
skill-type: rigid
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 검증자: items[] 기반 match rate와 4값 verdict(MET/NOT_MET/BLOCKED/IMPOSSIBLE)를 handoff에 포함. 생성자와 다른 컨텍스트에서 실행된다.

## Tool Parameter Rules -> See CLAUDE.md (ABSOLUTE)

## Domain Context Protocol
checkpoint.domain_context가 존재하면, Phase 2 Semantic Analysis에서 코드/UI가 CONTEXT.md 용어를 준수하는지 검증하라. Avoid 목록 용어 사용은 terminology_violation으로 보고.

docs/ARCH-VERIFY-REPORT.md가 존재하면 (da:arch-verify가 da:dev 이후 실행된 경우), Phase 2 결과에 병합한다:
- report의 blocking 항목 → Phase 2를 FAIL로 처리, da:improve로 넘기지 않고 수정 요구
- report의 warning 항목 → terminology_violation과 동일한 급으로 보고서에 나열
- report 자체가 없으면 (LIGHT/SIMPLE로 da:arch-verify 스킵됨) 이 단계는 N/A로 처리 — 에러 아님

# /da:verify - Code Verification and Improvement

ultrathink

> Claude MUST perform thorough analysis before suggesting any improvements.

## Extended Thinking Protocol
- **Analyze**: Deep analysis of code quality, performance, security
- **Identify**: Identify potential issues and improvement opportunities
- **Evaluate**: Assess impact and risk of each improvement
- **Recommend**: Present evidence-based improvement recommendations

---

## da:clone Visual Verification (--visual flag)

da:clone v2 파이프라인에서 `--visual` 플래그로 호출될 때:
1. Playwright로 결과물(clone-result.tsx/html/scene) 렌더링 + 스크린샷 캡처
2. CLI Vision으로 원본 스크린샷 vs 결과 스크린샷 비교
3. Fidelity Score 산출:
   - layout: 30% (요소 위치/크기 일치도)
   - color: 20% (색상 팔레트 일치도)
   - completeness: 25% (요소 누락 여부)
   - text: 15% (텍스트 내용 일치도)
   - interaction: 10% (인터랙션 요소 존재 여부)
4. 70점 미만 시 자동 수정 Skill("da:improve") 호출 (최대 2회)
5. clone-report.md 생성 (Fidelity Score + 개선 사항)

---

## 🔬 EVIDENCE-BASED VERIFICATION

### Core Principle: Never Guess, Always Verify
```yaml
Verification_Sources:
  Primary:
    - Context7 MCP: Official framework documentation
    - Tavily MCP: Current best practices
    - CodeGraph MCP: Codebase pattern analysis

  Secondary:
    - Test results and coverage
    - Static analysis tools
    - Performance profiling

Anti_Patterns:
  ❌ "I think this might be a problem..."
  ❌ "This could potentially cause..."
  ❌ "It's probably better to..."

Required_Pattern:
  ✅ "According to [source], this pattern..."
  ✅ "Tests show [evidence] indicating..."
  ✅ "Documentation states [citation]..."
```

---

## 🎭 INTEGRATED MODES

### Deep Research Mode (Auto for Security/Performance)
```yaml
Activation:
  - Security vulnerabilities detected
  - Performance issues identified
  - Framework version compatibility questions
  - Best practice verification needed

Research_Flow:
  1. Query Context7 for framework-specific guidance
  2. Search Tavily for current security advisories
  3. Cross-reference multiple sources
  4. Confidence scoring on recommendations

Output:
  - Evidence-based findings
  - Cited recommendations
  - Confidence levels per issue
```

### Token Efficiency Mode
`✅ Pass | ❌ Fail | ⚠️ Warn | 🛡️ Sec | ⚡ Perf | 🔧 Fix | "[File:Line] [Symbol] [Issue] → [Fix]"`

---

## 🤖 SPECIALIZED AGENTS

### Code Safety Engineer (Primary for --type security)
```yaml
Focus_Areas:
  - OWASP Top 10 code patterns
  - Authentication/Authorization gaps
  - Input validation gaps
  - Data handling patterns
  - Dependency health

Mandatory_Checks:
  SQL_Injection:
    - Pattern: String concatenation in queries
    - Fix: Parameterized queries
  XSS:
    - Pattern: Unescaped user input in HTML
    - Fix: Proper sanitization
  CSRF:
    - Pattern: State-changing GET requests
    - Fix: CSRF tokens
  Auth_Bypass:
    - Pattern: Missing authorization checks
    - Fix: Middleware guards
```

### Quality Engineer
```yaml
Focus_Areas:
  - Code complexity metrics
  - Test coverage gaps
  - Error handling completeness
  - Documentation quality
  - Code duplication

Quality_Metrics:
  - Cyclomatic complexity < 10
  - Test coverage > 80%
  - No uncaught exceptions
  - Clear error messages
```

### Performance Engineer
```yaml
Focus_Areas:
  - Algorithm complexity (Big O)
  - Database query efficiency
  - Memory leaks
  - Bundle size
  - Rendering performance

Performance_Patterns:
  N+1_Queries:
    - Detection: Loop with DB calls
    - Fix: Batch queries
  Expensive_Renders:
    - Detection: Unnecessary re-renders
    - Fix: Memoization
  Memory_Leaks:
    - Detection: Uncleared subscriptions
    - Fix: Cleanup on unmount
```

### Root Cause Analyst
```yaml
Focus_Areas:
  - Why did this issue occur?
  - What allowed it to pass review?
  - How to prevent recurrence?
  - What systemic issues exist?

Analysis_Framework:
  1. Symptom: What happened?
  2. Root_Cause: Why did it happen?
  3. Prevention: How to prevent?
  4. Detection: How to catch earlier?
```

### Self-Review Agent
```yaml
Focus_Areas:
  - Best practice compliance
  - Pattern consistency
  - Architecture alignment
  - Documentation accuracy

Review_Checklist:
  - Follows project conventions?
  - Matches design specification?
  - Tests cover edge cases?
  - Error handling complete?
```

---

## ★ VERIFY TIER SYSTEM (Turbo v2 Speed Optimization)

Verification depth is automatically selected based on task complexity. Automatically passed from da:work based on complexity tier; can be specified via --tier flag for manual execution.

### Tier Definitions

```yaml
Tier_Fast (--tier fast):
  description: Minimal verification — type safety + lint + basic structure
  execution_Phase: Phase 1 (Static Analysis) only
  tools: CodeGraph (symbol analysis), ESLint/Prettier, TypeScript
  thinking_level: normal (ultrathink disabled)
  MCP: codegraph only
  estimated_time: ~30sec-1min
  applies_to: LIGHT tasks (typos, config changes)
  preserved:
    ✅ Self-Check 4 Questions (tests pass, requirements met, assumptions verified, evidence exists)
    ✅ 7 Hallucination Red Flags
    ✅ match rate 90% threshold
    ❌ Context7 best practices check (skip)
    ❌ Playwright E2E tests (skip)
    ❌ Tavily security advisories (skip)

Tier_Standard (--tier standard):
  description: Medium verification — Static + best practices verification
  execution_Phase: Phase 1 (Static) + Phase 2 (Semantic)
  tools: CodeGraph, ESLint/Prettier, TypeScript, Context7, Sequential
  thinking_level: ultrathink
  MCP: codegraph, context7, sequential
  estimated_time: ~2-3min
  applies_to: SIMPLE tasks
  preserved:
    ✅ Self-Check 4 Questions
    ✅ 7 Hallucination Red Flags
    ✅ match rate 90% threshold
    ✅ Context7 best practices check
    ❌ Playwright E2E tests (skip)
    ❌ Tavily security advisories (skip)

Tier_Full (--tier full, default):
  description: Full verification — Static + Semantic + Evidence
  execution_Phase: Phase 1 + Phase 2 + Phase 3 (all)
  tools: All (CodeGraph, Context7, Sequential, Playwright, Tavily)
  thinking_level: ultrathink
  MCP: codegraph, context7, sequential, playwright, tavily
  estimated_time: ~5-8min
  applies_to: COMPLEX/EPIC tasks
  preserved: All safeguards 100%
```

### Tier Auto-Selection (da:work integration)

```yaml
da:work_complexity_mapping:
  LIGHT   → --tier fast
  SIMPLE  → --tier standard
  MODERATE → --tier full
  COMPLEX  → --tier full
  EPIC     → --tier full

manual_execution_default: --tier full (same as existing behavior)

Override_rules:
  - When security keyword detected → always --tier full (security cannot be skipped)
  - When 5+ new files created → minimum --tier standard
  - When --type security specified → force --tier full
```

### Tier-Based Behavioral Flow Branching

```yaml
Phase_1_Static (all tiers execute):
  1. CodeGraph: codegraph_explore → codegraph_node → structure analysis
  2. Bash: ESLint/Prettier check (npx eslint . or npm run lint)
  3. Bash: TypeScript type check (npx tsc --noEmit)
  4. Collect results → classify issues (Critical/High/Medium/Low)

  if tier == "fast":
    → Execute Self-Check → generate report → complete
    → Skip Phase 2, 3

Phase_2_Semantic (standard, full only):
  1. Context7: Query framework best practices
  2. Sequential: Complex logic verification
  3. Anti-pattern matching
  4. Domain terminology consistency check:
     - If checkpoint.domain_context exists → verify code/UI uses CONTEXT.md terms
     - Flag any usage of Avoid-listed terms in variable names, UI text, comments
     - Report mismatches as "terminology_violations" in results
  5. Collect results → merge with Phase 1 results

  if tier == "standard":
    → Execute Self-Check → generate report → complete
    → Skip Phase 3

Phase_3_Evidence (full only):
  1. Playwright: Execute E2E tests
  2. Tavily: Check security advisories
  3. Coverage: Test coverage report
  4. Collect results → merge with Phase 1+2 results
  → Execute Self-Check → generate report → complete
```

---

## 🔄 ENHANCED SELF-CHECK PROTOCOL

### Three-Phase Verification
```yaml
Phase_1_Static_Analysis:
  Tools:
    - CodeGraph: Symbol analysis, reference tracking
    - ESLint/Prettier: Style and basic errors
    - TypeScript: Type safety
  Output:
    - Syntax issues
    - Type errors
    - Style violations

Phase_2_Semantic_Analysis:
  Tools:
    - Context7: Framework best practices
    - Sequential: Complex logic verification
  Output:
    - Anti-pattern detection
    - Best practice violations
    - Architecture misalignment

Phase_3_Evidence_Gathering:
  Tools:
    - Playwright: E2E test execution
    - Tavily: Security advisory check
    - Coverage: Test coverage report
  Output:
    - Test results
    - Security findings
    - Coverage metrics
```

### PM Agent Self-Check Integration
```yaml
Pre_Verification:
  - think_about_collected_information()
  - "Do I have enough context for this review?"
  - "What documentation should I consult?"

During_Verification:
  - think_about_task_adherence()
  - "Am I following the verification protocol?"
  - "Have I checked all required areas?"

Post_Verification:
  - think_about_whether_you_are_done()
  - "Have I verified all findings with evidence?"
  - "Are my recommendations actionable?"
```

---

## Triggers
- Code quality enhancement and refactoring requests
- Performance optimization and bottleneck resolution needs
- Security audit and vulnerability assessment
- Pre-commit validation and review requests
- Post-implementation verification

## Usage
```
/da:verify [target] [--type quality|performance|security|all] [--tier fast|standard|full] [--safe] [--interactive] [--compact]
```

---

## Behavioral Flow

### Phase 1: Analyze
```yaml
0. Acceptance_Ledger (da:protocol §3.5):
   - Glob docs/.da-acceptance.json → 있으면 Read: 이 항목들이 검증 기준의 전부다 (임의 기준 추가 금지, 항목 삭제 금지)
   - 없으면 PLAN/REQUIREMENTS의 요구사항 섹션에서 1회 생성 후 저장 (이후 불변, passes/evidence만 갱신)
   - previous_failure 가 주입되었으면 실패 항목을 우선 재검증 (attempt N/M 인식)

1. Scope_Definition:
   - Identify files to verify
   - Determine verification depth
   - Select relevant agents

2. Context_Gathering:
   - CodeGraph: Analyze symbols and references
   - Read: Existing tests and documentation
   - Context7: Framework requirements
```

### Phase 2: Verify
```yaml
1. Static_Analysis:
   - Run linters and type checkers
   - Check code complexity
   - Identify obvious issues

2. Semantic_Analysis:
   - Pattern matching against anti-patterns
   - Best practice verification
   - Architecture compliance

3. Evidence_Collection:
   - Run relevant tests
   - Check security advisories
   - Measure performance metrics
```

### Phase 3: Report
```yaml
1. Findings_Compilation:
   - Categorize by severity (Critical/High/Medium/Low)
   - Group by type (Security/Performance/Quality)
   - Provide evidence for each finding

2. Recommendations:
   - Prioritized fix suggestions
   - Code examples for fixes
   - Estimated effort levels

3. Verdict_Handoff (MANDATORY — da:protocol §3.3 / §3.3-b):
   - items[]: 검증 항목별 {name, status: pass|fail|partial, weight, detail}
     (acceptance ledger docs/.da-acceptance.json 이 있으면 그 항목을 그대로 사용, passes/evidence 갱신)
   - match_rate: passed_weight / total_weight (items 없는 % 숫자는 무효)
   - severity_max: Critical|High|Medium|Low|None
   - verdict: MET (match_rate ≥ threshold AND severity_max ∉ {Critical, High})
              NOT_MET (재시도 가능 — reason + next_action_hint 필수)
              BLOCKED (외부 요인: 환경/키/서비스 부재 — 재시도 무의미)
              IMPOSSIBLE (요구사항 모순/불가)
   - evidence[]: 실행한 명령·exit code·테스트 카운트·스크린샷 경로 (없는 판정은 오케스트레이터가 NOT_MET로 다운그레이드)
```

**Verdict Handoff 예시** (응답 마지막 JSON 블록):
```json
{"skill": "da:verify", "node_id": "3:2:da:verify", "status": "completed",
 "verdict": "NOT_MET", "match_rate": 82, "severity_max": "High",
 "reason": "auth 미들웨어 3개 테스트 실패 (401 대신 500)",
 "next_action_hint": "에러 핸들러를 라우트별 재시도 대신 미들웨어 레벨에서 수정",
 "items": [{"name": "AC-03 로그인 실패 시 401", "status": "fail", "weight": 5, "detail": "returns 500"}],
 "evidence": [{"kind": "test", "ref": "npm test -- auth", "result": "38 passed, 3 failed / exit 1", "ok": false}]}
```
- 생성 노드(da:dev/da:game/da:fix)와 **다른 컨텍스트**에서 실행되었음을 전제로 판정한다. 생성 노드의 "self-verify passed" 문구는 근거로 인정하지 않는다(§3.2).

### Phase 4: Fix (If --interactive)
```yaml
1. Auto_Fix:
   - Apply safe, low-risk fixes automatically
   - Style fixes, unused imports, simple refactors

2. Approval_Required:
   - Present changes for review
   - Wait for user confirmation
   - Apply approved changes
```

---

> MCP Routing: See CLAUDE.md

---

## Key Patterns

### Verification Report Template
```markdown
# Verification Report: [Target]

## Summary
| Category | Issues | Critical | High | Medium | Low |
|----------|--------|----------|------|--------|-----|
| Security | X | X | X | X | X |
| Performance | X | X | X | X | X |
| Quality | X | X | X | X | X |

## Critical Issues (Immediate Action Required)

### [Issue ID]: [Title]
- **Location**: `file.ts:123`
- **Category**: 🛡️ Security
- **Evidence**: [Citation or test result]
- **Description**: [What's wrong]
- **Impact**: [Potential consequences]
- **Fix**: [Recommended solution with code example]

## High Priority Issues
[...]

## Medium Priority Issues
[...]

## Low Priority Issues
[...]

## Recommendations
1. [Priority action 1]
2. [Priority action 2]

## Confidence Level: [High/Medium/Low]
## Sources: [Citations]
```

### Compact Report Format
```
# Verify: src/auth/

## 🚨 Critical
  auth.ts:45 🛡️ SQL injection → parameterized query
  login.ts:78 🛡️ weak password hash → bcrypt

## ⚠️ High
  api.ts:123 ⚡ O(n²) complexity → Map lookup
  user.ts:90 🔍 no error handling → try/catch

## 💡 Medium
  utils.ts:34 🔍 magic number → named constant

✅ Pass: 45/52 checks
❌ Fail: 7 issues (2 critical)
```

### Compact Tier Report
```
# Verify (tier: fast): src/
## 🔧 Static
  auth.ts:45 TS2345 → fix type mismatch
  utils.ts:12 @typescript-eslint/no-unused-vars → remove unused variable
✅ Pass: 23/25 checks | Tier: fast | Phase: 1/1
```

```
# Verify (tier: standard): src/
## 🔧 Static
  auth.ts:45 TS2345 → type mismatch
## 📋 Semantic
  api.ts:78 ❌ async-parallel → Promise.all()
✅ Pass: 41/45 checks | Tier: standard | Phase: 2/2
```

---

## AUTO-FIX VS APPROVAL-REQUIRED

### Auto-fix (Applies Automatically)
```yaml
Safe_Fixes:
  - Formatting and style
  - Unused import removal
  - Simple type annotations
  - Whitespace cleanup
  - Sort imports
```

### Approval Required (Prompts User)
```yaml
Risky_Changes:
  - Architectural modifications
  - Logic refactoring
  - Function signature changes
  - Removing code used by public APIs
  - Changes affecting multiple files
  - Security-related fixes
```

### Explicitly Will NOT (Without --force)
```yaml
Blocked_Actions:
  - Architectural decisions
  - Major refactoring
  - Removing functionality
  - Breaking API changes
```

---

## Examples

### Security Audit
```
/da:verify src/auth/ --type security
# Agents: security-engineer, root-cause-analyst
# MCP: Context7 (auth patterns), Tavily (CVE check)
# Output: Security-focused report with OWASP mapping
```

### Performance Review
```
/da:verify src/api/ --type performance --compact
# Agents: performance-engineer
# MCP: Sequential (complexity analysis)
# Output: Compact symbolic report
```

### Full Verification
```
/da:verify src/ --type all --interactive
# Agents: All verification agents
# MCP: Full suite
# Output: Interactive fixing with approval prompts
```

### Pre-Commit Check
```
/da:verify --safe
# Quick verification of staged changes
# Auto-fix safe issues
# Report blockers
```

---

## Boundaries

**Will:**
- Provide evidence-based verification with citations
- Identify issues with severity and impact assessment
- Recommend prioritized fixes with code examples
- Execute safe auto-fixes when appropriate

**Will Not:**
- Make claims without supporting evidence
- Apply risky fixes without user approval
- Skip verification steps for speed
- Override security findings

---

## Session End
Save checkpoint and proceed to next step.

---

## 🎯 SKILL-BASED VERIFICATION

### Agent-Skills Rule Checking
`/da:verify` checks code against Vercel Engineering's agent-skills rules.

```yaml
Verification_Skills:
  - react-best-practices: Performance anti-patterns
  - composition-patterns: Architecture violations
  - react-native-skills: Mobile-specific issues
  - web-design-guidelines: UI/UX and accessibility
  - react-view-transitions: View Transition API correctness
```

### Pattern Violation Detection

```yaml
Composition_Patterns_Checks:
  architecture-avoid-boolean-props:
    Trigger: Component has 3+ boolean props
    Severity: ⚠️ High
    Report: "Consider Compound Component pattern for better composition"
    Rule_File: agent-skills/skills/composition-patterns/rules/architecture-avoid-boolean-props.md

  architecture-compound-components:
    Trigger: Multiple related components without shared context
    Severity: 💡 Medium
    Report: "Use shared context for component coordination"
    Rule_File: agent-skills/skills/composition-patterns/rules/architecture-compound-components.md

React_Best_Practices_Checks:
  async-parallel:
    Trigger: Sequential await statements that could be parallelized
    Severity: 🚨 Critical
    Report: "Use Promise.all() for independent operations"
    Rule_File: agent-skills/skills/react-best-practices/rules/async-parallel.md

  bundle-barrel-imports:
    Trigger: Import from index.ts barrel file
    Severity: 🚨 Critical
    Report: "Import directly from source file to reduce bundle size"
    Rule_File: agent-skills/skills/react-best-practices/rules/bundle-barrel-imports.md

  rerender-memo:
    Trigger: Expensive component without React.memo
    Severity: ⚠️ High
    Report: "Wrap in React.memo to prevent unnecessary re-renders"
    Rule_File: agent-skills/skills/react-best-practices/rules/rerender-memo.md

  rerender-derived-state:
    Trigger: Subscribing to raw values instead of derived booleans
    Severity: 💡 Medium
    Report: "Subscribe to derived booleans to reduce re-renders"
    Rule_File: agent-skills/skills/react-best-practices/rules/rerender-derived-state.md

React_Native_Checks:
  list-performance-virtualize:
    Trigger: FlatList or ScrollView for large lists
    Severity: 🚨 Critical
    Report: "Use FlashList for large lists"
    Rule_File: agent-skills/skills/react-native-skills/rules/list-performance-virtualize.md

  animation-gpu-properties:
    Trigger: Animating non-GPU properties (width, height, margin)
    Severity: ⚠️ High
    Report: "Animate only transform and opacity for 60fps"
    Rule_File: agent-skills/skills/react-native-skills/rules/animation-gpu-properties.md

  list-performance-inline-objects:
    Trigger: Inline style objects in list items
    Severity: ⚠️ High
    Report: "Move style objects outside render to prevent re-renders"
    Rule_File: agent-skills/skills/react-native-skills/rules/list-performance-inline-objects.md

React_View_Transitions_Checks:
  vt-missing-default-none:
    Trigger: <ViewTransition> without default="none" causing unwanted cross-fades on every transition
    Severity: ⚠️ High
    Report: "Add default='none' to prevent cross-fade on Suspense resolves and background revalidations"
    Rule_File: agent-skills/skills/react-view-transitions/SKILL.md

  vt-wrapped-placement:
    Trigger: <ViewTransition> nested inside a DOM element instead of appearing before any DOM nodes
    Severity: ⚠️ High
    Report: "Move <ViewTransition> outside wrapper div — enter/exit suppressed when wrapped"
    Rule_File: agent-skills/skills/react-view-transitions/references/implementation.md

  vt-duplicate-name:
    Trigger: Multiple mounted <ViewTransition> components with the same name prop
    Severity: ⚠️ High
    Report: "Only one VT with a given name can be mounted at a time — use unique names (e.g., photo-${id})"
    Rule_File: agent-skills/skills/react-view-transitions/references/patterns.md

  vt-missing-reduced-motion:
    Trigger: View transitions CSS without prefers-reduced-motion media query
    Severity: ⚠️ High
    Report: "Add prefers-reduced-motion CSS from css-recipes.md to global stylesheet"
    Rule_File: agent-skills/skills/react-view-transitions/references/css-recipes.md

  vt-manual-start-view-transition:
    Trigger: Direct call to document.startViewTransition() instead of using React's <ViewTransition>
    Severity: ⚠️ High
    Report: "Never call startViewTransition yourself — React handles it via <ViewTransition>"
    Rule_File: agent-skills/skills/react-view-transitions/SKILL.md

  vt-fade-exit-with-shared-morph:
    Trigger: Fade-out exit animation on pages containing shared element morphs
    Severity: ⚠️ Medium
    Report: "Use directional slide instead of fade-out on pages with shared morphs"
    Rule_File: agent-skills/skills/react-view-transitions/references/patterns.md

Web_Design_Guidelines_Checks:
  wdg-color-contrast:
    Trigger: Text color with insufficient contrast ratio against background (< 4.5:1 for normal text, < 3:1 for large text)
    Severity: ⚠️ High
    Report: "Ensure WCAG 2.1 AA color contrast ratios: 4.5:1 normal text, 3:1 large text"
    Rule_File: agent-skills/skills/web-design-guidelines/SKILL.md

  wdg-missing-focus-indicator:
    Trigger: Interactive elements without visible focus styles or focus-visible pseudo-class
    Severity: ⚠️ High
    Report: "Add visible focus indicators for keyboard navigation — use focus-visible for mouse/keyboard distinction"
    Rule_File: agent-skills/skills/web-design-guidelines/SKILL.md

  wdg-touch-target-size:
    Trigger: Interactive elements smaller than 44x44px on touch devices
    Severity: ⚠️ High
    Report: "Minimum 44x44px touch target size per WCAG 2.5.5"
    Rule_File: agent-skills/skills/web-design-guidelines/SKILL.md

  wdg-missing-alt-text:
    Trigger: img elements without alt attribute or with empty alt on non-decorative images
    Severity: ⚠️ High
    Report: "Add descriptive alt text to all meaningful images for screen reader accessibility"
    Rule_File: agent-skills/skills/web-design-guidelines/SKILL.md

  wdg-animation-reduced-motion:
    Trigger: CSS animations or transitions without prefers-reduced-motion media query
    Severity: ⚠️ Medium
    Report: "Respect prefers-reduced-motion: disable or reduce animations for users who prefer reduced motion"
    Rule_File: agent-skills/skills/web-design-guidelines/SKILL.md
```

### Skill Verification Report Format

```markdown
## Skill Rule Violations

### 🚨 Critical (Immediate Fix Required)
| Rule | Location | Issue | Fix |
|------|----------|-------|-----|
| async-parallel | `api/users.ts:45` | Sequential awaits | Use Promise.all() |
| bundle-barrel-imports | `components/index.ts:*` | Barrel file imports | Import directly |

### ⚠️ High Priority
| Rule | Location | Issue | Fix |
|------|----------|-------|-----|
| architecture-avoid-boolean-props | `Button.tsx:10` | 5 boolean props | Use Compound Component |
| rerender-memo | `UserList.tsx:25` | Expensive unmemoized | Add React.memo |

### 💡 Medium Priority
| Rule | Location | Issue | Fix |
|------|----------|-------|-----|
| rerender-derived-state | `Dashboard.tsx:30` | Raw state subscription | Derive boolean |

### ✅ Passed Checks
- server-cache-react: React.cache usage correct
- async-suspense-boundaries: Suspense boundaries present
- rendering-conditional-render: Using ternary correctly
```

### Compact Skill Report (--compact)

```
# Verify (Skills): src/

## 🚨 Critical
  api/users.ts:45 async-parallel → Promise.all()
  components/index.ts bundle-barrel-imports → direct import

## ⚠️ High
  Button.tsx:10 architecture-avoid-boolean-props → Compound Component
  UserList.tsx:25 rerender-memo → React.memo

## 💡 Medium
  Dashboard.tsx:30 rerender-derived-state → derive boolean

Skills: 3 violations (2 critical) | Rules checked: 25
```

### Verification with Skills Examples

```bash
# Full skill-based verification
/da:verify src/ --type all
# Checks: react-best-practices + composition-patterns + web-design-guidelines

# React Native specific
/da:verify src/ --framework react-native
# Checks: react-native-skills (list-performance, animation, ui)

# Architecture focus
/da:verify src/components/ --type quality
# Checks: composition-patterns (architecture-*, state-*, patterns-*)

# Performance focus
/da:verify src/ --type performance
# Checks: react-best-practices (async-*, bundle-*, rerender-*, js-*)
```

### Reading Full Rule Documentation

When a violation is found, read the full rule for detailed fix guidance:

```yaml
Violation_Found: async-parallel in api/users.ts:45

Read_Rule:
  File: agent-skills/skills/react-best-practices/rules/async-parallel.md
  Contains:
    - Why it matters
    - Incorrect code example
    - Correct code example
    - Additional context

Apply_Fix:
  Before: |
    const user = await fetchUser(id);
    const posts = await fetchPosts(id);
    const comments = await fetchComments(id);

  After: |
    const [user, posts, comments] = await Promise.all([
      fetchUser(id),
      fetchPosts(id),
      fetchComments(id)
    ]);
```
