---
name: vercel
description: "Vercel-specific deployment -- CLI auth, preview deploy, production promote, health check, monitoring."
agent: devops-guide
agents: [infra-architect]
davinci-phase: null
allowed-tools: [Read, Bash, Glob, Grep, Task]
next-skill: null
skill-type: flexible
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 유틸리티: 부작용(외부 API/배포/삭제) 전 §7 destructive/cost_gate 규칙을 확인한다.

## Tool Parameter Rules -> See CLAUDE.md (ABSOLUTE)
# /da:vercel - Vercel Deployment Protocol

## Purpose
Vercel-specific deployment skill. Handles CLI authentication, project linking, preview-first deployment, production promotion, health checks, and monitoring.

## Usage
```
/da:vercel [--env staging|production] [--dry-run]
```

### Arguments
- `--env` — Target environment (default: preview -> production flow)
- `--dry-run` — Pre-flight checks only, no actual deployment

## Iron Law

> **Preview first, user confirm before production. Never skip preview deployment.**

## Behavioral Flow

### Phase 0: Pre-flight
```yaml
Pre_Flight:
  1. CLI_Check:
     - which vercel || "Vercel CLI not installed. Run: npm i -g vercel"
  2. Auth_Check:
     - vercel whoami || "Not authenticated. Run: vercel login"
  3. Project_Link:
     - Check .vercel/ directory or vercel.json
     - If missing: "No linked project. Run: vercel link"
  4. Git_Status:
     - git status --porcelain
     - Warn if working directory is dirty
```

### Phase 1: Deploy
```yaml
Deploy:
  1. Preview_Deploy:
     command: vercel deploy
     action: Generate preview URL, wait for build
     wait: vercel inspect <preview-url> --wait

  2. Preview_Verification:
     - Display preview URL to user
     - curl -sI <preview-url> | head -5 (health check)
     - "Preview OK. Deploy to production?" -> request user confirmation

  3. Production_Deploy (after confirmation):
     command: vercel --prod
     action: Production deployment
```

### Phase 2: Verify
```yaml
Verify:
  1. Health_Check:
     - curl -sI <production-url> | head -5
     - Verify HTTP 200 response
     - Measure response time

  2. Log_Check:
     - vercel logs <url> --json (check for errors)
     - vercel inspect <deployment-url> (deployment details)
     - vercel httpstat <url> (latency breakdown)

  3. Deployment_List:
     - vercel ls --limit 3 (recent deployments)
```

### Monitoring Commands
```yaml
Monitoring:
  logs: vercel logs <url> --json
  inspect: vercel inspect <deployment-id>
  httpstat: vercel httpstat <url>
  list: vercel ls --limit 10
```

### Rollback
```yaml
Rollback:
  immediate: vercel rollback
  specific: vercel rollback <deployment-id>
  list: vercel ls --limit 5 (find deployment to rollback to)
```

## Safety Guardrails
```yaml
Mandatory:
  - Preview deploy before production (no exceptions)
  - User confirmation before vercel --prod
  - Health check after every deployment
Forbidden:
  - Direct production deploy without preview
  - Deploying with unauthenticated CLI
  - Skipping health check verification
```

## Boundaries

**Will:**
- Check CLI installation and authentication
- Deploy to preview, then promote to production
- Run health checks and log verification
- Provide rollback commands on failure

**Will Not:**
- Deploy to production without user confirmation
- Skip preview deployment
- Manage DNS, domains, or SSL (use Vercel dashboard)
- Configure CI/CD pipelines
