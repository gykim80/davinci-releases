---
name: resume
description: "마지막 체크포인트에서 작업 복원"
agent: pipeline-guide
agents: [pipeline-guide]
davinci-phase: null
allowed-tools: [Read, Bash, Glob]
next-skill: null
skill-type: utility
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 유틸리티: 부작용(외부 API/배포/삭제) 전 §7 destructive/cost_gate 규칙을 확인한다.

# /da:resume

마지막 세션 체크포인트에서 작업 맥락을 복원합니다.

## Usage
```
/da:resume           # 가장 최근 체크포인트에서 복원
/da:resume list      # 저장된 체크포인트 목록 표시
```

## 동작 순서

1. **체크포인트 로드**
   ```python
   from davinci.session.checkpoint import load_latest_checkpoint
   checkpoint = load_latest_checkpoint()
   ```

2. **현재 상태와 비교**
   - git diff로 현재 코드 상태 확인
   - 체크포인트의 파일 목록과 현재 상태 비교
   - 불일치 항목 표시 (파일 삭제/이동 등)

3. **복원 요약 출력**
   ```
   마지막 체크포인트 복원 (2시간 전, 수동)
   ---
   작업: voice.rs WebSocket 연결 구현
   상태: in_progress (3/5 단계)
   수정 파일: src/hooks/useVoiceInput.ts, src-tauri/src/commands/voice.rs
   변경사항: 마이크 권한 체크 추가 / 오디오 스트림 초기화
   다음 단계: VAD 로직 구현 → PipelineMonitor 음성 상태 표시
   결정사항: Web Speech API 대신 Whisper 서버사이드 채택 (다국어)
   워크플로우: voice-input | act | iter 2 | 85%
   ---
   ※ 이전 세션 참고 정보입니다. 현재 코드와 다를 수 있습니다.
   ```

4. **다음 단계 제안**
   - 체크포인트의 `next_steps` 기반으로 작업 재개 제안
   - 현재 git 상태를 참고하여 실제로 필요한 작업 판단

## list 모드

`/da:resume list` 실행 시:
```
저장된 체크포인트:
1. [자동] 2026-03-31 14:30 — 파일 3개 수정 중
2. [수동] 2026-03-31 13:00 — voice.rs WebSocket 연결 구현
3. [수동] 2026-03-31 10:15 — 마이크 권한 체크 완료
```

## 체크포인트 없을 때

```
저장된 체크포인트가 없습니다.
- /da:save로 현재 상태를 저장할 수 있습니다.
- compact/stop 시 자동으로 체크포인트가 저장됩니다.
```

## 복원 방식

체크포인트 복원은 `/da:resume` 명시적 호출로 수행됩니다.
세션 시작 시 체크포인트가 있으면 경량 힌트(1줄)만 자동 주입됩니다:
`[이전 세션 체크포인트 있음] | 마지막 작업: ... | → /da:resume 으로 컨텍스트 복원`

전체 컨텍스트 복원(수정 파일, 변경사항, 다음 단계)은 `/da:resume` 명시적 호출이 필요합니다.
