---
name: next
description: Cycle transition planning and next iteration preparation
agent: cto-lead
agents: [cto-lead, senior-fullstack]
davinci-phase: null
allowed-tools: [Write, Edit, Read, Bash, Glob, Grep, Task]
next-skill: plan
skill-type: flexible
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 오케스트레이터: §4 그래프 ready-set 디스패치, §6 노드 단위 checkpoint, §7 interrupt 표 외 질문 금지.

# /da:next

Auto-navigate to the next appropriate DAVINCI workflow phase based on current state.
Workflow: idea -> plan -> plan-verify -> work -> report -> clean.
da:work internally orchestrates: system -> design -> dev/game -> verify -> improve.

## Iron Law
**NO PHASE TRANSITION WITHOUT VERIFIED DELIVERABLES FROM THE CURRENT PHASE.**

## Plan-Verify-Improve Auto-Chain (da:protocol §4.4)
When plan is complete + PLAN.md exists: da:verify →
- verdict MET (≥90%, items[] 기반, Critical/High 없음) → user approval → da:work
- verdict NOT_MET, attempts < 2 → da:improve(previous_failure 주입) → re-verify
- attempts == 2, Critical/High 잔존 → **blocked**: da:work 진입 금지, 사용자에게 blocked 항목 제시(§7 interrupt)
- attempts == 2, Medium/Low만 → degraded로 da:work 진입 허용(리포트 명시)
- verdict BLOCKED/IMPOSSIBLE → 즉시 사용자 보고

## Phase Transition Contract
전환 판단은 **직전 노드의 handoff JSON(status + evidence)** 으로만 한다. 산출물 파일 존재만으로 "완료"로 간주하지 않는다(§3.1).
`status: partial` → 같은 phase를 fresh context로 재개 제안 / `blocked` → blockers 해소 방안 제시 / `completed` + evidence → 다음 phase.

## Transition
- **Next**: Phase-dependent (auto-detected)
- **Condition**: Current phase deliverables complete + verification pass
