---
name: effect_particle
description: tsParticles overlay effect generation with cursor follower interaction.
agent: effect-composer
agents: [frontend-architect]
davinci-phase: design
allowed-tools: [Write, Edit, Read, Bash, Glob, Grep, Task]
next-skill: verify
skill-type: flexible
thinking: ultra
mcp-servers: [context7, codegraph]
skills-ref:
  - davinci_framework/agent-skills/skills/mengto-matterjs
  - davinci_framework/agent-skills/skills/mengto-gsap
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 생성자: 자기 검증은 사전 점검일 뿐이다. 최종 판정은 독립 verify 노드가 낸다. 미완료 시 partial + remaining.

# /da:effect_particle -- tsParticles Overlay Engine

## MengTo Reference Skills (on-demand — 필요 시에만 Read)
> 경로: `~/.claude/plugin/agent-skills/skills/<name>/SKILL.md`
- `mengto-matterjs`: 2D 물리 인터랙션 (DOM/canvas)
- `mengto-gsap`: 파티클 모션 오케스트레이션
## Tool Parameter Rules -> See CLAUDE.md (ABSOLUTE)


ultrathink

> Independent skill. No dependency on da:effect_bg or da:effect_text.

## Execution Protocol

### Step 1: Context Detection
```yaml
1. Check invocation mode:
   - ARGUMENTS contains persona info -> da:design delegation mode
   - ARGUMENTS contains only tone/prompt -> standalone mode
   - Some tones map to (none) -> skip execution entirely
2. Read package.json -> verify required dependencies
   - @tsparticles/react, @tsparticles/slim
3. Missing packages -> run pnpm add
```

### Step 2: Tone Selection
```yaml
When delegated from da:design:
  persona -> automatic tone mapping (refer to tone-presets.md)
  Tones with (none) particle -> return early, no output

When invoked standalone:
  Analyze prompt keywords -> select optimal preset
```

### Step 3: Implementation
```yaml
1. Layer 3 (Particle Overlay):
   - tsparticles-presets.md -> Create ParticleOverlay component
   - Apply density mapping (sparse 30, normal 80, dense 150)
   - pointerEvents: "none" required

2. Layer 4 (Interaction, built-in):
   - mouse:follower (CursorFollower component)
   - Mobile: disable cursor effects

3. Loading State:
   - EffectLoader for particle engine init
   - Refer to references/effect-loading.md
```

### Step 4: Validation
```yaml
1. tsc --noEmit (type check)
2. Verify pointerEvents: "none" on particle container
3. Verify z-index: 1 (above bg, below content)
4. Verify prefers-reduced-motion support
```

## Iron Rules

### Common (C1-C4)
- C1: prefers-reduced-motion -> CSS fallback only
- C2: cleanup function required
- C3: "use client" required
- C4: EffectLoader required (async particle engine init)

### Particle-Specific (P1-P4)
- P1: pointerEvents: "none" required (allow clicks through to content)
- P2: z-index: 1 (above background, below content)
- P3: Particle count cap: sparse 30, normal 80, dense 150
- P4: loadSlim only (loadFull forbidden for bundle size)

### Performance
- fpsLimit <= 30 when used with WebGL background
- Mobile: reduce particle count by 50%

## Deliverables
- ParticleOverlay component
- CursorFollower component
- ParticleLoader component
