---
name: adr
description: "Architecture Decision Record 생성/관리 -- 결정 감지 게이트, MADR/Lightweight 템플릿, 상태 라이프사이클, docs/adr/ 레지스트리. da:plan/da:system/da:work/da:dev가 아키텍처적으로 유의미한 결정을 만날 때 자동 호출"
agent: senior-architect
agents: []
davinci-phase: null
allowed-tools: [Write, Edit, Read, Glob, Grep]
next-skill: null
skill-type: rigid
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 생성자: 자기 검증은 사전 점검일 뿐이다. 최종 판정은 독립 verify 노드가 낸다. 미완료 시 partial + remaining.

## Tool Parameter Rules -> See CLAUDE.md (ABSOLUTE)
# /da:adr - Architecture Decision Record 관리

## Role in DAVINCI Workflow
```yaml
Invocation: Cross-cutting. da:plan/da:system/da:work/da:dev 내부에서 결정 감지 게이트가
  발동되면 자동 호출된다. 독립 실행도 가능: `/da:adr "결정 제목"`
Output: docs/adr/NNNN-kebab-title.md + docs/adr/README.md 인덱스 갱신
Consumers: da:work(Constitution Load 단계), da:dev(Domain Context Protocol),
  da:arch-verify(ADR 준수 검사)
```

## Decision-Detection Gate (MANDATORY -- 남발 방지)

ADR을 남발하면 문서가 아니라 소음이 된다. 아래 기준으로만 작성한다.

```yaml
Write_ADR_When:
  - 프레임워크/라이브러리 선택 또는 교체
  - DB/스키마/데이터 모델의 근본적 변경
  - API 설계 패턴 결정 (REST vs GraphQL vs RPC)
  - 인증/보안 아키텍처
  - 신규 런타임 의존성 추가
  - 서비스/모듈 경계 분리 방식
  - 배포/인프라 토폴로지 변경
  - 되돌리기 어려운(one-way door) 결정

Skip_ADR_When:
  - 패치/마이너 버전 업그레이드
  - 구현 세부사항 (변수명, 내부 함수 분해)
  - 이미 Accepted된 ADR 범위 내의 작업
  - 되돌리기 쉬운(two-way door) 결정

Ambiguous_Case: 판단이 애매하면 Lightweight 템플릿으로 짧게 기록 (스킵보다 저비용 기록이 낫다)
```

## Execution Steps

```yaml
1_Check_Existing:
  - Glob("docs/adr/*.md") 로 기존 ADR 번호/제목 확인
  - 없으면 docs/adr/ 디렉토리 신규 생성 예정으로 처리

2_Detect_Supersede:
  - 새 결정이 기존 Accepted ADR을 대체하는가?
  - Yes → 기존 ADR의 Status를 "Superseded by ADR-NNNN"으로 Edit

3_Select_Template: (references/adr-templates.md)
  - 임팩트 大 (프레임워크/보안/데이터모델) → MADR 템플릿
  - 임팩트 中/애매 → Lightweight 템플릿

4_Number_Assign:
  - 기존 최대 번호 + 1, 4자리 zero-pad (0001, 0002, ...)

5_Write:
  - docs/adr/NNNN-kebab-title.md 생성
  - Status: Proposed (사용자 확인 후 Accepted로 전환 -- 자동으로 Accepted 처리하지 않음)

6_Update_Index:
  - docs/adr/README.md 표 갱신: | 번호 | 제목 | 상태 | 날짜 |
  - 파일 없으면 신규 생성

7_Handoff:
  - 호출한 스킬에 adr_file 경로와 status를 반환 (아래 Handoff Output 참조)
```

## Status Lifecycle

```
Proposed -> Accepted -> Deprecated
                     -> Superseded by ADR-NNNN
```

- **Proposed**: 작성 직후 기본 상태. 사용자/팀 확인 전.
- **Accepted**: 확정. 이 시점부터 da:work/da:dev/da:arch-verify의 제약 조건이 된다.
- **Deprecated**: 더 이상 유효하지 않으나 대체 ADR은 없음 (그냥 폐기).
- **Superseded**: 새 ADR이 이 결정을 대체함 (양쪽 문서에 상호 링크 필수).

## Templates

전체 MADR / Lightweight 템플릿 원문은 `references/adr-templates.md` 참조.
간단 요약:

```markdown
# ADR-NNNN: [결정 제목]
## Status
Proposed | Accepted | Deprecated | Superseded by ADR-NNNN
## Context
[무엇이 이 결정을 필요하게 만들었는가]
## Decision
[무엇을 하기로 했는가]
## Consequences
[이 변경으로 쉬워지는 것 / 어려워지는 것]
## Alternatives Considered
[검토했던 다른 옵션과 기각 사유]
```

## Constitution Enforcement (da:work / da:dev 연동)

Accepted 상태의 ADR은 산출물이 아니라 이후 개발에 대한 **제약**이다.

```yaml
Enforcement_Rules:
  - 새 런타임 의존성 추가를 시도하는데 이를 다루는 Accepted ADR이 없음
    → da:work가 진행을 멈추고 da:adr을 먼저 호출 (Step 6 참조)
  - 구현이 기존 Accepted ADR과 모순됨
    → 경고 출력 + "새 ADR로 supersede 하시겠습니까?" 확인
  - da:arch-verify가 ADR 준수 여부를 코드 스캔으로 검증 (references/arch-checklist.md의
    ADR Compliance 항목)
```

## Handoff Output (MANDATORY)

```json
{
  "skill": "da:adr",
  "adr_file": "docs/adr/000N-title.md",
  "status": "Proposed",
  "supersedes": null,
  "decision_summary": "1줄 요약"
}
```
