---
name: turbo
description: "Next-gen autonomous pipeline orchestrator with 4 innovation axes: DNA Cache, Mega-Spec One-Shot, Event-Driven Reactive, Self-Learning Engine"
category: workflow
complexity: advanced
thinking: ultra
mcp-servers: [sequential, aside, codegraph]
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 오케스트레이터: §4 그래프 ready-set 디스패치, §6 노드 단위 checkpoint, §7 interrupt 표 외 질문 금지.

## Tool Parameter Rules → See CLAUDE.md (ABSOLUTE)

# /da:turbo - Next-Gen Pipeline Orchestrator

ultrathink

> **Architecture**: docs/architecture/ARCHITECTURE.md
> **Plan**: docs/pipe/07-PLAN-next-gen-pipeline.md
> **Base Layer**: docs/pipe/05-PLAN-parallel-pipeline.md (Subagent Worktree + DAG)

## Overview

da:turbo is a next-generation orchestrator that preserves the existing da:work 8-Phase logical structure
while fundamentally redesigning the execution method. 4 innovation axes + parallel base layer achieve COMPLEX project 50min → 15min.

### 4 Innovation Axes + Base Layer
| Axis | Engine | Role |
|------|--------|------|
| Innovation 1 | DNA Cache Engine | Previous project pattern caching/reuse (L1-L4) |
| Innovation 2 | Mega-Spec Generator | system+design unified one-shot generation |
| Innovation 3 | Event Bus | Filesystem-based reactive signaling |
| Innovation 4 | Learning Engine | Error→Timing→Prompt→Pattern 4-stage learning |
| Base | Parallel Engine | Subagent Worktree DAG parallel execution |

### 8-Phase → 5-Stage Mapping (logic preserved)
```yaml
Stage_0_Parse_Cache: [plan-parse] + DNA Cache Lookup + Learning Injection
Stage_1_MegaSpec: [system, design] → Mega-Spec one-shot
Stage_2_Parallel: [asset, dev] → N-way parallel code generation
Stage_3_Verify: [verify, improve, e2e] → Smart Verify + Inline Fix
Stage_4_Report: [report, git] → Report + Learning Update + Cache Refresh
```

---

## ⚠️ THINKING BUDGET (Minimize Extended Thinking)
This orchestrator does not need deep thinking for tool routing.
Checkpoint → just make the next tool call.
Minimize extended thinking and preserve 100% of output budget for tool calls.

---

## ★ FIRST ACTION: Infrastructure Init + Resume Check

```yaml
Execute_First:
  # 1. Infrastructure initialization (idempotent)
  Bash: |
    mkdir -p ~/.davinci/cache/projects
    mkdir -p ~/.davinci/learning
    mkdir -p ~/.davinci/events
    mkdir -p ~/.davinci/schemas
    mkdir -p ~/.davinci/bin

  # 2. Verify Turbo scripts exist
  Bash: |
    if [ ! -f ~/.davinci/bin/dna-cache.sh ]; then
      echo "TURBO_SCRIPTS_MISSING"
      echo "Run 'davinci install --force' to install turbo infrastructure scripts"
    else
      echo "TURBO_SCRIPTS_OK"
    fi

  # 3. Check checkpoint
  Bash: cat docs/.da-turbo-checkpoint.json 2>/dev/null || echo "NO_CHECKPOINT"

  If result is NOT "NO_CHECKPOINT":
    - Parse checkpoint JSON
    - Check current_stage, active_engines
    - Resume from that Stage
  If result is "NO_CHECKPOINT":
    - Start fresh from Stage 0
```

---

## CRITICAL BEHAVIOR: Seamless Automatic Execution

**This skill automatically executes the entire pipeline without user intervention.**
After completing each step, do not stop — proceed to the next step immediately.
Do not ask the user "Shall I proceed to the next step?" Just proceed.

---

## SESSION MANAGEMENT

```yaml
Session_ID_Strategy:
  Format: "sess-{YYYYMMDD}-{HHmmss}-{random4}"
  Generation: Generated once in Stage 0
  Scope: Shared throughout entire pipeline execution
  Persistence: 30min TTL after execution complete → auto cleanup

Session_Init:
  Bash: |
    SESSION_ID="sess-$(date +%Y%m%d-%H%M%S)-$(openssl rand -hex 2)"
    mkdir -p ~/.davinci/events/$SESSION_ID
    echo $SESSION_ID
```

---

## EXECUTION STRATEGY: Per-Skill Model Routing

**ADR-001 Path B**: Task/Agent tool의 `model`은 `["sonnet","opus","haiku"]` enum 고정이다. ModelRouter가 `opus-4.6`/`opus-4.7` 같은 version-qualified ID를 저장하더라도 호출 직전 `resolve_for_task()`로 base 모델로 축약한다. 실제 버전 제어는 Orchestrator `/model` 지정으로만 달성 — 긴 Wave 실행 전 `/model opus-4.6` 권장.

```yaml
Model_Routing_Table:
  # Opus (Code quality first)
  da:dev     → model: "opus"
  da:game    → model: "opus"
  da:e2e     → model: "opus"

  # Sonnet (Medium complexity)
  da:system  → model: "sonnet"
  da:design  → model: "sonnet"
  da:asset   → model: "sonnet"
  Mega-Spec  → model: "sonnet"    # Stage 1 unified spec generation

  # Haiku (Simple judgment)
  da:verify  → model: "haiku"     # 3-way parallel verify
  da:report  → Skill call

Heavy_Skills_as_Agent:
  - da:system  → Agent(subagent_type="general-purpose", model="opus", isolation="worktree")
  - da:design  → Agent(subagent_type="da-design-worker", model="opus", isolation="worktree")
  - da:asset   → Agent(subagent_type="da-asset-worker", model="opus", isolation="worktree")
  - da:dev     → Agent(subagent_type="da-frontend"|"da-backend", model="opus", isolation="worktree")
  - da:e2e     → Agent(subagent_type="general-purpose", model="opus", isolation="worktree")

Light_Skills:
  - da:verify  → 3x parallel Agent(model="haiku", run_in_background=true)
  - da:improve → Skill(skill="da:improve")
  - da:report  → Skill(skill="da:report")
  - da:git     → Skill(skill="da:git")
```

---

## ANTI-STALL PROTOCOL (Stall Prevention Mechanism)

### §1. Checkpoint System
File: `docs/.da-turbo-checkpoint.json` — updated via Bash on every Stage transition.
```json
{"pipeline":"da:turbo","session_id":"sess-...",
 "plan_file":"...","project_type":"GENERAL|GAME",
 "complexity_tier":"LIGHT|SIMPLE|MODERATE|COMPLEX|EPIC",
 "current_stage":0,"active_engines":["dna_cache","mega_spec","event_bus","learning","parallel"],
 "cache_hit":false,"similarity_score":0.0,
 "stage_timings":{},"agent_timings":{},
 "iterations":{"verify":0},"last_skill":"...","last_update":"...",
 "protocol_version":1,
 "graph":{"nodes":{"<stage:phase:skill>":{"status":"pending|running|passed|failed|blocked|degraded|skipped","attempts":0,"max_attempts":2,"depends_on":[],"evidence_ref":null}},"ready":[],"current":null},
 "loop_control":{"stall_count":0,"last_progress_hash":null},
 "budget":{"max_nodes":60,"nodes_executed":0,"max_wall_minutes":90,"started_at":"..."}}
```
- checkpoint는 **모든 노드(Task/Skill) 종료 직후** 저장한다 — Stage 전환 시점만 저장하지 않는다(da:protocol §6.1).
- 재개 시 `graph.current`가 `running`이면 attempts 증가 없이 같은 노드를 재실행하고, `passed` 노드는 evidence_ref 확인만 한다(§6.2).

### §2. Call-First Pattern
Skill/Task/Agent return → **0 bytes text output** → checkpoint Bash → immediately next tool call.
- ❌ Progress bars, Stage headers, emoji decorations, "Shall I continue?" questions forbidden
- ✅ When output needed, max 1 line (10 words or fewer)

### §3. Self-Progress Check
Internal check on Stage transition (no output): current Stage → next action → remaining Stages → if no reason to stop, proceed immediately.

### §4. Sub-Skill Interactive Override
All sub-skill AskUserQuestion forbidden during da:turbo.
Principle: if info exists in plan/architecture, self-decide; otherwise use safe defaults.

### §5. Never-End-After-Any-Skill
da:turbo responses must always end with tool calls (exception: only after Stage 4 da:report return).

---

## COMPLEXITY GATE MATRIX

Automatically determines the activation scope of innovation axes based on project complexity.

```yaml
Gate_Logic:
  auto_detection:
    LIGHT: pages <= 1, components <= 3, no API
    SIMPLE: pages <= 3, components <= 8, API <= 2
    MODERATE: pages <= 6, components <= 15, API <= 5
    COMPLEX: pages <= 12, components <= 30, API <= 15
    EPIC: pages > 12 or components > 30

Activation_Matrix:
  | Complexity | DNA Cache  | Mega-Spec   | Event-Driven | Learning  | Parallel   |
  |------------|-----------|-------------|--------------|----------|-----------|
  | LIGHT      | L4 only   | Skip (sequential) | Skip    | L1       | Skip      |
  | SIMPLE     | L1+L4     | Skip (sequential) | Skip    | L1+L2    | Skip      |
  | MODERATE   | L1+L2+L4  | Generate    | Skip (Wave)  | L1+L2+L3 | 2-wave    |
  | COMPLEX    | L1~L4     | Gen+N-way   | Event Bus    | L1~L4    | Full wave |
  | EPIC       | L1~L4     | Gen+N-way   | Event Bus    | L1~L4    | Full+Teams|
```

---

## Stage 0: Plan Parse + DNA Cache Lookup (30s)

```yaml
Step_1_Plan_Parse:
  - If user specified a path → Read(that path)
  - If not specified → Glob("**/PLAN*.md") search
  - Parse plan → extract project_type, tech_stack, features[], complexity

Step_2_Complexity_Gate:
  - Determine complexity tier via Phase count + task count + keyword analysis
  - Greenfield Guard: 1+ new files → force MODERATE or above
  - Determine active_engines (reference Activation_Matrix)

Step_3_DNA_Cache_Lookup:
  # DNA Cache Engine (~/.davinci/bin/dna-cache.sh) call
  - Bash: |
      bash ~/.davinci/bin/dna-cache.sh init  # idempotent initialization

      # Similarity-based cache lookup — returns JSON result
      CACHE_RESULT=$(bash ~/.davinci/bin/dna-cache.sh retrieve \
        --type "{project_type}" \
        --stack "{tech_stack_csv}" \
        --complexity "{complexity_tier}" \
        --domain "{domain_keywords_csv}" \
        --threshold 0.65)

      echo "$CACHE_RESULT"

  - Result_Parsing:
      status == "HIT":
        - Record similarity_score, best_match hash
        - Extract L1~L4 data from layers object
        - L1 Architecture → Mega-Spec template based (folder_structure, tech_decisions, routing)
        - L2 Components → Reuse component tree (design_tokens, component_tree)
        - L3 Code → Inject parameterized snippets (api-route, component, hook templates)
        - L4 Rules → Pre-apply verify prevention rules (KNOWN_ISSUES section)
        - Update access: bash ~/.davinci/bin/dna-cache.sh update-access {best_match}
      status == "MISS":
        - cache_hit = false, full generation mode
        - Partial match reference available from candidates list (score 0.5~0.65)

  - SimilarityScoring_Algorithm:
      project_type: exact match (weight: 0.40) — 1.0 if same type, 0.0 otherwise
      tech_stack: Jaccard similarity (weight: 0.35) — |A∩B| / |A∪B|
      complexity_tier: tier distance (weight: 0.15) — 1 - |idx_a - idx_b| / 4
      domain_keywords: keyword overlap (weight: 0.10) — Jaccard on keywords
      Threshold: 0.65 (below threshold → skip cache → full generation)

Step_4_Learning_Injection:
  # Learning Engine (~/.davinci/bin/learning-engine.sh) call
  # Context Budget Manager: max 2000 tokens, only patterns with confidence >= 0.3
  - Bash: |
      LEARNING_INJECTION=$(bash ~/.davinci/bin/learning-engine.sh inject "{project_type}" 2000)
      echo "$LEARNING_INJECTION"
      # Extract injection text from result → inject into Stage 1 Mega-Spec generation
      echo "$LEARNING_INJECTION" | jq -r '.injection // ""' > /tmp/learning-injection.txt
  - L1 error patterns → auto-generate KNOWN_ISSUES section
  - L3 prompt patterns → auto-generate EFFECTIVE_PATTERNS section
  - L4 architecture patterns → auto-generate ARCHITECTURE_DECISIONS section

Step_5_Session_Init:
  - Generate Session ID (see SESSION MANAGEMENT above)
  - Create event directory: ~/.davinci/events/{session-id}/
  - Create initial checkpoint

Step_6_Style_Auto_Detect:
  style_matrix: SaaS/tech→modern/gradient | game/dark→dark/glow | portfolio→minimal | luxury→glassmorphism
  font_matrix: modern→Bebas Neue | dark→Ethnocentric | minimal→Abolition (body: ITC Avant Garde Gothic)

Output: {plan_parsed, cache_result, learning_injection, complexity_tier, active_engines, session_id}
```

**Proceed immediately to Stage 1 after outputting execution plan. No user confirmation needed.**

```yaml
Checkpoint_Update: Create docs/.da-turbo-checkpoint.json via Bash
  {"current_stage":0, "complexity_tier":"...", "active_engines":[...], "session_id":"..."}
```

---

## Stage 1: Mega-Spec Generation (5min, 10min on Cache MISS)

```yaml
Condition: complexity >= MODERATE (LIGHT/SIMPLE skip Stage 1 → go directly to Stage 2)
Schema: ~/.davinci/schemas/mega-spec.schema.json (v2.0.0)
Template: docs/architecture/mega-spec-template.json
Script: ~/.davinci/bin/mega-spec.sh
```

### Step 1: Scaffold — Generate Initial Mega-Spec Structure

```yaml
Action:
  - Bash: |
      bash ~/.davinci/bin/mega-spec.sh generate "{plan_file}" \
        --project-id "{project_id}" \
        --complexity "{complexity_tier}" \
        --output "docs/mega-spec/mega-spec.json"
  Result: docs/mega-spec/mega-spec.json (template-based initial structure)
```

### Step 2: DNA Cache Injection — L1~L4 Auto-Injection

```yaml
Condition: cache_hit == true (determined in Stage 0)
Action:
  - Bash: |
      # On cache hit, auto-inject L1~L4 data into Mega-Spec
      bash ~/.davinci/bin/mega-spec.sh inject-cache \
        "docs/mega-spec/mega-spec.json" \
        "~/.davinci/cache/projects/{best_match_hash}"
  Injection_Points:
    L1_Architecture:
      - system_spec.folder_structure ← L1 folder_structure merge
      - system_spec.architecture_type ← L1 routing_pattern reference
      - dna_cache_injection.l1_decisions_reused ← reused decision list
    L2_Components:
      - design_spec.component_tree ← L2 component registry based
      - dna_cache_injection.l2_components_injected ← injected component names
    L3_Code:
      - (Not directly injected — passed as snippets in Stage 2 dev prompt)
      - dna_cache_injection.l3_snippets_count ← available snippet count
    L4_Rules:
      - learning_injection.known_error_patterns ← pre-apply prevention rules
      - dna_cache_injection.l4_rules_applied ← applied rule list
```

### Step 3: Learning Injection — Pre-Inject Error/Prompt/Pattern Data

```yaml
Action:
  - Bash: |
      bash ~/.davinci/bin/mega-spec.sh inject-learning \
        "docs/mega-spec/mega-spec.json"
  Context_Budget: max 2000 tokens
  Selection_Strategy:
    - Include only patterns with confidence_score >= 0.6
    - Prioritize patterns overlapping with current project tech_stack
    - Auto truncation (top-N) when budget exceeded
  Injection_Points:
    Error_Patterns: KNOWN_ISSUES section → reflected in verify criteria
    Prompt_Patterns: EFFECTIVE_PATTERNS → improve code generation quality
    Architecture_Recs: ARCHITECTURE_DECISIONS → reinforce system_spec
```

### Step 4: Mega-Spec Assembly — system+design Unified One-Shot Generation

```yaml
Action:
  Task(model="opus", prompt="
    Your task: Generate system + design unified Mega-Spec JSON in one shot.
    ★ TOOL RULES: Use only Write(file_path, content). 200+ lines → Write skeleton + Edit insert.

    ## Input
    1. Plan document: Read('{plan_file}')
    2. Current Mega-Spec (scaffold + cache + learning injection complete):
       Read('docs/mega-spec/mega-spec.json')
    3. Schema reference: ~/.davinci/schemas/mega-spec.schema.json

    ## Generation Requirements
    Fill in the following sections into docs/mega-spec/mega-spec.json via Edit:

    ### system_spec (da:system integration)
    - architecture_type: Architecture matching the plan's tech stack
    - tech_stack: Full tech stack array
    - folder_structure: src/ subdirectory role mapping
    - api_endpoints: All API endpoints (method, path, request/response schema)
    - data_models: All data models (name, fields, relations)
    - state_management: State management strategy + stores
    - environment_config: Environment variables, build settings
    - third_party_integrations: External SDKs/services

    ### design_spec (da:design integration)
    - design_system: Full design tokens (colors, typography, spacing, shadows)
    - component_tree: All components (name, type, props, children, file_path)
    - page_layouts: All pages (name, route, sections, seo)
    - responsive_breakpoints: sm/md/lg/xl/2xl
    - animations: Animation list (type, target, library)
    - accessibility: WCAG level, aria, keyboard nav

    ### file_manifest (complete file list)
    - Specify path, type, owner, depends_on, exports, imports, estimated_lines for all files
    - Owner rules:
      * src/app/**, src/components/**, src/hooks/** → da-frontend
      * src/api/**, src/lib/**, prisma/** → da-backend
      * public/**, src/assets/** → da-asset
      * src/types/**, package.json, configs → shared
    - priority: base files with no dependencies = critical, rest = high/medium/low

    ### interface_contracts (Inter-Agent contracts)
    - Specify contract_id, provider, consumer, type for all cross-agent references
    - provider_file, consumer_file, symbols required
    - type: api | import | shared-type | env-var

    ### dependency_graph (file dependency DAG)
    - nodes: all files from file_manifest → {file_path, owner, in_degree, out_degree}
    - edges: extract {from, to, type, symbols} from depends_on
    - waves: topological sort result → parallel-capable file groups per wave
    - has_cycles: verify false (if true, break cycles)

    ## DNA Cache/Learning Usage
    - If dna_cache_injection data exists → extend based on that structure
    - If learning_injection.known_error_patterns exists → prevent those patterns proactively

    ## Constraints
    - AskUserQuestion forbidden
    - Adding features not in the plan forbidden
    - File paths must match actual project structure")
```

### Step 5: Self-Check — 5 Structure Validations

```yaml
Action:
  - Bash: |
      bash ~/.davinci/bin/mega-spec.sh self-check "docs/mega-spec/mega-spec.json"
      EXIT_CODE=$?
      echo "Self-Check exit code: $EXIT_CODE"

SelfCheck_5_Checks:
  1. file_reference_consistency:
     - All depends_on references in file_manifest exist within the manifest
     - Missing file reference → SC-REF-001 error
  2. interface_matching:
     - interface_contracts provider_file/consumer_file exist in manifest
     - provider ↔ consumer bidirectional reference consistency
     - Mismatch → SC-IF-001 error
  3. completeness:
     - file_manifest is not empty (required)
     - system_spec.tech_stack is not empty (warning)
     - dependency_graph.nodes and file_manifest consistency (warning)
  4. naming_convention:
     - component/page filenames are kebab-case
     - Violation → SC-NAM-001 warning
  5. dependency_acyclicity:
     - No cycles in dependency_graph
     - 2-hop cycle detection based on edges
     - Cycle → SC-DAG-001 error (detailed cycle path display)

Auto_Fix_Protocol:
  Trigger: Self-Check failure (attempt 1)
  Actions:
    - Missing files → auto-add to manifest (type: utility, owner: shared)
    - If dependency_graph empty → auto-generate from file_manifest
    - After auto-correction → re-verify as attempt 2
  Max_Attempts: 2 (2 failures → record warning + proceed with best effort)
```

### Step 6: N-way Split — Per-Agent Sub-Spec Partitioning

```yaml
Action:
  - Bash: |
      bash ~/.davinci/bin/mega-spec.sh split "docs/mega-spec/mega-spec.json" \
        --manifest ".da-parallel-manifest.yaml" \
        --output-dir "docs/mega-spec/sub-specs"

NWay_Split_Algorithm:
  Input: Mega-Spec JSON (based on file_manifest.owner)
  Steps:
    1. Group by file ownership: da-frontend, da-backend, da-asset, shared
    2. Generate per-Agent sub-specs:
       - Agent's file list + dependent interfaces
       - Include full system_spec, design_spec (for reference)
       - dependency_subgraph: extract only edges for that Agent's files
       - Include learning/cache injection data
    3. Auto-generate .da-parallel-manifest.yaml:
       - owns: Agent file directory patterns
       - reads: other Agent directory patterns from depends_on
       - shared_files: append_only file list
       - merge_strategy: additive

  Output_Files:
    - docs/mega-spec/sub-specs/da-frontend-spec.json
    - docs/mega-spec/sub-specs/da-backend-spec.json
    - docs/mega-spec/sub-specs/da-asset-spec.json
    - docs/mega-spec/sub-specs/shared-spec.json
    - .da-parallel-manifest.yaml

  Merge_Order: shared → da-backend → da-frontend → da-asset → da-design-worker
```

### Step 7: Validation + Stats

```yaml
Action:
  - Bash: |
      # JSON validity verification
      bash ~/.davinci/bin/mega-spec.sh validate "docs/mega-spec/mega-spec.json"
      # Output statistics
      bash ~/.davinci/bin/mega-spec.sh stats "docs/mega-spec/mega-spec.json"

Validation_Checks:
  - JSON syntax validity
  - Required fields: version, project_id, generated_at, complexity_tier, system_spec, design_spec, file_manifest, interface_contracts, dependency_graph
  - Schema version: 2.0.0
  - Owner enum: da-frontend | da-backend | da-asset | da-design-worker | shared
  - Type enum: page | component | api | config | type | utility | asset | test | hook | store | middleware | layout
```

```yaml
Output: {mega_spec.json, sub-specs/*.json, .da-parallel-manifest.yaml}

Checkpoint_Update: {"current_stage":1, "last_skill":"mega_spec_done",
  "mega_spec_self_check": true/false,
  "mega_spec_files": N, "mega_spec_agents": N,
  "mega_spec_warnings": N}
```

---

## Stage 2: N-Way Parallel Code Generation (8min)

```yaml
Condition_Branch:
  LIGHT/SIMPLE: Single Task(model="opus") → direct da:dev execution (no parallelism)
  MODERATE: 2-wave parallel (design||asset → frontend||backend)
  COMPLEX/EPIC: Full wave parallel + Event Bus + Micro-Merge

Step_1_DAG_Scheduling:
  - Build file dependency graph (based on Mega-Spec file_manifest)
  - Topological sort → Wave generation:
      Wave 0: scaffold (shared configs, types, configs)
      Wave 1: design + asset (parallel, independent worktree)
      Wave 2: frontend + backend (parallel, independent worktree)

Step_2_Event_Bus_Init (COMPLEX+ only):
  # Event Bus + Micro-Merge initialization
  - Bash: |
      source ~/.davinci/bin/event-bus.sh
      source ~/.davinci/bin/micro-merge.sh
      SESSION_ID=$(event_bus_init "{session_id}")
      micro_merge_init "$(pwd)" ".da-parallel-manifest.yaml"
      echo "Event Bus + Micro-Merge initialized: ${SESSION_ID}"

  Event_Signal_Schema: ~/.davinci/schemas/event-signal.schema.json
  Event_Directory: ~/.davinci/events/{session-id}/
  Design_Constraint:
    - Filesystem isolation between worktrees → event directory placed outside worktree (~/.davinci/)
    - Each Subagent writes/reads events to shared path, not inside worktree
    - Session-id maintains isolation between project executions

Step_3_Wave_Execution:
  for wave in waves:
    if len(wave) == 1:
      Single Agent/Task execution
    elif len(wave) >= 2:
      # ★ Invoke multiple Agents simultaneously in the same message (Event Bus integration)
      Agent(subagent_type="da-frontend", isolation="worktree", run_in_background=true,
        prompt="Sub-spec: {sub_spec} | Manifest: {manifest} | Handoff: docs/handoff/
               ★ EVENT BUS: Must emit events on file creation.
                 source ~/.davinci/bin/event-bus.sh
                 event_bus_init '{session_id}'
                 event_emit_file_created 'da-frontend' '{file}' '[exports]'
                 On completion: event_emit_agent_done 'da-frontend' '[files_json]'")
      Agent(subagent_type="da-backend", isolation="worktree", run_in_background=true,
        prompt="Sub-spec: {sub_spec} | Manifest: {manifest} | Handoff: docs/handoff/
               ★ EVENT BUS: Must emit events on file creation.
                 source ~/.davinci/bin/event-bus.sh
                 event_bus_init '{session_id}'
                 event_emit_file_created 'da-backend' '{file}' '[exports]'
                 On completion: event_emit_agent_done 'da-backend' '[files_json]'")

Step_4_Event_Driven_Pipeline (COMPLEX+ only):
  # ~/.davinci/bin/event-bus.sh — Filesystem-based event signaling
  # Resolves worktree isolation: uses shared path ~/.davinci/events/{session-id}/
  #
  EventEmitter_Usage:
    - Bash: |
        source ~/.davinci/bin/event-bus.sh
        event_bus_init "{session_id}"
        event_emit_file_created "{agent}" "{file_path}" '{exports_json}'
        event_emit_dependency_ready "{agent}" '["src/lib/api.ts"]'
        event_emit_agent_done "{agent}" '{files_json}'

  EventListener_Usage:
    - Bash: |
        source ~/.davinci/bin/event-bus.sh
        event_bus_init "{session_id}"
        # Wait for specific Agent's event (2s polling, 300s timeout)
        EVENT_FILE=$(event_poll "file_created" "da-backend" 300)
        [ $? -eq 0 ] && EVENT_DATA=$(event_read "$EVENT_FILE")
        # Wait for all Agents to complete
        event_wait_all_agents_done 300 "da-frontend" "da-backend" "da-asset-worker"

  Event_Types:
    file_created:    {file_path, file_hash, exports[], status}
    build_error:     {file_path, error_message, status:"error"}
    test_failure:    {file_path, error_message, status:"error"}
    dependency_ready: {dependencies_satisfied[], status}
    agent_done:      {files_created[], status}

  Timeout_Fallback: 300s → Switch to Wave-based Merge Gate

Step_5_MicroMerge (COMPLEX+ only):
  # ~/.davinci/bin/micro-merge.sh — Per-file immediate merge + rollback
  # Integrates individual files immediately upon completion without waiting for entire Wave
  #
  On_file_created_Event:
    - Bash: |
        source ~/.davinci/bin/event-bus.sh
        source ~/.davinci/bin/micro-merge.sh
        event_bus_init "{session_id}"
        micro_merge_init "$(pwd)" ".da-parallel-manifest.yaml"
        # Event-driven automatic merge
        for evt in $(event_list "file_created"); do
          micro_merge_on_event "$evt" ".claude/worktrees"
        done
        micro_merge_status

  Ownership_Rules:
    - owns pattern match → immediate merge (return 0)
    - shared/append-only → wait until Wave completion (return 2, deferred)
    - Non-owned file → skip merge (return 1, skipped)

  Rollback_On_Failure:
    - Bash: |
        source ~/.davinci/bin/micro-merge.sh
        micro_merge_init "$(pwd)"
        micro_merge_rollback "src/components/hero.tsx"   # Per-file
        micro_merge_rollback_agent "da-frontend"          # Entire Agent
        micro_merge_rollback_all                          # Full emergency rollback
    Mechanism:
      - Auto backup before merge: ~/.davinci/backups/merge-{timestamp}/
      - New files → delete | Existing files → restore original
      - Emit failure event: build_error → Orchestrator notification

Step_6_Wave_Merge (Final Integration):
  Merge_Order: shared → backend → frontend → asset → docs
  - Bash: |
      source ~/.davinci/bin/micro-merge.sh
      micro_merge_init "$(pwd)" ".da-parallel-manifest.yaml"
      # Shared file additive merge
      micro_merge_shared_additive "src/types/index.ts" \
        ".claude/worktrees/da-frontend" ".claude/worktrees/da-backend"
      micro_merge_shared_additive "package.json" \
        ".claude/worktrees/da-frontend" ".claude/worktrees/da-backend"
      micro_merge_status
  - Skip already micro-merged files (prevent duplicates)
  - Worktree cleanup

Step_7_Event_Cleanup:
  - Bash: |
      source ~/.davinci/bin/event-bus.sh
      source ~/.davinci/bin/micro-merge.sh
      event_bus_init "{session_id}"
      event_bus_status
      event_cleanup          # Mark session completed, 30min TTL
      micro_merge_cleanup    # Clean up backup directories
      event_cleanup_expired 30  # Batch cleanup of expired sessions

Output: Complete project code (main branch integrated)

Checkpoint_Update: {"current_stage":2, "last_skill":"parallel_gen_done"}
```

---

## Stage 3: Smart Verify + Inline Fix + Learning Collection (1.5min)

```yaml
Step_1_Learning_Injection_Pre_Verify:
  # Inject existing error patterns from Learning Engine before verify for proactive prevention
  - Bash: |
      INJECTION=$(bash ~/.davinci/bin/learning-engine.sh inject "{project_type}" 2000)
      echo "$INJECTION" > /tmp/learning-injection.json
  - Apply injected KNOWN_ISSUES to verify criteria

Step_2_Smart_Verify:
  - Pre-apply DNA Cache L4 rules → minimize known issues
  - Pre-apply Learning Engine L1 error patterns → auto-detect recurring issues
  - Verify only changed files (using Verify Cache)
  - 3-way parallel verify (COMPLEX+ only):
      Agent(subagent_type="da-verify-security", model="haiku", run_in_background=true)
      Agent(subagent_type="da-verify-perf", model="haiku", run_in_background=true)
      Agent(subagent_type="da-verify-quality", model="haiku", run_in_background=true)
  - Aggregate results: calculate match_rate

Step_3_Inline_Fix (da:protocol §4.4 conditional edge):
  - verdict MET (items[] match_rate ≥ 90%, Critical/High 없음) → proceed directly to Stage 4
  - verdict NOT_MET → inline fix (da:improve, previous_failure + next_action_hint 주입) → re-verify (별도 Task = 다른 컨텍스트)
  - 2nd failure → attempt 2 must use a different approach (모델 승격 허용)
  - 2 failures exhausted:
      Medium/Low만 잔존 → record as known_issue, node degraded, proceed (리포트 명시)
      Critical/High 잔존 → node blocked → Stage 4 진입 금지, §7 interrupt(blocked_decision) — 강제 진행 없음
  - verdict BLOCKED/IMPOSSIBLE → 즉시 사용자 보고
  - 전이마다 checkpoint 저장 (§6.1)

Step_4_E2E_Smoke (COMPLEX+ only):
  - Verify build success
  - Verify main page rendering
  - Verify API endpoint responses

Step_5_Learning_Collect_Errors:
  # Immediately collect error patterns from verify results (redundant with Stage 4)
  - Bash: |
      # Extract issues from verify results → save via learning-engine.sh
      VERIFY_ISSUES=$(cat docs/.da-verify-results.json 2>/dev/null || echo '[]')
      ISSUE_COUNT=$(echo "$VERIFY_ISSUES" | jq 'if type == "array" then length else 0 end')
      i=0
      while [ "$i" -lt "$ISSUE_COUNT" ]; do
        ERR_TYPE=$(echo "$VERIFY_ISSUES" | jq -r ".[$i].error_type // \"other\"")
        ERR_DESC=$(echo "$VERIFY_ISSUES" | jq -r ".[$i].description // \"Unknown\"")
        ERR_FILES=$(echo "$VERIFY_ISSUES" | jq -r ".[$i].affected_files // \"\"")
        ERR_RULE=$(echo "$VERIFY_ISSUES" | jq -r ".[$i].prevention_rule // \"\"")
        bash ~/.davinci/bin/learning-engine.sh store-error "$ERR_TYPE" "$ERR_DESC" "$ERR_FILES" "$ERR_RULE"
        i=$((i + 1))
      done
      echo "Collected $ISSUE_COUNT error patterns"

Output: {verify_results, fix_log, smoke_test_results, learning_errors_collected}

Checkpoint_Update: {"current_stage":3, "last_skill":"verify_done"}
```

---

## Stage 4: Report + Learning Update (30s)

```yaml
Step_1_Report:
  Skill(skill="da:report", args="Generate da:turbo pipeline execution report.
    Include per-Stage execution time, cache hit rate, issue count, parallel execution results.")

Step_2_Learning_Update:
  # Collect 4-Source learning data via Learning Engine (~/.davinci/bin/learning-engine.sh)
  # PostSkill Hook redundancy: da:report completion + direct orchestrator invocation
  - Bash: |
      LE="~/.davinci/bin/learning-engine.sh"

      # === L1: Error Pattern Collector (already collected in Stage 3 + redundant here) ===
      VERIFY_RESULTS=$(cat docs/.da-verify-results.json 2>/dev/null || echo '[]')
      ISSUE_COUNT=$(echo "$VERIFY_RESULTS" | jq 'if type == "array" then length else 0 end')
      if [ "$ISSUE_COUNT" -gt 0 ]; then
        i=0
        while [ "$i" -lt "$ISSUE_COUNT" ]; do
          ET=$(echo "$VERIFY_RESULTS" | jq -r ".[$i].error_type // \"other\"")
          ED=$(echo "$VERIFY_RESULTS" | jq -r ".[$i].description // \"Unknown\"")
          AF=$(echo "$VERIFY_RESULTS" | jq -r ".[$i].affected_files // \"\"")
          PR=$(echo "$VERIFY_RESULTS" | jq -r ".[$i].prevention_rule // \"\"")
          bash "$LE" store-error "$ET" "$ED" "$AF" "$PR" > /dev/null
          i=$((i + 1))
        done
      fi
      echo "[L1] Errors collected: $ISSUE_COUNT"

      # === L2: Timing Analyzer ===
      CHECKPOINT=$(cat docs/.da-turbo-checkpoint.json 2>/dev/null || echo '{}')
      PROJECT_ID=$(echo "$CHECKPOINT" | jq -r '.session_id // "unknown"')
      TIER=$(echo "$CHECKPOINT" | jq -r '.complexity_tier // "MODERATE"')
      STAGE_TIMINGS=$(echo "$CHECKPOINT" | jq -c '.stage_timings // {}')
      AGENT_TIMINGS=$(echo "$CHECKPOINT" | jq -c '.agent_timings // {}')
      TOTAL_SECS=$(echo "$STAGE_TIMINGS" | jq '[.[]] | add // 0')
      CACHE_HIT=$(echo "$CHECKPOINT" | jq '.cache_hit // false')
      bash "$LE" store-timing "$PROJECT_ID" "$TIER" "$TOTAL_SECS" "$CACHE_HIT" "$STAGE_TIMINGS" "$AGENT_TIMINGS"
      echo "[L2] Timing stored for $PROJECT_ID"

      # === L3: Prompt Evolution Tracker ===
      # Convert verify match_rate to success_rate to measure prompt effectiveness
      MATCH_RATE=$(echo "$CHECKPOINT" | jq -r '.match_rate // 0' 2>/dev/null || echo "0")
      SUCCESS_RATE=$(echo "scale=2; $MATCH_RATE / 100" | bc -l 2>/dev/null || echo "0.5")
      LAST_SKILL=$(echo "$CHECKPOINT" | jq -r '.last_skill // "da:dev"')
      EFFECTIVE='[]'
      INEFFECTIVE='[]'
      if (( $(echo "$SUCCESS_RATE >= 0.9" | bc -l) )); then
        EFFECTIVE='["high-quality-output"]'
      elif (( $(echo "$SUCCESS_RATE < 0.7" | bc -l) )); then
        INEFFECTIVE='["needs-improvement"]'
      fi
      bash "$LE" store-prompt "prompt-${LAST_SKILL}" "$LAST_SKILL" "$SUCCESS_RATE" "$EFFECTIVE" "$INEFFECTIVE"
      echo "[L3] Prompt tracked: $LAST_SKILL (rate: $SUCCESS_RATE)"

      # === L4: Architecture Pattern Store ===
      # Extract and store architecture decisions from mega-spec
      if [ -f "docs/mega-spec/mega-spec.json" ]; then
        PROJECT_TYPE=$(cat docs/mega-spec/mega-spec.json | jq -r '.system_spec.architecture_type // "unknown"')
        TECH_STACK=$(cat docs/mega-spec/mega-spec.json | jq -c '.system_spec.tech_stack // []')
        DECISIONS=$(cat docs/mega-spec/mega-spec.json | jq -c '[.system_spec.tech_decisions // [] | .[] | .decision] // []' 2>/dev/null || echo '[]')
        DEC_COUNT=$(echo "$DECISIONS" | jq 'length')
        i=0
        while [ "$i" -lt "$DEC_COUNT" ]; do
          DEC=$(echo "$DECISIONS" | jq -r ".[$i]")
          bash "$LE" store-pattern "$PROJECT_TYPE" "$TECH_STACK" "$DEC" "From mega-spec" > /dev/null
          i=$((i + 1))
        done
        echo "[L4] Architecture patterns stored: $DEC_COUNT"
      else
        echo "[L4] No mega-spec found, skipping pattern store"
      fi

      # === Confidence Cleanup ===
      bash "$LE" cleanup
      echo "[Learning] Low-confidence data cleaned up"

      # === Output learning statistics ===
      bash "$LE" stats

Step_3_DNA_Cache_Update:
  # Store project DNA via DNA Cache Engine (~/.davinci/bin/dna-cache.sh)
  - Bash: |
      # Step 3a: Generate L1~L4 cache data as temporary JSON
      # (each layer extracted from previous Stage outputs)

      # L1 Architecture — Extract folder_structure, tech_decisions, routing from da:system outputs
      # → /tmp/dna-l1.json (auto-extracted from project structure via python3)
      python3 -c "
      import json, os, glob
      l1 = {'layer': 'L1', 'folder_structure': {}, 'tech_decisions': [], 'routing_pattern': '', 'api_pattern': '', 'state_management': ''}
      # Scan src/ subdirectories
      for d in glob.glob('src/**/'):
          rel = d.replace(os.getcwd() + '/', '')
          l1['folder_structure'][rel] = 'auto-detected'
      # Extract tech decisions from package.json
      pkg = 'package.json'
      if os.path.exists(pkg):
          data = json.load(open(pkg))
          deps = {**data.get('dependencies', {}), **data.get('devDependencies', {})}
          for k in deps:
              l1['tech_decisions'].append({'category': 'dependency', 'decision': k, 'rationale': 'from package.json'})
          if 'next' in deps: l1['routing_pattern'] = 'app-router'
          elif 'react-router-dom' in deps: l1['routing_pattern'] = 'react-router'
          if 'express' in deps: l1['api_pattern'] = 'express'
          elif 'next' in deps: l1['api_pattern'] = 'next-api-routes'
      print(json.dumps(l1, indent=2))
      " > /tmp/dna-l1.json 2>/dev/null || echo '{}' > /tmp/dna-l1.json

      # L2 Components — Auto-extract component tree from src/components/ structure
      python3 -c "
      import json, os, glob
      l2 = {'layer': 'L2', 'component_tree': [], 'design_tokens': {}}
      for f in glob.glob('src/components/**/*.tsx', recursive=True) + glob.glob('src/components/**/*.jsx', recursive=True):
          name = os.path.splitext(os.path.basename(f))[0]
          ctype = 'component'
          if '/ui/' in f or '/atoms/' in f: ctype = 'atom'
          elif '/layout/' in f: ctype = 'layout'
          elif '/pages/' in f or '/app/' in f: ctype = 'page'
          l2['component_tree'].append({'name': name, 'type': ctype, 'props': {}, 'children': []})
      print(json.dumps(l2, indent=2))
      " > /tmp/dna-l2.json 2>/dev/null || echo '{}' > /tmp/dna-l2.json

      # L3 Code — Extract reusable code patterns (hooks, utils, api routes)
      python3 -c "
      import json, os, glob, re
      l3 = {'layer': 'L3', 'snippets': []}
      # Extract hooks
      for f in glob.glob('src/hooks/**/*.ts', recursive=True) + glob.glob('src/hooks/**/*.tsx', recursive=True):
          name = os.path.splitext(os.path.basename(f))[0]
          with open(f) as fh:
              content = fh.read()
          template = re.sub(r'[A-Z][a-zA-Z]+(?:Page|Component|View)', '{{ComponentName}}', content[:500])
          l3['snippets'].append({'id': name, 'pattern_type': 'hook', 'template': template, 'parameters': [{'name': 'ComponentName', 'type': 'string', 'description': 'Target component'}], 'usage_count': 1})
      # Extract utilities
      for f in glob.glob('src/lib/**/*.ts', recursive=True) + glob.glob('src/utils/**/*.ts', recursive=True):
          name = os.path.splitext(os.path.basename(f))[0]
          l3['snippets'].append({'id': name, 'pattern_type': 'utility', 'template': '', 'parameters': [], 'usage_count': 1})
      print(json.dumps(l3, indent=2))
      " > /tmp/dna-l3.json 2>/dev/null || echo '{}' > /tmp/dna-l3.json

      # L4 Rules — Convert recurring issue patterns from verify results → prevention rules
      python3 -c "
      import json, os
      l4 = {'layer': 'L4', 'rules': []}
      # Parse if verify results exist
      verify_files = ['docs/verify-results.json', 'docs/.da-verify-results.json']
      for vf in verify_files:
          if os.path.exists(vf):
              try:
                  data = json.load(open(vf))
                  issues = data.get('issues', data.get('findings', []))
                  for i, issue in enumerate(issues[:20]):
                      l4['rules'].append({
                          'rule_id': f'R{i+1:03d}',
                          'error_pattern': issue.get('description', issue.get('message', str(issue))),
                          'prevention': f'Prevent: {issue.get(\"fix\", issue.get(\"recommendation\", \"review before commit\"))}',
                          'affected_files': issue.get('file', '*'),
                          'priority': issue.get('severity', 'medium'),
                          'confidence': 0.7
                      })
              except: pass
      print(json.dumps(l4, indent=2))
      " > /tmp/dna-l4.json 2>/dev/null || echo '{}' > /tmp/dna-l4.json

      # Step 3b: Invoke dna-cache.sh store
      PROJECT_HASH=$(bash ~/.davinci/bin/dna-cache.sh store \
        --type "{project_type}" \
        --stack "{tech_stack_csv}" \
        --complexity "{complexity_tier}" \
        --domain "{domain_keywords_csv}" \
        --l1-file /tmp/dna-l1.json \
        --l2-file /tmp/dna-l2.json \
        --l3-file /tmp/dna-l3.json \
        --l4-file /tmp/dna-l4.json \
        --source-path "$(pwd)")

      echo "DNA Cache stored: ${PROJECT_HASH}"

      # Step 3c: Auto-run LRU eviction (also runs inside store, but explicit check)
      bash ~/.davinci/bin/dna-cache.sh evict

      # Step 3d: Output cache statistics
      bash ~/.davinci/bin/dna-cache.sh stats

      # Clean up temporary files
      rm -f /tmp/dna-l{1,2,3,4}.json

Step_4_Git:
  Skill(skill="da:git", args="da:turbo pipeline completion commit/push")

Step_5_Cleanup:
  - Checkpoint cleanup: rm -f docs/.da-turbo-checkpoint.json
  - Event directory cleanup: rm -rf ~/.davinci/events/{session-id}/

Output: "da:turbo pipeline complete!"
```

---

## FAILURE MODES & FALLBACK (Phase 6: Fallback Controller)

```yaml
# Script: ~/.davinci/bin/turbo-fallback.sh
# Sourced and used across all Stages

Fallback_Controller_Init:
  # One-time initialization in Stage 0
  Bash: |
    source ~/.davinci/bin/turbo-fallback.sh
    fallback_init

Engine_Fallbacks:
  DNA_Cache_Miss: Skip cache, full generation
  DNA_Cache_Corrupt: Ignore cache, rebuild index.json
  MegaSpec_SelfCheck_Fail: Auto-correct 1 time → on failure, fallback to sequential (system → design)
  MegaSpec_Timeout: Switch to sequential mode
  EventBus_Timeout: Switch to Wave-based Merge Gate
  EventBus_Corrupt: Ignore the affected event
  Learning_Budget_Over: Selectively inject only top N
  Learning_Corrupt: Reset the affected learning layer (empty JSON)
  Parallel_Merge_Conflict: Ownership-based auto-resolution → if impossible, sequential re-execution
  Parallel_Agent_Crash: Retry only the affected Agent (max 2) → sequential execution

Per_Engine_Fallback_Protocol:
  # Must execute after every engine invocation:
  Bash: |
    source ~/.davinci/bin/turbo-fallback.sh
    fallback_init  # Idempotent if already initialized
    RESULT=0
    <engine_command> || RESULT=$?
    FALLBACK_RESULT=0
    fallback_check_engine "<engine_name>" $RESULT "<error_msg>" || FALLBACK_RESULT=$?
    if [ $FALLBACK_RESULT -eq 2 ]; then
      # Ultimate Fallback → da:work
      fallback_execute_dawork "{plan_file}"
      # → Skill(skill="da:work", args="{plan_file}")
    elif [ $FALLBACK_RESULT -eq 1 ]; then
      # Degraded mode → deactivate affected engine, proceed to next Stage
      echo "Engine degraded: <engine_name>, continuing..."
    fi

Ultimate_Fallback:
  Trigger: 2+ engines fail simultaneously (fallback_should_use_dawork → true)
  Action:
    1. Deactivate all innovation axes
    2. Switch to legacy da:work sequential mode (pass same Plan file)
    3. Skill(skill="da:work", args="{plan_file}")
  Script: |
    source ~/.davinci/bin/turbo-fallback.sh
    fallback_execute_dawork "{plan_file}" "docs/.da-turbo-checkpoint.json"
  Guarantee: "Even if da:turbo fails, project can be completed via da:work"

Data_Integrity:
  Cache: atomic write (temp → rename), index.json.bak backup
  Learning: atomic write, auto-cleanup when confidence <= 0.0
  Events: write-once, auto-cleanup with 30min TTL after session end
```

---

## PHASE 6 INTEGRATION: Stage 0-4 Pipeline Flow

```yaml
# This section defines the integrated flow of the entire pipeline.
# Specifies scripts invoked at each Stage and Fallback integration.

Pipeline_Flow:
  Stage_0_Parse_Cache:
    scripts:
      - ~/.davinci/bin/dna-cache.sh init
      - ~/.davinci/bin/dna-cache.sh retrieve
      - ~/.davinci/bin/learning-engine.sh inject
      - ~/.davinci/bin/turbo-fallback.sh (source)
    fallback_check:
      - fallback_check_engine "dna_cache" $CACHE_EXIT
      - fallback_check_engine "learning" $LEARNING_EXIT
    complexity_gate:
      - fallback_detect_complexity $pages $components $api_count
      - ACTIVE_ENGINES=$(fallback_get_active_engines $COMPLEXITY)
      - STAGE_CONFIG=$(fallback_get_stage_config $COMPLEXITY)

  Stage_1_MegaSpec:
    condition: complexity >= MODERATE (from STAGE_CONFIG)
    scripts:
      - ~/.davinci/bin/mega-spec.sh generate
      - ~/.davinci/bin/mega-spec.sh inject-cache (if cache_hit)
      - ~/.davinci/bin/mega-spec.sh inject-learning
      - ~/.davinci/bin/mega-spec.sh self-check
      - ~/.davinci/bin/mega-spec.sh split
    fallback_check:
      - fallback_check_engine "mega_spec" $SPEC_EXIT
    skip_action: LIGHT/SIMPLE → proceed directly to Stage 2 (sequential da:dev)

  Stage_2_Parallel:
    condition: from STAGE_CONFIG.stage_2.mode
    scripts:
      - ~/.davinci/bin/event-bus.sh (source, COMPLEX+ only)
      - ~/.davinci/bin/micro-merge.sh (source, COMPLEX+ only)
    modes:
      sequential: Single Task → da:dev
      parallel_wave: 2-wave or full wave parallel
      parallel_event_driven: Event Bus + Micro-Merge integration
    fallback_check:
      - fallback_check_engine "event_bus" $EVENT_EXIT
      - fallback_check_engine "parallel" $PARALLEL_EXIT

  Stage_3_Verify:
    scripts:
      - ~/.davinci/bin/learning-engine.sh inject (pre-verify)
      - ~/.davinci/bin/learning-engine.sh store-error (post-verify)
    fallback_check:
      - fallback_check_engine "learning" $LEARNING_EXIT

  Stage_4_Report:
    scripts:
      - ~/.davinci/bin/learning-engine.sh store-timing
      - ~/.davinci/bin/learning-engine.sh store-prompt
      - ~/.davinci/bin/learning-engine.sh store-pattern
      - ~/.davinci/bin/learning-engine.sh cleanup
      - ~/.davinci/bin/dna-cache.sh store
      - ~/.davinci/bin/dna-cache.sh evict

Testing_and_Benchmark:
  E2E_Test: ~/.davinci/bin/turbo-e2e-test.sh --all
  Benchmark: ~/.davinci/bin/turbo-benchmark.sh --overhead
  Syntax_Check: |
    for s in ~/.davinci/bin/turbo-*.sh ~/.davinci/bin/dna-cache.sh \
             ~/.davinci/bin/mega-spec.sh ~/.davinci/bin/event-bus.sh \
             ~/.davinci/bin/micro-merge.sh ~/.davinci/bin/learning-engine.sh; do
      bash -n "$s" && echo "OK: $s" || echo "FAIL: $s"
    done
```

---

## Usage
```
/da:turbo                           # Auto-find and execute PLAN.md
/da:turbo PLAN-homepage.md          # Specify a plan document
/da:turbo --complexity COMPLEX      # Manually set complexity
/da:turbo --cache skip              # Skip DNA Cache
/da:turbo --learning skip           # Skip Learning
/da:turbo --events wave-only        # Disable Event-Driven
/da:turbo --dry-run                 # Generate spec only, skip code generation
```

## Iron Law
**Never start without a plan document. Never stop midway. Run seamlessly through to Stage 4 Report.**
**On da:turbo failure, automatically fall back to da:work. Project completion is guaranteed.**

ARGUMENTS: $ARGUMENTS
