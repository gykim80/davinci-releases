---
name: memory
description: Browse, search, and inject past session memories into current context
agent: cto-lead
agents: [cto-lead]
davinci-phase: null
allowed-tools: [Read, Bash, Glob, Grep]
next-skill: null
skill-type: flexible
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 유틸리티: 부작용(외부 API/배포/삭제) 전 §7 destructive/cost_gate 규칙을 확인한다.

## Tool Parameter Rules -> See CLAUDE.md (ABSOLUTE)
# /da:memory - Cross-Session Memory Manager

## Purpose

Browse, search, and selectively inject memories from previous sessions into the current context. Enables cross-project knowledge transfer and session continuity.

## Capabilities

1. **List Recent Sessions** -- View sessions across all projects
2. **Search Sessions** -- Full-text search (FTS5) across features, summaries, and observations
3. **View Session Details** -- Inspect what was done in a past session
4. **Inject Memory** -- Load past session context into current conversation
5. **Cross-Project** -- Access memories from any DAVINCI project

## Usage

```
/da:memory                    # Interactive: show recent + search
/da:memory list               # List recent sessions
/da:memory search "auth"      # Search by keyword
/da:memory inject SESSION_ID  # Inject session into context
```

## Interactive Workflow

1. Display recent sessions (last 10)
2. Ask user to search or select
3. Show selected session details
4. Inject as `<davinci-memory>` XML block

## CLI Backend

All operations map to `davinci memory` CLI commands:
- `davinci memory list [--project NAME] [--limit N]`
- `davinci memory search "query"`
- `davinci memory show SESSION_ID`
- `davinci memory inject SESSION_ID [--detail compact|standard|full]`
- `davinci memory tags`
- `davinci memory projects`
- `davinci memory stats`

## Detail Levels

| Level | Content | Tokens |
|-------|---------|--------|
| compact | One-line summary | ~20 |
| standard | Summary + observations | ~100-200 |
| full | Complete session data | ~300-500 |
