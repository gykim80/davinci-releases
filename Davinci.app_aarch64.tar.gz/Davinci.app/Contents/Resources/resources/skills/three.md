---
name: three
description: Three.js 3D graphics/game development. Scene composition, materials, lighting, shaders, animation, interaction, HUD/menu overlay, game feel/juice, state machine, and genre-specific UI patterns.
agent: game-developer
agents: [senior-fullstack, frontend-architect]
davinci-phase: null
allowed-tools: [Write, Edit, Read, Bash, Glob, Grep, Task]
next-skill: verify
skill-type: flexible
version: 3.0
skills-ref:
  - davinci_framework/agent-skills/skills/mengto-threejs
  - davinci_framework/agent-skills/skills/mengto-build-isometric-arpg
  - davinci_framework/agent-skills/skills/mengto-design-action-combat
  - davinci_framework/agent-skills/skills/mengto-build-threejs-enemy-systems
  - davinci_framework/agent-skills/skills/mengto-tune-enemy-ai
  - davinci_framework/agent-skills/skills/mengto-create-game-vfx
  - davinci_framework/agent-skills/skills/mengto-optimize-threejs-games
  - davinci_framework/agent-skills/skills/mengto-test-playable-web-games
  - davinci_framework/agent-skills/skills/mengto-ship-web-games
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 생성자: 자기 검증은 사전 점검일 뿐이다. 최종 판정은 독립 verify 노드가 낸다. 미완료 시 partial + remaining.

# /da:three - Three.js 3D + Game UI/UX Pipeline (v3.0)

## MengTo Reference Skills (on-demand — 필요 시에만 Read)
> 경로: `~/.claude/plugin/agent-skills/skills/<name>/SKILL.md`
- `mengto-threejs`: 씬/카메라/GLTF/성능 기본기
- `mengto-build-isometric-arpg`: 게임 루프/수직 슬라이스 아키텍처
- `mengto-design-action-combat`: 전투 타이밍/판정/보스 페이즈
- `mengto-build-threejs-enemy-systems`: 데이터 주도 적 아키타입
- `mengto-tune-enemy-ai`: 적 AI 상태머신/밸런싱
- `mengto-create-game-vfx`: 판독성+성능 안전 VFX
- `mengto-optimize-threejs-games`: draw call/텍스처 예산/적응 품질
- `mengto-test-playable-web-games`: 결정론적 fixture 게임 QA
- `mengto-ship-web-games`: 릴리스/스모크/롤백


## Purpose
Build 3D graphics, interactive experiences, and web-based games using Three.js ecosystem with integrated Game UI/UX pipeline and automatic AI asset generation. Supports vanilla Three.js and React Three Fiber (R3F) with 9 mengto-* knowledge packs + 12 game UI/UX reference documents covering HUD, menus, game feel, state machines, accessibility, and 7 genre-specific templates.

## Workflow
1. **Project Detection** - Check package.json for `three`, `@react-three/fiber`, `@react-three/drei`
2. **Skill Loading** - Read relevant skill files based on task (Three.js skills + game UI references)
3. **Asset Planning** - Derive required asset list from game concept (see Asset Generation Rules)
4. **Scene Setup** - Configure renderer, camera, scene, and resize handling
5. **Implementation + Asset Generation (PARALLEL) — MANDATORY**
   - 에셋 생성과 3D 코드 작성을 **반드시 병렬** 실행 (순차 실행 절대 금지)
   - **메인 스레드에서** `Skill('da:asset', '--game')` 호출 (Agent subagent 내 Skill() 호출 불가)
   - 실행 패턴 (2가지 중 택 1):
     - **패턴 A (권장)**: 메인 스레드에서 먼저 `Skill('da:asset', '--game')` 호출 -> 완료 후 3D 코드 작성
     - **패턴 B (병렬)**: background Agent로 3D 코드 작성, 메인 스레드에서 `Skill('da:asset', '--game')` 호출
   - **주의**: Skill() 도구는 메인 대화에서만 사용 가능. Agent subagent 내에서 Skill() 호출 시 무시됨.
   - Wave B: Build 3D features using accurate Three.js API from skill references
   5.5. **Game UI Layer** - HUD overlay, menus, inventory, dialog
   5.6. **Game Feel** - Screen shake, hit stop, particles, camera FX
   5.7. **State Machine** - FSM, scene transitions, save/load
6. **Asset Integration** - Apply generated assets via TextureLoader/SpriteMaterial to game objects
7. **Optimization** - Apply performance patterns (instancing, LOD, disposal, 60fps target)
8. **Validation** - Verify with Context7 MCP for Three.js r160+ API accuracy

## Skill Loading Strategy
Do NOT load all packs at once. Load only what the task requires:

| User Request | Skills/Docs to Load |
|-------------|---------------|
| "Create a 3D scene" | mengto-threejs |
| "Apply material to a cube" | mengto-threejs + Context7 (materials/geometry) |
| "Load GLTF model" | mengto-threejs (GLTF 섹션) + Context7 (loaders/animation) |
| "Particle/shader effects" | mengto-create-game-vfx + Context7 (shaders/postprocessing) |
| "Click interaction" | Context7 (raycaster/pointer events) |
| "Add lighting/shadows" | mengto-threejs + Context7 (lighting) |
| "Build a complete game" | mengto-build-isometric-arpg + task-relevant mengto packs |
| "Add HP bar / HUD" | game-ui-patterns.md + genre-ui/{genre}.md |
| "Game feel / juice" | game-feel.md |
| "Menu / pause / save" | game-state-machine.md + game-ui-patterns.md |
| "Accessibility / colorblind" | game-accessibility.md |

## Supported Project Types
- 3D Portfolio / Landing Page
- Interactive Visualization (data, product configurator)
- Web-based Games (casual, puzzle, simulation)
- Particle Effects / Animation
- 3D Editor / Tools
- WebXR Experience (Experimental)

## Technology Support
| Tech | Level | Notes |
|------|-------|-------|
| Three.js (Vanilla) | Full | mengto-threejs + game packs direct |
| React Three Fiber | Full | Context7 for latest API |
| drei (R3F helpers) | Full | Context7 integration |
| rapier (physics) | Supported | Context7 + agent knowledge |
| postprocessing | Full | Context7 supplement |
| GLTF/GLB | Full | mengto-threejs pack |
| WebXR | Experimental | No dedicated skill, Context7 supplement |
| Zustand (State) | Full | game-state-machine.md FSM pattern |
| gsap (Animation) | Supported | game-feel.md juice effects |
| Gamepad API | Full | game-accessibility.md input remap |
| tsParticles | Supported | game-feel.md particle burst |

## Asset Generation Rules (MANDATORY)

게임 개발 시 AI 에셋 자동 생성은 필수. placeholder Box/Sphere/단색 대신 생성된 에셋을 반드시 사용.

### Rule 1: 에셋 생성 필수
- Workflow Step 3에서 게임 컨셉 기반 에셋 목록을 먼저 도출:
  - 캐릭터 스프라이트 (주인공, 적, NPC)
  - 배경/환경 텍스처 (하늘, 땅, 벽)
  - 오브젝트 텍스처 (아이템, 장애물, UI 요소)
  - 파티클/이펙트 텍스처
- NEVER use placeholder Box/Sphere/solid colors for final game objects

### Rule 2: 내장 Gemini 키 자동 활용 (Zero Config)
- 별도 API 키 설정 불필요 (빌드 시 XOR 임베딩된 키 자동 사용)
- 음성 인식/이미지 분석과 동일한 키 경로 (get_gemini_key)
- IMAGE_GEN_PROVIDER 미설정 시 Gemini 자동 fallback
- 모델 자동 선택:
  - 캐릭터/주요 오브젝트: gemini-3.1-flash-image-preview (고품질)
  - 타일셋/패턴/파티클: gemini-2.5-flash-image (경량)

### Rule 3: 배경 제거 (독립 오브젝트 필수)
- 캐릭터, 아이템 등 독립 오브젝트 에셋은 배경 투명 필수
- 3-Stage Fallback Chain:
  1. Prompt 레벨: "solid white background" 명시
  2. ImageMagick: `convert -fuzz 10% -transparent white`
  3. rembg: `python3 -m rembg` (설치되어 있을 때만)

### Rule 4: 병렬 처리 전략
- **메인 스레드에서** `Skill('da:asset', '--game')` 호출 필수 (Agent subagent 내 Skill() 불가)
- 게임 코드는 background Agent로 병렬 작성하거나, 에셋 생성 후 순차 작성
- Wave 구조:
  - Wave 1: 에셋 목록 도출 + Scene 기본 구조 코드
  - Wave 2: 메인 스레드에서 `Skill('da:asset', '--game')` 실행 | background Agent로 게임 로직 구현
  - Wave 3: 생성된 에셋 적용 (TextureLoader) + 최적화

### Rule 5: 에셋-코드 바인딩
- 생성된 에셋 저장 경로: `public/textures/generated/`
- Three.js 자동 로드 패턴:
  - Sprite 캐릭터: `new SpriteMaterial({ map: new TextureLoader().load(path) })`
  - 배경/타일: `new MeshBasicMaterial({ map: new TextureLoader().load(path) })`
  - 3D 오브젝트: `new MeshStandardMaterial({ map: new TextureLoader().load(path) })`
- `asset-manifest.json` 경로를 코드에 자동 반영

### Rule 6: 장르별 최소 에셋 세트
| 장르 | 최소 에셋 |
|------|----------|
| 플랫포머 | 캐릭터(1), 적(1), 배경(1), 타일(2), 아이템(1) |
| 슈팅 | 플레이어(1), 적(2), 총알(1), 배경(1), 폭발(1) |
| 퍼즐 | 블록/피스(3+), 배경(1), UI(2) |
| RPG | 캐릭터(1), 적(2), 맵타일(3), NPC(1), 아이템(2) |
| 캐주얼 | 메인 오브젝트(1), 장애물(2), 배경(1), UI(1) |

### Rule 7: Graceful Degradation
- da:asset 실패 또는 API 키 없음 시:
  - 게임 코드는 색상 placeholder로 정상 생성
  - 콘솔 경고: "Asset generation skipped. Run /da:asset --game to add assets later."
  - 게임 개발 파이프라인을 절대 중단하지 않음

## Core Systems

### 3D Engine (Phase 1-5)
mengto-threejs pack (scene/camera/GLTF/performance 기본기) + 8 mengto game packs (combat, enemy systems, AI tuning, VFX, optimization, QA, shipping). 세부 API는 Context7 Three.js 문서로 보강.

### Game UI/UX (Phase 5.5-5.7)
| Reference | Coverage |
|-----------|----------|
| `game-ui-patterns.md` | HUD (HP/minimap/score/cooldown/damage), menus, inventory, dialog, z-layer management |
| `game-feel.md` | Screen shake, hit stop, hit flash, particles, camera FX, squash & stretch, perf tiers |
| `game-state-machine.md` | Zustand FSM, scene transitions (fade/slide/dissolve), save/load, game loop integration |
| `game-design-tokens.md` | Rarity tiers (5), combat colors (8), UI panels, typography, icon sizes |
| `game-accessibility.md` | Color blind modes (3), difficulty scaling, subtitles, input remap, motion sensitivity |
| `genre-ui/*.md` (x7) | Platformer, RPG, Puzzle, Arcade, Idle, Card, Trivia |

### Genre Auto-Detection
When building a game, detect genre from PLAN.md or user prompt and auto-load the matching `genre-ui/{genre}.md` template. Fallback: load `game-ui-patterns.md` as universal reference.

## Deliverables
- Production-ready Three.js / R3F code with TypeScript strict mode
- Proper resource cleanup (dispose geometry, materials, textures)
- Responsive canvas with resize handling
- 60fps performance-optimized rendering
- Game UI overlay (HUD + menus) matching genre template
- Game feel effects (juice) appropriate to genre
- FSM-based state management with save/load support
- WCAG 2.1 game accessibility (color blind, motion, input remap)
- AI-generated game assets in `public/textures/generated/`
- `asset-manifest.json` with generated asset metadata
- Background-removed character/object sprites (transparent PNG)
