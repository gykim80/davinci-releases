---
name: idea
description: "Interactive requirements discovery with Brainstorming Mode and Deep Research capabilities. SaaS/business signal auto-detection triggers PRD generation."
agent: cto-lead
agents: [senior-architect, ux-designer, deep-research-agent, market-researcher]
davinci-phase: null
allowed-tools: [Write, Edit, Read, Bash, Glob, Grep, Task, AskUserQuestion, WebSearch, WebFetch]
next-skill: plan
skill-type: flexible
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 생성자: 자기 검증은 사전 점검일 뿐이다. 최종 판정은 독립 verify 노드가 낸다. 미완료 시 partial + remaining.

## Tool Parameter Rules -> See CLAUDE.md (ABSOLUTE)

# /da:idea - Interactive Requirements Discovery

ultrathink

## Extended Thinking Protocol
- **Explore**: Explore ideas through Socratic dialogue
- **Research**: Conduct latest information and competitive analysis
- **Synthesize**: Consolidate gathered information into requirements
- **Validate**: Verify feasibility and completeness

---

## INTEGRATED MODES

### Brainstorming Mode (Auto-Activated)
```yaml
Activation_Triggers:
  - Vague requests: "I want to build...", "Thinking about..."
  - Exploration keywords: brainstorm, explore, discuss, figure out
  - Uncertainty: "maybe", "possibly", "not sure"

Behavioral_Changes:
  - Socratic Dialogue: Exploratory questions that discover hidden requirements
  - Non-Presumptive: User decides direction without assumptions
  - Collaborative: Explore as a partner, not a director
  - Brief Generation: Consolidate into structured requirements document
```

### Deep Research Mode (--research Flag)
```yaml
Activation_Triggers:
  - "--research" or "--deep" flag
  - Market analysis requests
  - Competitive intelligence needs
  - Technology feasibility assessment

Research_Capabilities:
  Multi_Hop_Reasoning:
    - Entity expansion: Topic -> Related concepts -> Examples
    - Concept deepening: Overview -> Details -> Implementation
    - Temporal progression: Current -> Historical -> Future trends

  Adaptive_Depth:
    quick: 5-10 sources, 1 hop, ~2min
    standard: 10-20 sources, 3 hops, ~5min (default)
    deep: 20-40 sources, 4 hops, ~8min
    exhaustive: 40+ sources, 5 hops, ~10min

  Quality_Scoring:
    - Source credibility: 0.0-1.0
    - Coverage completeness tracking
    - Minimum threshold: 0.6, Target: 0.8
```

---

## Triggers
- Ambiguous project ideas requiring structured exploration
- Requirements discovery and specification development needs
- Concept validation and feasibility assessment requests
- Market research and competitive analysis scenarios
- Cross-session brainstorming and iterative refinement

## Usage
```
/da:idea [topic/idea] [--strategy systematic|agile|enterprise] [--depth quick|standard|deep|exhaustive] [--research] [--parallel] [--autonomous]
```

## Autonomous Mode (--autonomous)

```yaml
Autonomous_Mode:
  Activation: "--autonomous" flag in ARGUMENTS
  Trigger: da:super 메타 사이클에서 호출 시 사용

  Behavior:
    # Phase 1 (Discovery Loop) 완전 스킵 -- AskUserQuestion 절대 금지
    # Phase 2 (Research) 자동 실행 -- WebSearch로 경쟁사/시장 조사
    # Phase 3 (Synthesis) 자동 실행 -- 자체 판단으로 아이디어 도출
    # Phase 4 (Handoff) 자동 실행 -- 결과 반환

    1. Vision Memory 로드:
       Read(file_path="docs/.davinci-super-vision.md")

    2. 앱 코드 자체 분석:
       - CodeGraph: codegraph_explore로 주요 컴포넌트/기능 파악
       - 현재 기능 목록, 빠진 기능, 불완전한 기능 식별

    3. 경쟁사 자동 조사:
       - WebSearch: 경쟁사 최신 기능
       - Gap 분석: 경쟁사에 있는데 우리에 없는 기능
       - Opportunity: 경쟁사에도 없는 혁신 기회

    4. 창의적 아이디어 자체 도출 (5개):
       구조:
         1. 혁신 기능 1개 (경쟁사에 없는 킬러 피처)
         2. 경쟁사 gap 채우기 2개 (있는데 우리에 없는 것)
         3. 폴리시/UX 개선 2개 (기존 기능의 완성도 극대화)

       "결함 수정"이 아니라 "가치 창출"에 집중

    5. 자율 우선순위 결정:
       - Vision Memory의 Priority 순서 준수
       - Blacklist 확인 (거부된 아이디어 제외)
       - 결정 근거를 1줄로 기록

    Output: 5개 개선 아이디어 리스트 (간결한 리스트 형식)

  Forbidden_in_Autonomous:
    - AskUserQuestion 호출
    - 사용자 입력 대기
    - Discovery Loop (Phase 1)

  Active_in_Autonomous:
    - WebSearch (경쟁사/시장 조사)
    - CodeGraph (코드 분석)
    - WebFetch(공식 문서) (프레임워크 문서)
    - Vision Memory 참조
    - 자체 판단 + 결정
```

---

## Behavioral Flow

### Phase 0: Mode Detection

```yaml
Mode_Detection:
  if "--autonomous" in ARGUMENTS:
    -> Skip Phase 1 entirely
    -> Jump to Phase 2 (Research) with autonomous context
    -> All decisions are self-made (no AskUserQuestion)
  else:
    -> Normal interactive mode (Phase 1 Discovery Loop)
```

### Phase 1: Discovery Loop (Brainstorming + Ambiguity Scoring)
**Skipped entirely in --autonomous mode**

```yaml
# OMC-Integrated Iterative Discovery Loop
# CRITICAL: All questions MUST be asked using the AskUserQuestion tool.
# NEVER ask questions as plain text/markdown.
# EXCEPTION: In --autonomous mode, AskUserQuestion is FORBIDDEN.

Question_Tool_Rule: |
  MANDATORY: Always use the AskUserQuestion tool when asking users questions.
  Forbidden: Ask questions as markdown text and wait for user response
  Required: AskUserQuestion(questions=[{question: "...", header: "...", options: [...], multiSelect: false}])

  AskUserQuestion usage rules:
    - header: Short label under 12 characters (e.g., "Goal", "Target Users", "Tech Stack", "Revenue Model")
    - question: Specific question (ends with question mark)
    - options: 2-4 choices (user can freely input via "Other")
    - multiSelect: true only for questions requiring multiple selections
    - Up to 4 questions can be bundled and sent at once (parallel questions)

Round_1: (Open exploration -- questions via AskUserQuestion dialog)
  1. Parse user's vague idea
  2. Ask 1-2 exploration questions via AskUserQuestion:
     - Core problem/goal (with options)
     - Target users (multiSelect: true)
  3. NO scoring yet (ensure free exploration)
  4. Brownfield_Detection:
     signals:
       - User input mentions existing code/files
       - Use of verbs like "modify", "improve", "refactor", "migrate"
     decision:
       any_signal -> is_brownfield = True (add context dimension evaluation)
       none -> is_brownfield = False

Round_2+: (Structured interview -- Ambiguity Scoring activated)
  LOOP:
    1. Score current dimensions using AmbiguityScorer formula:
       Greenfield: ambiguity = 1 - (goal * 0.40 + constraints * 0.30 + criteria * 0.30)
       Brownfield: ambiguity = 1 - (goal * 0.35 + constraints * 0.25 + criteria * 0.25 + context * 0.15)
    2. Display progress_table (Markdown table with dimension scores)
    3. If ambiguity <= 0.20: BREAK -> Phase 2/3/4
    4. If round >= 20: BREAK with warning
    5. Identify weakest dimension -> target next question
    6. Check challenge activation:
       - Round 4+: Contrarian ("What if the opposite were true?")
       - Round 6+: Simplifier ("What is the simplest version?")
       - Round 8+ AND ambiguity > 0.3: Ontologist ("What is this really?")
       - 3 rounds consecutive +/-0.05 stagnation: Ontologist (stall detection)
    7. If challenge: inject challenge prompt via AskUserQuestion
    8. Else: Ask targeted question for weakest dimension via AskUserQuestion (options required)
    9. Update dimensions based on user response
    10. round += 1

  Dimension_Scoring_Guide:
    goal: Goal clarity (what to build, why it's needed)
    constraints: Constraints/boundaries (tech stack, budget, timeline, regulations)
    criteria: Success criteria (KPIs, completion conditions, acceptance criteria)
    context: Existing system understanding (brownfield only -- current architecture, dependencies)

  Output: Clarity Breakdown Table + Qualified requirements
```

### Phase 2: Research (Always Executed)
```yaml
# 시장분석은 항상 실행. --research 플래그는 depth를 deep 이상으로 올림.
# --research 없이도 standard depth로 시장/경쟁사 조사 수행.

Depth_Selection:
  if "--research" or "--deep" in ARGUMENTS:
    depth: deep  # 20-40 sources, 4 hops
  else:
    depth: standard  # 10-20 sources, 3 hops

1. Plan_Research:
   - Decompose query into sub-questions
   - Identify parallelization opportunities
   - Set investigation milestones
   - Market/competitor research questions auto-included

2. Execute_Research:
   - WebSearch: Web search and extraction
   - WebFetch(공식 문서): Framework documentation
   - URL content: Defuddle CLI -> WebFetch (fallback)
   - Parallel-first: Batch similar queries
   - Multi-hop: Follow entity chains
   - Market_Research (always):
     - Market size estimation (TAM/SAM/SOM)
     - Competitor identification and comparison
     - Pricing/cost structure analysis
     - Trend and growth signals

3. Validate_Findings:
   - Verify evidence chains
   - Check source credibility
   - Resolve contradictions
   - Note confidence levels
```

### Phase 3: Synthesis
```yaml
1. Consolidate_Insights:
   - Merge discovery and research findings
   - Identify patterns and themes
   - Resolve conflicts

2. Generate_Requirements:
   - Functional requirements
   - Non-functional requirements
   - User stories / acceptance criteria
   - Open questions for user

3. Extract_Domain_Terms:
   - 요구사항에서 도메인 고유 용어 후보를 추출 (비즈니스 엔티티, 상태, 액션)
   - 일반 기술 용어(API, DB, component 등)는 제외
   - 용어당: 영문 Term + 한국어 정의 1줄
   - handoff.domain_terms[] 배열로 da:plan에 전달
```

### Phase 4: Handoff (HARD STOP)
```yaml
1. Create_Brief:
   - Structured requirements document (Requirements Brief or PRD)
   - Priority ranking
   - Risk assessment
   - Domain Terminology 테이블 포함
   - Save to: docs/ideas/ or docs/prd/ directory
   - handoff JSON에 domain_terms[] 배열 포함 (Phase 3에서 추출한 용어 목록)

2. Persistence:
   - CodeGraph MCP: Save session context
   - Cross-session continuity enabled

3. HARD_STOP: true
   Terminal_Output: |
     ---
     아이디어 브리프 완성!

     다음 단계를 선택하세요:
       -> /da:plan    (아키텍처 설계)
       -> /da:design  (UI/UX 디자인)
       -> /da:dev     (직접 구현)
     ---

   TERMINATE:
     - 이 메시지 출력 후 어떤 추가 행동도 하지 않음
     - 코드 생성 금지
     - 프로젝트 scaffolding 금지
     - npm/pnpm/bun 명령어 실행 금지
     - Write tool로 코드 파일 생성 금지
```

---

## PERSONA ACTIVATION

### Deep Research Agent (Primary for --research)
```yaml
Role: Autonomous web research and evidence synthesis
Capabilities:
  - Multi-source verification
  - Confidence scoring
  - Citation management
  - Contradiction resolution
```

### Requirements Analyst
```yaml
Role: Requirements elicitation and specification
Focus:
  - User story generation
  - Acceptance criteria definition
  - Requirement prioritization
```

### Architect (Feasibility Assessment)
```yaml
Role: Technical feasibility evaluation
Focus:
  - Technology stack assessment
  - Integration complexity analysis
  - Scalability considerations
```

---

## Output Format

### Requirements Brief
```markdown
# [Project Name] Requirements Brief

## Executive Summary
[1-2 sentence overview]

## User Goals
- [Goal 1]
- [Goal 2]

## Functional Requirements
| ID | Requirement | Priority | Notes |
|----|-------------|----------|-------|
| FR-01 | ... | High | ... |

## Non-Functional Requirements
- Performance: ...
- Security: ...
- Scalability: ...

## User Stories
- As a [user], I want [feature] so that [benefit]

## Research Findings (always included)
### Market Analysis
### Competitive Landscape
### Technology Assessment

## Clarity Breakdown
| Dimension | Score | Status |
|-----------|-------|--------|
| Goal Clarity | 0.90 | Clear |
| Constraint Clarity | 0.85 | Clear |
| Success Criteria | 0.80 | Clear |
| **Ambiguity Score** | **0.14** | **Ready (< 0.20)** |

## Domain Terminology
| Term | 한국어 | 정의 |
|------|--------|------|
| Order | 주문 | 고객이 상품/서비스를 요청하는 단위 |

## Confidence Level: [High/Medium/Low]
## Sources: [Citations if research conducted]
```

---

## Boundaries

**Will:**
- Transform vague ideas into concrete specifications through systematic exploration
- Conduct deep research with evidence-based findings when requested
- Maintain cross-session context for iterative refinement
- Provide market analysis and competitive intelligence

**Will Not (ABSOLUTE):**
- Make implementation decisions without proper requirements discovery
- Override user vision with prescriptive solutions
- Skip research validation for complex queries
- Proceed to design/implementation (use `/da:plan` or `/da:design` next)
- Generate any code, scaffolding, or project structure
- Select or apply presets, frameworks, or templates
- Execute build/dev/install commands

---

## CRITICAL BOUNDARIES (ABSOLUTE)

**STOP AFTER REQUIREMENTS DISCOVERY -- 예외 없음**

This command produces a REQUIREMENTS SPECIFICATION / PRD ONLY.

```yaml
ABSOLUTE_STOP_RULE:
  - 이 스킬은 Requirements Brief/PRD 생성 후 즉시 종료합니다.
  - 프리셋 선택, 프로젝트 scaffolding, 코드 생성 절대 금지
  - "만들자", "개발하자" 등 구현 요청이 있어도 요구사항만 정리
  - 기술 스택 선택/적용 금지 (추천만 가능)
  - 디렉토리 생성, 파일 생성, npm/pnpm/bun init 절대 금지
  - Write tool로 코드 파일(.tsx, .ts, .js, .css 등) 생성 금지
  - 완료 후 다음 단계 안내만 출력하고 TERMINATE
```

**Next Step**: After idea completes, use `/da:plan` for system architecture, or `/da:design` for direct UI/UX implementation.

---

## Implementation Intent Guard (구현 의도 차단)

```yaml
Implementation_Intent_Guard:
  trigger_keywords:
    ko: ["만들자", "만들어줘", "개발하자", "구현해줘", "코딩하자", "바로 시작", "빌드하자"]
    en: ["build it", "create it", "code it", "start coding", "implement it", "let's build"]

  action_when_detected: |
    구현 의도가 감지되었지만, /da:idea는 요구사항 정리 전용입니다.
    먼저 아이디어를 체계적으로 정리하고,
    구현은 완료 후 /da:plan -> /da:dev 순서로 진행합니다.

  behavior:
    - 구현 키워드를 요구사항 탐색 의도로 재해석
    - Discovery Loop (Phase 1) 정상 진행
    - Phase 4 완료 후 다음 단계 안내만 출력
    - 절대 코드 생성/프로젝트 생성으로 넘어가지 않음
```

---

## Business/SaaS Signal Auto-Manifestation

### Signal Detection
When da:idea executes, it analyzes the user prompt to auto-detect business/SaaS intent.

**Business signal keywords:**
- Korean: SaaS, service, platform, revenue, subscription, payment, user acquisition, marketing, B2B, B2C, MVP, PMF, startup, launch, customer, pricing
- English: SaaS, service, platform, revenue, subscription, payment, marketing, startup, launch, monetize, customer, pricing
- Patterns: "I want to build ~", "~ service planning", "I want to make money with ~", "~ business model"

**Detection logic:**
```yaml
Signal_Detection:
  # 시장분석은 항상 수행. 비즈니스 키워드 유무와 관계없이 활성화.
  input: Full user prompt text
  method: Always active (keyword detection은 PRD depth 조절에만 사용)
  threshold: REMOVED — always activated
  result: is_business_signal = True (always)
```

### Business Mode Behavior (When Signal Detected)
Naturally weave business questions into the existing Brainstorming flow.
**All questions are performed via AskUserQuestion dialog (plain text questions forbidden).**

**Round 1-2 (Existing + Business Extension):**
- Ask core goal, target users, tech constraints via AskUserQuestion
- Business additional questions: revenue model, target customer willingness to pay, competitors (with options)

**Round 3-4 (Existing + Business Deep Dive):**
- Ask feature priorities, tech stack via AskUserQuestion
- Business additional questions: API cost structure, MVP paid features, marketing channels (with options)

**Synthesis Stage (When Business Detected):**
- Use 9-section PRD format instead of existing Requirements Brief
- Auto-research market data, competitors, API pricing via WebSearch
- Output: `docs/prd/PRD-{name}-{date}.md`

**PRD 9-Section Structure:**
```markdown
# [Service Name] PRD (Product Requirements Document)

## 1. Overview
Service overview, vision, mission statement

## 2. Problem & Solution
Problem definition, proposed solution, Value Proposition

## 3. Target Audience
Target user personas, ICP (Ideal Customer Profile), user segments

## 4. Market Research (WebSearch auto-research)
Market size (TAM/SAM/SOM), trends, growth rate

## 5. Competitor Analysis (WebSearch auto-research)
Competitor comparison table, differentiators, positioning

## 6. API & Pricing Research (WebSearch auto-research)
External API cost structure, estimated infrastructure costs, monthly operating cost estimates

## 7. Revenue Model
Revenue structure (subscription/transaction fees/premium etc.), pricing policy, unit economics

## 8. MVP Scope
Minimum feature definition, launch criteria, Phase 1/2/3 roadmap

## 9. Tech Stack Recommendation
Tech stack proposal and rationale (see WebFetch(공식 문서))
```

### Output Format Selection
```yaml
# 시장분석은 항상 수행되며, 출력 형식은 비즈니스 키워드 밀도에 따라 결정
Output_Format:
  if business_keyword_count >= 2 or business_pattern_matched:
    format: "9-Section PRD"  # 풀 PRD with revenue model, pricing
    save_to: "docs/prd/PRD-{name}-{date}.md"
  else:
    format: "Requirements Brief + Market Section"  # 기존 Brief에 시장분석 섹션 추가
    save_to: "docs/ideas/IDEA-{name}-{date}.md"
    additional_sections:
      - "## Market Analysis" (TAM/SAM/SOM, competitors, trends)
      - "## Competitive Landscape" (comparison table)
```
