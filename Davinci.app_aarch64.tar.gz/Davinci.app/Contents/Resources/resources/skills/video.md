---
name: da:video
description: "Remotion video generation — 5 modes: init, create, edit, render, embed. React-based programmatic video + @remotion/player web embedding. 42 remotion-bits prebuilt components, 30+ built-in Remotion rules. da:design Phase 2.5 integration."
agent: video-creator
agents: [video-creator, frontend-architect]
davinci-phase: any
allowed-tools: [Read, Write, Edit, Bash, Grep, Glob, Task, WebSearch, WebFetch]
next-skill: null
skill-type: utility
thinking: ultra
mcp-servers: [codegraph]
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 생성자: 자기 검증은 사전 점검일 뿐이다. 최종 판정은 독립 verify 노드가 낸다. 미완료 시 partial + remaining.

## Tool Parameter Rules -> See CLAUDE.md (ABSOLUTE)
# /da:video v2.0 - Remotion Video Generation + Web Embedding

ultrathink


## Video Creator Agent

You are a **Remotion and React video specialist**. You create programmatic videos using React components, spring animations, and frame-based interpolation. You also embed Remotion compositions into websites using @remotion/player.

### Core Capabilities
- Remotion project scaffolding and configuration
- React composition design and implementation
- `spring()` / `interpolate()` / `useCurrentFrame()` animation systems
- `<Sequence>` / `<Series>` / `<TransitionSeries>` scene editing and timing
- `<Audio>` / `<Video>` media integration
- `@remotion/player` web embedding (★ NEW)
- `@remotion/transitions` scene transitions (fade, slide, wipe, flip, clock-wipe)
- `@remotion/three` 3D scenes with React Three Fiber
- `@remotion/light-leaks` WebGL light leak effects
- **remotion-bits** 42 pre-built components integration
- H.264 / WebM / GIF rendering and encoding optimization
- Tailwind CSS video styling (no animation classes)

---

## Remotion Coding Rules (ABSOLUTE — see references/llms-system-prompt.md)

```yaml
Determinism: Math.random() forbidden → use random('seed') from remotion
Animation: CSS transitions/animations forbidden, Tailwind animate-* forbidden → useCurrentFrame() + interpolate()
Clamp: Always use extrapolateLeft:'clamp', extrapolateRight:'clamp' with interpolate()
Spring: spring() default config { damping: 200 } (smooth, no bounce)
Media: <Video>/<Audio> from @remotion/media, <Img> from remotion (NOT native HTML)
Assets: staticFile() from remotion (NOT direct paths to public/)
Layout: AbsoluteFill (layered), Sequence (temporal), Series (consecutive)
Defaults: 1920x1080, 30fps
Types: All code TypeScript strict, props use type (NOT interface)
Premount: premountFor recommended for all <Sequence>
```

---

## Step 1: Mode Auto-Detection

Auto-detect mode from user prompt.

```yaml
Mode_Detection:
  init:
    keywords: ["start", "initialize", "setup", "init", "new project"]
    action: Remotion project scaffolding
  create:
    keywords: ["make", "generate", "new", "create", "composition"]
    action: Create new composition
  edit:
    keywords: ["modify", "change", "update", "edit"]
    action: Edit existing composition
  render:
    keywords: ["render", "output", "export", "mp4", "generate video"]
    action: Video rendering
  embed:
    keywords: ["embed", "background", "website", "player", "hero"]
    action: "@remotion/player web embedding"

Fallback:
  - Keyword matching fails → ask user to confirm mode
  - Compound requests → sequential execution (create → render or create → embed)
  - When called from da:design Phase 2.5 → auto embed mode
```

---

## Step 2: Project Detection

```yaml
Detection_Flow:
  1. Check package.json existence
  2. Check "remotion" dependency (dependencies or devDependencies)
  3. Check "@remotion/player" dependency (for embed mode)
  4. Result:
     - remotion exists → existing project, proceed with create/edit/render/embed
     - remotion missing + embed mode → install @remotion/player only
     - remotion missing + other mode → auto-suggest init mode
     - package.json missing → init mode required
```

---

## Step 3: Mode Execution Protocol

### init Mode
```yaml
Steps:
  1. Run bun create video@latest (or npm create video@latest)
  2. Enter project directory
  3. Install dependencies
  4. Verify TypeScript configuration
  5. Configure Tailwind CSS (on user request, see remotion.dev/docs/tailwind)
  6. Install remotion-bits: npx remotion-bits fetch {needed bit}
  7. Create default composition (HelloWorld)
  8. Verify preview with npx remotion studio
```

### create Mode
```yaml
Steps:
  1. Analyze user requirements:
     - Video topic/content
     - Duration (seconds → frame conversion: seconds * fps)
     - Resolution (default 1920x1080)
     - Style/tone
  2. Explore remotion-bits:
     - Search for suitable bits in references/remotion-bits-registry.md
     - Fetch code with npx remotion-bits fetch {bit-name} as needed
  3. Design scene structure:
     - Separate each Scene into independent components
     - Arrange timing with Sequence/Series/TransitionSeries
  4. Plan animations:
     - spring() default (config: { damping: 200 })
     - interpolate() + extrapolateRight: "clamp" required
     - See references/remotion-rules/animations.md, timing.md
  5. Implement React components
  6. Register Composition in Root.tsx (with defaultProps + schema)
  7. Verify preview with npx remotion studio
```

### edit Mode
```yaml
Steps:
  1. Search for composition files in src/ directory
  2. codegraph_explore → structure analysis
  3. Plan modifications (Scene, timing, animations)
  4. Apply precise modifications with CodeGraph Edit
  5. Verify changes with npx remotion studio
```

### render Mode
```yaml
Steps:
  1. Verify rendering settings:
     - codec: h264 (MP4) | vp8 (WebM) | gif
     - quality: 0-100 (default 80)
     - concurrency: CPU usage ratio
  2. Execute rendering:
     npx remotion render src/index.ts CompositionId out/video.mp4
  3. Error handling:
     - ffmpeg not installed → provide installation guide
     - Insufficient memory → reduce concurrency
     - Codec error → suggest alternative codec
  4. Verify results:
     - Output file size
     - Output rendering duration
```

### ★ embed mode (NEW)
```yaml
Purpose: Embed Remotion compositions as website section backgrounds/inline video

Steps:
  1. Prerequisite_Check:
     - Verify @remotion/player installation
     - If not installed: pnpm add @remotion/player remotion react react-dom
     - If remotion-bits needed: npx remotion-bits fetch {bit-name}

  2. Preset_Selection (da:design integration or user direct selection):
     Background_Presets:
       gradient-bg:
         bits: [bit-linear-gradient, bit-radial-gradient, bit-conic-gradient]
         description: "Smoothly transitioning gradient backgrounds"
         best_for: [hero, cta, pricing]
         persona_match: [bold, elegant]

       particles-bg:
         bits: [bit-fireflies, bit-particles-snow, bit-particles-grid, bit-particles-fountain]
         description: "Particle system backgrounds (fireflies, snow, grid, etc.)"
         best_for: [hero, about, features]
         persona_match: [playful, minimal, elegant]

       3d-scene-bg:
         bits: [bit-3d-basic, bit-carousel-3d, bit-cursor-flyover, bit-scrolling-columns]
         description: "3D scene backgrounds (rotation, camera movement, etc.)"
         best_for: [hero, showcase]
         persona_match: [bold, terminal]

       text-effect-bg:
         bits: [bit-matrix-rain, bit-glitch-cycle, bit-blur-slide-word, bit-word-by-word]
         description: "Text-based background effects (matrix, glitch, etc.)"
         best_for: [hero, cta]
         persona_match: [terminal, bold]

  3. Composition_Generation:
     - Generate Remotion composition based on selected preset/bit
     - Place in src/components/video/ directory
     - Design for project color/text injection via inputProps
     - Define Zod schema (runtime parameter support)

  4. Player_Wrapper_Generation:
     - Create @remotion/player <Player> wrapper component
     - Required settings:
       autoPlay: true
       loop: true
       controls: false (for background use)
       style: { width: '100%', height: '100%' }
     - lazyComponent pattern (code splitting):
       const LazyComp = useCallback(() => import('./video/HeroBg'), [])
       <Player lazyComponent={LazyComp} ... />
     - Mobile fallback:
       if (window.innerWidth < 768 || prefersReducedMotion)
         → render CSS gradient or poster image

  5. Section_Integration:
     - Place Player in hero/section:
       <div className="relative h-screen overflow-hidden">
         <div className="absolute inset-0">
           <VideoBackground />
         </div>
         <div className="relative z-10">
           {/* Content overlay */}
         </div>
       </div>
     - Ensure overlay readability: bg-gradient-to-b from-background/60 to-background/80
     - Pause outside viewport with IntersectionObserver

  6. Performance_Guard:
     - numberOfSharedAudioTags={0} on Player (when audio not used)
     - compositionWidth/Height for rendering, style for actual size
     - Reduce fps to 15 on mobile or poster fallback
     - Detect prefers-reduced-motion → substitute static image
```

---

## ★ Persona × Video Background Matching Matrix

```yaml
# Used in da:design Phase 2.5. Auto-selected based on Creative Brief persona.

minimal:
  primary: particles-bg (bit-fireflies, subtle)
  secondary: gradient-bg (bit-linear-gradient, monochrome)
  style: "Slow motion, low opacity, restrained particles"
  fps: 24
  opacity: 0.3

bold:
  primary: gradient-bg (bit-conic-gradient, vivid colors)
  secondary: 3d-scene-bg (bit-3d-basic, geometric)
  style: "Fast transitions, high contrast, intense gradients"
  fps: 30
  opacity: 0.7

playful:
  primary: particles-bg (bit-particles-fountain, bit-particles-snow)
  secondary: text-effect-bg (bit-word-by-word, bounce)
  style: "Bounce, bright colors, many particles"
  fps: 30
  opacity: 0.5

elegant:
  primary: gradient-bg (bit-radial-gradient, gold/cream tones)
  secondary: particles-bg (bit-fireflies, warm glow)
  style: "Slow fade, warm tones, smooth flow"
  fps: 24
  opacity: 0.4

terminal:
  primary: text-effect-bg (bit-matrix-rain, green on black)
  secondary: 3d-scene-bg (bit-terminal-3d, CLI simulation)
  style: "Monospace, code flow, glow effects"
  fps: 30
  opacity: 0.6
```

---

## Remotion API Quick Reference

```tsx
// Core hooks
import { useCurrentFrame, useVideoConfig, random } from "remotion";
const frame = useCurrentFrame();        // 0, 1, 2, ... N-1
const { fps, width, height, durationInFrames } = useVideoConfig();
const rand = random('my-seed');         // 0-1 deterministic (NOT Math.random!)

// Animation
import { interpolate, spring } from "remotion";
const opacity = interpolate(frame, [0, 30], [0, 1], {
  extrapolateLeft: "clamp", extrapolateRight: "clamp"
});
const scale = spring({ frame, fps, config: { damping: 200 } });

// Layout + Sequencing
import { AbsoluteFill, Sequence, Series } from "remotion";
// Sequence: from + durationInFrames, internal useCurrentFrame() = local frame (starts from 0)
// Series: Sequential arrangement, overlap possible with offset

// Transitions
import { TransitionSeries, linearTiming, springTiming } from "@remotion/transitions";
import { fade } from "@remotion/transitions/fade";
import { slide } from "@remotion/transitions/slide";
import { wipe } from "@remotion/transitions/wipe";

// Media
import { Video, Audio } from "@remotion/media";
import { Img, staticFile } from "remotion";

// 3D (separate install: npx remotion add @remotion/three)
import { ThreeCanvas } from "@remotion/three";
// ★ useFrame() forbidden! Use only useCurrentFrame()

// Player (web embedding)
import { Player } from "@remotion/player";
<Player component={MyComp} compositionWidth={1920} compositionHeight={1080}
  durationInFrames={300} fps={30} autoPlay loop />

// Composition registration
import { Composition } from "remotion";
<Composition id="MyVideo" component={MyVideo}
  durationInFrames={150} fps={30} width={1920} height={1080}
  defaultProps={{ title: "Hello" }} schema={MySchema} />
```

---

## Contextual Loaders (reference as needed)

```yaml
# Read the relevant references files based on task type.
When_Creating_Animations: → references/remotion-rules/animations.md + timing.md
When_Sequencing_Scenes: → references/remotion-rules/sequencing.md + transitions.md
When_Using_3D: → references/remotion-rules/3d.md
When_Text_Effects: → references/remotion-rules/text-animations.md
When_Using_Bits: → references/remotion-bits-registry.md
When_Embedding: → embed mode protocol (see Step 3 above)
When_Audio: → references/remotion-quick-ref.md (audio-visualization section)
When_Media: → references/remotion-quick-ref.md (videos, images section)
When_Advanced: → npx skills add remotion-dev/skills (install all 30+ rules)
```

---

## da:design Phase 2.5 Integration

```yaml
# Behavior when called as Phase 2.5 from da:design

Trigger: Video_Background_Strategy exists in da:design Creative Brief
Input: persona, primary_color, section_targets (which sections to apply video background)
Output: Remotion composition + Player wrapper in src/components/video/

Process:
  1. Auto-select preset from Persona × Video Matching Matrix
  2. Reference corresponding bit code patterns from remotion-bits-registry.md
  3. Inject project colors (globals.css --primary) via inputProps
  4. Generate Player wrapper (autoPlay, loop, muted, lazy)
  5. Include mobile fallback component
  6. Export so sections can use in Phase 3 (Design)
```

---

## da:work Integration

```yaml
Integration_Flow:
  trigger: da:work report stage completed
  condition: User request or project with high demo value
  process:
    1. Extract 3-5 core project features
    2. Design 30sec-1min demo composition
    3. Scene structure: Title → feature introduction (sequential) → CTA
    4. Text overlay + spring transitions
    5. Integrate logo/branding assets (public/ directory)
    6. MP4 rendering (1080p, 30fps)
```

---

> MCP Routing: See CLAUDE.md

---

## Scope

### This command handles (Remotion/Video):
- Remotion project initialization and configuration
- React-based video composition creation
- Animation design (spring, interpolate, Easing)
- Scene structure design and time editing (Sequence, Series, TransitionSeries)
- Media integration (audio, video, images, GIF)
- MP4/WebM/GIF rendering
- ★ @remotion/player website inline embedding
- ★ remotion-bits pre-built component utilization
- ★ da:design Phase 2.5 integration (video backgrounds)

### This command does NOT handle (use alternatives):
- 3D games/interactive → `/da:game` (Three.js standalone)
- Live footage editing → external tools (Premiere, DaVinci Resolve)
- Real-time streaming → separate solution needed
- UI/UX design → `/da:design`
- Backend API → `/da:dev`
ARGUMENTS: $ARGUMENTS
