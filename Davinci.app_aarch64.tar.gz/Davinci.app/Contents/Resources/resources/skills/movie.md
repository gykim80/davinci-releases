---
name: movie
description: "Seedance 영상 생성 — Seedance 2.0 프롬프트 엔지니어링 + BytePlus ARK API 영상 생성. Settings > Video의 모델/키 사용. '영상 만들어줘', 'video 생성', 'Seedance' 요청 시 사용."
agent: asset-gen-artist
agents: [asset-gen-artist]
davinci-phase: null
allowed-tools: [Bash, Read, Write, AskUserQuestion]
next-skill: null
skill-type: utility
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 생성자: 자기 검증은 사전 점검일 뿐이다. 최종 판정은 독립 verify 노드가 낸다. 미완료 시 partial + remaining.

## Tool Parameter Rules → See CLAUDE.md (ABSOLUTE)

# /da:movie — Seedance 영상 생성 (프롬프트 엔지니어링 + BytePlus 생성)

사용자의 창작 요구를 받아 **Seedance 2.0 스타일의 구조화된 영상 프롬프트**를 설계하고,
Settings > Video 탭에서 설정한 BytePlus 모델로 **실제 영상을 생성**하여 로컬에 저장한다.

> 원본 프롬프트 방법론: songguoxs/seedance-prompt-skill (Seedance 2.0 视频提示词生成器) 포팅.

## Iron Law

> 영상 생성 결과는 반드시 `OK:/absolute/path.mp4 (NNN bytes)` 형식으로 출력한다.
>
> **절대 금지**: .env.local 파일 참조, 키 하드코딩.
> 이 스킬은 환경변수 `VIDEO_GEN_PROVIDER` / `VIDEO_GEN_MODEL` / `ARK_API_KEY`(또는 `BYTE_KEY`)만 사용한다.
> 키가 없으면 Settings > Video 탭에서 설정하도록 안내하고 중단한다.
>
> **프롬프트 언어**: Seedance는 중국어 프롬프트에 최적화되어 있다. 최종 영상 프롬프트는 중국어로 작성하고,
> 사용자에게 보여줄 때는 한국어 요약을 병기한다.

## 워크플로우

```yaml
Step_0: 환경 검증 (VIDEO_GEN_* env + API key)
Step_1: 요구사항 확인 (시간/비율/스타일 — 명확하면 생략)
Step_2: Seedance 프롬프트 엔지니어링 (아래 방법론 적용)
Step_3: BytePlus ARK API로 영상 생성 (비동기 task + polling)
Step_4: 결과 보고 (OK:경로 + 프롬프트 요약)
```

### Step 0: 환경 검증

```bash
PROVIDER="${VIDEO_GEN_PROVIDER:-byteplus}"
MODEL="${VIDEO_GEN_MODEL:-seedance-2.5}"
KEY="${ARK_API_KEY:-${BYTE_KEY:-}}"

if [ -z "$KEY" ]; then
  echo "FAIL: 영상 생성 API 키가 설정되지 않았습니다."
  echo "Settings > Video 탭에서 BytePlus API 키를 저장하세요."
  exit 1
fi
echo "Provider: $PROVIDER / Model: $MODEL"
```

### Step 1: 요구사항 확인

사용자 요청에서 아래 파라미터를 추출한다. 불명확하고 대화 맥락으로 추정 불가할 때만 AskUserQuestion 1회 사용:

1. **시간**: 4-15초 (기본 5초). >15초 요청 시 분할 생성 전략 적용 (아래 「초장편 전략」)
2. **비율**: 16:9(기본) / 9:16 / 1:1
3. **해상도**: 480p / 720p(기본) / 1080p
4. **스타일/분위기**: 요청에서 추론 (전문 용어는 어휘 라이브러리 참조)

## Step 2: Seedance 프롬프트 엔지니어링

### 기본 프롬프트 공식

```
(주체 묘사) + (동작 시퀀스) + (환경/광원) + (카메라 언어) + (스타일 키워드)
```

**예시 (중국어 프롬프트)**:
```
镜头跟随黑衣男子快速逃亡，后面一群人在追，镜头转为侧面跟拍，人物惊慌撞倒路边的水果摊爬起来继续逃，人群慌乱的声音。
```

### 시간戳 분镜法 (Timestamp Storyboard — 9초 이상 강력 권장)

긴 영상은 시간 구간별로 화면을 정밀 제어한다. 실전에서 가장 효과적인 고급 기법:

```
0-3秒：[화면 묘사 + 카메라 언어]
4-8秒：[화면 묘사 + 카메라 언어]
9-12秒：[화면 묘사 + 카메라 언어]
13-15秒：[화면 묘사 + 카메라 언어]
```

**예시 — 선협 전투 (15초)**:
```
15秒仙侠高燃战斗镜头，金红暖色调，0-3秒：低角度特写主角蓝袍衣摆被热浪吹得猎猎飘动，双手紧握雷纹巨剑，剑刃赤红电光持续爆闪；4-8秒：环绕摇镜快切，主角旋身挥剑，剑刃撕裂空气迸射红色冲击波；9-12秒：仰拍拉远定格慢放，主角跃起腾空，剑刃凝聚巨型雷光电弧劈向魔兵群；13-15秒：缓推特写主角落地收剑的姿态，音效收束为余音震颤与渐弱风声。
```

### 대사/음향 제어

- 대사는 따옴표로 감싸고 캐릭터와 감정을 표기: `台词（女主，冷漠）："晚了！"`
- 음향은 화면 묘사와 분리해 별도 줄로 기술: `音效：契约撕碎的声响，宾客窃窃私语声`
- Seedance는 음효/BGM을 자체 생성한다 — 원하는 사운드 분위기를 명시할 것

### 기술 파라미터 지정법

프롬프트 서두에 기술 규격을 선언하면 효과적:

```
[화폭비] 2.35:1/16:9/9:16 + [프레임] 24fps + [시간] X秒 + [톤/스타일 총강]
```

### 금지항 선언

프롬프트 말미에 원치 않는 요소를 선언해 흔한 문제를 회피:

```
禁止：任何文字、字幕、LOGO或水印
```

### 카메라 언어 어휘 라이브러리 (중국어)

| 분류 | 키워드 |
|------|--------|
| 숏 크기 | 大远景、远景、全景、中景、近景、特写、大特写 |
| 카메라 무빙 | 推镜头、拉镜头、摇镜头、移镜头、跟拍、环绕拍摄、航拍、手持跟拍、希区柯克变焦 |
| 앵글 | 平视、俯拍、仰拍、低角度、鸟瞰视角、鱼眼镜头、第一人称视角、主观视角 |
| 리듬 | 慢动作、快切、延时摄影、一镜到底、升格拍摄、硬切、卡点 |
| 포커스 | 浅景深、深景深、焦点转移、虚化背景、选择性对焦 |
| 특수 | 遮挡擦镜转场、无缝渐变转场、环绕摇镜快切特写、定格慢放 |

### 스타일 어휘 라이브러리 (중국어)

| 분류 | 키워드 |
|------|--------|
| 화면 질감 | 电影感、胶片质感、高清晰度、8K分辨率、HDR、RAW质感 |
| 영상 스타일 | 好莱坞大片、独立电影、纪录片、MV风格、广告大片、Vlog风格、2.35:1宽银幕 |
| 색조 분위기 | 暖色调、冷色调、高对比度、低饱和度、莫兰迪色系、赛博朋克霓虹、红金高饱和 |
| 예술 스타일 | 写实主义、超现实主义、极简主义、蒸汽波、赛博朋克、中国风水墨、3D国漫CG |
| 광원 효과 | 自然光、侧逆光、丁达尔效应、霓虹灯光、月光、黄金时段光线、体积光 |
| 애니 스타일 | 中国奇幻动画电影风格、超精细CG动画、日漫赛璐璐、3D渲染写实 |

### 장면 유형별 전략

- **전자상거래/광고**: 제품 360도 회전, 폭발 분해, 3D 렌더 특효, 브랜드 워딩
- **선협/판타지 드라마**: 시간戳 분镜 + 상세 특효 묘사 (법진, 에너지파, 파티클)
- **숏드라마/대사극**: 화면과 대사 분리 기술, 대사에 캐릭터·감정 표기, 정밀 시간 제어
- **과학 교육**: 4K 의학 CGI 스타일, 반투명 구조 시각화, 교육적 내레이션
- **MV/음악 카점**: 화폭비·프레임 지정, 숏별 분镜, 박자와 사운드 동기 강조

### @참조 시스템 (참고 소재가 있을 때)

즉몽(即梦) 플랫폼 수동 업로드용 프롬프트를 요청받은 경우 공식 명명을 사용:
- 이미지: `@图片1` ~ `@图片9` (≤9장) / 비디오: `@视频1` ~ `@视频3` / 오디오: `@音频1` ~ `@音频3`
- 각 소재의 용도를 프롬프트에 명시: `@图片1为首帧`, `参考@视频1的运镜效果`, `背景音乐参考@音频1`
- 「참고」(스타일/동작 차용)인지 「편집」(원본 수정)인지 구분해 기술
- ⚠️ 실사 인물 얼굴 소재는 업로드 불가 (플랫폼 자동 차단)

**활용 패턴 요약** (원본 스킬의 10대 능력):

| 패턴 | 프롬프트 공식 |
|------|--------------|
| 일관성 제어 | `[角色]@图片N + [动作/剧情] + [场景]@图片N + [运镜/光影]` |
| 무빙/동작 복각 | `参考@视频1的[运镜/动作/节奏] + [主体]@图片N + [场景]` |
| 특효/템플릿 복각 | `参考@视频1的[特效/转场] + 将[元素]替换为@图片N` |
| 스토리 창작/보완 | `[分镜脚本/图片描述] + [演绎方式] + [音效/台词要求]` |
| 영상 연장 | `将@视频1延长Xs + [新增内容描述]` (앞으로 연장: `向前延长Xs`) |
| 사운드 제어 | `[画面描述] + 音色/旁白参考@视频1 + "台词"` |
| 원테이크 | `一镜到底 + @图片1@图片2... + [连续场景] + 全程不要切镜头` |
| 영상 편집 | `将@视频1中的[A]换成@图片1` / `颠覆@视频1的剧情 + [新剧情]` |
| 음악 카점 | `@图片1...@图片N + 参考@视频1的画面节奏/卡点 + [风格]` |

### 프롬프트 품질 체크리스트

- [ ] 구체적이고 화면감 있는 묘사 (추상적 표현 금지)
- [ ] 동작·카메라에 시간 순서가 있는가
- [ ] 감정/분위기 묘사 포함 (최종 품질에 큰 영향)
- [ ] 대사는 따옴표 + 캐릭터/감정 표기, 음향은 별도 기술
- [ ] 정보 과잉 없이 핵심 강조 (프롬프트 길이 절제)

## Step 3: BytePlus ARK API 영상 생성

BytePlus ModelArk 영상 생성은 **비동기 task 방식**: task 생성 → polling → video_url 다운로드.
출력 디렉토리: `$(pwd)/.da-video/`

프롬프트 말미에 CLI 파라미터를 부착한다: `--ratio 16:9 --duration 5 --resolution 720p`

```bash
PROVIDER="${VIDEO_GEN_PROVIDER:-byteplus}"
MODEL="${VIDEO_GEN_MODEL:-seedance-2.5}"
KEY="${ARK_API_KEY:-${BYTE_KEY:-}}"
ARK_BASE="https://ark.ap-southeast.bytepluses.com/api/v3"
OUTDIR="$(pwd)/.da-video"
FNAME="video-$(date +%Y%m%d-%H%M%S).mp4"
mkdir -p "$OUTDIR"

# 프롬프트 안전 직렬화 (중국어 프롬프트 + 파라미터 suffix)
SAFE_PROMPT=$(python3 -c "import json,sys; print(json.dumps(sys.argv[1]))" \
  "<중국어 프롬프트> --ratio 16:9 --duration 5 --resolution 720p")

# 1) Task 생성
TASK_ID=$(curl -s -X POST "${ARK_BASE}/contents/generations/tasks" \
  -H "Authorization: Bearer ${KEY}" \
  -H "Content-Type: application/json" \
  -d "{\"model\": \"${MODEL}\", \"content\": [{\"type\": \"text\", \"text\": ${SAFE_PROMPT}}]}" \
  | python3 -c "
import json, sys
r = json.load(sys.stdin)
if 'error' in r:
    print(f'FAIL: {r[\"error\"].get(\"message\",\"unknown\")}', file=sys.stderr); sys.exit(1)
print(r['id'])
")
[ -z "$TASK_ID" ] && { echo "FAIL: task 생성 실패"; exit 1; }
echo "Task created: $TASK_ID"

# 2) Polling (5초 간격, 최대 10분)
for i in $(seq 1 120); do
  sleep 5
  RESP=$(curl -s "${ARK_BASE}/contents/generations/tasks/${TASK_ID}" \
    -H "Authorization: Bearer ${KEY}")
  STATUS=$(echo "$RESP" | python3 -c "import json,sys; print(json.load(sys.stdin).get('status',''))")
  echo "poll[$i]: $STATUS"
  if [ "$STATUS" = "succeeded" ]; then
    VIDEO_URL=$(echo "$RESP" | python3 -c "import json,sys; print(json.load(sys.stdin)['content']['video_url'])")
    break
  elif [ "$STATUS" = "failed" ] || [ "$STATUS" = "cancelled" ]; then
    echo "$RESP" | python3 -c "import json,sys; r=json.load(sys.stdin); print(f'FAIL: {r.get(\"error\",{}).get(\"message\",\"generation failed\")}')"
    exit 1
  fi
done
[ -z "${VIDEO_URL:-}" ] && { echo "FAIL: 생성 시간 초과 (10분)"; exit 1; }

# 3) 다운로드 (video_url은 24시간 유효 — 즉시 저장)
curl -s -o "${OUTDIR}/${FNAME}" "$VIDEO_URL"
SIZE=$(wc -c < "${OUTDIR}/${FNAME}" | tr -d ' ')
if [ "$SIZE" -gt 1000 ]; then
  echo "OK:${OUTDIR}/${FNAME} (${SIZE} bytes)"
else
  echo "FAIL: 다운로드 실패 (${SIZE} bytes)"
  exit 1
fi
```

### 이미지 참조 (image-to-video, 선택)

첫 프레임 이미지가 있으면 content 배열에 추가한다 (URL 또는 base64 data URI):

```json
{"model": "MODEL", "content": [
  {"type": "text", "text": "PROMPT --ratio adaptive --duration 5"},
  {"type": "image_url", "image_url": {"url": "https://... 또는 data:image/png;base64,..."}, "role": "first_frame"}
]}
```

로컬 파일은 base64로 인코딩: `base64 -i input.png` → `data:image/png;base64,<...>`
`.da-image/`에 최근 생성된 이미지가 있으면 first_frame 후보로 활용할 수 있다 (da:image 연계).

## Step 4: 결과 보고

```markdown
## 영상 생성 완료

OK:/absolute/path/.da-video/video-YYYYMMDD-HHMMSS.mp4 (NNN bytes)

**모델**: seedance-2.5 (BytePlus)
**프롬프트** (중국어): <사용한 프롬프트>
**한국어 요약**: <프롬프트 의도 1-2문장>
**파라미터**: 16:9 / 5초 / 720p
```

생성 실패 시 원인(키 오류/쿼터/컨텐츠 차단/시간 초과)을 구분해 보고하고, 재시도 가능 여부를 안내한다.

## 시간 전략

### 단일 영상 (4-15초)

| 길이 | 용도 | 기법 |
|------|------|------|
| 4-8초 | 제품 전시, 단일 동작, 짧은 특효 | 핵심 화면 1-2개에 집중, 분镜 불필요 |
| 9-12초 | 완결된 짧은 장면 | 시간戳 분镜 2-3단계 (선택) |
| 13-15초 | 완결된 서사 | 시간戳 분镜 3-4단계 (강력 권장) |

### 초장편 전략 (>15초): 분할 생성 + 연장 이어붙이기

Seedance 단일 생성 상한은 15초. 초과 시 **분할 생성** 방식:

1. 총 길이를 서사 리듬에 따라 각 ≤15초 구간으로 분할
2. 구간 사이에 **화면 연결점** 필수: 이전 구간의 끝 상태 = 다음 구간의 시작 상태
3. 1구간은 정상 생성, 이후 구간은 이전 결과 영상을 first_frame 참조(마지막 프레임 추출) 또는
   즉몽 플랫폼의 「视频延长」(将@视频1延长Xs) 기능으로 연장
4. 각 구간 프롬프트에 전체 중 몇 번째인지, 무엇을 잇는지 명시

| 총 길이 | 권장 분할 |
|---------|----------|
| 16-30초 | 2구간 (첫 15초 + 연장) |
| 31-45초 | 3구간 |
| 46-60초 | 4구간 |
| >60초 | 독립 장면별 생성 후 ffmpeg concat 병합 |

여러 구간 생성 시 각 mp4를 `.da-video/`에 저장한 뒤 병합:

```bash
cd .da-video && for f in video-*.mp4; do echo "file '$f'"; done > list.txt
ffmpeg -f concat -safe 0 -i list.txt -c copy merged-$(date +%H%M%S).mp4
```

## 주의사항

- 최종 영상 프롬프트는 **중국어**로 작성 (Seedance 최적화), 사용자 보고는 한국어
- 구체적·화면감 있는 묘사 사용, 동작과 카메라에 시간 순서 부여
- 실사 인물 얼굴 참조 소재 금지 (플랫폼 차단)
- 대사는 따옴표 + 캐릭터/감정 표기, 음향은 별도 줄
- video_url은 생성 후 24시간만 유효 — 반드시 즉시 다운로드
- 프롬프트만 요청받은 경우 (플랫폼 수동 사용 목적) 생성 단계를 건너뛰고
  2-3개 버전의 프롬프트를 「@참조 시스템」 규칙에 맞춰 출력한다
- 비용 참고: 5초 720p 기준 약 $0.1~0.3/영상 (모델별 상이) — 대량 생성 전 사용자에게 총 비용 고지
