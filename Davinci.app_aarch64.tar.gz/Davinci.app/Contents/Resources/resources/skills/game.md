---
name: game
description: Phaser 3 기반 2D 게임 개발. 스프라이트, 물리, 타일맵, 입력, 오디오, 파티클, UI/HUD, 장르별 패턴 지원.
agent: game-developer
agents: [senior-fullstack, frontend-architect]
davinci-phase: null
allowed-tools: [Write, Edit, Read, Bash, Glob, Grep, Task, Agent, Skill]
next-skill: verify
skill-type: flexible
version: 2.0
skills-ref:
  - davinci_framework/agent-skills/skills/mengto-test-playable-web-games
  - davinci_framework/agent-skills/skills/mengto-ship-web-games
  - davinci_framework/agent-skills/skills/mengto-matterjs
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 생성자: 자기 검증은 사전 점검일 뿐이다. 최종 판정은 독립 verify 노드가 낸다. 미완료 시 partial + remaining.

# /da:game - Phaser 2D Game Development

## MengTo Reference Skills (on-demand — 필요 시에만 Read)
> 경로: `~/.claude/plugin/agent-skills/skills/<name>/SKILL.md`
- `mengto-test-playable-web-games`: 결정론적 fixture 게임 QA (엔진 무관)
- `mengto-ship-web-games`: 릴리스/스모크/롤백 체크리스트 (엔진 무관)
- `mengto-matterjs`: Matter.js 물리 개념 참고 (Phaser Matter 물리 사용 시)


## Purpose
Build 2D games, interactive experiences, and web-based applications using Phaser 3 ecosystem.
Supports TypeScript/JavaScript projects. Phaser API coverage via Context7 (`/websites/phaser_io_phaser`) + 엔진 무관 mengto QA/릴리스 팩.

**3D 게임 개발은 `/da:three`를 사용하세요.**

## da:clone Context Injection

da:clone v2 파이프라인에서 호출될 때 추가 컨텍스트를 받는다:
- **system-spec.json**: 유추된 게임 시스템, 데이터 모델, 화면 맵
- **element-map.json**: UI 요소 좌표/크기/z_index 정보
- **assets/**: 이미 생성된 에셋 PNG 파일

system-spec.json이 존재하면:
1. `inferred_systems` 기반으로 게임 시스템 구현 (상태 머신, 데이터 모델)
2. `screen_map`의 `has_reference` 화면은 element-map.json 좌표로 배치
3. `data_model` 기반으로 TypeScript 인터페이스 생성
4. assets/ PNG를 Phaser preload에 등록 (코드 텍스처 생성 금지)

## Workflow
1. **Project Detection** - Check package.json for `phaser`
2. **Docs Loading** - Fetch relevant Phaser API docs via Context7 (`/websites/phaser_io_phaser`) based on task
3. **Asset Planning** - Derive required asset list from game concept (see Asset Generation Rules)
4. **Game Config** - Configure Phaser.Game, scenes, physics, scale manager
5. **Implementation + Asset Generation (PARALLEL) — MANDATORY**
   - 에셋 생성과 게임 코드 작성을 **반드시 병렬** 실행 (순차 실행 절대 금지)
   - **메인 스레드에서** `Skill('da:asset', '--game')` 호출 (Agent subagent 내 Skill() 호출 불가)
   - 실행 패턴 (2가지 중 택 1):
     - **패턴 A (권장)**: 메인 스레드에서 먼저 `Skill('da:asset', '--game')` 호출 -> 완료 후 게임 코드 작성
     - **패턴 B (병렬)**: background Agent로 게임 코드 작성, 메인 스레드에서 `Skill('da:asset', '--game')` 호출
       ```
       Agent({ prompt: "게임 코드 작성: [게임 컨셉]. public/assets/generated/ 에셋 키를 사용하라.", run_in_background: true })
       Skill('da:asset', '--game')  // 메인 스레드에서 실행
       ```
   - **주의**: Skill() 도구는 메인 대화에서만 사용 가능. Agent subagent 내에서 Skill() 호출 시 무시됨.
   - **post_skill hook이 da:game 완료 후 에셋 존재를 검증한다. 에셋 미생성 시 block 신호 발생.**
6. **Asset Integration** - Apply generated assets via this.load.image/spritesheet
7. **Optimization** - Apply performance patterns (object pooling, texture atlas, 60fps target)
8. **Validation** - Verify with Context7 MCP `/websites/phaser_io_phaser` for API accuracy

## Docs/Pack Loading Strategy
전부 로드하지 말 것. 작업에 필요한 것만 로드:

| User Request | Docs/Packs to Load |
|-------------|---------------|
| "Create a 2D game" | Context7: game config, scene lifecycle |
| "Add a player sprite" | Context7: sprites, input |
| "Add physics/collisions" | Context7: arcade/matter physics (+ mengto-matterjs) |
| "Build a tilemap level" | Context7: tilemaps |
| "Add sound effects" | Context7: audio |
| "Create HUD/menu" | Context7: text, containers, UI |
| "Add particle effects" | Context7: particle emitters |
| "QA / 릴리스 준비" | mengto-test-playable-web-games, mengto-ship-web-games |

## Supported Game Genres
- Platformer / Action
- Top-down RPG / Dungeon Crawler
- Tilemap-based Strategy
- Shoot'em Up (Top-down / Side-scroll)
- Puzzle / Casual
- Card / Board Game
- Idle / Clicker
- Visual Novel / UI-heavy

## Technology Support
| Tech | Level | Notes |
|------|-------|-------|
| Phaser 3 (Vanilla) | Full | Context7 docs direct |
| Phaser + TypeScript | Full | Strict mode supported |
| Arcade Physics | Full | Context7 physics docs |
| Matter.js Physics | Full | Context7 + mengto-matterjs |
| Tiled Tilemap Editor | Full | Context7 tilemap docs |
| Phaser Editor 2D | Supported | Context7 supplement |

## Asset Generation Rules (MANDATORY — post_skill hook이 검증)

게임 개발 시 AI 에셋 자동 생성은 필수. placeholder 단색 대신 생성된 에셋을 반드시 사용.
**hook 강제**: da:game 완료 후 `public/assets/generated/`에 이미지가 없으면 block 신호 발생.

### Rule 1: 에셋 생성 필수 (Skill 호출 강제)
- Workflow Step 3에서 게임 컨셉 기반 에셋 목록을 먼저 도출
- **반드시 `Skill('da:asset', '--game')`를 호출**하여 에셋 생성 (수동 curl 금지)
- NEVER use placeholder solid colors for final game objects
- 에셋 미생성 시 게임 구현을 완료한 것으로 인정하지 않음

### Rule 2: 내장 Gemini 키 자동 활용 (Zero Config)
- 별도 API 키 설정 불필요 (빌드 시 XOR 임베딩된 키 자동 사용)

### Rule 3: 배경 제거 (독립 오브젝트 필수)
- 캐릭터, 아이템 등 독립 오브젝트 에셋은 배경 투명 필수

### Rule 4: 병렬 처리 전략
- **메인 스레드에서** `Skill('da:asset', '--game')` 호출 필수 (Agent subagent 내 Skill() 불가)
- 게임 코드는 background Agent로 병렬 작성하거나, 에셋 생성 후 순차 작성
- Workflow Step 5 참조

### Rule 5: 에셋-코드 바인딩
- 생성된 에셋 저장 경로: `public/assets/generated/`
- Phaser 로드 패턴:
  - 이미지: `this.load.image('key', 'assets/generated/file.png')`
  - 스프라이트시트: `this.load.spritesheet('key', 'path', { frameWidth, frameHeight })`
  - 오디오: `this.load.audio('key', 'path')`

### Rule 6: 장르별 최소 에셋 세트
| 장르 | 최소 에셋 |
|------|----------|
| 플랫포머 | 캐릭터(1), 적(1), 배경(1), 타일(2), 아이템(1) |
| 슈팅 | 플레이어(1), 적(2), 총알(1), 배경(1), 폭발(1) |
| 퍼즐 | 블록/피스(3+), 배경(1), UI(2) |
| RPG | 캐릭터(1), 적(2), 맵타일(3), NPC(1), 아이템(2) |
| 캐주얼 | 메인 오브젝트(1), 장애물(2), 배경(1), UI(1) |

### Rule 7: 에셋 스타일 일관성 (Style Consistency)
- da:asset의 4-Layer 프롬프트 중 Layer 1(Style DNA)을 전체 에셋에 동일 적용
- 에셋 생성 전 아트 스타일을 먼저 결정 (da:asset Phase 1.5):
  - Pixel Art / Hand-Drawn / Vector-Flat / Realistic-Painterly
- 선택된 스타일은 모든 에셋에 일관 적용:
  - Layer 1 (Style DNA): 색상 팔레트 + 분위기 + 아트 스타일 → 전체 에셋 고정
  - Layer 2 (Asset Context): 개별 에셋 설명만 변경
  - Layer 3/4: Anti-AI + 기술 스펙 → 고정
- 캐릭터/적/아이템/배경이 동일한 세계관에 속하도록 시각적 통일감 보장

### Rule 8: Graceful Degradation
- da:asset 실패 시 색상 placeholder로 정상 생성
- 게임 개발 파이프라인을 절대 중단하지 않음

## Deliverables
- Production-ready Phaser 3 code with TypeScript strict mode
- Proper scene cleanup (shutdown event handlers)
- Responsive game canvas with Scale Manager
- 60fps performance-optimized rendering
- AI-generated game assets in `public/assets/generated/`

---

## Turbo Execution Protocol (Speed Optimization)

### Anti-Stall: Call-First Pattern (ABSOLUTE)
```yaml
Rule: tool call 사이에 텍스트 출력 0 bytes
- 진행 상황 설명, 단계 전환 안내, 중간 멘트 전부 금지
- 모든 progress는 행동(tool call)으로만 표현
- 유일한 예외: 사용자에게 선택지를 제시해야 할 때
```

### Parallel Call Rules (MANDATORY)

독립적인 tool call은 반드시 같은 메시지에서 병렬 실행한다.
순차 호출 시 1회당 ~20초 낭비. 6개 순차 = 2분 낭비.

```yaml
Rule_1_Parallel_Read_Search:
  # 독립 파일 Read/Search는 반드시 병렬
  - 여러 파일을 읽을 때: 1회 메시지에 N개 Read 동시 호출
  - 여러 패턴 검색 시: 1회 메시지에 N개 codegraph_search 동시 호출
  - 예시 (6개 Scene 파일 분석):
    ✅ 1회 메시지: Read(boot-scene.ts) + Read(menu-scene.ts) + Read(game-scene.ts) + ...
    ❌ 6회 메시지: Read(boot) → Read(menu) → Read(game) → ...

Rule_2_Batch_File_Generation:
  # 동일 구조 파일은 배치 생성
  - tilemap, config, scene 등 동일 구조 파일: Template 변수만 변경하여 동시 Write
  - 예시 (tilemap 3개 생성):
    ✅ 1회 메시지: Write(stage-1.json) + Write(stage-2.json) + Write(stage-3.json)
    ❌ 3회 메시지: Write(stage-1) → Write(stage-2) → Write(stage-3)

Rule_3_Analysis_Asset_Parallel:
  # 코드 분석과 에셋 기획을 병렬로
  - Wave A: 기존 코드베이스 분석 (codegraph_explore, codegraph_node 등)
  - Wave B: 에셋 목록 도출 + 아트 스타일 결정
  - 두 작업은 독립적 → 반드시 병렬 실행 (Agent tool 활용)

Rule_4_Scene_Parallel_Implementation:
  # 독립 Scene은 Agent subagent로 병렬 구현
  - 조건: Scene 간 import 의존성이 없을 때만
  - 예시 (3개 Scene 병렬):
    Agent(prompt="MenuScene 구현", run_in_background=true)
    Agent(prompt="GameOverScene 구현", run_in_background=true)
    # 메인 스레드에서 GameScene 구현 (가장 복잡한 것)
  - 주의: 공유 타입/유틸은 먼저 생성 (Wave 0: shared types → Wave 1: scenes)
```

### Tool Fallback Chain (도구 실패 시 즉시 전환)

같은 도구로 2회 이상 재시도 절대 금지. 실패 즉시 다음 도구로 전환.

```yaml
Code_Edit_Chain:
  1st: CodeGraph Edit  # 심볼 단위 정밀 교체
  2nd: Edit(old_string, new_string) # 문자열 매칭 교체
  3rd: Write(file_path, content)    # 전체 파일 재작성 (마지막 수단)
  규칙: 1st 실패 → 즉시 2nd | 2nd 실패 → 즉시 3rd | 동일 도구 재시도 금지

Code_Read_Chain:
  1st: codegraph_explore  # 토큰 효율적 개요
  2nd: codegraph_node(include_body=true) # 특정 심볼 본문
  3rd: Read(file_path)              # 전체 파일 (비코드 파일 또는 전체 필요 시)
  규칙: 심볼명을 아는 경우 codegraph_node 직접 사용

Code_Search_Chain:
  1st: codegraph_node            # 심볼명 기반 (가장 빠름)
  2nd: codegraph_search     # 정규식 패턴 (유연)
  3rd: Grep                          # 일반 텍스트 (최후 수단)
  규칙: 클래스/함수명 알면 1st, 코드 패턴이면 2nd, 일반 텍스트면 3rd
```

### Mega-Spec: One-Shot File Structure Generation

게임 구현 시작 전, 전체 파일 구조를 한 번에 도출하여 의존성 기반 병렬 실행.

```yaml
MegaSpec_Protocol:
  When: Workflow Step 4 (Game Config) 직후, Step 5 (Implementation) 직전
  How:
    1. 게임 컨셉 + 장르 + 요구사항에서 전체 파일 목록 도출
    2. 파일 간 의존성 분석 → DAG(방향 비순환 그래프) 생성
    3. DAG topological sort → Wave 분할
    4. Wave별 병렬 구현

  MegaSpec_JSON_Schema:
    game_spec:
      scenes:
        - { name: "BootScene", file: "src/scenes/boot-scene.ts", deps: [], assets: [] }
        - { name: "MenuScene", file: "src/scenes/menu-scene.ts", deps: ["types"], assets: ["bg-menu"] }
        - { name: "GameScene", file: "src/scenes/game-scene.ts", deps: ["types", "systems/*"], assets: ["player", "enemy", "tiles"] }
        - { name: "GameOverScene", file: "src/scenes/game-over-scene.ts", deps: ["types"], assets: ["bg-gameover"] }
      systems:
        - { name: "LevelManager", file: "src/systems/LevelManager.ts", deps: ["types", "config"] }
        - { name: "ScoreManager", file: "src/systems/ScoreManager.ts", deps: ["types"] }
      configs:
        - { name: "GameConfig", file: "src/config.ts", deps: [] }
      shared:
        - { name: "Types", file: "src/types/index.ts", deps: [] }
      assets:
        - { key: "player", type: "spritesheet", prompt: "pixel art hero character" }
        - { key: "enemy", type: "spritesheet", prompt: "pixel art slime enemy" }
      tilemaps:
        - { stage: "stage-1", template: "base-tilemap", vars: { width: 40, height: 20, difficulty: "easy" } }
        - { stage: "stage-2", template: "base-tilemap", vars: { width: 60, height: 25, difficulty: "medium" } }

  Wave_Execution_Example:
    Wave_0: [Types, GameConfig]           # 공유 의존성 (순차 OK, 작음)
    Wave_1: [LevelManager, ScoreManager]  # 시스템 (병렬, 독립적)
    Wave_2: [BootScene, MenuScene, GameOverScene] # 독립 Scene (3-way 병렬)
    Wave_3: [GameScene]                   # 메인 Scene (모든 의존성 필요)
    Asset_Wave: Skill('da:asset', '--game')  # 메인 스레드에서 실행 (Skill()은 subagent 불가)
```

### DNA Cache: Genre Pattern Reuse

이전 게임 프로젝트의 검증된 패턴을 캐시하여 재사용.
캐시 미스 시 일반 구현으로 fallback (graceful degradation).

```yaml
DNA_Game_Component_Cache:
  cache_dir: ~/.davinci/cache/game-patterns/
  cache_targets:
    scene_boilerplate:
      - boot-scene.ts   # 에셋 로딩 + 프로그레스바 패턴
      - menu-scene.ts    # 타이틀 + 버튼 + 씬 전환 패턴
      - game-over.ts     # 스코어 표시 + 재시작/메뉴 버튼 패턴
    genre_skeletons:
      - platformer/game-scene.ts   # 횡스크롤, 중력, 타일맵 충돌
      - shooter/game-scene.ts      # 자동 스크롤, 총알 풀링, 적 스폰
      - puzzle/game-scene.ts       # 그리드 기반, 매칭 로직
      - rpg/game-scene.ts          # 타일맵 월드, NPC 대화, 인벤토리
    system_patterns:
      - LevelManager.ts    # 스테이지 전환 + 난이도 곡선
      - ScoreManager.ts    # 점수 + 하이스코어 + localStorage
      - InputHandler.ts    # 키보드 + 터치 통합 입력
    data_templates:
      - tilemap-base.json  # Tiled 호환 기본 구조

  cache_lookup_protocol:
    1. 장르 감지 → genre_skeletons에서 매칭
    2. 캐시 히트 → 템플릿 로드 + 프로젝트별 변수 치환
    3. 캐시 미스 → 일반 구현 (기존 워크플로우 그대로)
    4. 구현 완료 후 → 새 패턴을 캐시에 저장 (자동 학습)

  cache_invalidation:
    - Phaser 메이저 버전 변경 시 전체 무효화
    - 캐시 항목별 TTL: 90일 (3개월)
    - 수동 무효화: rm -rf ~/.davinci/cache/game-patterns/
```

### Structured Handoff (Inter-Skill Context Compression)

da:game 완료 시 구조화된 JSON으로 다음 스킬에 정보 전달.
raw output 대신 핵심 정보만 전달하여 60-80% context 절약.

```yaml
Game_Handoff_Schema:
  da:game_to_verify:
    # IBaseHandoff 필수 필드
    skill: "da:game"
    status: "completed"
    timestamp: "2026-04-02T21:30:00Z"
    phase: 1
    artifacts:
      files_created: ["src/scenes/game-scene.ts", "src/systems/LevelManager.ts"]
      files_modified: ["src/config.ts"]
    # 게임 전용 필드
    scenes: ["BootScene", "MenuScene", "GameScene", "GameOverScene"]
    systems: ["LevelManager", "ScoreManager"]
    assets:
      generated: ["player.png", "enemy.png", "tiles.png"]
      path: "public/assets/generated/"
    config:
      physics: "arcade"
      scale_mode: "FIT"
      target_fps: 60
    test_hints:
      - "Scene 전환이 정상 동작하는지 확인"
      - "물리 충돌이 올바르게 설정되었는지 확인"
      - "에셋 로딩 실패 시 fallback 동작 확인"

  da:game_to_asset:
    style_dna:
      art_style: "pixel-art"
      color_palette: ["#1a1a2e", "#16213e", "#0f3460", "#e94560"]
      mood: "retro-adventure"
    asset_list:
      - { key: "player", type: "spritesheet", frames: 4, size: "32x32" }
      - { key: "enemy-slime", type: "spritesheet", frames: 2, size: "32x32" }
      - { key: "tiles", type: "tileset", size: "16x16" }
      - { key: "bg-sky", type: "image", size: "800x600" }
    output_dir: "public/assets/generated/"
```
