---
name: super
description: "7-Lens Radar 기반 자율 반복 제품 고도화 메타 오케스트레이터. 매 사이클마다 품질 최저 렌즈를 자동 선택하여 집중 개선. N회 반복으로 프로덕트 완성."
agent: super-pm
agents: [super-pm, cto-lead, deep-research-agent, frontend-architect, qa-strategist, security-architect, senior-fullstack, ux-designer]
davinci-phase: null
allowed-tools: [Write, Edit, Read, Bash, Glob, Grep, Task, Skill, WebSearch, WebFetch]
next-skill: report
skill-type: flexible
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 오케스트레이터: §4 그래프 ready-set 디스패치, §6 노드 단위 checkpoint, §7 interrupt 표 외 질문 금지.

## Tool Parameter Rules -> See CLAUDE.md (ABSOLUTE)
# /da:super - 7-Lens Radar Meta-Orchestrator

## ★ Orchestrator Model Recommendation (ADR-001 Path B)

`da:super`는 N회 반복으로 매우 긴 실행을 수행한다. Task tool의 `model`이 enum 고정이므로 sub-skill 내부에서 버전을 바꿀 수 없고, **Orchestrator `/model` 지정만이 실제 버전 제어 수단**이다.

- N ≥ 5 (기본값): `/model opus-4.6` 권장 (지속력 우선)
- 품질 우선 짧은 사이클: `/model opus-4.7` 유지
- 진단: `uv run davinci model doctor`

## Protocol

### Step 0: Init

Parse `$ARGUMENTS` to extract cycle count N (default: 5).

```yaml
Argument_Parsing:
  /da:super          → N = 5 (default)
  /da:super 10       → N = 10
  /da:super resume   → Jump to Special Commands (resume)
  /da:super status   → Jump to Special Commands (status)
  /da:super cancel   → Jump to Special Commands (cancel)

Resume_Check:
  Bash: cat docs/.davinci-super.json 2>/dev/null || echo "NO_STATE"

  If result is NOT "NO_STATE":
    - Parse state JSON
    - If current_step != "complete":
      Output: "Checkpoint found. Resuming cycle {current_cycle}/{target_cycles}, step: {current_step}."
      Resume from the current_step (skip Init)
    - If current_step == "complete":
      Output: "Previous super cycle completed. Starting fresh."
      Start new cycle

  If result is "NO_STATE":
    - Initialize new SuperState via Python:
      Bash: uv run python -c "
      from davinci.workflow.super_cycle import SuperState, save_state
      from datetime import datetime, timezone
      state = SuperState(
          target_cycles={N},
          current_cycle=0,
          current_step='init',
          threshold=85,
          started_at=datetime.now(timezone.utc).isoformat(),
          last_update=datetime.now(timezone.utc).isoformat(),
      )
      save_state(state)
      print('SuperState initialized: target_cycles={N}')
      "
    - Load Vision Memory:
      Read(file_path="docs/.davinci-super-vision.md")
      If not found: Create default vision from CLAUDE.md patterns
    - Proceed to Step 1
```

### Step 1: Radar Scan

Measure all 7 lenses against the current project state. Each lens is scored 0–100.

```yaml
Radar_Scan_Protocol:
  1. Update state: current_step = "radar_scan"
  2. Evaluate each lens using its criteria below
  3. Save scores via Python
  4. Display radar bar chart

Score_Save:
  Bash: uv run python -c "
  from davinci.workflow.super_cycle import load_state, save_state
  state = load_state()
  scores = {'market': M, 'uiux': U, 'usability': B, 'stability': S, 'performance': P, 'security': C, 'accessibility': A}
  for lens, score in scores.items():
      state.update_radar(lens, score)
  state.current_step = 'radar_scan'
  save_state(state)
  from davinci.workflow.radar import RadarScore
  r = RadarScore(**scores)
  print(r.to_bar_chart())
  "
```

#### L1: 시장검증 (Market Validation) — 100점 만점

Use WebSearch to analyze competitors and market fit.

| Criteria | Weight | Method | Scoring |
|----------|--------|--------|---------|
| 경쟁사 기능 커버리지 | 30 | WebSearch top 3 competitors, compare feature parity | 30: ≥90% parity, 20: 70-89%, 10: 50-69%, 0: <50% |
| PMF 지표 | 30 | Core value proposition clarity, target user fit | 30: clear + validated, 20: clear, 10: vague, 0: missing |
| 차별화 요소 | 20 | Unique features vs competitors | 20: strong moat, 13: some differentiation, 7: weak, 0: none |
| 시장 트렌드 적합성 | 20 | Alignment with current tech/market trends | 20: ahead of trend, 13: aligned, 7: lagging, 0: misaligned |

#### L2: UI/UX — 100점 만점

Evaluate using Nielsen heuristics and visual consistency audit.

| Criteria | Weight | Method | Scoring |
|----------|--------|--------|---------|
| Nielsen 10대 휴리스틱 | 40 | Check visibility, match, consistency, error prevention, recognition, flexibility, aesthetics, help, freedom, docs | 4pts each (40 total) |
| 시각적 일관성 | 25 | Color palette, typography, spacing consistency across pages | 25: fully consistent, 17: minor issues, 8: major issues, 0: inconsistent |
| 레이아웃 품질 | 20 | Grid alignment, responsive behavior, whitespace usage | 20: polished, 13: good, 7: needs work, 0: broken |
| 폴리시 (polish) | 15 | Micro-interactions, loading states, transitions, empty states | 15: premium feel, 10: adequate, 5: basic, 0: missing |

#### L3: 사용성 (Usability) — 100점 만점

Evaluate task efficiency and error recovery via Playwright flow simulation.

| Criteria | Weight | Method | Scoring |
|----------|--------|--------|---------|
| 태스크 효율성 | 35 | Core user flow step count, time-to-completion | 35: optimal, 23: good, 12: bloated, 0: broken |
| 에러 복구 | 25 | Error messages clarity, recovery paths, undo support | 25: graceful, 17: adequate, 8: confusing, 0: missing |
| 학습성 | 20 | Onboarding, progressive disclosure, intuitive navigation | 20: intuitive, 13: learnable, 7: steep curve, 0: cryptic |
| 피드백 품질 | 20 | Loading indicators, success/error feedback, progress bars | 20: comprehensive, 13: good, 7: sparse, 0: absent |

#### L4: 안정성 (Stability) — 100점 만점

Evaluate via E2E test pass rate, build verification, error handling.

| Criteria | Weight | Method | Scoring |
|----------|--------|--------|---------|
| E2E pass rate | 35 | Playwright test suite pass percentage | 35: 100%, 25: ≥90%, 15: ≥70%, 0: <70% |
| 빌드 성공 | 25 | Clean build (no warnings), type-check pass | 25: zero warnings, 17: minor warnings, 8: errors fixed, 0: build fails |
| 에러 핸들링 | 25 | Error boundaries, try/catch coverage, graceful degradation | 25: comprehensive, 17: good, 8: partial, 0: missing |
| 엣지케이스 | 15 | Empty states, max length, concurrent access, offline | 15: covered, 10: most covered, 5: few, 0: none |

#### L5: 성능 (Performance) — 100점 만점

Evaluate via Lighthouse audit, bundle analysis, runtime metrics.

| Criteria | Weight | Method | Scoring |
|----------|--------|--------|---------|
| Lighthouse 점수 | 35 | Performance score from Lighthouse audit | 35: ≥90, 25: ≥75, 15: ≥50, 0: <50 |
| 번들 사이즈 | 25 | JS bundle size (gzipped) | 25: <100KB, 17: <250KB, 8: <500KB, 0: ≥500KB |
| 로딩 속도 | 25 | FCP < 1.5s, LCP < 2.5s, TTI < 3.5s | 25: all pass, 17: 2/3 pass, 8: 1/3 pass, 0: all fail |
| 런타임 효율 | 15 | No memory leaks, efficient re-renders, no jank | 15: smooth, 10: minor issues, 5: noticeable, 0: severe |

#### L6: 보안 (Security) — 100점 만점

Evaluate via OWASP compliance, auth strength, data protection.

| Criteria | Weight | Method | Scoring |
|----------|--------|--------|---------|
| OWASP Top 10 준수 | 40 | Check injection, auth, XSS, CSRF, misconfig, components, logging, SSRF, crypto | 4pts per item (40 total) |
| 인증 강도 | 25 | Auth mechanism, session management, password policy | 25: MFA+JWT+secure, 17: JWT+secure, 8: basic auth, 0: none |
| 데이터 보호 | 20 | Encryption at rest/transit, PII handling, input sanitization | 20: comprehensive, 13: good, 7: partial, 0: missing |
| 의존성 감사 | 15 | npm audit / pip audit results | 15: 0 vulnerabilities, 10: low only, 5: moderate, 0: high/critical |

#### L7: 접근성/SEO (Accessibility & SEO) — 100점 만점

Evaluate via axe-core scan, keyboard navigation, semantic HTML, SEO meta tags.

| Criteria | Weight | Method | Scoring |
|----------|--------|--------|---------|
| WCAG 2.1 AA 준수 | 35 | axe-core violations count (0=35, 1-3=25, 4-10=15, 10+=0) | 35: 0 violations, 25: ≤3, 15: ≤10, 0: >10 |
| 키보드 네비게이션 | 25 | Tab order, focus indicators, skip-nav, no keyboard traps | 25: full support, 17: mostly, 8: partial, 0: broken |
| 시맨틱 HTML | 20 | Proper heading hierarchy, landmarks, ARIA labels | 20: excellent, 13: good, 7: partial, 0: div soup |
| SEO 메타태그 | 20 | title, description, OG tags, structured data, sitemap | 20: complete, 13: good, 7: basic, 0: missing |

### Step 2: Lens Select

Auto-select the lowest-scoring lens and prepare the appropriate agent/tool set.

```yaml
Lens_Select_Protocol:
  1. Update state: current_step = "lens_select"
  2. Determine lowest lens via Python:
     Bash: uv run python -c "
     from davinci.workflow.super_cycle import load_state
     from davinci.workflow.radar import RadarScore, LENS_LABELS, LENS_NAMES
     state = load_state()
     scores = {k: state.radar.get(k, {}).get('current', 0) for k in LENS_NAMES}
     r = RadarScore(**scores)
     lens = r.lowest_lens()
     print(f'FOCUS={lens}|SCORE={getattr(r, lens)}')
     "
  3. Parse output → focus_lens, focus_score
  4. Output: "Focus Lens: {LENS_LABELS[focus_lens]} — {focus_score}/100"

Agent_Tool_Mapping:
  L1_market:
    primary_agent: deep-research-agent
    skills: [da:research, da:idea]
    tools: [WebSearch, WebFetch]
  L2_uiux:
    primary_agent: frontend-architect
    skills: [da:design, da:verify]
    tools: [Read, Write, Edit, Bash]
  L3_usability:
    primary_agent: ux-designer
    skills: [da:e2e, da:verify]
    tools: [Bash, Task]  # Playwright
  L4_stability:
    primary_agent: qa-strategist
    skills: [da:e2e, da:verify]
    tools: [Bash, Task]  # Playwright + build
  L5_performance:
    primary_agent: senior-fullstack
    skills: [da:perf, da:analyze]
    tools: [Bash, Read]  # Lighthouse + bundle
  L6_security:
    primary_agent: security-architect
    skills: [da:security, da:audit]
    tools: [Bash, Read, Grep]
  L7_accessibility:
    primary_agent: frontend-architect
    skills: [da:e2e, da:verify]
    tools: [Bash, Task]  # axe-core + meta
```

### Step 3: Cycle Execute — Super PM Autonomous Pipeline

**★ 핵심 원칙: Super PM이 앤드류를 대신하여 자율적으로 판단하고 실행한다.**
AskUserQuestion 절대 금지. 모든 의사결정은 Vision Memory + 코드 분석 + 경쟁사 조사로 자체 수행.
"결함 수정"이 아니라 "가치 창출 + 경쟁력 극대화 + 폴리시"에 집중한다.

```yaml
Cycle_Execute:
  Bash: uv run python -c "
  from davinci.workflow.super_cycle import load_state, save_state
  state = load_state()
  state.advance_cycle()
  state.current_step = 'cycle_execute'
  save_state(state)
  print(f'Cycle {state.current_cycle}/{state.target_cycles} started')
  "
```

#### 3a. da:idea --autonomous — 시장조사 + 경쟁사 분석 + 아이디어 도출

```yaml
Idea_Protocol:
  # ★ CRITICAL: da:idea를 --autonomous 모드로 호출한다.
  # --autonomous 모드에서는 AskUserQuestion이 금지되고,
  # da:idea가 자체적으로 시장조사 + 코드분석 + 아이디어 도출을 수행한다.
  # Vision Memory를 참조하여 앤드류의 의사결정 패턴을 반영한다.

  Skill(skill="da:idea", args="--autonomous --research
    현재 앱을 {focus_lens} 관점에서 평가하고 개선 아이디어를 도출하라.
    Radar 현재 점수: {focus_lens}={score}/100.
    프로젝트 경로: {project_path}

    Focus Lens별 평가 방향:
    - L1(시장): 경쟁사 대비 기능 gap + 차별화 기회 + 트렌드 적합성
    - L2(UI/UX): 디자인 폴리시 + 시각적 일관성 + 프리미엄 느낌
    - L3(사용성): 유저 플로우 효율성 + 에러 복구 + 온보딩
    - L4(안정성): 빌드 안정성 + 에러 핸들링 + 엣지케이스
    - L5(성능): 로딩 속도 + 번들 사이즈 + 런타임 효율
    - L6(보안): OWASP 준수 + 인증 + 데이터 보호
    - L7(접근성): WCAG 준수 + 키보드 네비 + 시맨틱 HTML

    ★ 결함 수정보다 가치 창출에 집중:
    - 혁신 기능 1개 (경쟁사에 없는 킬러 피처)
    - 경쟁사 gap 2개 (있는데 우리에 없는 것)
    - 폴리시/UX 개선 2개 (기존 기능 완성도 극대화)
  ")

  # da:idea --autonomous는 AskUserQuestion 없이 자체 분석 후
  # 5개 개선 아이디어 리스트를 반환한다.
  # 이 결과를 다음 단계(da:plan)에 전달한다.
```

#### 3b. da:plan — 개선 계획 수립 (PLAN.md 생성)

```yaml
Plan_Protocol:
  # ★ CRITICAL: da:idea --autonomous 결과를 기반으로 da:plan을 호출한다.
  # da:idea가 자율적으로 도출한 5개 아이디어를 구현 계획으로 변환.

  Skill(skill="da:plan", args="
    da:idea --autonomous 결과를 기반으로 Cycle {K}의 {focus_lens} 개선 계획을 수립하라.

    [여기에 da:idea가 도출한 5개 아이디어를 구체적으로 기술]

    포함 사항:
    1. 개선 목표 (현재 {score}점 → 목표 점수)
    2. Phase별 작업 항목 (da:work가 파싱할 수 있는 구현 로드맵 형식)
    3. 각 Phase에 design 필요 여부
    4. 검증 기준 (verify 필드)
    5. 리스크 및 주의사항

    PLAN 파일을 docs/super/cycle-{K}-plan.md에 저장하라.
    --no-verify 플래그 사용.
    AskUserQuestion 호출 금지.
  ")
```

#### 3c. da:work — 전체 개발 파이프라인 실행

```yaml
Work_Protocol:
  # ★ CRITICAL: 반드시 Skill tool로 da:work를 호출한다.
  # da:plan이 생성한 PLAN.md 기반으로 전체 파이프라인을 자동 실행.
  # system → design → dev → verify → improve 내부 루프 포함.

  Skill(skill="da:work", args="
    docs/super/cycle-{K}-plan.md 기획서 기반으로 파이프라인 실행.
    Cycle {K}: {focus_lens} 집중 개선.
  ")

  # da:work는 내부에서 다음을 자동 실행:
  #   Stage 0: Plan Parsing (cycle-{K}-plan.md 읽기)
  #   Stage 1: da:system (아키텍처 — complexity에 따라 스킵 가능)
  #   Stage 3: Phase별 da:design → da:dev → da:verify → da:improve
  #   Stage 4: da:e2e (E2E 테스트)
  #   Stage 5: da:report
  #
  # ★ da:work가 전체 DAVINCI 워크플로우를 자율 실행하므로,
  #    super 오케스트레이터는 결과만 받으면 된다.
```

#### 3d. da:e2e — 최종 E2E 검증 (컴파일 + 구동 + 테스트)

```yaml
E2E_Protocol:
  # da:work 내부에서 이미 E2E를 실행하지만,
  # super는 추가로 한 번 더 전체 E2E를 돌려 최종 안정성을 확인한다.

  Skill(skill="da:e2e", args="
    Cycle {K} 완료 후 최종 E2E 검증.
    빌드 성공 확인 + 핵심 유저 플로우 테스트 + 접근성 검사.
    실패 시 이슈 리스트 반환.
  ")

  # E2E 실패 시:
  #   → Skill(skill="da:improve", args="E2E 실패 항목 수정")
  #   → Skill(skill="da:e2e") 재실행 (max 2회)
```

#### 3e. da:verify — 최종 품질 검증

```yaml
Verify_Protocol:
  Skill(skill="da:verify", args="
    --tier full. Cycle {K} {focus_lens} 전체 개선사항 최종 검증.
    match rate 90% 이상 목표.
  ")

  # match rate < 90%:
  #   → Skill(skill="da:improve") 후 재검증 (max 2회)

  # Git tag 생성:
  Bash: git tag -a "super/cycle-{K}" -m "Super cycle {K}: {focus_lens} improvements"
```

#### 3f. Evaluate — Re-measure focus lens + full radar update

```yaml
Evaluate_Protocol:
  - Re-score the focus lens using same criteria as Step 1
  - Update radar scores via Python
  - Regression Guard: check all OTHER lenses for > 5pt drop
    Bash: uv run python -c "
    from davinci.workflow.super_cycle import load_state, save_state
    state = load_state()
    regressions = []
    for lens in ['market','uiux','usability','stability','performance','security','accessibility']:
        if lens == '{focus_lens}':
            continue
        if state.check_regression(lens, {new_score_for_lens}):
            regressions.append(lens)
    if regressions:
        print(f'REGRESSION_WARNING: {regressions}')
    else:
        print('NO_REGRESSION')
    "
  - If regression detected:
    - Output warning with affected lenses
    - Re-run E2E for affected lenses
    - Offer rollback: git revert to super/cycle-{K} tag
  - Record cycle result:
    CycleRecord(cycle=K, focus_lens, before_score, after_score, delta, improvements, regressions)
```

#### 3g. Memory — Save reflexion + cycle report + Vision update

```yaml
Memory_Protocol:
  - Save cycle report: docs/super/cycle-{K}-report.md
    Content: focus lens, before/after scores, improvements made, regressions, duration

  - Update reflexion memory in state:
    - Success patterns: what worked well
    - Anti-patterns: what caused regressions
    - Strategy hints for next cycle

  - ★ Vision Memory 자동 업데이트 (harness engineering 참고):
    # 사이클에서 학습한 패턴을 Vision Memory에 반영
    Read(file_path="docs/.davinci-super-vision.md")
    Edit로 다음 업데이트:
    - "Observed Decision Patterns"에 이번 사이클에서 발견한 패턴 추가
    - 사용자가 사이클 중간에 개입했다면 → 그 결정을 패턴으로 기록
    - 사용자가 거부한 아이디어가 있다면 → Blacklist에 추가
    - 효과적이었던 개선 방향 → Innovation Compass에 반영

  - Compress memory to < 2K tokens (token efficiency)
  - Save state:
    Bash: uv run python -c "
    from davinci.workflow.super_cycle import load_state, save_state
    state = load_state()
    state.cycles.append({
        'cycle': {K}, 'focus_lens': '{focus_lens}',
        'before_score': {before}, 'after_score': {after}, 'delta': {delta},
        'improvements': {improvements_list}, 'regressions': {regressions_list},
        'duration': '{duration}'
    })
    state.current_step = 'gate_check'
    save_state(state)
    "
```

### Step 4: Gate Check

Determine whether to continue cycling or complete.

```yaml
Gate_Check_Protocol:
  Bash: uv run python -c "
  from davinci.workflow.super_cycle import load_state, save_state
  from davinci.workflow.radar import RadarScore, LENS_NAMES
  state = load_state()
  scores = {k: state.radar.get(k, {}).get('current', 0) for k in LENS_NAMES}
  r = RadarScore(**scores)
  all_above = r.all_above(state.threshold)
  max_reached = state.current_cycle >= state.target_cycles
  stalled = state.is_stalled()
  print(f'ALL_ABOVE={all_above}|MAX_REACHED={max_reached}|STALLED={stalled}|AVG={r.average():.0f}|CYCLE={state.current_cycle}/{state.target_cycles}')
  "

  Decision_Tree:
    ALL_ABOVE == True:
      - Output: "All lenses ≥ {threshold}! Product quality target achieved."
      - Update state: current_step = "complete"
      - Proceed to Step 5 (Final Report)

    MAX_REACHED == True:
      - Output: "Max cycles ({N}) reached. Completing with current scores."
      - Update state: current_step = "complete"
      - Proceed to Step 5 (Final Report)

    STALLED == True (da:protocol §5.2 / §5.3):
      - 1st stall → Output: "WARNING: Stall detected (2 consecutive cycles with total delta < 2). Switching strategy."
        - state.stall_events += 1; 다음 사이클은 **다른 렌즈 또는 다른 접근**을 강제(직전 cycle의 focus lens 제외, reason을 plan에 주입)
        - Log stall event in memory → continue to next cycle
      - 2nd consecutive stall (stall_events >= 2 without radar delta ≥ 2 between) →
        - Output: "STOP: no progress across 2 strategy changes." → state.current_step = "complete", stop_reason = "no_progress"
        - Proceed to Step 5 (Final Report) with blocked/degraded lens list — 무한 사이클 금지

    BLOCKED lens (verify verdict BLOCKED/IMPOSSIBLE in last cycle):
      - 해당 렌즈를 다음 Lens Select에서 제외(state.blocked_lenses[]), 최종 리포트에 사유와 함께 노출
      - 모든 렌즈가 blocked → Step 5

    else:
      - Output: "Gate: {avg}/100 avg, cycle {K}/{N}. Continuing..."
      - Loop back to Step 1 (Radar Scan)
```

### Step 5: Final Report

Generate the final comprehensive super report.

```yaml
Final_Report_Protocol:
  1. Update state: current_step = "complete"
  2. Create report directory: mkdir -p docs/super
  3. Generate docs/super/SUPER-REPORT-{YYYY-MM-DD}.md with:
     - Header: project name, date, total cycles, final threshold
     - Final Radar bar chart (all 7 lenses)
     - Radar history: initial scores → final scores per lens
     - Per-cycle summary table:
       | Cycle | Focus Lens | Before | After | Delta | Key Improvements |
     - Cumulative improvements list
     - Reflexion insights (success patterns + anti-patterns)
     - Regressions encountered and resolutions
     - Recommendations for further improvement
  4. Clean up state if complete:
     Bash: uv run python -c "
     from davinci.workflow.super_cycle import load_state, save_state
     state = load_state()
     state.current_step = 'complete'
     save_state(state)
     print('Super cycle complete')
     "
  5. Transition to da:report:
     Skill(skill="da:report", args="Generate final report based on docs/super/SUPER-REPORT-{date}.md")
```

## Special Commands

### /da:super resume

Resume an interrupted super cycle from the last checkpoint.

```yaml
Resume_Protocol:
  1. Read docs/.davinci-super.json
  2. If not found: Output "No super cycle state found. Start with /da:super N."
  3. If found:
     - Display current progress (cycle K/N, last step, radar scores)
     - Resume from current_step:
       - "init" → Step 1 (Radar Scan)
       - "radar_scan" → Step 2 (Lens Select)
       - "lens_select" → Step 3 (Cycle Execute)
       - "cycle_execute" → Step 3 (restart current sub-step)
       - "gate_check" → Step 4 (Gate Check)
       - "complete" → Output "Cycle already complete."
```

### /da:super status

Display current super cycle status without modifying state.

```yaml
Status_Protocol:
  Bash: uv run python -c "
  from davinci.workflow.super_cycle import load_state
  from davinci.workflow.radar import RadarScore, LENS_NAMES
  state = load_state()
  if not state:
      print('No active super cycle.')
  else:
      scores = {k: state.radar.get(k, {}).get('current', 0) for k in LENS_NAMES}
      r = RadarScore(**scores)
      print(f'Cycle: {state.current_cycle}/{state.target_cycles}')
      print(f'Step: {state.current_step}')
      print(f'Threshold: {state.threshold}')
      print(r.to_bar_chart())
      if state.cycles:
          last = state.cycles[-1]
          print(f'Last focus: {last[\"focus_lens\"]} (delta: +{last[\"delta\"]})')
  "
```

### /da:super cancel

Cancel the running super cycle and clean up state.

```yaml
Cancel_Protocol:
  1. Bash: rm -f docs/.davinci-super.json
  2. Output: "da:super cancelled. State file deleted."
  3. Note: cycle reports in docs/super/ are preserved for reference.
```

---

## Stop Hook Interaction

This command integrates with the super guard in `on_stop.py`:

```
Session termination attempt
    ↓
on_stop.py Phase 1: Safety Guards
    ↓
on_stop.py Phase 2: Pipeline Guard (da:work)  ← highest priority
    ↓
on_stop.py Phase 2.5: Loop Guard (da:loop)
    ↓
on_stop.py Phase 2.7: Super Guard (da:super)  ← intercepted here
    ↓
  Check docs/.davinci-super.json
    ↓
  current_step != "complete" && current_cycle < target_cycles
    ↓
  YES → exit code 2 (block), re-inject: /da:super resume
  NO  → allow normal termination
```

---

## TokenBudget Integration

```yaml
Token_Strategy:
  per_cycle: complex (2,500 tokens for analysis + planning)
  per_develop: delegated to sub-Task (separate budget)
  memory_compression: ≤ 2K tokens per cycle reflexion
  total_budget: N * 2,500 + sub-Task budgets

  Efficiency_Rules:
    - Reuse radar scores from state file (avoid re-measurement)
    - Compress cycle reports to essential metrics
    - Delegate heavy work (develop, test) to Task sub-agents
    - Use Skill for lightweight operations (verify, report)
```

---

## Examples

### Basic Super Cycle (5 iterations)
```
/da:super
```

### Extended Super Cycle (10 iterations)
```
/da:super 10
```

### Resume Interrupted Cycle
```
/da:super resume
```

### Check Progress
```
/da:super status
```

### Cancel
```
/da:super cancel
```

---

## Boundaries

**Will:**
- Measure all 7 quality lenses every cycle
- Auto-select weakest lens for focused improvement
- Run full Analyze→Plan→Develop→Test→Evaluate→Memory pipeline per cycle
- Track regression across lenses
- Generate per-cycle and final reports
- Protect session via stop hook

**Will Not:**
- Exceed max N cycles without user restart
- Skip Radar Scan before any cycle
- Ignore regression warnings
- Operate without state file
- Override pipeline guard or loop guard priority

## Iron Law

**N회 반복 또는 모든 렌즈 85+ 달성까지 멈추지 않는다. 각 사이클 전에 반드시 Radar Scan을 실행한다.**

ARGUMENTS: $ARGUMENTS
