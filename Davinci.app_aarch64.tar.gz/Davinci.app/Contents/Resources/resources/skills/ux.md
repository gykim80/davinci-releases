---
name: ux
description: "UX Validation + Planning + Evaluation + Improvement. 6 modes: --pre, --post, --audit, --improve, --research, --autonomous. 8-Dim UX Score (Cognitive Load 포함), LLM Heuristic Engine, HEART Proxy, WCAG 2.1 AA, UX Diff, UX Debt Register (자동 등록), --ci JSON output."
agent: ux-designer
agents: [ux-designer, frontend-architect, qa-strategist]
davinci-phase: null
allowed-tools: [Read, Glob, Grep, Bash, Write, Edit, Task, WebSearch, WebFetch, AskUserQuestion]
next-skill: design
skill-type: flexible
thinking: ultra
mcp-servers: [codegraph, playwright, context7]
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 검증자: items[] 기반 match rate와 4값 verdict(MET/NOT_MET/BLOCKED/IMPOSSIBLE)를 handoff에 포함. 생성자와 다른 컨텍스트에서 실행된다.

# /da:ux — UX Validation & Improvement Engine

전체 파이프라인에서 UX 품질을 검증·기획·평가·개선하는 전담 스킬.
`da:plan` / `da:design` 앞뒤 어디서든 실행 가능. 코드 기반 분석 전용 (스크린샷 절대 금지).

## Usage
```
/da:ux [target] [--pre|--post|--audit|--improve|--research|--autonomous] [--depth quick|standard|deep] [--fix-only critical|high|all] [--ci] [--legacy-score]
```

**Flags**:
- `--ci`: Non-interactive JSON output (CI/CD 파이프라인 통합용). exit code 0: score≥75, exit code 1: score<75 or P0
- `--legacy-score`: 8-Dim 대신 7-Dim 방식으로 점수 계산 (이전 감사 결과와 직접 비교 시)

## Mode Detection (Auto)
```yaml
No_flag_given:
  # Step 1: src/ 경로 자동 탐지
  path_detection:
    - Glob("**/package.json") 또는 Glob("**/pyproject.toml") → 프로젝트 루트
    - {root}/src/ 존재 확인 → target = "src/"
    - src/ 없으면 → target = "."
    - PLAN.md만 있고 src/ 없음 → --pre (기획 전 스펙 모드)

  # Step 2: 이전 감사 결과 컨텍스트 확인
  context_check:
    - --ci 플래그 있으면 → --audit {target} 즉시 실행 (AskUserQuestion 생략)
    - Glob("docs/ux/UX-AUDIT*.md") 또는 Glob("**/UX-AUDIT*.md") 실행
    - 발견 시 → AskUserQuestion:
        header: "이전 감사"
        question: "이전 UX 감사 결과({파일명})가 있습니다. 어떻게 진행할까요?"
        options:
          - "새 감사 실행" → --audit {target}
          - "이전 결과 기반 개선" → --improve {target}
    - 미발견 시 → --audit {target} 즉시 실행

--pre:    기획 전 UX 스펙 작성 (da:plan / da:design 실행 전)
--post:   구현 후 UX 감사 (da:design / da:dev 완료 후)
--audit:  독립 실행 — 현재 코드 전면 UX 감사
--improve: 최신 UX-AUDIT 결과 기반 자동 수정
--research: 경쟁사 UX 패턴 조사 (WebSearch)
--autonomous: da:super 호출용 — AskUserQuestion 금지, 자동 판단
```

---

## Phase 0: Context Load

```yaml
1. Load docs/ux/UX-SPEC-*.md (latest, if exists) → baseline spec
2. Load docs/ux/UX-AUDIT-*.md (latest, if exists) → previous score for UX Diff
3. Load docs/{feature}/PLAN.md (if exists) → product context
4. Load docs/.davinci-super.json (if exists) → super cycle context
5. Detect: brownfield vs greenfield, framework type (React/Next/Vue/Tauri/etc.)
```

---

## Mode: --pre (Pre-Design UX Spec)

**When**: Before da:plan or da:design. Creates UX Spec to guide design decisions.

### Phase 1 — Discovery
```yaml
Greenfield:
  - Parse PLAN.md / requirements for user goals
  - Run --research if competitive context is missing
  - AskUserQuestion (if not --autonomous):
      questions: [target users, primary tasks x3, device targets, accessibility requirements]

Brownfield:
  - Glob src/**/*.{tsx,jsx,vue} → analyze existing screens
  - Extract navigation structure, current IA
  - Identify UX debt (inconsistent patterns, missing states)
```

### Phase 2 — UX Spec Generation
```yaml
Output: docs/ux/UX-SPEC-{project}-{date}.md
Contents:
  1. User Personas (2-3): Name, role, goals, pain points, tech savviness
  2. User Journey Maps: Primary flows (top 3 tasks) — step/touchpoint/emotion/friction
  3. Information Architecture: Text-based tree (root → sections → pages → components)
  4. Screen Inventory: All screens with entry/exit points
  5. Interaction Pattern Spec: Which patterns to use for which contexts
  6. Accessibility Requirements: WCAG level, target assistive tech
  7. Microcopy Guidelines: Tone, error format, CTA patterns
  8. UX Success Metrics: Task completion rate targets, error rate ceiling, time-on-task
```

---

## Mode: --post / --audit (UX Audit)

**When**: After da:design or da:dev. Full code-based UX evaluation.

### Phase 1 — Static Analysis (always)
```yaml
1. Map all component files → list of UI screens/flows
2. Nielsen 10 Heuristics check (→ references/heuristics.md)
3. WCAG 2.1 AA static check (→ references/wcag-checklist.md)
4. Microcopy quality audit (→ references/microcopy.md)
5. UX Flow friction analysis (→ references/ux-flows.md)
6. Component consistency check (design token usage)
```

### Phase 2 — LLM Heuristic Engine [NEW]
```yaml
# arXiv 2512.04262 — GPT-4o 코드 레이어 heuristic 평가 84% 정확도
# Iron Law: file:line 없는 이슈 출력 절대 금지
# Token Budget: 컴포넌트당 ≤2,000 tokens

1. Phase 1에서 수집된 주요 컴포넌트 파일 선별
   - 우선순위: Page 컴포넌트 > Layout > Form
   - 500줄+ 파일 → 함수 단위로 청크 분리
2. references/heuristics.md의 LLM Master Prompt에 코드 삽입
3. H1-H10 위반 이슈 추출:
   Issue schema: { heuristic_id, severity(0-4), location(file:line), evidence, fix_suggestion }
4. severity 4 → P0 자동 분류
5. 파일당 최대 5개 이슈 (false positive 방지)
6. 결과 → "H1-H10 Violation Map (LLM)" 섹션으로 UX-AUDIT에 추가
```

### Phase 3 — Dynamic Analysis (if playwright available)
```yaml
Bash: npx playwright test --grep="accessibility" 2>&1 | head -50
Bash: npx axe-core --dir=src 2>&1 | head -100
→ Parse violations → map to UX Score dimensions
```

### Phase 4 — UX Score Calculation (8 Dimensions, 100pt) [UPDATED]
```yaml
# Full scoring matrix → references/ux-score.md
# --legacy-score flag: 7-Dim 구 방식 사용 (이전 기록과 직접 비교 시)

Dimension scores (8-Dim v2):
  IA:             /14  (navigation, content org, labeling, wayfinding, mental model)
  Interaction:    /18  (affordance, feedback, consistency, error prevention, undo)
  Visual:         /13  (typography hierarchy, spacing, color semantics)
  Accessibility:  /18  (contrast, keyboard nav, ARIA, touch targets)
  User_Flow:      /14  (task completion, CTA clarity, cognitive load)
  Responsive:     /10  (mobile layout, touch UX)
  Perf_States:    /5   (loading/skeleton, empty/error states)
  Cognitive_Load: /8   (click depth, form fields, decision points, info density)
  ──────────────────────────────────────
  TOTAL:          /100
  → Dim 8 세부 기준: references/cognitive-load.md

Thresholds:
  < 60:  Critical — da:design 수준 재작업 필요
  60-74: Poor — --improve 즉시 실행
  75-84: Acceptable — 고우선순위 이슈 수정
  85-94: Good — 선택적 개선
  95+:   Excellent
```

### Phase 5 — HEART Proxy Analysis [NEW]
```yaml
# Google HEART 프레임워크 코드 기반 proxy 측정
# 8-Dim 점수에 미포함 — UX-AUDIT 별도 참고 섹션
# AskUserQuestion 없이 실행 (--autonomous 호환)
# 세부 기준: references/heart-proxy.md

1. Happiness:    ErrorBoundary + Empty state 커버리지 + 에러 메시지 품질
2. Engagement:   hover/focus state 완성도 + transition + skeleton 비율
3. Adoption:     온보딩 플로우 + tooltip 수 + progressive disclosure
4. Retention:    localStorage 사용 + 개인화 + 최근 항목
5. Task Success: CTA 명확성 + 성공 피드백 + Cognitive Load 8-A 연계

Output:
  - UX-AUDIT에 "HEART Proxy Score" 섹션 추가
  - 각 차원: High/Medium/Low + evidence(file:line)
  ⚠️ 항상 고지: "코드 구조 proxy. 실제 행동 데이터로 검증 권장."
```

### Phase 6 — UX Diff (이전 감사 결과와 비교)
```yaml
if previous UX-AUDIT exists:
  Calculate delta per dimension (8-Dim vs 8-Dim 비교)
  if previous was 7-Dim: → 호환 비교 + migration 안내 출력
  Flag regressions (negative delta) as CRITICAL
  Output diff table:
    IA:             prev → current  (±delta) ✅/⚠️/❌
    ...
    Cognitive_Load: prev → current  (±delta) [NEW if first 8-Dim]
    TOTAL:          prev → current  (±delta) ⬆️/⬇️
```

### Phase 7 — Issue Priority Queue + UX Debt Auto-Register [UPDATED]
```yaml
Priority_Matrix:
  Critical (P0): Score drop ≥10pt OR WCAG AA violation OR blocking user flow OR LLM severity 4
  High (P1):     Score 5-9pt gap OR heuristic violation affecting core task OR LLM severity 3
  Medium (P2):   Score 1-4pt gap OR microcopy issue OR LLM severity 2
  Low (P3):      Polish / LLM severity 0-1

UX Debt Auto-Register:
  P0 이슈 → docs/ux/UX-DEBT.md에 즉시 자동 등록 (UXD-{n} schema)
  P1 이슈 → "1 sprint 내 등록 권고" 메시지 출력
  중복 방지: 같은 file:line이 이미 UXD에 존재 시 스킵

Sprint Recommendation:
  Open UXD 수 > 10 → WARN: "UX Debt {count}개. 스프린트 15% 할당 권고."
  Open UXD 수 > 5  → INFO: "UX Debt {count}개. 스프린트 10% 할당 권고."

Output: docs/ux/UX-AUDIT-{project}-{date}.md
```

---

## Mode: --improve (UX Fix — Insight-to-Action Loop) [ENHANCED]

```yaml
# Insight-to-Action 루프: 탐지 → 제안 → 적용 → 검증 → UXD 업데이트
# 패턴 참고: FullStory StoryAI, LogRocket Galileo (2025)

1. Load latest UX-AUDIT → extract P0/P1/P2 issues
2. For each issue (P0 → P1 → P2 order):
   a. CodeGraph: Read affected component (codegraph_explore → codegraph_node → read body)
   b. Generate specific fix suggestion (코드 스니펫 + file:line)
   c. [AUTO-FIX] 태그: 기계적으로 적용 가능한 이슈 표시
      자동 적용 대상: ARIA attributes, 색상 대비 토큰, 터치 타깃 min-size, empty state 컴포넌트
   d. --fix-only critical|high|all 플래그에 따라 범위 제한
   e. Apply fix (Edit tool)
   f. Mark as FIXED in audit doc + UX-DEBT.md status → "Resolved"
3. Re-run Phase 1 static check on modified files (scope: changed files only)
4. Recalculate score delta → report improvement
5. If score < 75 after improve → recommend full da:design cycle

Fix Suggestion Format:
  ### [AUTO-FIX] H4-01: aria-label 누락 — src/components/IconButton.tsx:34
  **Issue**: 아이콘 버튼에 aria-label 없음 (WCAG 2.1 AA 위반)
  **Fix**:
  ```tsx
  // Before
  <button onClick={onClick}><TrashIcon /></button>
  // After
  <button onClick={onClick} aria-label="Delete item"><TrashIcon /></button>
  ```
```

---

## Mode: --research (Competitive UX)

```yaml
1. Identify product category from PLAN.md or user context
2. WebSearch: "{category} best UX patterns 2025"
3. WebSearch: "{competitors} navigation UX"
4. Extract: IA patterns, interaction conventions, CTA patterns
5. Compare vs current implementation gaps
6. Output: docs/ux/UX-RESEARCH-{project}-{date}.md
   - Competitive matrix (features × UX quality)
   - Convention map (what users expect in this category)
   - Differentiation opportunities
```

---

## Mode: --autonomous (da:super Integration)

```yaml
# AskUserQuestion 완전 금지. 자동 판단만.
# 신규: Phase 2 LLM Heuristic + Phase 5 HEART Proxy도 포함
1. Load super context (docs/.davinci-super.json)
2. Run --audit (Phase 1+2+4+5 only, skip Playwright if slow)
   - Phase 1: Static Analysis
   - Phase 2: LLM Heuristic Engine (top 5 컴포넌트만)
   - Phase 4: 8-Dim Score Calculation
   - Phase 5: HEART Proxy Analysis
3. Auto-identify top 3 P0/P1 issues
4. Run --improve for those 3 issues (Insight-to-Action 루프)
5. Recalculate score delta
6. Return: { before_score, after_score, delta, issues_fixed, heart_proxy }
   → da:super UI/UX lens updates with new score
```

---

## Mode: --ci (CI/CD Integration) [NEW]

```yaml
# Non-interactive JSON output. AskUserQuestion 완전 금지.
# GitHub Actions, Railway CI 등 파이프라인 통합용.

Behavior:
  - 모든 마크다운 출력 제거 → JSON stdout만
  - Phase 1+2+4 실행 (Phase 3 Playwright skip for speed)
  - exit code 0: score ≥ 75 AND P0 이슈 없음
  - exit code 1: score < 75 OR P0 이슈 존재

Output JSON Schema:
  {
    "version": "8-dim-v2",
    "score": 82,
    "prev_score": 78,
    "delta": 4,
    "dimensions": {
      "ia": 12, "interaction": 15, "visual": 11,
      "accessibility": 16, "user_flow": 12,
      "responsive": 9, "perf_states": 4, "cognitive_load": 6
    },
    "heart": {
      "happiness": "High", "engagement": "Medium",
      "adoption": "High", "retention": "Low", "task_success": "High"
    },
    "issues": [
      { "id": "H4-01", "priority": "P0", "heuristic": "H1",
        "file": "src/components/Form.tsx", "line": 42,
        "severity": 4, "message": "No loading state on form submit",
        "fix": "Add isLoading state + disabled button" }
    ],
    "wcag_violations": 0,
    "llm_issues_found": 3,
    "ux_debt_open": 5,
    "passed": true
  }
```

---

## UX Debt Register Schema

```markdown
# UX Debt Register — docs/ux/UX-DEBT.md

## UXD-{number}: {title}

- **Category**: {IA|Interaction|Visual|Accessibility|User_Flow|Responsive|Perf_States|Cognitive_Load}
- **Source**: {--audit|--post|manual}
- **Discovered**: {YYYY-MM-DD} (Release: {version or "dev"})
- **Impact**: {High|Medium|Low}
- **Effort**: {S(≤2h)|M(≤1d)|L(≤3d)|XL(>3d)}
- **Status**: {Open|In Progress|Resolved}
- **Files**: {file:line, ...}
- **Sprint**: {sprint ID or "Unscheduled"}
- **Notes**: {optional}
```

**Auto-populate rules**:
- P0 → 즉시 자동 등록 (`--audit`/`--post` 완료 시)
- P1 → "1 sprint 내 등록 권고" 출력
- 중복 방지: file:line 동일 시 기존 항목 업데이트
- `--improve` 완료 시: Status → "Resolved"

---

## Core Systems

- **8-Dimension UX Score**: references/ux-score.md (scoring matrix, 7→8-Dim migration table)
- **LLM Heuristic Engine**: references/heuristics.md (H1-H10 prompt templates, 84% accuracy)
- **Cognitive Load (Dim 8)**: references/cognitive-load.md (4 proxy metrics, CLT 기반)
- **HEART Proxy Framework**: references/heart-proxy.md (5-dim code proxy, behavior data 대체)
- **Nielsen 10 Heuristics**: references/heuristics.md (code-based + LLM evaluation)
- **WCAG 2.1 AA Checklist**: references/wcag-checklist.md (axe-core + grep patterns)
- **Microcopy Quality**: references/microcopy.md (button labels, error messages, empty states)
- **UX Flow Analysis**: references/ux-flows.md (friction count, cognitive load measurement)
- **UX Diff Engine**: Before/after comparison across all 8 dimensions with regression alerts
- **UX Debt Register**: docs/ux/UX-DEBT.md — auto-populated, sprint recommendation system

## Iron Law

**NO UX SCORE WITHOUT CODE-BASED EVIDENCE. ALL CLAIMS REQUIRE FILE:LINE CITATIONS.**
**NEVER TAKE SCREENSHOTS OR SEND IMAGES TO LLM. CODE ANALYSIS ONLY.**
**UX DIFF IS MANDATORY IF PREVIOUS AUDIT EXISTS — NEVER SKIP REGRESSION CHECK.**
**MICROCOPY AUDIT READS ACTUAL UI TEXT STRINGS, NOT ASSUMPTIONS.**
**WCAG VIOLATIONS ARE ALWAYS P0 — NEVER DEFER ACCESSIBILITY FIXES.**
**LLM HEURISTIC ISSUES WITHOUT FILE:LINE ARE FORBIDDEN — DISCARD THEM.**
**HEART PROXY IS INFORMATIONAL ONLY — NEVER INCLUDE IN 8-DIM SCORE.**

## Pipeline Integration

```
da:idea → [da:ux --pre] → da:plan → [da:ux --pre refine] → da:work →
  da:system → da:design → [da:ux --post] → da:dev → [da:ux --audit] →
  da:e2e → da:verify → da:report

da:super (UI/UX lens weakest) → da:ux --autonomous → score delta → continue
CI/CD pipeline → da:ux --ci → JSON + exit code → gate decision
```

## Transition
- **Before**: da:idea, da:plan (--pre mode)
- **After**: da:design, da:dev → da:verify (--post / --audit mode)
- **Next**: da:design (if --pre, to guide design), da:improve (if score < 75)
- **In super cycle**: Returns score delta to da:super lens tracker
- **In CI**: JSON output + exit code for pipeline gate
