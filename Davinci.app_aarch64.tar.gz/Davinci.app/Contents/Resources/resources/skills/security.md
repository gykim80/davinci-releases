---
name: security
description: Security audit with OWASP Top 10 scanning, threat modeling, and vulnerability assessment
agent: security-architect
agents: [security-architect, code-analyzer]
davinci-phase: null
allowed-tools: [Read, Glob, Grep, Bash, Write, Task]
next-skill: null
skill-type: rigid
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 검증자: items[] 기반 match rate와 4값 verdict(MET/NOT_MET/BLOCKED/IMPOSSIBLE)를 handoff에 포함. 생성자와 다른 컨텍스트에서 실행된다.

## Tool Parameter Rules -> See CLAUDE.md (ABSOLUTE)
# /da:security - Security Audit

ultrathink


## Purpose
Security audits covering OWASP Top 10 vulnerability scanning, authentication/authorization flow analysis, dependency vulnerability assessment, and threat modeling.

## Usage
```
/da:security [target-path] [--owasp] [--threat-model] [--dependencies]
```

## OWASP Top 10 Checks

1. **A01 Broken Access Control** - Missing auth checks, IDOR, CORS misconfig
2. **A02 Cryptographic Failures** - Weak hashing, plaintext secrets, missing encryption
3. **A03 Injection** - SQL, NoSQL, OS command, LDAP injection
4. **A04 Insecure Design** - Missing threat modeling, insecure patterns
5. **A05 Security Misconfiguration** - Default creds, verbose errors, missing headers
6. **A06 Vulnerable Components** - Known CVEs in dependencies
7. **A07 Auth Failures** - Weak passwords, missing MFA, session issues
8. **A08 Data Integrity Failures** - Insecure deserialization, unsigned updates
9. **A09 Logging Failures** - Missing audit logs, log injection
10. **A10 SSRF** - Unvalidated redirects, internal service access

> MCP Routing: See CLAUDE.md

## 4-Step Security Audit Flow

### 1. Scan
- OWASP Top 10 code inspection
- Detect hardcoded secrets (API keys, passwords, tokens)
- Dependency vulnerability check (npm audit, CVE databases)
- Detect missing input validation

### 2. Model
- Identify attack surface
- Data flow analysis (sensitive data exposure paths)
- Verify authentication/authorization architecture
- STRIDE threat classification

### 3. Recommend
- Severity-based prioritization
- Concrete fix code examples
- Security pattern application guide

### 4. Verify
- Re-scan after fixes
- Confirm no security regressions
- Generate security report

## OWASP Detection Patterns

```yaml
SQL_Injection:
  pattern: String concatenation in queries
  fix: Parameterized queries

XSS:
  pattern: Unescaped user input
  fix: Proper sanitization

CSRF:
  pattern: State-changing GET requests
  fix: CSRF tokens

Auth_Bypass:
  pattern: Missing authorization checks
  fix: Middleware guards

Sensitive_Data:
  pattern: Plaintext secrets
  fix: Environment variables, encryption

Broken_Access:
  pattern: Horizontal/vertical privilege escalation
  fix: RBAC, resource ownership verification
```

## Safety Mode

```yaml
--safe (default):
  - Read-only analysis only
  - No code modifications
  - Report generation only

without --safe:
  - Apply safe auto-fixes (import cleanup, header additions, etc.)
  - Risky fixes require user confirmation
```

## Output Format

```markdown
# Security Audit Report: [Target]

## Critical
  auth.ts:45 SQL injection -> parameterized query
  login.ts:78 weak password hash -> bcrypt

## High
  api.ts:12 missing CSRF token
  config.js:5 hardcoded API key -> env variable

## Medium
  server.ts:1 missing security headers -> helmet

Pass: 42/50 checks
Fail: 8 issues (2 critical)
```

## Boundaries

**Will:**
- Scan for OWASP Top 10 vulnerabilities
- Generate threat models
- Check dependency CVEs
- Provide remediation guidance

**Will Not:**
- Execute actual exploits
- Modify security code without approval
