---
name: monitor
description: "Post-deployment monitoring -- logs, metrics, health checks for Vercel, Railway, Supabase"
agent: devops-guide
agents: [infra-architect]
davinci-phase: null
allowed-tools: [Read, Bash, Glob, Grep, Task]
next-skill: null
skill-type: flexible
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 유틸리티: 부작용(외부 API/배포/삭제) 전 §7 destructive/cost_gate 규칙을 확인한다.

## Tool Parameter Rules -> See CLAUDE.md (ABSOLUTE)
# /da:monitor - Post-Deployment Monitoring Protocol

## Purpose
Post-deployment monitoring for Vercel, Railway, and Supabase. Checks health, collects logs, gathers metrics, and produces a summary report with rollback recommendations.

## Usage
```
/da:monitor [--provider vercel|railway|supabase|all] [--since 1h|6h|24h] [--level error|warn|info]
```

### Arguments
- `--provider` -- Specific provider to monitor (default: auto-detect all deployed)
- `--since` -- Log time window (default: 1h)
- `--level` -- Minimum log level (default: error)

## Behavioral Flow

### Phase 0: Provider Detection
```yaml
Detection:
  vercel:
    - vercel ls --limit 1 succeeds
    - .vercel/ directory or vercel.json exists
  railway:
    - railway status succeeds (linked project)
    - railway.toml or .railwayignore exists
  supabase:
    - supabase projects list succeeds
    - supabase/ directory with config.toml exists
  Skip_Logic:
    - Unauthenticated or uninstalled provider -> skip with notice
```

### Phase 1: Health Check
```yaml
Health_Check:
  - For each deployed URL, run: curl -sI <url> | head -5
  - Verify HTTP 200 response
  - Measure response time: curl -w "%{time_total}" -o /dev/null -s <url>
  - Flag any non-2xx response as FAIL
```

### Phase 2: Log Monitoring
```yaml
Log_Collection:
  vercel:
    command: vercel logs --json --follow --level error --since 1h
    action: Collect error-level logs from last hour
    note: Adjust --level and --since per arguments

  supabase:
    commands:
      - supabase inspect db cache-hit
      - supabase inspect db long-running-queries
      - supabase inspect db seq-scans
    action: Check DB performance indicators
    edge_functions: supabase functions logs --limit 50

  railway:
    command: railway logs --json -n 100
    action: Collect last 100 log entries
    filter: Parse JSON for error/warn level entries
```

### Phase 3: Metric Summary
```yaml
Metrics:
  vercel:
    - vercel inspect <deployment-url> (deployment details)
    - Response time via curl -w "%{time_total}" -o /dev/null -s <url>
    - vercel ls --limit 5 (recent deployments)

  supabase:
    - supabase inspect db table-sizes
    - supabase inspect db index-usage
    - Cache hit ratio from Phase 2

  railway:
    - railway status --json (service health)
    - Memory/CPU from dashboard or logs
```

### Phase 4: Report
```yaml
Report:
  format: |
    ## Monitoring Report

    | Provider  | Health | Response Time | Errors (last 1h) |
    |-----------|--------|---------------|-------------------|
    | Vercel    | OK/FAIL| Xms           | N                 |
    | Railway   | OK/FAIL| Xms           | N                 |
    | Supabase  | OK/FAIL| N/A           | N                 |

    ### Issues Found
    - [list any errors, slow queries, low cache hit ratios]

    ### Rollback Recommendation
    - [Yes/No with reasoning]

  Rollback_Trigger:
    - Health check FAIL on any provider
    - Error rate exceeds 5% in log window
    - Response time exceeds 3x baseline
```

### Rollback Guide (per provider)
```yaml
Rollback:
  vercel:
    immediate: vercel rollback
    specific: vercel rollback <deployment-id>
    list: vercel ls --limit 5

  railway:
    immediate: railway redeploy
    stop: railway down
    recover: railway up --environment=production

  supabase:
    note: "Automatic rollback not available -- manual revert migration required"
    steps:
      1. supabase migration new rollback_<name>
      2. Write reverse SQL (DROP/ALTER etc.)
      3. supabase db push
    warning: "Potential data loss -- always backup before proceeding"
```

## Boundaries

**Will:**
- Auto-detect deployed providers and check health
- Collect logs and surface errors
- Measure response times and DB metrics
- Recommend rollback when error thresholds are exceeded

**Will Not:**
- Automatically execute rollbacks (user confirmation required)
- Modify deployment configurations
- Access provider dashboards or billing information
- Replace proper APM/observability tooling for production workloads
