---
name: asset
description: Enhance web/game application completeness with AI image asset generation. Asset audit → generation → auto-apply via multi-provider (Gemini, OpenAI, OpenRouter, fal.ai, BytePlus).
agent: asset-gen-artist
agents: [image-gen-artist, frontend-architect, game-developer]
davinci-phase: null
allowed-tools: [Write, Edit, Read, Bash, Glob, Grep, Task, AskUserQuestion]
next-skill: verify
skill-type: flexible
skills-ref:
  - davinci_framework/agent-skills/skills/mengto-unsplash-asset-images
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 생성자: 자기 검증은 사전 점검일 뿐이다. 최종 판정은 독립 verify 노드가 낸다. 미완료 시 partial + remaining.

# /da:asset - AI Image Asset Generation

## MengTo Reference Skills (on-demand — 필요 시에만 Read)
> 경로: `~/.claude/plugin/agent-skills/skills/<name>/SKILL.md`
- `mengto-unsplash-asset-images`: AI 생성 실패/비용 부담 시 Unsplash 스톡 fallback


## 🚨 ABSOLUTE FIRST ACTION — Execute immediately upon reading 🚨

**You MUST execute the following actions in order in your first response.**

```
[Action 1] Framework detection:
  Bash: cat package.json 2>/dev/null | python3 -c "
    import json,sys
    d=json.load(sys.stdin).get('dependencies',{})
    dd=json.load(open('package.json')).get('devDependencies',{}) if True else {}
    mode='game' if 'three' in d or '@react-three/fiber' in d else 'web'
    print(f'MODE={mode}')
  " || echo "MODE=web"

[Action 2] Provider + API key check (multi-provider):
  Bash: |
    PROVIDER="${IMAGE_GEN_PROVIDER:-NOT_SET}"
    if [ "$PROVIDER" != "NOT_SET" ]; then
      echo "PROVIDER=$PROVIDER MODEL=${IMAGE_GEN_MODEL:-default}"
      case "$PROVIDER" in
        gemini)     echo "${GEMINI_API_KEY:-NOT_SET}" | head -c 10 ;;
        openai)     echo "${OPENAI_API_KEY:-NOT_SET}" | head -c 10 ;;
        openrouter) echo "${OPENROUTER_API_KEY:-NOT_SET}" | head -c 10 ;;
        fal.ai)     echo "${FAL_KEY:-NOT_SET}" | head -c 10 ;;
        byteplus)   echo "${BYTE_KEY:-${ARK_API_KEY:-NOT_SET}}" | head -c 10 ;;
      esac
    else
      # Legacy fallback: check GEMINI_API_KEY / GEMINI_IMAGE_API_KEY
      echo "${GEMINI_API_KEY:-${GEMINI_IMAGE_API_KEY:-NOT_SET}}" | head -c 10
    fi
  # If all keys "NOT_SET":
  AskUserQuestion:
    question: "No image generation provider configured. Please enter an API key or configure in Settings > Models > Image Generation."
    header: "API Key"
    options:
      - label: "Enter Gemini key"
        description: "API key from Google AI Studio (default provider)"
      - label: "Enter OpenAI key"
        description: "API key from OpenAI Platform"
      - label: "Skip"
        description: "Run audit only without image generation"

[Action 3] Python dependency check:
  Bash: python3 -c "import PIL; print('Pillow OK')" 2>/dev/null || echo "NEED_PILLOW"

[Action 4] Run asset audit → proceed to Phase 1
```

### FORBIDDEN (never do in first response)
- Generate images without API key verification
- Create asset lists without project scan
- Start image generation without user approval
- Load existing images into conversation context via Read tool

---

## Routing

```yaml
/da:asset (default):
  → Auto-detect: "three" in package.json → --game, otherwise → --web
  → Phase 0 → Phase 1 (Audit) → Phase 2 (Plan) → Phase 3 (Generate) → Phase 4 (Apply) → Phase 5 (Validate)

/da:asset --web:
  → Web assets only (Hero, OG, Favicon, Empty State, etc.)
  → Phase 0 → 1 → 2 → 3 → 4 → 5

/da:asset --game:
  → Game assets only (Sprite, Texture, Tileset, UI, Particle)
  → Phase 0 → 1 → 1.5 (Art Style Select) → 2 → 3 → 4 → 5

/da:asset --audit-only:
  → Run audit only without generation → output asset-audit-report.json and exit

/da:asset --replace <path>:
  → Interactively replace a single image (multi-turn editing)
  → Backup original → generate → compare → approve/rollback

/da:asset --clone <element-map-path>:
  → da:clone v2 파이프라인에서 호출됨
  → element-map.json 기반 에셋 목록 자동 구성 (수동 audit 스킵)
  → Phase 0 → Phase 2 (Generate) → Phase 4 (Apply)
  → element-map.json의 각 요소를 개별 투명 PNG로 생성
  → prompt_builder.py 4-Layer 프롬프트로 스타일 일관성 유지
  → 배경 인페인팅 (inpainter.py) + 요소 재생성 (element_generator.py)
  → 스프라이트 포지 (sprite_forge.py, sprite_candidate=true만)
```

## Phase 0: DETECT (auto-execute)

```yaml
Step_1_Framework_Detection:
  Bash: |
    # Detect framework + game engine from package.json
    python3 -c "
    import json, os
    pkg = json.load(open('package.json')) if os.path.exists('package.json') else {}
    deps = {**pkg.get('dependencies',{}), **pkg.get('devDependencies',{})}
    framework = 'nextjs' if 'next' in deps else 'vite' if 'vite' in deps else 'cra' if 'react-scripts' in deps else 'static'
    is_game = 'three' in deps or '@react-three/fiber' in deps
    print(f'FRAMEWORK={framework}')
    print(f'IS_GAME={is_game}')
    print(f'MODE={\"game\" if is_game else \"web\"}')
    "

Step_2_Provider_Detection:
  # Multi-provider detection (IMAGE_GEN_PROVIDER injected by session_start)
  # Env vars available: IMAGE_GEN_PROVIDER, IMAGE_GEN_MODEL,
  #   GEMINI_API_KEY, OPENAI_API_KEY, OPENROUTER_API_KEY, FAL_KEY
  Bash: |
    echo "IMAGE_GEN_PROVIDER=${IMAGE_GEN_PROVIDER:-NOT_SET}"
    echo "IMAGE_GEN_MODEL=${IMAGE_GEN_MODEL:-NOT_SET}"

  # Provider routing logic:
  #   1. If IMAGE_GEN_PROVIDER is set → use that provider
  #   2. If NOT_SET → fallback to legacy GEMINI_API_KEY / GEMINI_IMAGE_API_KEY behavior
  #   3. If no provider and no legacy key → fallback to --audit-only

Step_3_API_Key_Check:
  # Verify API key exists for the detected provider
  Bash: |
    PROVIDER="${IMAGE_GEN_PROVIDER:-NOT_SET}"
    if [ "$PROVIDER" = "NOT_SET" ]; then
      # Legacy fallback: check GEMINI_API_KEY or GEMINI_IMAGE_API_KEY
      if [ -n "${GEMINI_API_KEY:-}" ]; then
        echo "PROVIDER=gemini (legacy fallback via GEMINI_API_KEY)"
      elif [ -n "${GEMINI_IMAGE_API_KEY:-}" ]; then
        echo "PROVIDER=gemini (legacy fallback via GEMINI_IMAGE_API_KEY)"
      else
        echo "NO_PROVIDER: No image generation provider configured"
        echo "Setup: Settings > Models > Image Generation, or set GEMINI_API_KEY env"
      fi
    else
      # Verify the provider's API key exists
      case "$PROVIDER" in
        gemini)
          [ -n "${GEMINI_API_KEY:-}" ] && echo "KEY=OK" || echo "KEY=MISSING: Set GEMINI_API_KEY" ;;
        openai)
          [ -n "${OPENAI_API_KEY:-}" ] && echo "KEY=OK" || echo "KEY=MISSING: Set OPENAI_API_KEY" ;;
        openrouter)
          [ -n "${OPENROUTER_API_KEY:-}" ] && echo "KEY=OK" || echo "KEY=MISSING: Set OPENROUTER_API_KEY" ;;
        fal.ai)
          [ -n "${FAL_KEY:-}" ] && echo "KEY=OK" || echo "KEY=MISSING: Set FAL_KEY" ;;
        byteplus)
          [ -n "${BYTE_KEY:-${ARK_API_KEY:-}}" ] && echo "KEY=OK" || echo "KEY=MISSING: Set BYTE_KEY or ARK_API_KEY" ;;
        *)
          echo "KEY=UNKNOWN_PROVIDER: $PROVIDER" ;;
      esac
    fi

  # If no key available for any provider:
  #   → AskUserQuestion for API key, or fallback to --audit-only

Step_4_Dependency_Check:
  # Pillow: Required for sprite sheet assembly
  # rembg: Transparent background removal (optional in game mode)
  # cwebp: WebP conversion (optional in web mode)
  Bash: |
    python3 -c "import PIL; print('OK')" 2>/dev/null || echo "NEED: uv pip install Pillow"
    which cwebp >/dev/null 2>&1 || echo "OPTIONAL: brew install webp"

Step_5_Design_DNA_Check:
  # Auto-load if design-reference.json exists (da:design deliverable)
  Bash: |
    for f in design-reference.json .design-ref/design-reference.json; do
      [ -f "$f" ] && echo "DESIGN_DNA=$f" && break
    done || echo "DESIGN_DNA=NONE"
```

## Phase 1: AUDIT (Asset Audit)

```yaml
Web_Scan:
  # Search image reference patterns with Grep tool
  Grep: pattern="(src=[\"']|background-image:|url\\()" glob="*.{tsx,jsx,html,css}"
  Grep: pattern="(placeholder\\.com|placehold\\.co|picsum\\.photos)" glob="*.{tsx,jsx,html}"
  Grep: pattern="src=[\"']\\s*[\"']|src=[\"']#[\"']|src=[\"']TODO" glob="*.{tsx,jsx,html}"

  # Verify meta image existence
  Glob: pattern="**/favicon*"
  Glob: pattern="**/og-image*"
  Glob: pattern="**/apple-touch-icon*"

Game_Scan:
  # Search Three.js texture references
  Grep: pattern="(TextureLoader|useTexture|useGLTF|loadTexture)" glob="*.{tsx,jsx,ts,js}"
  Grep: pattern="new MeshBasicMaterial|new MeshStandardMaterial" glob="*.{tsx,jsx,ts,js}"
  # Detect hardcoded colors (using color only without textures)
  Grep: pattern="color:\\s*(0x[0-9a-fA-F]+|[\"']#)" glob="*.{tsx,jsx,ts,js}"

Style_Extraction:
  # Extract styles in priority order
  # 1. design-reference.json (da:design deliverable)
  # 2. tailwind.config.ts → theme.extend.colors
  # 3. CSS variables (globals.css, --primary, etc.)
  # → compose style_anchor prompt

Output:
  # Generate asset-audit-report.json
  # {
  #   "mode": "web|game",
  #   "framework": "nextjs|vite|static",
  #   "style_anchor": { "palette": [...], "mood": "..." },
  #   "assets": [
  #     { "type": "placeholder", "file": "...", "line": N, "action": "generate" },
  #     { "type": "missing_favicon", "action": "generate" },
  #     { "type": "texture_missing", "file": "...", "line": N, "action": "generate" }
  #   ],
  #   "summary": { "total_gaps": N, "generate": N, "replace": N, "skip": N }
  # }

  # Output summary table to user:
  # "📊 Asset Audit Results:
  #  | Type | Count | Recommended Action |
  #  |------|-------|-------------------|
  #  | Placeholder images | 3 | Generate |
  #  | Missing Favicon | 1 | Generate |
  #  | Objects without textures | 5 | Generate |"

  # Exit here if --audit-only
```

## Phase 1.5: STYLE SELECT (--game mode only)

```yaml
# Execute only in --game mode
AskUserQuestion:
  questions:
    - question: "Please select an art style for the game assets"
      header: "Art Style"
      options:
        - label: "Pixel Art"
          description: "Retro dot graphics (8-bit~16-bit style)"
        - label: "Hand-Drawn"
          description: "Hand-drawn feel, soft lines (indie games)"
        - label: "Vector/Flat"
          description: "Clean vector style, modern casual games"
        - label: "Realistic/Painterly"
          description: "Realistic painting, high-detail assets"
      multiSelect: false

  # Store selection result → art_style variable
  # Inject into Layer 1 of all game asset prompts
```

## Phase 2: PLAN (Generation Plan)

```yaml
Step_1_Asset_List:
  # Extract "action: generate|replace" items from asset-audit-report.json
  # Compose 4-Layer prompts for each item

Step_2_Prompt_Composition:
  # Layer 1 — Style DNA Injection:
  #   "Color palette: {palette_hex}. Mood: {mood}. Archetype: {archetype}."
  #   Game mode: "Art style: {art_style}."
  # Layer 2 — Asset Context:
  #   Web: "Hero background for SaaS landing page" / "Social preview card"
  #   Game: "Character idle sprite frame 1 of 4, facing right"
  # Layer 3 — Anti-AI Directives:
  #   "Professional quality. Natural imperfections. No AI artifacts.
  #    No lens flare. No plastic textures. No embedded text."
  # Layer 4 — Technical Specs:
  #   "No text, no watermarks. PNG format. {WxH}. {transparent if needed}."

Step_3_Model_Selection:
  # Select optimal model per asset — provider-aware
  #
  # If IMAGE_GEN_MODEL is set (via Settings), use that model for all assets.
  # Otherwise, select model based on provider + asset complexity:
  #
  # Gemini (default):
  #   Hero/CTA/characters → gemini-3.1-flash-image-preview (NB2, high quality)
  #   Tilesets/patterns/icons/particles → gemini-2.5-flash-image (NB1, lightweight)
  #   Complex scenes/concept art → gemini-3-pro-image-preview (Pro, highest quality)
  #
  # OpenAI:
  #   All assets → gpt-image-1 (or dall-e-3 if configured)
  #
  # OpenRouter:
  #   All assets → configured model (e.g., google/gemini-3.1-flash-image-preview)
  #
  # fal.ai:
  #   High quality → fal-ai/seedream-v4.0 or seedream-v5.0-lite
  #   Fast/bulk → fal-ai/flux-pro/v1.1-ultra
  #
  # BytePlus (ModelArk):
  #   Best → seedream-5.0 (latest)
  #   High quality → seedream-4.5 or seedream-4.0
  #   Economy → seedream-3.0

Step_4_Cost_Estimate:
  # Calculate image count × per-model cost
  # e.g.: NB2 x 5 + NB1 x 8 = $0.25 + $0.32 = $0.57
  # 11% of $5 budget used

Step_5_User_Approval:
  # Request generation plan + cost approval via AskUserQuestion
  # "📋 Generation Plan: 13 images, estimated cost $0.57
  #  | Asset | Model | Cost |
  #  |-------|-------|------|
  #  | Hero background | NB2 | $0.05 |
  #  | Feature illustrations x4 | NB1 | $0.16 |
  #  Proceed?"
```

## Phase 3: GENERATE (Image Generation)

```yaml
Step_0_Resolve_Provider:
  # Determine provider + model + API key for this generation session
  # Priority: IMAGE_GEN_PROVIDER env (set by session_start) > legacy env fallback
  Bash: |
    PROVIDER="${IMAGE_GEN_PROVIDER:-NOT_SET}"
    if [ "$PROVIDER" = "NOT_SET" ]; then
      # Legacy fallback
      if [ -n "${GEMINI_API_KEY:-}" ] || [ -n "${GEMINI_IMAGE_API_KEY:-}" ]; then
        PROVIDER="gemini"
        export GEMINI_API_KEY="${GEMINI_API_KEY:-${GEMINI_IMAGE_API_KEY}}"
        export IMAGE_GEN_MODEL="${IMAGE_GEN_MODEL:-gemini-2.0-flash-exp}"
      else
        echo "ERROR: No image generation provider available"
        echo "Configure in: Settings > Models > Image Generation"
        echo "Or set env: GEMINI_API_KEY, OPENAI_API_KEY, OPENROUTER_API_KEY, FAL_KEY, or ARK_API_KEY"
        exit 1
      fi
    fi
    echo "Using provider: $PROVIDER, model: ${IMAGE_GEN_MODEL:-default}"

Step_1_Generate:
  # Provider adapter routing — call appropriate API per provider
  # Each provider uses its own curl template and response parser

  # ──────────────────────────────────────────────────────────
  # GEMINI ADAPTER
  # ──────────────────────────────────────────────────────────
  # Env: GEMINI_API_KEY, IMAGE_GEN_MODEL
  # Endpoint: generativelanguage.googleapis.com/v1beta/models/{model}:generateContent
  # Auth: x-goog-api-key header
  # Response: candidates[0].content.parts[N].inline_data.data (base64 PNG)
  Gemini_Generate:
    Bash: |
      curl -s -X POST \
        "https://generativelanguage.googleapis.com/v1beta/models/${IMAGE_GEN_MODEL}:generateContent" \
        -H "x-goog-api-key: ${GEMINI_API_KEY}" \
        -H "Content-Type: application/json" \
        -d '{
          "contents": [{"parts": [{"text": "{4-layer-prompt}"}]}],
          "generationConfig": {"responseModalities": ["IMAGE"]}
        }' | python3 -c "
      import json, sys, base64, os
      r = json.load(sys.stdin)
      if 'error' in r:
          print('FAIL:' + json.dumps(r['error']))
          sys.exit(1)
      parts = r.get('candidates', [{}])[0].get('content', {}).get('parts', [])
      for part in parts:
          if 'inlineData' in part:
              os.makedirs('{output_dir}', exist_ok=True)
              with open('{output_dir}/{filename}', 'wb') as f:
                  f.write(base64.b64decode(part['inlineData']['data']))
              print('OK:{output_dir}/{filename}')
              break
      else:
          print('FAIL:' + json.dumps(r.get('promptFeedback', 'no_image_in_response')))
      "

  # ──────────────────────────────────────────────────────────
  # OPENAI ADAPTER
  # ──────────────────────────────────────────────────────────
  # Env: OPENAI_API_KEY, IMAGE_GEN_MODEL
  # Endpoint: api.openai.com/v1/images/generations
  # Auth: Bearer token
  # Response: data[0].b64_json (base64)
  OpenAI_Generate:
    Bash: |
      curl -s -X POST "https://api.openai.com/v1/images/generations" \
        -H "Authorization: Bearer ${OPENAI_API_KEY}" \
        -H "Content-Type: application/json" \
        -d '{
          "model": "${IMAGE_GEN_MODEL}",
          "prompt": "{4-layer-prompt}",
          "n": 1,
          "size": "1024x1024",
          "output_format": "b64_json"
        }' | python3 -c "
      import json, sys, base64, os
      r = json.load(sys.stdin)
      if 'error' in r:
          print('FAIL:' + json.dumps(r['error']))
          sys.exit(1)
      data = r.get('data', [])
      if data and 'b64_json' in data[0]:
          os.makedirs('{output_dir}', exist_ok=True)
          with open('{output_dir}/{filename}', 'wb') as f:
              f.write(base64.b64decode(data[0]['b64_json']))
          print('OK:{output_dir}/{filename}')
      else:
          print('FAIL:no_image_data')
      "

  # ──────────────────────────────────────────────────────────
  # OPENROUTER ADAPTER
  # ──────────────────────────────────────────────────────────
  # Env: OPENROUTER_API_KEY, IMAGE_GEN_MODEL
  # Endpoint: openrouter.ai/api/v1/chat/completions
  # Auth: Bearer token
  # Response: choices[0].message.content (multimodal — may contain base64 image)
  OpenRouter_Generate:
    Bash: |
      curl -s -X POST "https://openrouter.ai/api/v1/chat/completions" \
        -H "Authorization: Bearer ${OPENROUTER_API_KEY}" \
        -H "Content-Type: application/json" \
        -d '{
          "model": "${IMAGE_GEN_MODEL}",
          "messages": [{"role": "user", "content": "Generate image: {4-layer-prompt}"}]
        }' | python3 -c "
      import json, sys, base64, os, re
      r = json.load(sys.stdin)
      if 'error' in r:
          print('FAIL:' + json.dumps(r['error']))
          sys.exit(1)
      choices = r.get('choices', [])
      if not choices:
          print('FAIL:no_choices')
          sys.exit(1)
      content = choices[0].get('message', {}).get('content', '')
      # OpenRouter multimodal: content may be a list of parts or a string
      if isinstance(content, list):
          for part in content:
              if isinstance(part, dict) and part.get('type') == 'image_url':
                  url = part.get('image_url', {}).get('url', '')
                  if url.startswith('data:image'):
                      b64 = url.split(',', 1)[1] if ',' in url else ''
                      os.makedirs('{output_dir}', exist_ok=True)
                      with open('{output_dir}/{filename}', 'wb') as f:
                          f.write(base64.b64decode(b64))
                      print('OK:{output_dir}/{filename}')
                      sys.exit(0)
      elif isinstance(content, str):
          # Try to extract base64 from inline data URI
          m = re.search(r'data:image/[^;]+;base64,([A-Za-z0-9+/=]+)', content)
          if m:
              os.makedirs('{output_dir}', exist_ok=True)
              with open('{output_dir}/{filename}', 'wb') as f:
                  f.write(base64.b64decode(m.group(1)))
              print('OK:{output_dir}/{filename}')
              sys.exit(0)
      print('FAIL:no_image_in_response (OpenRouter multimodal parsing failed)')
      "

  # ──────────────────────────────────────────────────────────
  # FAL.AI ADAPTER
  # ──────────────────────────────────────────────────────────
  # Env: FAL_KEY, IMAGE_GEN_MODEL
  # Endpoint: fal.run/{model} (e.g., fal.run/fal-ai/seedream-v4.0)
  # Auth: Key header
  # Response: images[0].url (URL — needs download)
  FalAI_Generate:
    Bash: |
      curl -s -X POST "https://fal.run/${IMAGE_GEN_MODEL}" \
        -H "Authorization: Key ${FAL_KEY}" \
        -H "Content-Type: application/json" \
        -d '{
          "prompt": "{4-layer-prompt}",
          "image_size": "landscape_16_9",
          "num_images": 1
        }' | python3 -c "
      import json, sys, os, subprocess
      r = json.load(sys.stdin)
      if 'detail' in r:
          print('FAIL:' + json.dumps(r['detail']))
          sys.exit(1)
      images = r.get('images', [])
      if images and 'url' in images[0]:
          url = images[0]['url']
          os.makedirs('{output_dir}', exist_ok=True)
          out_path = '{output_dir}/{filename}'
          # Download image from URL
          result = subprocess.run(
              ['curl', '-s', '-o', out_path, url],
              capture_output=True, text=True
          )
          if result.returncode == 0 and os.path.exists(out_path) and os.path.getsize(out_path) > 1000:
              print('OK:' + out_path)
          else:
              print('FAIL:download_failed')
      else:
          print('FAIL:no_image_url')
      "

  # ──────────────────────────────────────────────────────────
  # BYTEPLUS MODELARK ADAPTER (OpenAI 호환)
  # ──────────────────────────────────────────────────────────
  # Env: BYTE_KEY (or ARK_API_KEY fallback), IMAGE_GEN_MODEL
  # Endpoint: ark.ap-southeast.bytepluses.com/api/v3/images/generations
  # Auth: Bearer token
  # Response: OpenAI 호환 — data[0].b64_json (base64)
  BytePlus_Generate:
    Bash: |
      curl -s -X POST "https://ark.ap-southeast.bytepluses.com/api/v3/images/generations" \
        -H "Authorization: Bearer ${BYTE_KEY:-${ARK_API_KEY}}" \
        -H "Content-Type: application/json" \
        -d '{
          "model": "${IMAGE_GEN_MODEL}",
          "prompt": "{4-layer-prompt}",
          "size": "1024x1024",
          "n": 1,
          "response_format": "b64_json"
        }' | python3 -c "
      import json, sys, os, base64
      r = json.load(sys.stdin)
      if 'error' in r:
          print('FAIL:' + json.dumps(r['error']))
          sys.exit(1)
      data = r.get('data', [])
      if data and 'b64_json' in data[0]:
          img_bytes = base64.b64decode(data[0]['b64_json'])
          os.makedirs('{output_dir}', exist_ok=True)
          out_path = '{output_dir}/{filename}'
          with open(out_path, 'wb') as f:
              f.write(img_bytes)
          if os.path.getsize(out_path) > 1000:
              print('OK:' + out_path)
          else:
              print('FAIL:empty_image')
      else:
          print('FAIL:no_b64_data')
      "

Step_2_Quality_Check:
  # Verify file size (0 bytes = failure)
  Bash: |
    file_size=$(wc -c < "{output_path}" 2>/dev/null || echo 0)
    [ "$file_size" -gt 1000 ] && echo "QUALITY:OK" || echo "QUALITY:FAIL"
  # On failure, modify prompt and retry up to 2 times

Step_3_Cost_Tracking:
  # Calculate cumulative cost per provider
  # Gemini: NB2 ~$0.05/image, NB1 ~$0.04, Pro ~$0.13 (preview: free)
  # OpenAI: gpt-image-1 ~$0.04/image (1024x1024), dall-e-3 ~$0.04-0.12
  # OpenRouter: varies by underlying model
  # fal.ai: Seedream ~$0.03/image, Flux Pro ~$0.05/image
  # BytePlus: Seedream 3.0 ~$0.02, Seedream 4.0/4.5/5.0 ~$0.03
  # Warning at 80% budget → auto-downgrade model tier

Step_4_Batch_Delay:
  # API rate limit prevention: 1 second delay between images
  # Exponential backoff on error (2s, 4s, 8s, max 3 retries)
```

### --replace Mode (Interactive Editing)
```yaml
# Multi-turn image modification — uses the same provider adapter from Step_1_Generate
# ⚠️ ThoughtSignature: Include full content of previous response in next request
# Note: --replace mode uses whichever provider is configured (Gemini/OpenAI/OpenRouter/fal.ai)
#       Multi-turn editing is best supported by Gemini (ThoughtSignature passthrough).
#       Other providers: each turn is an independent generation (no conversation history).
Step_1_Backup:
  Bash: mkdir -p .da-asset/backups && cp "{original_path}" .da-asset/backups/

Step_2_Initial_Generate:
  # Analyze existing image alt text and surrounding code → compose prompt
  # Generate first image using active provider adapter (see Step_1_Generate above)

Step_3_User_Feedback_Loop (max 5 turns):
  # User: "make it brighter", "change background color", etc.
  # → Add full previous response (including thoughtSignature) to contents
  # → Add modification instruction as new user part
  # → Re-call API

Step_4_Apply_or_Rollback:
  # Approved → copy to original path
  # Rejected → delete generated version, restore from backup
```

## Phase 4: APPLY (Auto-Apply + Post-Processing)

```yaml
Web_Post_Processing:
  WebP_Conversion:
    Bash: cwebp -q 85 "{input}.png" -o "{input}.webp" 2>/dev/null || echo "SKIP_WEBP"
  Responsive_Variants:
    # Original(2x) → 1x(50%) → 0.5x(25%) resize
    Bash: |
      python3 -c "
      from PIL import Image
      img = Image.open('{path}')
      for scale, suffix in [(0.5, '1x'), (0.25, '0.5x')]:
          resized = img.resize((int(img.width*scale), int(img.height*scale)), Image.LANCZOS)
          resized.save('{path}'.replace('.png', f'-{suffix}.png'))
      "
  OG_Image:
    # Generate 1200x630 OG Image based on site title + description
    # prompt: "Social media preview card for {site_title}. {style}. 1200x630."
  Favicon_Set:
    # Generate single icon → resize to multiple sizes with Pillow
    # favicon.ico (32x32), apple-touch-icon (180x180), android-chrome (192x192, 512x512)
    Bash: |
      python3 -c "
      from PIL import Image
      icon = Image.open('{icon_path}')
      sizes = [(32,32,'favicon-32x32.png'), (180,180,'apple-touch-icon.png'),
               (192,192,'android-chrome-192x192.png'), (512,512,'android-chrome-512x512.png')]
      for w,h,name in sizes:
          icon.resize((w,h), Image.LANCZOS).save(f'public/{name}')
      icon.resize((32,32), Image.LANCZOS).save('public/favicon.ico', format='ICO')
      "

Game_Post_Processing:
  Background_Removal:
    # 3-stage fallback chain:
    # 1. Specify solid background in prompt ("solid white background")
    # 2. ImageMagick fuzz removal:
    Bash: convert "{input}" -fuzz 10% -transparent white "{output}" 2>/dev/null
    # 3. rembg AI removal (if installed):
    Bash: python3 -m rembg i "{input}" "{output}" 2>/dev/null || echo "SKIP_REMBG"

  Sprite_Sheet_Assembly:
    # Individual frames → sheet assembly + metadata JSON
    Bash: |
      python3 -c "
      from PIL import Image
      import json, glob, os
      frames = sorted(glob.glob('{sprite_dir}/*.png'))
      if not frames: exit()
      first = Image.open(frames[0])
      fw, fh = first.size
      cols = len(frames)
      sheet = Image.new('RGBA', (fw * cols, fh), (0,0,0,0))
      for i, f in enumerate(frames):
          sheet.paste(Image.open(f), (i * fw, 0))
      sheet.save('{output_sheet}')
      json.dump({'frames': cols, 'frameWidth': fw, 'frameHeight': fh,
                 'totalWidth': fw*cols, 'totalHeight': fh}, open('{output_meta}','w'))
      "

Code_Reference_Update:
  # Update image paths with CodeGraph or Grep+Edit
  # 1. Replace placeholder URL → generated image path
  # 2. Insert new image path into empty src
  # 3. Next.js: <Image src="/assets/generated/..." />
  # 4. Three.js: new TextureLoader().load('/textures/generated/...')

Asset_Manifest:
  # Generate asset-manifest.json
  # Record paths, prompt hashes, costs, and code reference locations for all generated assets
```

## Phase 5: VALIDATE (Verification)

```yaml
Step_1_Build_Check:
  Bash: npm run build 2>&1 | tail -20
  # Check for TypeScript compile errors (image import related)

Step_2_Image_Verify:
  # Verify all generated image files exist + size > 1KB
  Bash: |
    python3 -c "
    import json, os
    manifest = json.load(open('asset-manifest.json'))
    for a in manifest['assets']:
        path = a['file']
        if os.path.exists(path) and os.path.getsize(path) > 1000:
            print(f'✅ {path} ({os.path.getsize(path)} bytes)')
        else:
            print(f'❌ {path} MISSING or EMPTY')
    "

Step_3_Reference_Check:
  # Verify that referenced_in paths in asset-manifest.json actually reference the images
  # Verify references with Grep

Step_4_Report:
  # Output final report:
  # "🎨 Asset Generation Complete:
  #  | Item | Result |
  #  |------|--------|
  #  | Generated images | 13 |
  #  | Applied | 12 |
  #  | Failed | 1 (content filter) |
  #  | Total cost | $0.57 |
  #  | Build | ✅ Success |"
```

## Critical Rules

```yaml
1. Proxy-Safe Image Handling:
   ❌ FORBIDDEN: Loading generated images into conversation context via Read tool
   ❌ FORBIDDEN: Including base64 data in LLM responses
   ✅ REQUIRED: All image operations use Bash base64/curl/python3 only
   ✅ REQUIRED: Image verification by file size/existence only (file, wc -c)

2. User Approval Required:
   - Must present generation plan + cost to user after Phase 2 completion
   - No API calls without approval

3. Budget Enforcement:
   - Default budget $5, warning at 80%
   - Auto-downgrade Pro→NB2→NB1 on budget exceeded, then confirm with user

4. Style Consistency:
   - Apply same style anchor (Layer 1) to all assets
   - Only change Layer 2 within batch, fix Layer 1/3/4

5. Anti-AI Quality:
   - Include "No text in image" in all prompts
   - Include "Professional quality, natural imperfections"
   - Forbid perfect symmetry, oversaturation, plastic textures

6. Graceful Fallback:
   - If IMAGE_GEN_PROVIDER not set → fallback to GEMINI_API_KEY / GEMINI_IMAGE_API_KEY (legacy compat)
   - If IMAGE_GEN_PROVIDER set but API key missing → show error with setup instructions
   - If no provider and no legacy key → fallback to --audit-only (no pipeline interruption)
   - API error → skip only that image, continue with rest
   - Transparent background failure → 3-stage fallback chain

7. Copyright Safety:
   - No replication of logos/characters/brand marks from reference sites
   - Reference brand essence only, direct replication not allowed

8. ThoughtSignature (Multi-turn):
   - Include full content of previous response in next request for --replace mode
   - Single generation (1-turn) is not affected

9. Multi-Provider Compatibility:
   - All 5 providers (Gemini, OpenAI, OpenRouter, fal.ai, BytePlus) use the SAME prompt format (4-Layer)
   - Provider adapter handles API-specific curl + response parsing
   - IMAGE_GEN_PROVIDER env is injected by session_start from Settings config
   - IMAGE_GEN_MODEL env specifies the exact model ID per provider
   - Response normalization: all providers → decoded PNG file on disk
```

## Deliverables

- `asset-audit-report.json` — Asset audit results
- `asset-manifest.json` — Generated asset manifest (paths, prompts, costs, references)
- `public/assets/generated/` — Web assets (hero, og, favicon, empty-state, etc.)
- `public/textures/generated/` — Game assets (sprite, tileset, background, particle, ui)
- `.da-asset/backups/` — Backups of replaced original images

## Transition
- **Next**: /da:verify (asset application verification)
