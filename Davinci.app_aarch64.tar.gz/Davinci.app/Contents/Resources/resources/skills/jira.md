---
name: jira
description: Jira CRUD operations via natural language chat
agent: starter-guide
agents: []
davinci-phase: null
allowed-tools: [Bash, Read, Grep, Glob, AskUserQuestion]
next-skill: null
skill-type: flexible
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 유틸리티: 부작용(외부 API/배포/삭제) 전 §7 destructive/cost_gate 규칙을 확인한다.

## Tool Parameter Rules -> See CLAUDE.md (ABSOLUTE)
# /da:jira - Jira Issue Management

## Usage
```
/da:jira                          # 도움말
/da:jira 이 버그 지라에 등록해줘    # 티켓 생성
/da:jira PROJ-123 Done으로         # 상태 변경
/da:jira 내 티켓 보여줘             # 조회
```

## Authentication (CRITICAL — GUI 앱과 동일 경로 사용)

**절대 규칙**: MCP, `jira` CLI, `JIRA_*` 환경변수는 **검사하지 말 것**.
항상 `~/.davinci/atlassian-credentials.json`을 **유일한 소스**로 사용한다.
이 파일은 Davinci GUI 앱(Tauri)이 관리하며 우측 Jira 탭이 사용하는 credentials와 동일하다.

### Credentials 로드 (모든 작업 전 1회 실행)
```bash
CREDS=~/.davinci/atlassian-credentials.json
if [ ! -f "$CREDS" ]; then
  echo "ERROR: GUI 앱에서 먼저 Jira 로그인이 필요합니다 (~/.davinci/atlassian-credentials.json 없음)"
  exit 1
fi
EMAIL=$(python3 -c "import json;print(json.load(open('$CREDS'))['email'])")
TOKEN=$(python3 -c "import json;print(json.load(open('$CREDS'))['api_token'])")
SITE=$(python3 -c "import json;print(json.load(open('$CREDS'))['site_url'])")
AUTH=$(printf '%s:%s' "$EMAIL" "$TOKEN" | base64)
```

### 공통 호출 헤더
```
-H "Authorization: Basic $AUTH"
-H "Accept: application/json"
-H "Content-Type: application/json"   # POST/PUT 시
```

## Modes

### Query (조회)
```bash
# 내 티켓
curl -s -H "Authorization: Basic $AUTH" "$SITE/rest/api/3/search/jql?jql=assignee=currentUser()&fields=key,summary,status&maxResults=50"

# 특정 이슈
curl -s -H "Authorization: Basic $AUTH" "$SITE/rest/api/3/issue/$KEY?fields=summary,status,assignee,priority,parent"
```

### Transition (상태 변경)
```bash
# 1) 사용 가능 transition 조회
curl -s -H "Authorization: Basic $AUTH" "$SITE/rest/api/3/issue/$KEY/transitions"
# 2) 상태명 매칭 후 id 추출 (대소문자/한글 name 모두 지원)
# 3) 전환 실행
curl -s -o /dev/null -w "%{http_code}" -X POST \
  -H "Authorization: Basic $AUTH" -H "Content-Type: application/json" \
  "$SITE/rest/api/3/issue/$KEY/transitions" -d "{\"transition\":{\"id\":\"$TID\"}}"
# 204 = 성공
```

**안전 규칙 (중요)**:
- 에픽(issueType=Epic)은 사용자가 명시적으로 허가하지 않으면 **전환 금지**
- 복수 전환 시 dry-run 요약(현재→목표) 보여주고 `AskUserQuestion`으로 승인 받음
- "~~ 바꿔" 같은 자연어는 대상/목표상태/개수를 반드시 확정 후 실행

### Create (티켓 생성)
```bash
# 프로젝트/이슈타입/에픽 AskUserQuestion으로 확정
curl -s -X POST -H "Authorization: Basic $AUTH" -H "Content-Type: application/json" \
  "$SITE/rest/api/3/issue" -d '{
    "fields": {
      "project": {"key": "PROJ"},
      "summary": "...",
      "description": {"type":"doc","version":1,"content":[{"type":"paragraph","content":[{"type":"text","text":"..."}]}]},
      "issuetype": {"name": "Task"},
      "parent": {"key": "PROJ-123"}
    }
  }'
```

## Skill Bridge (전환/생성 성공 직후 필수 실행)

**목적**: GUI 앱이 처리하는 "리스트 즉시 새로고침 + 채널 매핑 기반 Slack 알림"을
그대로 재사용한다. SKILL은 REST 직접 호출 대신 브릿지 파일에 한 줄 append만 하면
GUI Rust watcher가 감지해 `slack_send_notification` Tauri 커맨드와 프론트엔드
이벤트를 발화한다.

### 브릿지 파일 경로
```
~/.davinci/bridge/jira-events.ndjson   (append-only NDJSON)
```

### 이벤트 append 스니펫 (transition)
```bash
# Jira REST 전환 성공(http=204) 직후 실행
BRIDGE=~/.davinci/bridge/jira-events.ndjson
mkdir -p "$(dirname "$BRIDGE")"

# 이슈 메타 재조회 (summary/assignee/status 최신값)
META=$(curl -s -H "Authorization: Basic $AUTH" \
  "$SITE/rest/api/3/issue/$KEY?fields=summary,status,assignee")
PROJ_KEY="${KEY%%-*}"    # CRS-8733 -> CRS

python3 - "$KEY" "$PROJ_KEY" "$SITE" "$OLD_STATUS" "$NEW_STATUS" "$META" <<'PY' >> "$BRIDGE"
import json, sys
key, proj, site, old, new, meta_raw = sys.argv[1:7]
m = json.loads(meta_raw).get("fields", {})
summary = m.get("summary", "")
assignee = (m.get("assignee") or {}).get("displayName")
payload = {
  "action": "transition",
  "issue_key": key,
  "slack": {
    "event_type": "transition",
    "project_key": proj,
    "issue_key": key,
    "summary": summary,
    "assignee": assignee,
    "from_status": old,
    "to_status": new,
    "site_url": site,
  }
}
print(json.dumps(payload, ensure_ascii=False))
PY
```

### 이벤트 append 스니펫 (create)
```bash
# POST /rest/api/3/issue 응답(201)에서 {KEY, summary} 캡처 후:
python3 - "$KEY" "$PROJ_KEY" "$SITE" "$SUMMARY" "$ASSIGNEE" <<'PY' >> "$BRIDGE"
import json, sys
key, proj, site, summary, assignee = sys.argv[1:6]
print(json.dumps({
  "action": "create",
  "issue_key": key,
  "slack": {
    "event_type": "create",
    "project_key": proj,
    "issue_key": key,
    "summary": summary,
    "assignee": assignee or None,
    "site_url": site,
  }
}, ensure_ascii=False))
PY
```

**규칙**:
- 전환/생성 성공 **즉시** append (사용자 확인 추가 없이)
- append만 하면 GUI가 자동으로: ① 리스트 즉시 새로고침 ② 채널 매핑 있으면 Slack 전송 ③ 선택된 이슈 상세 갱신
- GUI가 실행 중이지 않으면(브릿지 미처리) append만 누적됨. 다음 GUI 실행 시 무시 (앱 시작 시점 이후만 tail)
- `events.create/transition/comment` 플래그는 GUI가 이미 확인하므로 SKILL에서 중복 확인 불필요
- Bridge append 실패해도 Jira 작업 결과는 성공으로 간주 (비차단)

## Behavioral Flow (엄격 준수)

1. **Detect credentials** — 위 Authentication 스니펫 먼저 실행, 실패 시 즉시 종료
2. **Parse intent** — 자연어에서 이슈 키(`[A-Z]+-\d+`) / 상태명 / 프로젝트 추출
3. **Dry-run 요약** — 변경 대상/범위 출력
4. **확정** — 전환 대상이 2개 이상이거나 Epic 포함 시 `AskUserQuestion` 필수
5. **실행** — HTTP 204/201 확인
6. **[MANDATORY] Bridge append** — 성공한 **모든** 이슈에 대해 NDJSON 한 줄 append.
   **이 step을 건너뛰면 GUI 리스트 새로고침/Slack 알림이 발생하지 않는다.**
   `sendNotification` / Slack API 직접 호출 금지 — 반드시 bridge append만 수행.
7. **요약 출력** — `KEY  old→new  http=STATUS  bridge=ok` 테이블. `bridge=ok`가 없으면 실패로 간주하고 재시도.

## Anti-Patterns (하지 말 것)

- `which jira`, `acli`, `claude mcp list`로 인증 확인 (불필요)
- `env | grep JIRA` 확인 (사용하지 않음)
- credentials 파일 없으면 설치 안내 — **대신 GUI에서 로그인하라고 안내**
- 사용자 명시 없이 에픽 전환 / 대량 전환 실행
- dry-run 건너뛰고 즉시 실행
- **전환/생성 성공 후 bridge append 생략** — GUI 리스트/Slack 알림 전부 실패
- Slack Web API(`chat.postMessage` 등) 직접 호출 — 채널 매핑/events 플래그 무시됨
- `~/.davinci/slack-config.json` 직접 파싱하여 알림 전송 — GUI가 처리할 영역

## Boundaries

**Will**: credentials 파일 기반 REST API 호출, 자연어 파싱, dry-run, 안전 전환, **성공 직후 bridge append 필수 실행**
**Will Not**: MCP/CLI/환경변수 의존, 에픽 무단 전환, 미승인 대량 변경, **Slack API 직접 호출, bridge append 생략**
