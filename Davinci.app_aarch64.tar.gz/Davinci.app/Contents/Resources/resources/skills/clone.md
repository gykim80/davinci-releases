---
name: clone
description: "Image-to-Application Reconstruction. Multi-Skill Orchestrator: DETECT -> ANALYZE -> GENERATE(da:asset) -> ASSEMBLE(da:game/da:dev) -> VERIFY(da:verify). CLI-agnostic."
agent: frontend-architect
agents: [frontend-architect, game-developer, asset-gen-artist]
davinci-phase: null
allowed-tools: [Write, Edit, Read, Bash, Glob, Grep, Task, Skill, AskUserQuestion]
next-skill: verify
skill-type: flexible
thinking: high
mcp-servers: [context7, playwright, codegraph]
version: 2.0
skills-ref:
  - davinci_framework/agent-skills/skills/mengto-video-to-superprompt
  - davinci_framework/agent-skills/skills/mengto-html-to-interaction-prompts
  - davinci_framework/agent-skills/skills/mengto-stitched-full-page-capture
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 오케스트레이터: §4 그래프 ready-set 디스패치, §6 노드 단위 checkpoint, §7 interrupt 표 외 질문 금지.

# /da:clone v2 - Multi-Skill Orchestrated Pipeline

## MengTo Reference Skills (on-demand — 필요 시에만 Read)
> 경로: `~/.claude/plugin/agent-skills/skills/<name>/SKILL.md`
- `mengto-video-to-superprompt`: 영상 레퍼런스→재현 프롬프트 역추출
- `mengto-html-to-interaction-prompts`: HTML→섹션/인터랙션 프롬프트 추출
- `mengto-stitched-full-page-capture`: lazy/WebGL 페이지 풀페이지 캡처


## IDENTITY

da:clone은 **오케스트레이터**다. 직접 코드를 작성하지 않는다.
Phase 0-1은 내부 수행, Phase 2-4는 하위 스킬을 Skill() 호출로 위임한다.

## IRON LAW (violations = skill failure)

> 1. element-map.json 없으면 코드 한 줄도 금지.
> 2. Phase 순서 강제: 0->1->2->3->4. 스킵 불가.
> 3. 모든 에셋은 AI 이미지 생성. 코드로 그리기(Graphics/Canvas) 금지.
> 4. Phase Gate 통과 전 다음 Phase 진행 금지.
> 5. Phase 2-4는 반드시 Skill() 호출. 직접 코딩 금지.

## FORBIDDEN

- Phase 0-1 건너뛰고 코딩/Skill 호출
- Phaser Graphics/Canvas로 텍스처 코드 생성
- placeholder 색상 사각형으로 UI 구성
- element-map.json/system-spec.json 없이 da:game/da:dev 호출

## Phase Gate Enforcement

clone_gate.py 훅이 .davinci/clone/config.json 기반으로 Phase Gate를 강제한다.
- Phase 1 미완료 -> 코드 파일 Write/Edit 차단
- Phase 2 미완료 -> 게임/앱 코드 Write/Edit 차단
- 비-clone 프로젝트에는 영향 없음

## Pipeline

```
Phase 0: DETECT (내부) -> config.json 생성
Phase 1: ANALYZE (내부) -> element-map.json + system-spec.json
Phase 2: GENERATE -> Skill("da:asset", "--clone")
Phase 3: ASSEMBLE -> Skill("da:game") 또는 Skill("da:dev")
Phase 4: VERIFY  -> Skill("da:verify", "--visual")
```

## Skill Chain

- Phase 2: `Skill("da:asset", "--clone")` -- element-map.json 기반 에셋 생성
- Phase 3 (game_ui): `Skill("da:game")` + system-spec + element-map + assets
- Phase 3 (web_ui): `Skill("da:dev")` + system-spec + element-map + assets
- Phase 3 (needs_design): `Skill("da:design")` 또는 `Skill("da:create")`
- Phase 4: `Skill("da:verify", "--visual")` -- Fidelity Score 비교

## Phase 1D: System Inference (NEW)

element-map.json 분석 -> system-spec.json 생성:
- 게임/앱 시스템 유추 (UI 패턴 매칭)
- 누락 화면 추론 (needs_design)
- 데이터 모델 초안

## Flags

- `(auto)`: UI 유형 자동 감지 (기본값)
- `--web`: React TSX 출력 강제
- `--game`: Phaser 3 출력 강제
- `--assets-only`: 에셋 추출만 (Phase 3-4 스킵)
- `--no-sprites`: 스프라이트 포지 스킵
- `--budget=N`: 비용 한도 (기본: $3.00)

## Output Structure

```
.davinci/clone/config.json        # Phase Gate 체크포인트
.davinci/artifacts/${SESSION_ID}/
  element-map.json                 # Phase 1
  system-spec.json                 # Phase 1D
  assets/                          # Phase 2
  clone-result.tsx|.html|scene     # Phase 3
  clone-report.md                  # Phase 4
```
