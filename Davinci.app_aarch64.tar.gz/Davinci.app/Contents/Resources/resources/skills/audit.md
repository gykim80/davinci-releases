---
name: audit
description: Security Architecture Review -- 8-dimension analysis with Self-Verify, BIS Scoring, Evidence Verification, and optional independent verification pipeline
agent: security-architect
agents: [security-architect, code-analyzer]
davinci-phase: check
allowed-tools: [Read, Glob, Grep, Bash, Task]
next-skill: audit-verify
skill-type: rigid
version: 2.0.0
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 검증자: items[] 기반 match rate와 4값 verdict(MET/NOT_MET/BLOCKED/IMPOSSIBLE)를 handoff에 포함. 생성자와 다른 컨텍스트에서 실행된다.

# /da:audit

Methodology-based security architecture review across 8 dimensions (A1-A8) and 9 domains.

## Execution Phases
1. **Phase 0**: Recon — tech stack, 9 domains (Backend/Frontend/BaaS_DB/Web3/Infra/Mobile/AI_ML/NativeClient/SDK), lifecycle detection
2. **Phase 0.5**: Context Binding — bind recon results to each dimension
3. **Phase 1**: Architecture Review — A1-A8 dimension analysis across all active domains
4. **Phase 2**: Deep Analysis — principle-based free reasoning
5. **Phase 2.5**: Self-Verify — reachability, FP filtering, attack prerequisites, Impact Gate (What/So_What/How), compensating controls, lightweight attack chains
6. **Phase 2.8**: Scoring — BIS formula (100 - CRITICAL*25 - HIGH*10 - MEDIUM*3 - LOW*1), grade A-F, pass/fail
7. **Phase 2.9**: Evidence Verification — Read_Before_Cite, independent re-read of all file:line citations
8. **Phase 3**: Report — Korean report with Score, Attack Scenarios, Structural Weakness section

## Key Features
- **Self-Verify**: Filters false positives via reachability analysis + Impact Gate 3-proof
- **BIS Scoring**: Deterministic scoring with reverse verification
- **Evidence Classification**: Observed (code-confirmed) / Unverified (library assumed)
- **Finding Classification**: Confirmed_Vulnerability (scored) / Structural_Weakness (INFO, excluded)
- **Attack Scenarios**: Required for CRITICAL/HIGH findings with multi-step narrative

## Options
- `--verify`: Automatically chains to da:audit-verify for independent 2-round adversarial verification
- `--target <path>`: Specify target repository
- `--severity <level>`: Minimum severity filter

## vs da:security
- da:security: OWASP Top 10 code-level vulnerability scanning
- da:audit: Structural design flaw analysis (8 dimensions, methodology-based, Self-Verify + Scoring)

## Counterpart
- **security-architect** agent performs the audit
- **security-verifier** agent (da:audit-verify) independently validates findings

## Iron Law
**NO SECURITY CLAIM WITHOUT INDEPENDENT VERIFICATION.**

## Deliverables
- `docs/{feature}/audit-report.md`
- When `--verify`: triggers da:audit-verify pipeline with 2-round feedback → consensus report
