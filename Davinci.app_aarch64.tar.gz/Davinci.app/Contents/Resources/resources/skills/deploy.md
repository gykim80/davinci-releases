---
name: deploy
description: "Unified deployment -- Vercel (frontend/fullstack), Railway (backend), Supabase (DB/Edge Functions). Preview-first safe deploy."
agent: devops-guide
agents: [infra-architect]
davinci-phase: null
allowed-tools: [Read, Bash, Glob, Grep, Task]
next-skill: null
skill-type: flexible
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 유틸리티: 부작용(외부 API/배포/삭제) 전 §7 destructive/cost_gate 규칙을 확인한다.

## Tool Parameter Rules -> See CLAUDE.md (ABSOLUTE)
# /da:deploy - Integrated Deployment Protocol

## Purpose
Unified deployment for Vercel (frontend/fullstack), Railway (backend/services), and Supabase (DB migrations/Edge Functions). Enforces preview-first safe deployment workflow.

## Usage
```
/da:deploy [target] [--provider vercel|railway|supabase|all] [--env staging|production] [--dry-run]
```

### Arguments
- `target` — (optional) Specific service or directory to deploy
- `--provider` — Force a specific provider instead of auto-detection
- `--env` — Target environment (default: staging → production flow)
- `--dry-run` — Run pre-flight checks and show what would happen without deploying

## Iron Law

> **Production deployment MUST only proceed after successful preview/staging. Never deploy to production without user confirmation.**

## Behavioral Flow

### Phase -1: Service Type Verification (FR-07)
```yaml
Service_Type_Guard:
  trigger: Railway 프로바이더 감지 시 반드시 실행
  goal: DB 서비스와 App 서비스를 구분하여 파괴적 작업 방지

  steps:
    1. railway service list 실행
    2. 각 서비스의 유형 식별:
       - Database: Postgres, MySQL, Redis, MongoDB (플러그인 서비스)
       - Application: 사용자 배포 앱 서비스
    3. DB 서비스 목록을 명시적으로 나열하여 사용자에게 보고

  rules:
    DB_Services:
      - redeploy 절대 금지
      - railway up 절대 금지
      - git source 연결 여부 확인 -- 연결되어 있으면 경고
      - Docker image 변경은 사용자 확인 필수
    App_Services:
      - 기존 배포 프로토콜 적용 (preview-first)
      - 같은 repo에 여러 App 서비스가 연결된 경우 각 서비스의 root directory 확인

  anti_pattern:
    - DB 서비스에 git push로 앱 코드가 배포되는 상황
    - DB 서비스에 railway redeploy 실행
    - 서비스 유형 미확인 상태에서 배포 명령 실행
```

### Phase 0: Pre-flight Checks
```yaml
Pre_Flight:
  1. Git_Status:
     - Check for uncommitted changes: git status --porcelain
     - Warn if working directory is dirty (recommend commit first)

  2. Provider_CLI_Check:
     vercel:
       - which vercel || "Vercel CLI not installed. Run: npm i -g vercel"
       - vercel whoami || "Not authenticated. Run: vercel login"
       - Check .vercel/ directory or vercel.json existence
     railway:
       - which railway || "Railway CLI not installed. See: https://docs.railway.app/guides/cli"
       - railway whoami || "Not authenticated. Run: railway login"
       - railway status || "No linked project. Run: railway link"
     supabase:
       - which supabase || "Supabase CLI not installed. Run: brew install supabase/tap/supabase"
       - supabase projects list || "Not authenticated. Run: supabase login"
       - Check supabase/ directory existence

  3. Skip_Logic:
     - Uninstalled or unauthenticated provider → show setup guide + skip that provider
     - All providers failed → error + setup instructions
```

### Phase 1: Provider Auto-Detection
```yaml
Auto_Detection:
  vercel:
    - .vercel/ directory exists
    - vercel.json exists
    - next.config.* exists (Next.js project)
    - package.json has "vercel" in scripts or devDependencies

  railway:
    - railway status succeeds (linked project)
    - .railwayignore exists
    - railway.toml or railway.json exists

  supabase:
    - supabase/ directory exists
    - supabase/config.toml exists
    - supabase/migrations/ has .sql files

  Manual_Override:
    - When --provider flag is specified, auto-detection is bypassed
    - --provider all → sequential deployment of all detected providers
```

### Phase 2: Deploy — Vercel
```yaml
Vercel_Deploy:
  1. Preview_Deploy:
     command: vercel deploy
     action: Generate Preview URL + wait for build
     wait: vercel inspect <preview-url> --wait

  2. Preview_Verification:
     - Display Preview URL
     - curl -sI <preview-url> | head -5 (health check)
     - "Deploy to production after confirming preview?" → request user confirmation

  3. Production_Deploy (after user confirmation):
     command: vercel --prod
     action: Production deployment

  4. Production_Verification:
     - Display Production URL
     - curl -sI <production-url> | head -5
     - vercel ls --limit 3 (recent deployment list)

  Rollback:
     command: vercel rollback
     note: Instantly restore to previous successful deployment
```

### Phase 2: Deploy — Railway
```yaml
Railway_Deploy:
  1. Staging_Deploy:
     command: railway up --environment=staging
     action: Deploy to staging environment

  2. Staging_Verification:
     - railway logs -n 20 (check recent logs)
     - railway status (check deployment status)
     - "Deploy to production after confirming staging?" → request user confirmation

  3. Production_Deploy (after user confirmation):
     command: railway up --environment=production
     action: Deploy to production environment

  4. Production_Verification:
     - railway logs -n 20 --environment=production
     - railway status
     - Deployment URL health check

  Rollback:
     command: railway redeploy (redeploy previous successful deployment)
     alternative: railway down (stop service)
```

### Phase 2: Deploy — Supabase
```yaml
Supabase_Deploy:
  1. Migration_DryRun:
     command: supabase db push --dry-run
     action: Preview changes (no execution)
     display: Show list of migrations to be applied

  2. Migration_Confirmation:
     - Display dry-run results
     - "Execute migration?" → request user confirmation

  3. Migration_Execute (after user confirmation):
     command: supabase db push
     action: Apply database migration

  4. Edge_Functions_Deploy:
     check: Verify functions exist in supabase/functions/ directory
     command: supabase functions deploy
     action: Deploy all Edge Functions

  5. Secrets_Sync (optional):
     check: Verify .env.production or .env.local exists
     command: supabase secrets set --env-file .env.production
     action: Sync secrets
     warning: ⚠️ Display .env file contents to user first

  Rollback:
     note: Supabase migrations cannot be automatically rolled back
     manual: supabase migration new rollback_xxx → write manual revert SQL
     guide: Provide guide for writing reverse SQL for failed migration
```

### Phase 3: Verification & Report
```yaml
Post_Deploy_Verification:
  1. Health_Check:
     - Run curl -sI for each deployed URL
     - Verify HTTP 200 response
     - Measure response time

  2. Log_Check:
     - Vercel: vercel logs <url> --follow (5 sec)
     - Railway: railway logs -n 30
     - Supabase: supabase functions logs (Edge Functions)

  3. Report:
     format: |
       ## 🚀 Deployment Report

       | Provider   | Environment | Status | URL                    |
       |-----------|-------------|--------|------------------------|
       | Vercel    | Production  | ✅/❌  | https://...            |
       | Railway   | Production  | ✅/❌  | https://...            |
       | Supabase  | Production  | ✅/❌  | (migrations applied)   |

       ### Actions Taken
       - [list of actions]

       ### Rollback Commands (if needed)
       - [provider-specific rollback commands]
```

### Phase 4: Rollback Guide (auto-displayed on failure)
```yaml
Rollback_Guide:
  vercel:
    immediate: vercel rollback
    specific: vercel rollback <deployment-id>
    list: vercel ls --limit 5

  railway:
    immediate: railway redeploy
    stop: railway down
    recover: railway up --environment=production

  supabase:
    note: "Automatic rollback not available — manual revert migration required"
    steps:
      1. supabase migration new rollback_<name>
      2. Write reverse SQL (DROP/ALTER etc.)
      3. supabase db push
    warning: "Potential data loss — always backup before proceeding"
```

## Anti-Rationalization Defense

| Rationalization | Reality |
|---|---|
| "Let's push to production directly" | Preview-first is mandatory. Saving 1 minute can cause production outage |
| "We can skip dry-run" | Supabase migrations are hard to reverse. dry-run is mandatory |
| "We'll handle rollback later" | Provide rollback guide immediately on deployment failure |
| "Environment variables are already set" | Verify every time. Environment mismatch is the most common deployment failure cause |
| "It's fine without staging" | Production-only deployment is a last resort. Staging is the default |

## Safety Guardrails

```yaml
Mandatory_Checks:
  - Warn on uncommitted changes (git status)
  - Prevent direct .env file deployment (use secrets management tools)
  - Always require user confirmation before production deploy
  - Migration dry-run required (Supabase)

Forbidden_Actions:
  - Deploy to production without user confirmation
  - Execute migration without dry-run
  - Commit or directly upload .env files to git
  - Attempt deployment in unauthenticated state
```

## Boundaries

**Will:**
- Auto-detect providers from project structure
- Deploy to preview/staging first, then promote to production
- Run health checks and show deployment status
- Provide rollback commands on failure

**Will Not:**
- Deploy to production without user confirmation
- Skip preview/staging for any provider
- Execute migrations without dry-run first
- Manage DNS, domains, or SSL certificates (use provider dashboards)
- Handle CI/CD pipeline configuration (use provider-specific config files)
