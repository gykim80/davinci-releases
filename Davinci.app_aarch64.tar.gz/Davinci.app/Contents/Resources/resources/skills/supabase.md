---
name: supabase
description: "Supabase-specific -- CLI auth, DB migration (dry-run first), Edge Functions deploy, Secrets sync, monitoring."
agent: devops-guide
agents: [infra-architect]
davinci-phase: null
allowed-tools: [Read, Bash, Glob, Grep, Task]
next-skill: null
skill-type: flexible
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 유틸리티: 부작용(외부 API/배포/삭제) 전 §7 destructive/cost_gate 규칙을 확인한다.

## Tool Parameter Rules -> See CLAUDE.md (ABSOLUTE)
# /da:supabase - Supabase Deployment Protocol

## Purpose
Supabase-specific skill. Handles CLI authentication, database migration with mandatory dry-run, Edge Functions deployment, secrets synchronization, and database monitoring.

## Usage
```
/da:supabase [--target db|functions|secrets|all] [--dry-run]
```

### Arguments
- `--target` — Specific target (default: auto-detect pending changes)
- `--dry-run` — Preview all changes without execution

## Iron Law

> **Dry-run before migration push. Never apply migrations without previewing changes first.**

## Behavioral Flow

### Phase 0: Pre-flight
```yaml
Pre_Flight:
  1. CLI_Check:
     - which supabase || "Supabase CLI not installed. Run: brew install supabase/tap/supabase"
  2. Auth_Check:
     - supabase projects list || "Not authenticated. Run: supabase login"
  3. Project_Check:
     - Check supabase/ directory and supabase/config.toml
     - Check supabase/migrations/ for pending .sql files
  4. Git_Status:
     - git status --porcelain
     - Warn if working directory is dirty
```

### Phase 1: DB Migration
```yaml
Migration:
  1. Dry_Run (mandatory):
     command: supabase db push --dry-run
     action: Preview migration changes without execution
     display: Show list of migrations to be applied

  2. User_Confirmation:
     - Display dry-run results
     - "Execute migration?" -> request user confirmation

  3. Execute (after confirmation):
     command: supabase db push
     action: Apply database migrations
```

### Phase 2: Edge Functions
```yaml
Edge_Functions:
  1. Detect:
     - Check supabase/functions/ directory for function folders
  2. Deploy:
     command: supabase functions deploy
     action: Deploy all Edge Functions
  3. Verify:
     - supabase functions list (confirm deployment)
```

### Phase 3: Secrets Sync
```yaml
Secrets:
  1. Check:
     - Verify .env.production or .env.local exists
  2. Display:
     - Show env file contents to user first (safety)
  3. Sync (after confirmation):
     command: supabase secrets set --env-file .env.production
     warning: Always display contents before syncing
```

### Monitoring Commands
```yaml
Monitoring:
  cache_hit: supabase inspect db cache-hit
  unused_indexes: supabase inspect db unused-indexes
  seq_scans: supabase inspect db seq-scans
  long_queries: supabase inspect db long-running-queries
  table_sizes: supabase inspect db table-sizes
  index_sizes: supabase inspect db index-sizes
  bloat: supabase inspect db bloat
  functions_logs: supabase functions logs
  prometheus: "Prometheus metrics endpoint (if configured)"
```

### Rollback
```yaml
Rollback:
  note: "Supabase migrations cannot be automatically rolled back"
  steps:
    1. supabase migration new rollback_<name>
    2. Write reverse SQL (DROP/ALTER etc.)
    3. supabase db push
  warning: "Potential data loss -- always backup before proceeding"
```

## Safety Guardrails
```yaml
Mandatory:
  - dry-run before every migration push
  - User confirmation before migration execute
  - Display env contents before secrets sync
Forbidden:
  - Migration push without dry-run
  - Direct secrets sync without user review
  - Deploying with unauthenticated CLI
```

## Boundaries

**Will:**
- Check CLI installation and authentication
- Run migration dry-run, then execute after confirmation
- Deploy Edge Functions and sync secrets
- Provide database monitoring commands

**Will Not:**
- Push migrations without dry-run
- Sync secrets without user review
- Manage Supabase dashboard settings
- Handle RLS policies (use SQL migrations)
