---
name: protocol
description: "Shared Execution Protocol v1 — 모든 da:* 스킬이 따르는 공통 실행 규약. Graph-gated pipeline(의존성 그래프 + 조건 분기), Evidence-based completion(자기보고 금지), Bounded retry + escalation, Checkpoint-after-node + fresh-context 재개, Stall/oscillation 감지. 오케스트레이터(da:work/turbo/super/loop)와 모든 하위 스킬의 계약서."
agent: cto-lead
davinci-phase: any
allowed-tools: [Read, Bash]
next-skill: null
skill-type: reference
protocol-version: 1
---

# da:protocol — Shared Execution Protocol v1

> 이 문서는 **참조 규약**이다. 직접 실행하는 스킬이 아니라, 모든 `da:*` 스킬이 `## Execution Protocol` 블록에서
> 가리키는 단일 계약서다. 스킬 본문과 이 문서가 충돌하면 **이 문서가 우선**한다.
> 오케스트레이터(da:work, da:turbo, da:super, da:loop)는 §1~§8 전부를, 리프 스킬은 §2·§3·§5를 최소로 준수한다.

## 설계 근거 (2026 프레임워크 비교 요약)

| 출처 | 차용한 개념 | 이 규약에서의 표현 |
|------|-------------|-------------------|
| LangGraph (StateGraph / checkpointer / interrupt) | 타입 있는 상태, 조건 edge, 노드 단위 checkpoint, HITL interrupt | §1 State Schema, §4 Conditional Edges, §6 Checkpoint, §7 Interrupt |
| Anthropic "Building effective agents" / long-running harness | Evaluator-Optimizer 분리, 환경에서 ground truth 획득, progress file | §3 Evidence, §2 Node Contract, §6 progress |
| Ralph Wiggum → ralph-wiggum plugin 이후 세대 | Stop-hook 루프의 한계 → 자기보고 `<promise>` 폐기, 검증 명령 기반 종료 | §3 Completion, §5 Loop Control |
| get-shit-done (GSD) / superpowers | fresh-context 서브에이전트, verifier ≠ generator, verification-before-completion | §2.3 Fresh Context, §3.2 Verifier 분리 |
| GitHub spec-kit / Claude Code Tasks(blockedBy) | 태스크 의존성 그래프, [P] 병렬 마커, 체크리스트 게이트 | §4 Dependency Graph, §4.3 Ready-set 디스패치 |
| Mastra / Pydantic Graph / OpenAI Agents SDK | step retry policy, dountil 상한, max_turns, guardrails | §5 Retry Policy, §8 Budget |

상세 비교표와 출처: `references/framework-comparison.md`

---

## §1. State Schema (공통 체크포인트 필드)

모든 오케스트레이터 checkpoint(`docs/.da-*-checkpoint.json`, `docs/.davinci-loop.json`, `docs/.davinci-super.json`)는
기존 필드에 더해 아래 공통 필드를 가진다. 필드는 **추가만** 하며 기존 필드를 제거하지 않는다.

```json
{
  "protocol_version": 1,
  "graph": {
    "nodes": {"<node_id>": {"status": "pending|running|passed|failed|blocked|degraded|skipped",
                            "attempts": 0, "max_attempts": 3,
                            "depends_on": ["<node_id>"], "evidence_ref": "<path|null>"}},
    "ready": ["<node_id>"], "current": "<node_id|null>"
  },
  "loop_control": {"stall_count": 0, "last_progress_hash": null, "oscillation_keys": []},
  "budget": {"max_nodes": 60, "nodes_executed": 0, "max_wall_minutes": 90, "started_at": "<iso>"},
  "interrupts": [{"node": "<node_id>", "reason": "...", "resolved": false}]
}
```

- `node_id` 규칙: `{stage}:{phase}:{skill}` (예: `3:2:da:dev`, `2:0:da:verify`, `loop:7`).
- `status` 전이는 §4.2의 표만 허용한다. 임의 전이 금지.
- checkpoint 쓰기는 **노드 종료 직후 1회, 원자적**(임시 파일 → mv)으로 수행한다.

## §2. Node Contract (스킬 = 그래프의 노드)

오케스트레이터가 Task/Skill로 호출하는 모든 스킬 실행은 하나의 **노드**다. 노드는 아래 계약을 지킨다.

### §2.1 입력 계약
- 오케스트레이터는 노드에 **자기 노드 id, 의존 노드의 handoff, 시도 횟수(attempt N/M), 이전 실패 사유**를 넘긴다.
- 재시도(attempt ≥ 2)일 때는 반드시 `previous_failure`를 포함한다. 이유 없는 재시도 금지(PM 6-Step 규칙과 동일).

### §2.2 출력 계약 — Handoff JSON (필수)
모든 노드는 응답 **마지막**에 아래 스키마를 만족하는 JSON 블록 1개를 반환한다. 스킬별 추가 필드는 자유.

```json
{
  "skill": "da:<name>", "node_id": "<node_id>",
  "status": "completed | partial | blocked | failed",
  "evidence": [{"kind": "command|file|test|screenshot|http",
                "ref": "npm test", "result": "exit 0 / 42 passed / path", "ok": true}],
  "remaining": ["..."], "blockers": ["..."],
  "next_hint": "<다음 노드에 넘길 1줄 힌트|null>"
}
```

- `status` 의미: `completed`=요구 전부 + evidence ok 전부 / `partial`=일부 완료(remaining 필수) / `blocked`=외부 요인(blockers 필수) / `failed`=시도했으나 실패(evidence에 실패 근거).
- **evidence가 비어 있는 `completed`는 오케스트레이터가 `partial`로 강제 다운그레이드**한다.
- JSON 파싱 실패 → 오케스트레이터는 `extract_fallback_handoff` 후 `status="partial"`로 취급하고 재시도 카운트를 1 올린다.

### §2.3 Fresh-Context 원칙 (Context-% 종료 규칙 대체)
- ❌ 폐기: "Context 50%(또는 N%) 도달 시 핵심 작업만 마치고 종료" — 모델은 자기 컨텍스트 사용량을 측정할 수 없다.
- ✅ 대체: 노드는 **작업 단위(파일/기능 1개) 완료마다 progress를 파일에 기록**하고, 스스로 끝낼 수 없다고 판단되면
  `status="partial"` + `remaining[]`을 반환한다. 오케스트레이터는 같은 node_id를 **새 Task(새 컨텍스트)**로 재개한다.
- 오케스트레이터 자신은 §6.3의 Proactive Compact를 노드 경계에서만 수행한다.

### §2.4 금지 사항
- AskUserQuestion은 §7 Interrupt 규칙을 통해서만 허용된다(오케스트레이션 중 직접 호출 금지).
- 노드가 자기 결과를 스스로 "passed"로 표시할 수 없다. 판정은 §3의 Verifier 또는 evidence 규칙이 한다.

<!-- SECTION:node-contract-end -->
## §3. Evidence-Based Completion (자기보고 완료 금지)

### §3.1 완료 판정 규칙
"완료/통과/done/passed/works"라는 모든 긍정 주장은 **환경에서 얻은 근거**를 동반해야 한다.

| 주장 | 인정되는 근거(evidence.kind) | 인정되지 않는 것 |
|------|------------------------------|------------------|
| 빌드/타입 통과 | `command`: `tsc --noEmit`/`cargo check` 실행 결과 + exit code | "타입 오류 없음을 확인했다"는 서술 |
| 테스트 통과 | `test`: 러너 출력의 passed/failed 카운트 + exit code | 테스트 코드 존재 사실만 |
| 파일 산출 | `file`: 경로 + 존재 확인(ls/wc) | "생성했다"는 서술 |
| UI 동작 | `screenshot`/`http`: Playwright 스크린샷 경로 또는 HTTP 상태 | 코드 리뷰만으로 추정 |
| 요구사항 충족 | 요구사항 항목별 pass/fail 리스트(§3.3) | 단일 % 숫자만 |

- 근거 없는 주장은 오케스트레이터가 **`partial`로 다운그레이드**하고 다음 edge 판정에 반영한다.
- `<promise>DONE</promise>` 같은 **자기보고 완료 태그는 단독으로 완료 신호가 될 수 없다**. da:loop에서는 `completion_check` 명령이 exit 0일 때만 종료한다(§5.4).

### §3.2 Verifier ≠ Generator
- MODERATE 이상 복잡도에서 구현 노드(da:dev/da:game/da:fix)와 검증 노드(da:verify/da:e2e)는 **서로 다른 Task(컨텍스트)**로 실행한다.
- 구현 노드의 self-check는 허용하되 "사전 점검"으로만 취급한다. 최종 판정은 독립 Verifier가 낸다.
- LIGHT/SIMPLE에서는 단일 노드 내 self-verify를 허용하되 §3.1 근거 표를 그대로 적용한다.

### §3.3 Match Rate의 정의
- match rate = `passed_weight / total_weight` (항목별 pass/fail/partial 리스트에서 계산, `davinci.workflow.match_rate` 와 동일 정의).
- Verifier는 `items[]`(name, status, weight, detail)를 handoff에 포함한다. **items 없는 % 숫자는 무효** → "판정 불가"로 처리.
- 판정 불가는 `<threshold`와 동일하게 취급한다(기존 §2.6 규칙 유지).

### §3.3-b Verifier Verdict (3-value + reason → guidance)
Verifier(da:verify/da:e2e/독립 evaluator Task)는 match rate와 함께 **4값 verdict**를 반환한다. 이진 pass/fail은 BLOCKED와 IMPOSSIBLE을 구분하지 못해 무한루프를 만든다(Claude Code `/goal`, superpowers status enum과 동일 설계).

```json
{"verdict": "MET | NOT_MET | BLOCKED | IMPOSSIBLE", "reason": "<1-2문장>", "next_action_hint": "<다음 시도가 다르게 할 것>"}
```
- `MET` → passed. `NOT_MET` → failed(재시도 가능, `reason`+`next_action_hint`를 다음 노드 입력으로 주입).
- `BLOCKED` → 외부 요인, 재시도 무의미 → §7 Interrupt. `IMPOSSIBLE` → 요구사항 자체가 모순/불가 → 즉시 루프 종료 + 사용자 보고.
- verdict 없는 verify 결과는 "판정 불가"(= NOT_MET)로 처리한다.

### §3.5 Acceptance Ledger (Sprint Contract, JSON)
- da:plan(또는 오케스트레이터 Stage 0)은 구현 전에 `docs/.da-acceptance.json`을 만든다:
  `[{"id":"AC-01","criterion":"...","check":"npm test -- auth","passes":false,"evidence":null}]`
- Verifier는 **이 목록만** 대조한다(임의 기준 추가 금지). 항목 **삭제·재작성 금지**, `passes`와 `evidence`만 갱신(Anthropic long-running harness의 feature list 규칙).
- check가 없는 정성 항목은 `rubric` 필드에 앵커 문구를 두고 독립 evaluator가 판정한다.
- 원장이 없는 프로젝트(기존 PLAN.md만 존재)는 Verifier가 요구사항 섹션에서 원장을 생성한 뒤 시작한다(1회, 이후 불변).
- 강제 구현: `davinci.workflow.acceptance` (원장 로딩/구조 검증/항목 판정/불변 규칙 위반 탐지) + `verdict.acceptance_gate` + `post_task` hook. 항목 삭제·criterion 재작성은 `ledger_mutations()` 가 잡는다.
- hook 은 원장의 `check` 명령을 **자동 실행하지 않는다**. 매 Task 완료마다 임의 셸을 돌리면 부작용과 지연을 통제할 수 없다. `check` 는 무엇을 돌려야 하는지의 기록이고, 판정은 제출된 `evidence` 가 §3.1 을 통과하는지로 한다.

### §3.6 코드 강제 계층 (Enforcement — 프롬프트가 아닌 hook이 검사)

규약의 다음 항목은 `davinci.workflow.verdict` 모듈과 hook이 실제로 파싱·기록한다. 모델이 문구를 무시해도 hook이 되돌린다.

| 시점 | hook | 검사 | 결과 |
|------|------|------|------|
| Task 완료 (PostToolUse) | `post_task.py::_enforce_verdict_contract` | 결과 JSON의 `verdict` 추출 → §4.4 severity gate 계산 | MET/NOT_MET(재시도 가능) → additionalContext 지시. blocked/BLOCKED/IMPOSSIBLE → `decision: block` 으로 진행 차단 |
| Task 완료 (PostToolUse) | 같은 함수 → `workflow.evidence.verify_all` | `status: completed` 의 `evidence[]` 를 §3.1 대조표대로 kind 별 검증 (command=exit code, test=카운트+exit code, file/screenshot=경로 실존+비어있지 않음, http=상태코드). 허용되지 않은 kind·서술형 근거·`ok:true` 자기보고는 불인정 | partial로 강등 지시 + `docs/.da-verdicts.jsonl` 에 `evidence_gate` 기록 |
| Task 완료 (PostToolUse) | 같은 함수 → `workflow.acceptance.verify_ledger` | `docs/.da-acceptance.json` 이 있을 때 항목별 pass/fail 대조(§3.1 마지막 행, §3.3). `passes: true` 는 근거가 §3.1 을 통과해야 인정. `rubric` 정성 항목은 `unjudged` — 독립 evaluator 필요. **원장이 없으면 아무것도 막지 않는다(fail-open)** | partial로 강등 지시 + `acceptance_gate` 기록(match_rate 포함) |
| Stop | `on_stop.py::_record_verdict_from_transcript` | transcript 마지막 assistant 메시지의 verdict (Skill 경로 da:verify/da:e2e) | checkpoint `last_verdict` + jsonl 기록 |
| Stop (da:work 활성) | pipeline guard block reason | `checkpoint.last_verdict.action ∈ {retry_improve, blocked, report}` | block 이유에 "MET 없이 완료 보고 금지" 추가 |
| Stop (da:loop 활성) | `on_stop.py::_check_loop_guard` (Phase 0.5, 안전장치보다 먼저) | `completion_check` exit code · progress hash · max | §5.4 |

기록 위치: checkpoint `graph.nodes[node_id].{status,attempts,last_verdict}`, `checkpoint.last_verdict`, 그리고 append-only `docs/.da-verdicts.jsonl`.
Task prompt에 `node_id: <id>` 를 명시하면 hook이 그래프 노드를 정확히 갱신한다(없으면 `verdict:<skill>` 임시 노드).

### §3.4 Severity Gate (강제 진행 금지)
- Verifier 결과에 `Critical` 또는 `High` 이슈가 1개라도 남아 있으면, 재시도 상한에 도달했더라도 **다음 단계로 강제 진행할 수 없다**.
  → 노드를 `blocked`로 표시하고 §7 Interrupt(사용자 결정) 또는 §5.3 Escalation으로 넘긴다.
- Medium/Low만 남은 상태에서 상한 도달 → `degraded`로 표시하고 진행 가능. `degraded` 노드는 최종 리포트에 반드시 노출한다.

<!-- SECTION:evidence-end -->
## §4. Dependency Graph + Conditional Edges (고정 선형 파이프라인 대체)

### §4.1 그래프 구성 (Stage 0에서 1회)
- 오케스트레이터는 계획 문서에서 노드를 추출하고 `depends_on`을 채운다.
  - roadmap 모드: `blocked_by` 필드를 그대로 사용.
  - plan 모드: 명시된 의존이 없으면 **같은 Stage 내 Phase 순서 = 선형 의존**을 기본값으로 둔다.
  - COMPLEX+: `davinci.orchestration.coordinator` 의 wave 분석 결과를 `depends_on`으로 변환한다(파일 소유권 충돌 = 의존).
- Foundation Guard: config/토큰/스키마 노드는 다른 모든 노드가 의존하도록 강제(Wave 0 단독).

### §4.2 상태 전이표 (허용되는 전이만)

| from → to | 조건 |
|-----------|------|
| pending → running | `depends_on` 전부 `passed|degraded|skipped` |
| running → passed | Verifier verdict pass **and** evidence ok |
| running → failed | verdict fail 또는 evidence 부족, attempts < max_attempts |
| failed → running | 재시도(§5.1 정책 충족, previous_failure 전달) |
| failed → blocked | attempts == max_attempts **and** Critical/High 잔존 |
| failed → degraded | attempts == max_attempts **and** Medium/Low만 잔존 |
| pending → skipped | complexity 게이트/플래그로 제외(사유 기록) |
| blocked → running | §7 Interrupt가 resolved=true 로 해소됨 |

### §4.3 Ready-set 디스패치
```
loop:
  ready = [n for n in nodes if n.status == pending and all(dep.status in {passed, degraded, skipped} for dep in n.depends_on)]
  if not ready and no running nodes: → 종료 판정(§5.5)
  독립 노드가 2개 이상이면 같은 메시지에서 병렬 Task 호출(파일 소유권 겹침 없을 때만)
  각 노드 종료 → handoff 추출 → verdict → 전이표 적용 → checkpoint 저장 → 다음 ready 계산
```

### §4.4 Conditional Edge 표준 (verify 이후)
```
verdict(items) ≥ threshold and no Critical/High → passed → 다음 ready 노드
verdict < threshold, attempts < max → failed → da:improve(previous_failure 포함) → 동일 verify 노드 재실행
attempts == max, Critical/High 잔존 → blocked → §7 Interrupt 또는 §5.3 Escalation
attempts == max, Medium/Low만 → degraded → 진행(리포트에 명시)
verdict 판정 불가(items 없음) → failed 로 취급
```
threshold 기본값 90 (기존 규칙 유지). 복잡도별 override는 오케스트레이터가 checkpoint에 기록한다.

<!-- SECTION:graph-end -->
## §5. Loop Control — Bounded Retry, Escalation, Stall Detection

### §5.1 Retry Policy (노드 단위)
| 노드 종류 | max_attempts | 재시도 조건 |
|-----------|--------------|-------------|
| verify/improve 루프(arch, dev, e2e) | 3 (MODERATE는 dev 1) | previous_failure가 직전과 **다른 접근**을 요구함을 명시 |
| 구현 노드(dev/game/fix) partial 재개 | 2 | remaining[]이 직전보다 줄었을 때만(진척 조건) |
| 외부 API/도구 실패(이미지, 배포, MCP) | 2 | 지수 대기(5s, 15s) 후 1회, 이후 graceful degradation |
| da:loop 반복 | max_iterations(기본 10) | §5.4 completion_check 미통과 + stall 아님 |

- 동일 입력·동일 접근으로 재시도 금지(PM Error Root-Cause 6-Step). 재시도 프롬프트에 "이전 시도: X → 실패 사유: Y → 이번에 다르게 할 것: Z"를 반드시 포함.

### §5.2 Progress Hash & Stall
- 노드(또는 loop 반복) 종료 시 `progress_hash = sha1(git diff --stat + 실패 테스트 목록)`을 기록한다.
- 직전 해시와 동일 → `stall_count += 1`. **2회 연속 stall → 루프 중단**(`blocked`, 사유 "no progress").
- 실패 테스트 집합이 A→B→A로 왕복(oscillation_keys에 동일 키 재등장) → 즉시 중단 후 §5.3.

### §5.3 Escalation Ladder (3-Fix Rule의 일반화)
```
attempt 1 실패 → 새 정보로 재분석 (같은 노드, 다른 접근)
attempt 2 실패 → 가정 재검토, 범위 축소(remaining 분할)
attempt 3 실패 → STOP. 구조 문제로 간주 →
    - 아키텍처 영향 → da:system 재검토 노드를 그래프에 삽입(depends_on = 실패 노드의 의존)
    - 요구사항 모호 → §7 Interrupt(사용자 결정)
    - 외부 요인 → blocked + blockers[] 기록, 나머지 독립 노드는 계속
```
- 모델 승격(선택): attempt 2부터는 **새 컨텍스트 + 상위 모델**(예: sonnet→opus)로 재시도하고, 직전 시도의 diff만 범위로 재검토한다(superpowers fix-loop ladder). 같은 컨텍스트에 이어 붙이는 재시도는 attempt 1에서만 허용.
- Stop-hook 기반 루프는 Claude Code가 연속 block 횟수를 제한(8회)하므로, **반복 횟수·진척 해시는 항상 상태 파일에 영속**하고 hook이 아닌 파일이 진실의 원천이다.

### §5.4 da:loop 완료 규칙 (Stop-hook 루프)
- 상태 파일 `docs/.davinci-loop.json` 필드: `status, prompt, iteration, max_iterations, completion_check, stall_count, last_progress_hash`.
- **완료 판정 우선순위**: ① `completion_check`(셸 명령) exit 0 → completed ② stall 2회 → stopped(no progress) ③ iteration ≥ max → stopped(max) ④ 사용자 cancel.
- `<promise>` 태그는 **completion_check가 정의되지 않은 경우에만** 보조 신호로 인정하되, 반드시 evidence 1개 이상을 같은 응답에 동반해야 한다.

### §5.5 종료 판정 (오케스트레이터)
- 종료 = ready 노드 없음 **and** running 노드 없음. 이때 `blocked` 노드가 있으면 "부분 완료" 리포트, 없으면 "완료" 리포트.
- "Never stop midway" 규칙은 **ready 노드가 남아 있는 동안** 적용된다. blocked만 남았을 때 계속 도는 것은 규칙 위반이다.

<!-- SECTION:loop-control-end -->
## §6. Checkpoint-After-Node + Idempotent Resume

### §6.1 저장 시점
- **모든 노드 종료 직후**(성공/실패 무관) checkpoint를 저장한다. Stage 전환 시점만 저장하던 규칙은 폐기.
- 저장 내용: §1 graph 전체 + 해당 노드의 handoff(`handoff_<skill>`) + `progress_hash` + `budget.nodes_executed`.
- 원자적 쓰기: `tmp → mv`. `davinci.workflow.pipeline_guard.save_checkpoint_atomic` 사용 가능 시 우선.

### §6.2 Resume 규칙 (idempotent)
```
checkpoint 로드 → graph.current 확인
  current 노드 status == running (중단됨) → 해당 노드를 attempts 증가 없이 재실행 (idempotent 재개)
  passed 노드는 재실행 금지 (evidence_ref 존재 확인만)
  handoff_* 가 있으면 재생성하지 않고 그대로 주입
  stale(2h+) checkpoint → 사용자에게 1줄 알림 후 resume 여부는 §7 Interrupt
```
- 재개 시 노드 결과가 달라질 수 있는 부작용 작업(git push, 배포, 외부 API 과금)은 **evidence_ref로 완료 여부를 먼저 확인**하고 건너뛴다.

### §6.3 Proactive Compact (노드 경계 한정)
- compact 트리거는 **노드 경계**에서만 허용(노드 중간 금지). 기존 "2 Phase마다" 규칙은 "ready-set 1회 소진 후"로 대체.
- compact 직전 checkpoint 저장 필수. 복구는 PreCompact hook의 `<da-work-pipeline>` 주입 + §6.2 규칙으로 수행.

### §6.4 Progress Tag (GUI 호환 유지)
- 기존 `<!-- progress: {...} -->` 태그는 유지하되 `"nodes": {"passed": n, "total": m, "blocked": k}`를 추가 필드로 포함한다.

<!-- SECTION:checkpoint-end -->
## §7. Interrupt Points (Human-in-the-Loop)

자율 실행 중 사용자 개입은 **명시된 interrupt 지점에서만** 발생한다. 그 외 AskUserQuestion은 금지(기존 §5 Sub-Skill Override 유지).

| Interrupt | 발생 조건 | 자율 모드(da:super/da:turbo --autonomous) 기본 결정 |
|-----------|-----------|-----------------------------------------------------|
| scope_confirm | MODERATE+ Stage 0 완료 | 기존 Scope Confirmation Gate 유지 / 자율 모드는 전체 범위 승인 |
| blocked_decision | 노드 `blocked` (Critical/High 잔존) | 나머지 독립 노드 계속 → 최종 리포트에 blocked 목록 |
| cost_gate | 외부 과금 예상 > 설정 한도(기본 $5) | 한도 내 축소 실행 또는 skip(사유 기록) |
| destructive | 삭제/강제 push/프로덕션 배포/마이그레이션 적용 | **항상 중단**(자율 모드에서도 예외 없음) |
| stale_resume | 2h+ 체크포인트 재개 | 재개 진행 |

- interrupt 발생 시 checkpoint `interrupts[]`에 기록하고, 응답은 "결정 요청 1줄 + 선택지"로 끝낸다(다른 텍스트 금지).
- 해소되면 `resolved=true` 후 §4.2 `blocked → running` 전이.

## §8. Budget & Circuit Breaker

- `budget.max_nodes`(기본 60), `budget.max_wall_minutes`(기본 90) 초과 → 새 노드 시작 금지, 현재 노드 종료 후 partial 리포트.
- 동일 스킬 연속 실패 5회(노드 무관) → 회로 차단: 해당 스킬 노드 전부 `blocked`, 사유 "circuit open".
- 외부 API(이미지/영상/배포) 호출 총 실패 3회 → 해당 provider 회로 차단, graceful degradation(placeholder) 경로로 전환.
- 예산 상태는 checkpoint의 `budget`에만 기록한다(stdout 출력 금지 — Call-First 규칙 유지).

<!-- SECTION:interrupt-budget-end -->
## §9. 폐기된 패턴 (Anti-Patterns) — 발견 시 이 규약으로 교체

| 폐기 패턴 | 문제 | 대체 |
|-----------|------|------|
| `<promise>` 자기보고 완료 | 모델이 검증 없이 완료 선언 → 미완성 종료 | §3.1 evidence + §5.4 completion_check |
| "Context N% 도달 시 종료" | 측정 불가한 값에 의존, 조기 종료/무한 진행 | §2.3 partial handoff + fresh-context 재개 |
| "max 도달 → 강제 진행" | Critical 이슈를 안고 다음 단계로 → 후속 전부 오염 | §3.4 Severity Gate + §4.2 blocked/degraded |
| 고정 선형 Stage 1→2→3→4 | 독립 작업도 직렬, 실패 전파 경로 불명확 | §4 그래프 + ready-set 디스패치 |
| 생성자가 자기 결과를 검증 | 확증 편향, 근거 없는 "passed" | §3.2 Verifier ≠ Generator |
| 텍스트에서 "Match Rate: XX%" 추출 | 항목 없는 숫자, 재현 불가 | §3.3 items[] 기반 계산 |
| 동일 프롬프트 무한 재주입(Stop-hook) | 진척 없이 토큰 소모 | §5.2 stall/oscillation + §5.4 |
| Stage 전환 시점만 checkpoint | 노드 중간 중단 시 재작업 | §6.1 노드 단위 저장 |
| "Shall I continue?" 질문으로 끝내기 | 자율 파이프라인 정지 | §7 interrupt 표 외 질문 금지 |

<!-- SECTION:anti-patterns-end -->
## §10. 스킬 준수 블록 (각 SKILL.md에 삽입되는 표준 문구)

모든 `da:*` SKILL.md는 frontmatter 직후에 아래 블록을 가진다. 스킬 종류별로 한 줄만 다르다.

```markdown
## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- {ROLE_LINE}
```

`{ROLE_LINE}` 값:
- **orchestrator**(work, work-standard, work-parallel, turbo, super, loop, next, pm, ready, clone, cowork): `오케스트레이터: §4 그래프 ready-set 디스패치, §6 노드 단위 checkpoint, §7 interrupt 표 외 질문 금지.`
- **verifier**(verify, e2e, arch-verify, audit-verify, visual-qa, analyze, security, audit, ux, critique): `검증자: items[] 기반 match rate와 severity를 handoff에 포함. 생성자와 다른 컨텍스트에서 실행된다.`
- **generator**(dev, game, fix, improve, design, create, create_edit, create-deck, asset, effect*, image, movie, video, three, tuto, migrate, perf, clean): `생성자: 자기 검증은 사전 점검일 뿐이다. 최종 판정은 독립 verify 노드가 낸다. 미완료 시 partial + remaining.`
- **utility**(나머지): `유틸리티: 부작용(외부 API/배포/삭제) 전 §7 destructive/cost_gate 규칙을 확인한다.`

### 준수 검증
`scripts/lint-skill-protocol.mjs` 가 (1) 블록 존재 (2) 폐기 패턴(§9) 문구 부재 (3) frontmatter 파싱을 검사한다.
릴리스 전 `node scripts/lint-skill-protocol.mjs && node scripts/generate-skill-catalog.mjs` 실행이 필수다.

---

## Iron Law
**근거 없는 완료는 완료가 아니다. 진척 없는 반복은 반복이 아니다. 막힌 노드를 안고 전진하지 않는다.**

ARGUMENTS: $ARGUMENTS
