---
name: design
description: "UI/UX Design + Implementation. Creative Brief → shadcn/ui + motion. Fidelity Score v4.2 (24-dim), Anti-Generic Rules, Font Registry (EN/KR), Senior Effects (S/A/B), Editorial Layout, Video Background, Industry Data Lookup, Design DNA Resolver, DESIGN.md Export, 3-Dial System, Creative Arsenal, Korean Content Standards, Landing Section Library, Bento Archetypes, Implementation Guards. --ref pixel clone."
agent: frontend-architect
agents: [ux-designer, frontend-architect, design-dna-analyst, image-gen-artist, design-validator, effect-composer]
davinci-phase: design
allowed-tools: [Write, Edit, Read, Bash, Glob, Grep, Task, WebFetch, WebSearch]
next-skill: dev
skill-type: flexible
thinking: ultra
mcp-servers: [sequential, aside, codegraph]
required-model: claude-opus-4-8
model-lock: enforced
thinking-effort: high
skills-ref:
  - davinci_framework/agent-skills/skills/mengto-style-index
  - davinci_framework/agent-skills/skills/mengto-landing-page
  - davinci_framework/agent-skills/skills/mengto-pricing-page
  - davinci_framework/agent-skills/skills/mengto-animation-systems
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 생성자: 자기 검증은 사전 점검일 뿐이다. 최종 판정은 독립 verify 노드가 낸다. 미완료 시 partial + remaining.

# /da:design v5.0

## MengTo Reference Skills (on-demand — 필요 시에만 Read)
> 경로: `~/.claude/plugin/agent-skills/skills/<name>/SKILL.md`
- `mengto-style-index`: 시각 방향 후보 탐색 — 서명 스캔 후 선택분만 로드
- `mengto-landing-page`: 랜딩 정보구조/전환 전략
- `mengto-pricing-page`: 프라이싱 페이지 구조/실험
- `mengto-animation-systems`: 모션 시스템 설계 기준
> **MODEL LOCK**: 이 스킬은 무조건 **Claude Opus 4.8** (`claude-opus-4-8`)로 실행됩니다.
> UI 프리셋/세션 설정으로 변경 불가 — `modelConfigStore.FORCED_SKILL_MODELS`에서 강제됩니다.
>
> **EFFORT LOCK**: Thinking effort `high` 강제 적용 — `modelConfigStore.FORCED_SKILL_EFFORTS`에서 강제됩니다.


Premium UI/UX design. Creative Brief → Component Assembly → Design Restructure → shadcn/ui + motion 구현. Senior designer 수준 출력.

## Flags

| Flag | Description |
|------|-------------|
| (auto) | `.template-context.json` 존재 시 Redesign 모드 |
| `--ref` | Pixel-faithful clone 모드 |
| `--no-effect` | Effect 통합 스킵 |
| `--full-redesign` | preserve_files 무시, Creative Brief부터 풀 파이프라인 |
| `--review` | Phase 6 only — Fidelity Score 측정만 |
| `--improve` | 최하위 3개 차원 타겟 개선 (Phase 3-5) |
| `--design-md` | DESIGN.md 9-Section 강제 출력 |
| `--no-design-md` | DESIGN.md Export 비활성화 |

### Redesign Mode
`.template-context.json` 존재 시 자동 활성화. `redesign_targets`만 수정, `preserve_files` 보존.
`--full-redesign`은 제약 무시 전면 재설계. `--review`는 Phase 6만, `--improve`는 Phase 3-5만.

## Pipeline (v5)

**Phase 1 — Brief** (전제: shadcn/ui + motion + lenis 설치 확인)

**★ Phase 1 첫 번째 행동은 반드시 Interactive Discovery이다. 이 단계를 건너뛰면 프로토콜 위반.**

**[Step 1] Interactive Discovery — AskUserQuestion 필수 호출**
`.design-preference.json` 존재 여부와 무관하게, 사용자에게 디자인 방향을 확인한다.
AskUserQuestion 도구를 아래 파라미터로 호출 (options 최대 4개 제한 준수):
```
questions: [
  {
    "question": "어떤 디자인 성격이 좋을까요?",
    "header": "Persona",
    "options": [
      {"label": "minimal", "description": "깔끔하고 정돈된 인터페이스 (variance:3 motion:2 density:3)"},
      {"label": "bold", "description": "강렬하고 실험적인 레이아웃 (variance:9 motion:8 density:6)"},
      {"label": "elegant", "description": "절제되고 세련된 분위기 (variance:5 motion:4 density:3)"},
      {"label": "terminal", "description": "데이터 중심 고밀도 인터페이스 (variance:6 motion:3 density:8)"}
    ],
    "multiSelect": false
  },
  {
    "question": "원하는 색상 톤/분위기가 있나요?",
    "header": "Tone",
    "options": [
      {"label": "warm/professional", "description": "따뜻한 톤, 비즈니스/SaaS 느낌"},
      {"label": "cool/tech", "description": "차가운 톤, 테크/AI 느낌"},
      {"label": "dark/glow", "description": "어두운 배경 + 네온/글로우 효과"},
      {"label": "luxury/editorial", "description": "하이엔드, 매거진/프리미엄 느낌"}
    ],
    "multiSelect": false
  },
  {
    "question": "참고할 사이트나 영감이 있나요? (선택, 없으면 스킵)",
    "header": "Reference",
    "options": [
      {"label": "없음", "description": "Design DNA Resolver가 최적 레퍼런스 자동 매칭"},
      {"label": "직접 입력", "description": "URL이나 브랜드명 입력 (예: vercel, stripe, linear)"}
    ],
    "multiSelect": false
  }
]
```
참고: playful/neutral 등 나머지 선택지는 "Other" 자유입력으로 커버됨 (AskUserQuestion 자동 제공).

**FORBIDDEN — Discovery 없이 다음 행동 금지:**
- AI가 페르소나/톤을 자동 결정하고 사용자에게 안 물어봄
- 사용자 프롬프트에서 "느낌"을 추론해서 Discovery 생략
- Creative Brief부터 바로 생성
- 컴포넌트 매칭/코드 작성 시작
- `.design-preference.json` 읽고 그대로 사용 (변경 확인 없이)

**[Step 2] Persona → 3-Dial 매핑**: 선택된 페르소나로 DESIGN_VARIANCE/MOTION_INTENSITY/VISUAL_DENSITY 자동 설정(references/dial-system.md). 사용자 커스텀 오버라이드 허용.
**[Step 3] Industry Data Lookup**(references/industry/) + **Design DNA Resolver**(references/design-md/): Discovery 결과 기반 자동 매칭.
**[Step 4] Creative Brief 생성**: Color/Typography 3 variants/Tone/Motion/Layout. Korean Content Standards(references/korean-content-standards.md). DTCG Token Export(design.tokens.json). DESIGN.md 9-Section Export(--design-md). Industry Color Augmentation: colors.csv Primary→--primary 매핑.
**[Step 5] Brief 확인 Gate**: Creative Brief 결과를 사용자에게 제시하고 확인/수정 받은 후 Phase 2 진행. **사용자 확인 없이 Phase 2 진입 금지.**

**Phase 2 — Effect + Typography** (--no-effect로 스킵 가능)
★ 필수: 3개 이펙트 스킬을 순차 호출할 것. da:effect_bg (배경) -> da:effect_text (텍스트) -> da:effect_particle (파티클). 각 스킬의 SKILL.md + references/ 참조.
1. Creative Brief 톤 -> 각 effect 스킬 Tone Preset 매핑 (references/context-bridge.md의 DESIGN_CONTEXT 포맷 사용)
2. 3개 이펙트 스킬 순차 호출: da:effect_bg (Vanta WebGL + L4/L5) -> da:effect_text (Anime.js) -> da:effect_particle (tsParticles). 각 스킬이 독립 Iron Rules 준수 (references/senior-effects.md S/A/B Tier)
3. VantaBackground + TextAnimation + ParticleOverlay + InteractionLayer + FinishingOverlay + EffectLoader 컴포넌트 구현 (Effect 전용 파일 분리). THREE static import + Vanta children 패턴 + splitText+createScope 패턴 필수.
4. Typography System 확정: 크기 3x+ 점프, weight 극단 대비 (100/200 vs 800/900)
5. Phase 3에서 Hero 콘텐츠를 Effect 위에 배치 (z-index layering). Device Tier Detection으로 저사양 자동 다운그레이드.
Video Background(@remotion/player) 옵션. 개별 이펙트 스킬 단독 호출도 지원 (/da:effect_bg, /da:effect_text, /da:effect_particle).

**Phase 3 — Component Assembly** (신규, 기존 Layout 흡수)
Brief 기반 블록 선택 + 조립 명세 생성. references/assembly-spec.md 참조.
1. da:plan의 template_foundation에서 base template 확인 (있으면 Assembly Spec에 template_base 반영)
2. block-registry.json 메타데이터만 로드 (전체 TSX 로드 금지 — 토큰 예산 절약)
3. Brief 의도 + 페이지 목적 기반 카테고리별 최적 블록 선택 (10개 카테고리: hero/features/pricing/testimonial/cta/navigation/footer/dashboard/form/content)
4. 선택된 블록의 TSX 코드만 Read (선택적 로딩 — 필요한 블록만)
5. Assembly Spec (YAML) 생성: 페이지별 섹션 구성 명세 (블록 ID + customization + effect 연결)
6. 블록이 없는 카테고리는 기존 Layout 참조 (landing-section-library, creative-arsenal, bento-archetypes)로 fallback
★ 블록 없이 호출 시 기존 v4 Layout Phase로 자동 fallback (하위 호환 100%)

**Phase 4 — Design Restructure** (신규)
Assembly Spec에 디자인 토큰 적용 + Brief 톤/무드 기반 커스터마이즈. references/assembly-spec.md 참조.
1. Assembly Spec의 각 블록에 design.tokens.json 디자인 토큰 적용
2. Brief 톤/무드에 맞게 블록 커스터마이즈 결정 (색상/타이포/간격/모션)
3. 기존 Layout 참조 적용: Editorial Layout(references/editorial-layout.md), Creative Arsenal(references/creative-arsenal.md, 44+ patterns), Landing Section Library(references/landing-section-library.md, 17 patterns), Bento Archetypes(references/bento-archetypes.md)
4. Section Diversity Audit: 연속 동일 레이아웃 진단 → 위반 섹션 블록 교체
5. Anti-Generic Rules(references/anti-generic-rules.md) 적용: 7 Core Principles + 20 NEVER/INSTEAD Pairs
6. 최종 Restructured Spec 출력 (Phase 5 Implement의 입력)

**Phase 5 — Implement**
Restructured Spec 기반 코드 생성. 구현 전 references/design-examples/ 예시 패턴을 참고하되, 그대로 복사하지 마라. 패턴의 "왜"를 이해하고 프로젝트에 맞게 변형할 것.
1. Restructured Spec의 블록 코드 복사 + 커스터마이즈 적용 (토큰, 색상, 타이포, 간격)
2. 템플릿 코드와 블록 통합 (import, 라우팅, 레이아웃 구성)
3. 인터랙션/기능 개발 (스크롤 애니메이션, 호버 효과, 반응형)
4. Implementation Guards(references/implementation-guards.md: RSC Safety, Dependency Verification). Component State Spec(references/component-state-spec.md). UX Rules(references/industry/ux-rules.csv, 보충).
5. Section Diversity Audit: 구조 반복 진단 → 위반 섹션 자동 수정. Web Design Guidelines Cross-Reference: 접근성/포커스/폼/모션/터치/네비게이션 검증.

**Phase 6 — Validate**
Fidelity Score v4.2: 24 dimensions (9 design + 11 code + 2 senior + 2 new), 60-point passing. references/fidelity-score-v42.md 참조.

## Progress Tag (GUI 진행률)
각 Phase 진입 시 progress 태그를 출력하여 davinci-gui 프로그레스 바를 갱신한다.
```
Phase 1 Brief:     <!-- progress: {"skill":"da:design","stage":"design","percent":10,"label":"Brief"} -->
Phase 2 Effect:    <!-- progress: {"skill":"da:design","stage":"design","percent":25,"label":"Effect"} -->
Phase 3 Assembly:  <!-- progress: {"skill":"da:design","stage":"design","percent":45,"label":"Assembly"} -->
Phase 4 Restructure: <!-- progress: {"skill":"da:design","stage":"design","percent":60,"label":"Restructure"} -->
Phase 5 Implement: <!-- progress: {"skill":"da:design","stage":"design","percent":80,"label":"Implement"} -->
Phase 6 Validate:  <!-- progress: {"skill":"da:design","stage":"design","percent":95,"label":"Validate"} -->
```

## Iron Law (6)

1. **Interactive Discovery 필수**: Phase 1 첫 행동은 AskUserQuestion이다. 사용자 응답 없이 Creative Brief 생성/코드 작성 금지. 프로토콜 위반 시 전체 파이프라인 무효.
2. **shadcn/ui 필수**: shadcn/ui + motion + tailwindcss-motion + radix-ui + lenis. 스킵 불가.
3. **Creative Brief 필수**: 모든 디자인은 Creative Brief + block-registry.json Component Registry 기반. Phase 3에서 registry 메타데이터로 블록 선택, 선택된 블록 TSX만 로드.
4. **Font 3 Variants 필수**: display + body + mono. 단일 폰트 금지. Pretendard 남용 금지(references/font-registry.md).
5. **Section Diversity 필수**: 연속 2 섹션 동일 레이아웃 금지. 페이지당 최소 4 패턴.
6. **Anti-Convergence**: 첫 번째 흔한 선택을 버려라. LLM 분포 중심 수렴이 "AI 티"의 원인.

## Transition
- **Next**: /da:dev or /da:asset or /da:verify
- **Phase 2 단독**: /da:effect_bg, /da:effect_text, /da:effect_particle (독립 호출 지원)
