---
name: visual-qa
description: "AI-powered Visual QA Loop. Aside MCP screenshot capture (dv.shot/dv.responsive) + Claude Vision analysis + runtime error gate + auto-fix iteration. Fidelity Score 0-100."
agent: qa-strategist
agents: [qa-strategist, frontend-architect]
davinci-phase: check
allowed-tools: [Write, Edit, Read, Bash, Glob, Grep]
next-skill: e2e
skill-type: flexible
thinking: ultra
mcp-servers: [aside, codegraph]
skills-ref:
  - davinci_framework/agent-skills/skills/mengto-stitched-full-page-capture
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 검증자: items[] 기반 match rate와 4값 verdict(MET/NOT_MET/BLOCKED/IMPOSSIBLE)를 handoff에 포함. 생성자와 다른 컨텍스트에서 실행된다.

# /da:visual-qa - AI Screenshot Verification Loop

## MengTo Reference Skills (on-demand — 필요 시에만 Read)
> 경로: `~/.claude/plugin/agent-skills/skills/<name>/SKILL.md`
- `mengto-stitched-full-page-capture`: 풀페이지 캡처 실패(공백/회색) 시 스티칭 절차
## Tool Parameter Rules -> See CLAUDE.md (ABSOLUTE)

## Browser: Aside MCP (da:protocol §11)
모든 캡처·상호작용은 `mcp__aside__repl` 로 한다. `dv` 헬퍼는 hook 이 자동 주입한다.
Aside 미실행 시에만 Playwright MCP fallback (handoff 에 `browser: playwright-fallback`).

## Arguments
`--url <url>` (기본: 실행 중 dev server — `da:devsh` 포트 또는 `package.json` dev 스크립트 포트)
`--threshold <n>` (기본 85) · `--max-iterations <n>` (기본 3) · `--ref <design image/html>` (비교 기준, 선택)

## Loop (iteration i = 1..max)

### Step 1 — Capture (Aside)
```js
// 호출 1: 열기 + 런타임 상태
console.log(JSON.stringify(await dv.open(URL)));
console.log(JSON.stringify(await dv.report()));
console.log((await snapshot(page, {interactive:true})).tree);
```
**Viewport 선택 (대상 플랫폼이 실제로 지원하는 폭만 검사)**
| 대상 | 판별 | viewport 목록 | 입력 |
|------|------|---------------|------|
| 웹/모바일 웹 | 기본 | `['mobile','tablet','desktop']` | touch + mouse |
| Tauri 데스크톱 | `src-tauri/tauri.conf.json` 존재 | `[{name:'min', width: minWidth, height: minHeight}, {name:'default', width, height}, {name:'wide', width:1920, height:1080}]` | mouse |
| Electron | `electron` 의존성 + `BrowserWindow({minWidth})` | Tauri 와 동일 규칙 | mouse |
| 모바일 웹 번들 (`mobile.html`, `vite.mobile.config.*`) | 별도 URL | `['mobile','tablet']` | touch |

```js
// 호출 2: 반응형 스크린샷 + 문서 가로 overflow + 화면 밖으로 잘린 상호작용 요소(offscreenInteractive)
const vq_i = await dv.responsive('vqa-i' + I, VIEWPORTS);
console.log(JSON.stringify(vq_i));
await dv.viewport('desktop'); await dv.shot('vqa-i' + I + '-full', {fullPage:true});
```
- 반환된 절대 경로 PNG 를 `Read` 로 열어 Vision 분석한다.
- 주요 인터랙션(네비게이션, 폼, 모달, 다크모드 토글)은 snapshot ref 로 클릭 → `dv.shot()` → `dv.report()` 로 상태별 캡처.
- 다크모드: `await page.emulateMedia({colorScheme:'dark'})` 후 재캡처.

### Step 2 — Score (Claude Vision, 0-100)
| 차원 | 가중치 | 기준 |
|------|-------|------|
| Layout | 25 | 정렬·간격·그리드, `--ref` 와의 구조 일치 |
| Completeness | 20 | 빈 영역/placeholder/깨진 이미지 없음 (`dv.resources({failed:true})` = 0) |
| Typography | 15 | 위계·가독성·한글 줄바꿈 |
| Responsive | 20 | 선택한 모든 viewport 에서 `overflowX:false` + `offscreenInteractive:[]`. 타겟 크기: touch 입력 ≥ 44px, mouse 전용 ≥ 24px (WCAG 2.2 AA 2.5.8) |
| Interactive | 20 | 상호작용 후 기대 상태, 콘솔 에러 0 |

**Runtime Gate (점수와 별개, 하드 게이트)**: `dv.report().ok === false`(uncaught error·console.error·실패 요청·에러 오버레이) 이면 점수와 무관하게 해당 iteration 은 fail.

### Step 3 — Fix
- 점수 미달 항목별로 원인 코드를 `codegraph_explore` 로 찾고 `Edit` 로 최소 수정.
- HMR 반영 후 `await dv.reload()` 로 재캡처 (boot 캡처 재설치).

### Step 4 — Exit
- score ≥ threshold AND runtime gate pass → `completed`
- 개선폭 < 5점 (stagnation) 또는 max 도달 → `partial` (잔여 이슈 remaining[])
- 마지막에 `await closeTab(page)` 로 검증 탭 정리.

## Handoff
```json
{"skill":"da:visual-qa","status":"completed|partial|blocked","verdict":"MET|NOT_MET|BLOCKED",
 "fidelity_score":0,"pass":false,"iterations":1,"browser":"aside",
 "evidence":["<dv.shot 절대 경로>","dv.report: {ok, errors, failedRequests}"],
 "items":[{"id":"vqa-layout","status":"pass|fail","severity":"medium"}],"remaining":[]}
```
