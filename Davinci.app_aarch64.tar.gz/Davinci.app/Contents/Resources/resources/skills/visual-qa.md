---
name: visual-qa
description: "AI-powered Visual QA Loop. Playwright MCP screenshot capture + Claude Vision analysis + auto-fix iteration. Fidelity Score 0-100."
agent: qa-strategist
agents: [qa-strategist, frontend-architect]
davinci-phase: check
allowed-tools: [Write, Edit, Read, Bash, Glob, Grep]
next-skill: e2e
skill-type: flexible
thinking: ultra
mcp-servers: [playwright, codegraph]
skills-ref:
  - davinci_framework/agent-skills/skills/mengto-stitched-full-page-capture
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 검증자: items[] 기반 match rate와 4값 verdict(MET/NOT_MET/BLOCKED/IMPOSSIBLE)를 handoff에 포함. 생성자와 다른 컨텍스트에서 실행된다.

# /da:visual-qa - AI Screenshot Verification Loop

## MengTo Reference Skills (on-demand — 필요 시에만 Read)
> 경로: `~/.claude/plugin/agent-skills/skills/<name>/SKILL.md`
- `mengto-stitched-full-page-capture`: 풀페이지 캡처 실패(공백/회색) 시 스티칭 절차
## Tool Parameter Rules -> See CLAUDE.md (ABSOLUTE)


Read the full SKILL.md protocol and execute:
```
Read(file_path="davinci-plugin/skills/da/visual-qa/SKILL.md")
```

Follow the Execution Protocol in SKILL.md exactly.
