---
name: token
description: CrossRamp token management — Interactive CLI skill for ERC20 token deploy, mint, and burn
agent: starter-guide
agents: [senior-fullstack]
davinci-phase: null
allowed-tools: [Bash, Read, AskUserQuestion, Glob]
next-skill: null
skill-type: rigid
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 유틸리티: 부작용(외부 API/배포/삭제) 전 §7 destructive/cost_gate 규칙을 확인한다.

# /da:token - CrossRamp Token Management

Deploy, mint, and burn ERC20 tokens on the CrossRamp platform via clientKey authentication.
Forge pool creation must be done by the user directly on the frontend.

## Quick Start

### 1. Environment Variable Setup

Create a `.env` file and configure client authentication credentials:

```
CLIENT_KEY=your-client-key
CLIENT_SECRET=your-client-secret
```

### 2. Install Dependencies

```bash
cd davinci_framework/davinci-plugin/skills/da/token && npm install
```

### 3. Run CLI

```bash
node token-cli.js deploy "MyToken" "MTK" "A fun token" "https://img.png" "0x1234..." "MyProject"
node token-cli.js mint "0xABCD..." "1000000" "0x5678..."
node token-cli.js burn "0xABCD..." "500000"
node token-cli.js info "0xABCD..."
```

## Agent Execution Guide

When a user requests token-related operations, proceed in the following order.

### Step 0: Action Selection

If user does not specify an action:

```yaml
AskUserQuestion:
  question: "Which token operation would you like to proceed with?"
  header: "Token Action"
  options:
    - label: "Deploy"
      description: "Deploy a new ERC20 token"
    - label: "Mint"
      description: "Mint additional supply to an existing token"
    - label: "Burn"
      description: "Burn existing token supply"
    - label: "Info"
      description: "Query deployed token status"
```

### Step 1: Environment Variable Check

```bash
cd davinci_framework/davinci-plugin/skills/da/token
test -f .env && echo "ENV_OK" || test -f ../../../../.env && echo "ENV_ROOT" || echo "ENV_MISSING"
```

If `ENV_MISSING`, request CLIENT_KEY, CLIENT_SECRET input from the user.

### Step 2: Dependency Check

```bash
test -d node_modules && echo "DEPS_OK" || npm install
```

### Step 3A: Deploy (Token Deployment)

Information to collect from user:

| Field | Description | Example |
|-------|-------------|---------|
| Token name | Name of the token | "MyToken" |
| Symbol | Token symbol (uppercase recommended) | "MTK" |
| Token description | Token description | "A fun community token" |
| Image URL | Token image URL (PNG) | "https://example.com/token.png" |
| User wallet | Token owner wallet address | "0x1234..." |
| Project name | Project name | "MyProject" |

Execute:
```bash
node token-cli.js deploy "TokenName" "Symbol" "TokenDesc" "ImageURL" "UserWallet" "ProjectName"
```

Deliver results:
- `tokenAddress`: Token contract address
- `tradeLink`: `https://x.crosstoken.io/forge/token/{tokenAddress}` (valid after Forge pool creation)
- ⚠️ **Forge pool creation must be done by the user directly on the frontend.**

### Step 3B: Mint (Token Minting)

| Field | Description | Example |
|-------|-------------|---------|
| Token address | Deployed token contract address | "0xABCD..." |
| Amount | Amount to mint | "1000000" |
| Recipient wallet | Wallet address to receive tokens | "0x5678..." |

```bash
node token-cli.js mint "TokenAddress" "Amount" "RecipientWallet"
```

### Step 3C: Burn (Token Burning)

| Field | Description | Example |
|-------|-------------|---------|
| Token address | Deployed token contract address | "0xABCD..." |
| Amount | Amount to burn | "500000" |

```bash
node token-cli.js burn "TokenAddress" "Amount"
```

### Step 3D: Info (Token Query)

| Field | Description | Example |
|-------|-------------|---------|
| Token address | Token contract address to query | "0xABCD..." |

```bash
node token-cli.js info "TokenAddress"
```

### Step 4: Deliver Results

Deliver script output to user in structured format.

## Technical Details

### Authentication
Authenticate API calls with `Authorization: API-Key {clientKey}:{clientSecret}` header.

### Configuration Values

| Item | Value |
|------|-----|
| API Base URL | `https://cross-console-api.crosstoken.io` |
| Deploy Endpoint | `/api/client/mcp/builder` |
| Trade URL | `https://x.crosstoken.io/forge/token` |

### Environment Variable Overrides

| Variable | Description |
|----------|-------------|
| `API_BASE_URL` | Override API base URL |
| `MINT_ENDPOINT` | Override Mint API path |
| `BURN_ENDPOINT` | Override Burn API path |
| `INFO_ENDPOINT` | Override Info API path |

## Precautions

1. **Environment variables required**: `CLIENT_KEY`, `CLIENT_SECRET` must be configured in `.env` file
2. **Image format**: Only PNG supported for Deploy
3. **Symbol duplication**: Already existing symbols cannot be used (case-insensitive)
4. **Forge pool separate**: After token deployment, Forge pool creation must be done by the user directly on the frontend
5. **Mint/Burn endpoints**: Override with environment variables if default paths are incorrect

## Folder Structure

```
skills/da/token/
├── SKILL.md           # This file (usage guide)
├── SKILL_EN.md        # English guide
├── token-cli.js       # Unified CLI script
└── package.json       # Dependency definitions
```
