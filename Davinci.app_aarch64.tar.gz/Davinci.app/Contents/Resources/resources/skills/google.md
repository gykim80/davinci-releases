---
name: google
description: Google Workspace integration — Access 17+ Google services via gws CLI including Drive, Gmail, Sheets, Calendar, Docs, Chat
agent: google-workspace-agent
agents: [google-workspace-agent, senior-fullstack]
davinci-phase: null
allowed-tools: [Bash, Read, Write, AskUserQuestion, Glob, Grep]
next-skill: null
skill-type: rigid
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 유틸리티: 부작용(외부 API/배포/삭제) 전 §7 destructive/cost_gate 규칙을 확인한다.

# /da:google - Google Workspace Integration

Access Google Workspace services through gws CLI.
Integrates 17+ services including Drive, Gmail, Sheets, Calendar, Docs, Chat, Meet, Tasks into a single skill.

## Quick Start

### 1. Install gws CLI

```bash
npm install -g @googleworkspace/cli@0.8.1
```

### 2. Authentication Setup

```bash
gws auth setup    # Enter OAuth Client ID/Secret (issued from GCP Console)
gws auth login    # Browser OAuth authentication
```

### 3. Connection Test

```bash
gws drive files list --params '{"pageSize":3}'
```

## Agent Execution Guide

### Phase 0: Environment Verification

```bash
which gws && gws --version || echo "GWS_NOT_INSTALLED"
```

If `GWS_NOT_INSTALLED`:
```bash
npm install -g @googleworkspace/cli@0.8.1
```

Check authentication status:
```bash
gws drive files list --params '{"pageSize":1}' 2>&1 | head -5
```

Guide user on authentication failure:
1. Google Cloud Console → APIs & Services → Credentials
2. Create OAuth 2.0 Client ID (Desktop app)
3. `gws auth setup` → Enter Client ID, Client Secret
4. `gws auth login` → Browser authentication

### Phase 1: Action Selection

If user does not specify an action:

```yaml
AskUserQuestion:
  question: "Which Google Workspace task would you like to proceed with?"
  header: "GWS Action"
  options:
    - label: "Gmail"
      description: "Send, triage, search emails (send, triage, watch)"
    - label: "Drive"
      description: "File upload, list, share (upload, list, share)"
    - label: "Sheets"
      description: "Spreadsheet read/write (read, append, create)"
    - label: "Calendar"
      description: "Event view/create (agenda, insert, find-free-time)"
```

Additional options (based on selected category):

| Category | Detailed Actions |
|----------|-----------------|
| Gmail | `+send` (send email), `+triage` (inbox summary), `+watch` (new mail monitoring) |
| Drive | `+upload` (file upload), `files list` (listing), `files get` (download) |
| Sheets | `+read` (read values), `+append` (add rows), `values update` (update values) |
| Calendar | `+agenda` (view events), `+insert` (create event), `events list` (full list) |
| Docs | `+write` (add text), `documents get` (read document) |
| Chat | `+send` (send message), `spaces list` (list spaces) |
| Workflow | `+standup-report` (daily briefing), `+meeting-prep` (meeting preparation), `+weekly-digest` (weekly summary) |

### Phase 2: Parameter Collection

Collect required parameters for the selected action via AskUserQuestion.

#### Gmail +send

| Field | Description | Example |
|-------|-------------|---------|
| --to | Recipient email | "user@example.com" |
| --subject | Subject | "Sprint Report" |
| --body | Body | "Sprint results..." |
| --cc | CC (optional) | "team@example.com" |

#### Sheets +read

| Field | Description | Example |
|-------|-------------|---------|
| --spreadsheet-id | Spreadsheet ID | "1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgVE2upms" |
| --range | Cell range | "Sheet1!A1:D10" |

#### Calendar +insert

| Field | Description | Example |
|-------|-------------|---------|
| --summary | Event title | "Sprint Review" |
| --start | Start time (RFC3339) | "2026-03-10T14:00:00+09:00" |
| --end | End time (RFC3339) | "2026-03-10T15:00:00+09:00" |
| --attendees | Attendees (optional) | "user1@example.com,user2@example.com" |

### Phase 3: Execution

#### Execution Rules by Safety Level

```yaml
Safe (auto-execute):
  - Read operations: list, get, search, triage, agenda, read, schema
  - e.g.: gws drive files list --params '{"pageSize":10}'

Confirm (execute after user confirmation):
  - Write operations: send, append, insert, create, upload, write, update
  - e.g.: "Sending email to user@example.com. Proceed?"

Blocked (--dry-run enforced):
  - Delete operations: delete, trash, remove
  - Bulk operations: batch*, bulk*
  - e.g.: gws drive files delete --dry-run --params '{"fileId":"..."}'
```

#### Execution Command Patterns

```bash
# Helper commands (simple)
gws gmail +send --to "user@example.com" --subject "Subject" --body "Body"
gws sheets +read --spreadsheet-id "ID" --range "Sheet1!A1:D10"
gws calendar +agenda
gws workflow +standup-report

# Direct API calls (detailed)
gws drive files list --params '{"pageSize":10,"q":"mimeType=\"application/pdf\""}'
gws sheets values get --params '{"spreadsheetId":"ID","range":"Sheet1!A:D"}'
gws gmail messages list --params '{"q":"is:unread","maxResults":5}'
```

#### Output Format Options

```bash
--format json    # Default (optimal for agent pipelines)
--format table   # Human-readable table
--format yaml    # YAML format
--format csv     # CSV format
```

### Phase 4: Results Report

Deliver execution results to user in structured format.

On success:
- Summarize key results
- Provide related URL/ID
- Suggest next possible actions

On failure:
- Error message + root cause analysis
- Provide resolution guide

## da:work Pipeline Integration

Commands for auto-trigger after da:work completion:

```bash
# Record sprint metrics
gws sheets +append --spreadsheet-id "ID" --range "Sheet1" --values '[["2026-03-09","Phase 4","100%","PASS"]]'

# Team notification email
gws gmail +send --to "team@company.com" --subject "Sprint Complete" --body "Phase 4 complete, match rate 95%"

# Chat notification
gws chat +send --space-name "spaces/SPACE_ID" --text "✅ Sprint complete"

# Daily briefing
gws workflow +standup-report
```

## Precautions

1. **Authentication required**: Must complete `gws auth setup` + `gws auth login`
2. **GCP project**: OAuth Client ID issuance required from Google Cloud Console
3. **API quotas**: Google API quota limits exist, watch for rate limits on bulk calls
4. **No destructive operations**: delete/trash operations must use `--dry-run` then user confirmation
5. **JSON output**: `--format json` recommended for agent integration
6. **Version pinning**: Using gws 0.8.1 (pre-v1.0, breaking changes possible)
