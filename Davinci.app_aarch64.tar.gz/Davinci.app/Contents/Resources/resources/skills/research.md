---
name: research
description: "Deep research with adaptive planning, multi-hop exploration, confidence scoring. Market research auto-detection."
agent: cto-lead
agents: [cto-lead, deep-research-agent, market-researcher]
davinci-phase: null
allowed-tools: [Read, Glob, Grep, Bash, Write, Task, WebSearch, WebFetch]
next-skill: null
skill-type: flexible
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 생성자: 자기 검증은 사전 점검일 뿐이다. 최종 판정은 독립 verify 노드가 낸다. 미완료 시 partial + remaining.

## Tool Parameter Rules -> See CLAUDE.md (ABSOLUTE)

# /da:research - Deep Research

ultrathink

## Purpose
Comprehensive research for topics requiring web search, multi-hop exploration, and evidence-based analysis with confidence scoring.

## Usage
```
/da:research [topic-or-question] [--depth quick|standard|deep|exhaustive]
```

## Iron Law
**NO CONCLUSION WITHOUT CITED SOURCES AND CONFIDENCE SCORES.**

## Research Depth Levels

### Quick (1-2 sources)
- Single search query
- Top results summary
- Basic answer with source

### Standard (3-5 sources)
- Multiple search queries
- Cross-reference findings
- Confidence scoring

### Deep (5-10 sources)
- Multi-hop exploration
- Source credibility assessment
- Comprehensive synthesis

### Exhaustive (10+ sources)
- Systematic literature review
- Contradicting viewpoints analysis
- Full evidence chain

## Behavioral Flow

### Phase 1: Plan
```yaml
1. Query_Analysis:
   - Break topic into sub-questions
   - Identify knowledge domains
   - Plan search strategy

2. Source_Strategy:
   - Official documentation (Context7)
   - Web search (Tavily)
   - URL content extraction: Defuddle CLI -> WebFetch (fallback)
   - Codebase patterns (CodeGraph)
```

### Phase 2: Execute
```yaml
1. Multi_Hop_Search:
   - Execute parallel searches
   - Follow citation chains
   - Detect research loops

2. Evidence_Collection:
   - Extract key findings per source
   - Score source credibility
   - Note contradictions
```

### Phase 3: Synthesize
```yaml
1. Analysis:
   - Cross-reference findings
   - Resolve contradictions
   - Calculate confidence score

2. Report:
   - Executive summary
   - Detailed findings with citations
   - Confidence level per claim
   - Recommendations
```

## Boundaries

**Will:**
- Provide evidence-based findings with citations
- Score confidence levels per claim
- Identify knowledge gaps

**Will Not:**
- Present speculation as fact
- Skip source verification

---

## Market Research Auto-Manifestation

### Signal Detection Logic
When da:research executes, it analyzes the user prompt to automatically detect market research intent. Even without flags like `--market`, if market/demand intent is detected from natural language, the Reddit pipeline is automatically activated.

**Market Signal Keywords:**
- Korean: 시장조사, 수요, 경쟁사, 레딧, 고객, 니즈, 타겟, 마켓, PMF, 리드, 잠재고객, 되겠어?, 시장, 수익, 사용자 반응, 반응이 어때
- English: market research, demand, competitor, reddit, customer, needs, target audience, PMF, leads, viable, market fit, user feedback

**Session Context Detection:**
- `docs/prd/` exists in project -> PRD in progress -> high market relevance
- Executed right after `da:idea` -> inferred as idea validation intent
- `PLAN.md` mentions "target users" -> market validation needed

**Behavior Branching (AI auto-determines):**
```yaml
signal_detected:
  action: "Auto-activate Reddit pipeline + parallel technical research"
  agent: "market-researcher (Reddit/community analysis)"
  parallel: "Runs simultaneously with deep-research-agent (technical research)"
  output: "docs/research/market-{keyword}-{date}.md + CSV"

signal_not_detected:
  action: "Existing technical research mode (no change)"
  agent: "deep-research-agent (default)"
  output: "claudedocs/research_{topic}_{timestamp}.md"
```

### Reddit Market Research Pipeline

When a signal is detected, the `market-researcher` agent is spawned as a Task to execute the following pipeline:

#### Stage 1: Reddit Data Collection
```yaml
primary:
  method: "Reddit JSON API"
  endpoint: "reddit.com/r/{sub}/search.json?q={keyword}&sort=relevance&t=month&limit=25"
  headers: "User-Agent: DavinciResearch/1.0"
  rate_limit: "2-second intervals"

fallback_1:
  method: "RSS Feed"
  endpoint: "reddit.com/search.rss?q={keyword}"
  trigger: "When JSON API fails"

fallback_2:
  method: "WebSearch/Tavily"
  query: "site:reddit.com {keyword} {pain/solution/recommendation}"
  trigger: "When both API + RSS fail"

keyword_strategy:
  base: "{keyword}"
  pain_suffixes: [pain point, frustrating, problem, struggle, hate]
  solution_suffixes: [solution, alternative, recommendation, best, switch from]
  comparison_suffixes: [vs, comparison, better than, migrate from]
```

#### Stage 2: AI Lead Scoring
```yaml
dimensions:
  pain_intensity (1-10): "Problem severity"
  market_fit (1-10): "Product/service fit"
  urgency (1-10): "Resolution urgency"
  specificity (1-10): "Requirement specificity"

qualification:
  qualified: "Average >= 7 points"
  marginal: "Average 5-6.9 points"
  disqualified: "Average < 5 points"

false_positive_filters:
  1: "Bot accounts (karma < 100, account age < 30 days)"
  2: "Self-promotion posts"
  3: "Memes/humor"
  4: "Old posts (90+ days)"
  5: "Duplicate posts (same user)"
  6: "Deleted posts/comments"
  7: "Spam questions"
  8: "Off-topic"
  9: "General complaints (not specific demand)"
  10: "Technical help requests (no purchase intent)"
  11: "Price-only inquiries"
  12: "Already resolved issues"
```

#### Stage 3: Analysis & Deliverables
```yaml
analysis:
  pain_point_classification: "Aggregation by category"
  competitor_extraction: "Sorted by mention frequency"
  trend_detection: "Demand change tracking over time"

deliverables:
  markdown: "docs/research/market-{keyword}-{date}.md"
  csv: "docs/research/market-{keyword}-{date}.csv"
  template: "davinci-plugin/templates/market-research-report.md"
```

### Deliverable Format

#### Markdown Report (market-{keyword}-{date}.md)
```
# Market Research Report: {keyword}
> Created | Data Source | Analysis Period

## Executive Summary
## Data Collection Results (Table)
## Top Qualified Leads (Table)
## Pain Point Classification (By Category)
## Competitor Analysis (Mention Frequency, Complaints, Opportunities)
## Insights & Recommendations
## Raw Data (CSV Link)
```

#### CSV (market-{keyword}-{date}.csv)
```
Headers: title, subreddit, author, upvotes, pain_intensity, market_fit, urgency, specificity, total_score, qualified, pain_category, competitors_mentioned, url
```

### Market Research MCP Integration

| MCP Server | Role | Auto-Activation |
|------------|------|-----------------|
| **WebSearch/Tavily** | Reddit search, web search | Always |
| **WebFetch** | Reddit JSON/RSS data collection | On Reddit API calls |
| **Sequential** | Lead scoring, comprehensive analysis | Complex queries |
| **CodeGraph** | Research session persistence | Cross-session preservation |

### Market Research Iron Law

**Market judgment without data is speculation.**

All market judgments must be backed by actual Reddit/community data and lead scores. If demand signals are insufficient, honestly report as "insufficient data".
