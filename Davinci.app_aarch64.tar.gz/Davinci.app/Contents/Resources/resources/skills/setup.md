---
name: setup
description: "Install and configure required MCP servers for the Davinci plugin with automated health checks"
category: workflow
complexity: moderate
mcp-servers: []
personas:
  - devops-architect
  - self-review
modes: [sequential, diagnostic]
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 유틸리티: 부작용(외부 API/배포/삭제) 전 §7 destructive/cost_gate 규칙을 확인한다.

## Tool Parameter Rules → See CLAUDE.md (ABSOLUTE)

# /da:setup - MCP Server Setup

## Purpose
Install and configure MCP servers required for the Davinci plugin with automated inventory checking, validation, and health reporting.

## Usage
```
/da:setup [--all|--server <name>|--check|--repair]
```

## MCP Server Inventory

### Core (Required for Basic Operation)
| Server | Purpose | Install Command | Health Check |
|--------|---------|-----------------|--------------|
| **sequential-thinking** | Extended reasoning for complex tasks | `davinci mcp install sequential` | Ping test |

### Design (Project-level, auto-included)
| Server | Purpose | Config Location | Validation |
|--------|---------|-----------------|------------|
| **davinci-design** | Canvas design tools (90 tools) | `.mcp.json` | Port 7600 relay check |

> ⚠️ davinci-design MCP는 프로젝트 `.mcp.json`에 포함되어 있어 clone 시 자동 등록됩니다.
> davinci-gui가 실행 중이어야 port 7600 릴레이가 동작합니다.

### Recommended (Enhanced Capabilities)
| Server | Purpose | Install Command | Health Check |
|--------|---------|-----------------|--------------|
| **codegraph** | Semantic code operations | `davinci mcp install codegraph` | Symbol lookup test |
| **playwright** | Browser testing, E2E | `davinci mcp install playwright` | Browser launch test |

### Optional (External API Required)
| Server | Purpose | Install Command | Requirements |
|--------|---------|-----------------|--------------|

## Installation Sequence

### Phase 1: Inventory Check
```yaml
Actions:
  - Run: davinci mcp status
  - Parse: installed server list
  - Compare: against required inventory
  - Report: missing servers
```

### Phase 2: Installation (Sequential)
```yaml
Core_First:
  1. sequential-thinking → verify → continue

Recommended_Next:
  3. codegraph → verify → continue
  4. playwright → verify → continue

Optional_Last:
```

### Phase 3: Configuration Validation
```yaml
Validate:
  - Read: ~/.claude/settings.json
  - Schema: check mcpServers section
  - Backup: settings.json.bak before any writes
  - Update: add missing server entries
```

### Phase 4: Health Check
```yaml
Health_Tests:
  sequential: echo test → response time < 500ms
  codegraph: symbol search → no errors
  playwright: browser check → launches successfully
```

### Phase 5: Status Report
```yaml
Report_Format:
┌──────────────────┬───────────┬──────────────┬─────────────┐
│ Server           │ Status    │ Version      │ Health      │
├──────────────────┼───────────┼──────────────┼─────────────┤
│ sequential       │ ✅ Active │ 1.0.0        │ Healthy     │
│ davinci-design      │ ⚠️ Config │ project-mcp  │ GUI needed  │
│ codegraph           │ ❌ Missing│ -            │ -           │
│ playwright       │ ✅ Active │ 0.9.0        │ Healthy     │
└──────────────────┴───────────┴──────────────┴─────────────┘
```

## Behavioral Flow

### Main Command: /da:setup
```yaml
Step_1_Status_Check:
  - Execute: davinci mcp status
  - Parse: output for installed servers
  - Build: inventory comparison table

Step_2_User_Prompt:
  - If all installed: "✅ All MCP servers are already installed!"
  - If missing: "Missing servers detected. Install now? [Y/n]"
  - If --all flag: skip prompt, install all

Step_3_Installation_Loop:
  For each missing server:
    - Execute: davinci mcp install {server}
    - Monitor: installation progress
    - Verify: post-install health check
    - Rollback: if installation fails

Step_4_Configuration_Update:
  - Backup: cp ~/.claude/settings.json ~/.claude/settings.json.bak
  - Update: add server entries to mcpServers section
  - Validate: JSON syntax check
  - Restore: from backup if corrupted

Step_5_Final_Report:
  - Run: davinci doctor
  - Format: health status table
  - Suggest: next steps or fixes
```

### /da:setup --check
```yaml
Quick_Health_Check:
  - Skip installation phase
  - Run health checks only
  - Report current status
  - Exit without changes
```

### /da:setup --server <name>
```yaml
Single_Server_Setup:
  - Validate server name against inventory
  - Install/update single server only
  - Run targeted health check
  - Report success/failure
```

### /da:setup --repair
```yaml
Repair_Mode:
  - Detect broken installations
  - Remove corrupted configs
  - Reinstall from scratch
  - Validate all connections
```

## Error Handling

### Installation Failures
```yaml
NPM_Registry_Timeout:
  - Retry with: --registry https://registry.npmjs.org
  - Fallback: manual npm install instructions

Permission_Denied:
  - Suggest: npm install -g with sudo (cautiously)
  - Alternative: npx execution mode

Network_Offline:
  - Check: cached packages in ~/.npm
  - Provide: offline installation guide
```

### Configuration Corruption
```yaml
Invalid_JSON:
  - Auto-restore: from settings.json.bak
  - Manual fix: provide JSON validation hints
  - Reset option: minimal valid config template

Missing_Settings_File:
  - Create: minimal settings.json
  - Populate: with MCP server skeleton
```

### Health Check Failures
```yaml
Server_Unreachable:
  - Check: process running (ps aux | grep)
  - Restart: kill and reinstall
  - Debug: check logs in ~/.claude/logs/

API_Key_Invalid:
  - Prompt: enter valid API key
  - Store: in secure location only
  - Skip: optional servers without keys
```

## Advanced Features

### Batch Operations
```bash
# Install all recommended servers
/da:setup --all

# Install core + recommended (skip optional)
/da:setup --recommended

# Force reinstall everything
/da:setup --all --force
```

### Integration with da:work
When da:work detects missing MCP servers, it can trigger:
```
/da:setup --server {missing-server} --auto
```

### Settings.json Management
```json
{
  "mcpServers": {
    "sequential-thinking": {
      "command": "npx",
      "args": ["@modelcontextprotocol/server-sequential-thinking"]
    },
    "codegraph": {
      "command": "npx",
      "args": ["-y", "@colbymchenry/codegraph@latest", "serve", "--mcp", "--no-watch"]
    },
    "playwright": {
      "command": "npx",
      "args": ["@context-labs/playwright-mcp-server"]
    }
  }
}
```

## Boundaries

**Will:**
- Install and configure MCP servers via davinci CLI
- Validate ~/.claude/settings.json integrity
- Provide comprehensive health status reports
- Backup configurations before modifications
- Suggest fixes for common issues

**Will Not:**
- Modify system-level configurations
- Install servers outside the approved inventory
- Store API keys in plaintext files
- Override user's manual MCP configurations
- Install without user consent (except --auto mode)

## Completion Criteria

Installation is DONE when:
- ✅ All requested servers installed successfully
- ✅ Settings.json updated and valid
- ✅ Health checks pass for installed servers
- ✅ Status report displayed
- ✅ Backup created for rollback safety

Next recommended action: Run your project with full MCP capabilities!