---
name: railway
description: "Railway-specific deployment -- CLI auth, project link, staging deploy, production promote, monitoring."
agent: devops-guide
agents: [infra-architect]
davinci-phase: null
allowed-tools: [Read, Bash, Glob, Grep, Task]
next-skill: null
skill-type: flexible
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 유틸리티: 부작용(외부 API/배포/삭제) 전 §7 destructive/cost_gate 규칙을 확인한다.

## Tool Parameter Rules -> See CLAUDE.md (ABSOLUTE)
# /da:railway - Railway Deployment Protocol

## Purpose
Railway-specific deployment skill. Handles CLI authentication, project linking, staging-first deployment, production promotion, log monitoring, and rollback.

## Usage
```
/da:railway [--env staging|production] [--dry-run]
```

### Arguments
- `--env` — Target environment (default: staging -> production flow)
- `--dry-run` — Pre-flight checks only, no actual deployment

## Iron Law

> **Staging first, user confirm before production. Never deploy directly to production.**

## Behavioral Flow

### Phase 0: Pre-flight
```yaml
Pre_Flight:
  1. CLI_Check:
     - which railway || "Railway CLI not installed. See: https://docs.railway.app/guides/cli"
  2. Auth_Check:
     - railway whoami || "Not authenticated. Run: railway login"
  3. Project_Link:
     - railway status || "No linked project. Run: railway link"
  4. Git_Status:
     - git status --porcelain
     - Warn if working directory is dirty
  5. Service_Type_Verification (FR-07):
     - railway service list 실행
     - 각 서비스를 Database / Application으로 분류
     - DB 서비스(Postgres/MySQL/Redis) 목록을 명시적으로 출력
     - DB 서비스에 git source가 연결되어 있으면 즉시 경고
     - 이후 모든 배포 명령은 App 서비스에만 실행
     - DB 서비스에 redeploy/up 명령 절대 금지
```

### Phase 1: Deploy
```yaml
Deploy:
  1. Staging_Deploy:
     command: railway up --environment=staging
     action: Deploy to staging environment

  2. Staging_Verification:
     - railway logs -n 20 (check recent logs)
     - railway status (check deployment status)
     - Health check on staging URL
     - "Staging OK. Deploy to production?" -> request user confirmation

  3. Production_Deploy (after confirmation):
     command: railway up --environment=production
     action: Deploy to production environment
```

### Phase 2: Verify
```yaml
Verify:
  1. Health_Check:
     - curl -sI <production-url> | head -5
     - Verify HTTP 200 response

  2. Log_Check:
     - railway logs -n 30 --environment=production
     - Check for errors or warnings

  3. Status:
     - railway status (deployment details)
```

### Monitoring Commands
```yaml
Monitoring:
  logs: railway logs --json
  status: railway status
  graphql: "Railway GraphQL API (https://backboard.railway.app/graphql/v2)"
  variables: railway variables
```

### Rollback
```yaml
Rollback:
  immediate: railway redeploy (redeploy previous successful deployment)
  stop: railway down (stop service entirely)
  recover: railway up --environment=production (redeploy after fix)
```

## Safety Guardrails
```yaml
Mandatory:
  - Staging deploy before production
  - User confirmation before production deploy
  - Log check after every deployment
Forbidden:
  - Direct production deploy without staging
  - Deploying with unauthenticated CLI
  - Skipping log verification
```

## Boundaries

**Will:**
- Check CLI installation and authentication
- Deploy to staging, then promote to production
- Run health checks and log verification
- Provide rollback commands on failure

**Will Not:**
- Deploy to production without user confirmation
- Skip staging deployment
- Manage Railway dashboard settings or billing
- Configure custom domains (use Railway dashboard)
