---
name: clean
description: Code cleanup, workspace hygiene, and technical debt reduction
agent: pipeline-guide
agents: [senior-fullstack]
davinci-phase: archived
allowed-tools: [Write, Edit, Read, Bash, Glob, Grep, Task]
next-skill: next
skill-type: rigid
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 생성자: 자기 검증은 사전 점검일 뿐이다. 최종 판정은 독립 verify 노드가 낸다. 미완료 시 partial + remaining.

## Tool Parameter Rules -> See CLAUDE.md (ABSOLUTE)
# /da:clean - Code and Project Cleanup

ultrathink

> Claude MUST analyze cleanup impact before making any changes.

## Extended Thinking Protocol
- **Scan**: Scan entire codebase to identify cleanup targets
- **Assess**: Evaluate safety and impact of each cleanup item
- **Plan**: Plan safe cleanup order
- **Execute**: Execute cleanup step-by-step with verification

---

## 🎭 TOKEN EFFICIENCY MODE

### Symbol-Based Reporting
```yaml
Cleanup_Symbols:
  🗑️ delete    | 📦 archive   | 🔄 refactor
  ✂️ trim      | 📁 organize  | 🧹 clean
  ⚠️ skip      | ✅ done      | ❌ blocked

Status_Output:
  "[Action] [Target] [Reason]"

Examples:
  "🗑️ src/utils/old.ts (0 refs, last modified 2023)"
  "✂️ imports in api.ts (15 unused)"
  "📁 move tests/ → __tests__/ (convention)"
```

### Compact Progress Format
```yaml
Progress_Template:
  Phase: [Current/Total]
  🗑️ Deleted: X files, Y lines
  ✂️ Trimmed: X imports, Y vars
  📁 Organized: X moves
  ⏳ Remaining: X items

Example:
  "Phase: 2/4 | 🗑️ 3 files | ✂️ 47 imports | 📁 2 moves | ⏳ 12 items"
```

---

## 🔧 ORCHESTRATION MODE

### Tool Selection for Cleanup
```yaml
| Cleanup Task | Best Tool | Fallback |
|--------------|-----------|----------|
| Dead code detection | CodeGraph MCP | Grep patterns |
| Symbol references | codegraph_callers | Manual search |
| Safe rename | CodeGraph Edit | Edit + verify |
| Pattern cleanup | Morphllm MCP | Individual edits |
| Bulk operations | MultiEdit | Sequential Edit |
```

### Parallel Cleanup Execution
```yaml
Wave_1 (Analysis):
  - CodeGraph: Scan all symbols and references
  - Read: Check import graphs
  - Glob: Find candidate files

Checkpoint:
  - Classify cleanup items by safety
  - Plan execution order
  - Identify dependencies

Wave_2 (Safe Cleanup):
  - Remove unused imports (parallel)
  - Delete dead files (parallel)
  - Clean empty blocks (parallel)

Wave_3 (Risky Cleanup):
  - Refactor with user approval
  - Reorganize file structure
  - Update documentation
```

---

## 🔄 PM AGENT MAINTENANCE AUTOMATION

### Monthly Maintenance Cycle
```yaml
Documentation_Health_Check:
  Scan:
    - docs/ folder for outdated files
    - Last Verified dates > 6 months
    - Files with no recent references

  Actions:
    - Flag outdated documentation
    - Identify duplicates for merge
    - List candidates for deletion

Code_Pattern_Review:
  Analyze:
    - docs/patterns/ for outdated patterns
    - docs/mistakes/ for resolved issues
    - CLAUDE.md for stale rules

  Actions:
    - Archive resolved mistake docs
    - Update pattern examples
    - Prune obsolete rules

Memory_Cleanup:
  Operations:
    - list_memories() → Review all
    - Identify stale checkpoints
    - Archive completed plans

  Retention:
    - Keep: Active project context
    - Archive: Completed session summaries
    - Delete: Old checkpoints (>30 days)
```

### PDCA Integration for Cleanup
```yaml
Plan:
  - Identify cleanup scope
  - Assess risk for each item
  - Define success criteria
  Memory: write_memory("cleanup_plan", plan)

Do:
  - Execute cleanup in waves
  - Checkpoint after each wave
  - Track changes made
  Memory: write_memory("cleanup_checkpoint", progress)

Check:
  - think_about_task_adherence()
  - Verify no functionality broken
  - Validate tests still pass

Act:
  Success:
    - Document cleanup patterns
    - Update maintenance checklist
  Failure:
    - Rollback changes
    - Document what went wrong
    - Update prevention rules
```

---

## Triggers
- Code maintenance and technical debt reduction requests
- Dead code removal and import optimization needs
- Project structure improvement and organization requirements
- Monthly documentation and memory maintenance
- Pre-release cleanup and optimization

## Usage
```
/da:clean [target] [--type code|imports|files|docs|all] [--safe|--aggressive] [--interactive] [--maintenance]
```

---

## 🤖 SPECIALIZED AGENTS

### Refactoring Expert
```yaml
Role: Safe code transformation and cleanup
Focus:
  - Dead code identification
  - Import optimization
  - Code deduplication
  - Structure improvement

Tools:
  - CodeGraph: Symbol analysis, safe rename
  - Morphllm: Pattern-based cleanup
```

### Quality Engineer
```yaml
Role: Code quality assessment during cleanup
Focus:
  - Ensure cleanup doesn't break functionality
  - Verify test coverage maintained
  - Check for introduced issues
```

### PM Agent
```yaml
Role: Documentation and memory maintenance
Focus:
  - Outdated documentation cleanup
  - Memory/checkpoint pruning
  - Pattern library maintenance
  - Mistake archive management
```

---

## Behavioral Flow

### Phase 1: Analyze
```yaml
1. Scope_Detection:
   - Identify cleanup targets
   - Determine cleanup type
   - Assess current state

2. Reference_Analysis:
   - CodeGraph: Find all symbol references
   - Build dependency graph
   - Identify safe deletions

3. Risk_Assessment:
   - Classify items by safety level
   - Flag items needing approval
   - Estimate impact
```

### Phase 2: Plan
```yaml
1. Cleanup_Strategy:
   - Order by safety (safe first)
   - Group related cleanups
   - Plan rollback points

2. Approval_Queue:
   - List items needing confirmation
   - Prepare before/after previews
   - Document reasoning
```

### Phase 3: Execute
```yaml
1. Safe_Cleanup (Auto):
   - Unused imports
   - Dead code (0 references)
   - Empty blocks
   - Redundant type annotations

2. Interactive_Cleanup (--interactive):
   - Present changes for review
   - Apply approved changes
   - Skip declined items

3. Documentation_Cleanup (--maintenance):
   - Archive old docs
   - Merge duplicates
   - Update dates
```

### Phase 4: Validate
```yaml
1. Functionality_Check:
   - Run tests
   - Verify builds
   - Check for regressions

2. Report_Generation:
   - Summarize changes
   - List remaining items
   - Recommendations for future
```

---

> MCP Routing: See CLAUDE.md

---

## Key Patterns

### Dead Code Detection
```yaml
Detection_Criteria:
  Definitely_Dead:
    - 0 references (codegraph_callers)
    - Not exported
    - Not in test fixtures
    - Not dynamically referenced

  Probably_Dead:
    - Only self-references
    - Referenced in dead code
    - Last modified > 1 year

  Needs_Review:
    - Exported but unused in project
    - Referenced via string
    - Part of public API
```

### Import Optimization
```yaml
Cleanup_Actions:
  Remove:
    - Unused imports
    - Duplicate imports
    - Type-only imports (when not needed)

  Organize:
    - Sort alphabetically
    - Group by source (external/internal)
    - Separate type imports

  Consolidate:
    - Merge multiple imports from same module
    - Use namespace imports when appropriate
```

### Documentation Cleanup
```yaml
Maintenance_Checklist:
  ✅ All docs have Last Verified date
  ✅ No duplicate content
  ✅ All links valid
  ✅ Examples are current
  ✅ No outdated version references
  ✅ Archive old experiment logs (>7 days)
```

---

## AUTO-FIX VS APPROVAL-REQUIRED

### Auto-fix (Applies Automatically)
```yaml
Safe_Cleanups:
  - Unused imports removal
  - Dead code with 0 references
  - Empty blocks removal
  - Redundant type annotations
  - Trailing whitespace
  - Import sorting
```

### Approval Required (Prompts User)
```yaml
Risky_Cleanups:
  - Code with indirect references
  - Exports potentially used externally
  - Test fixtures/utilities
  - Configuration values
  - Public API changes
  - File deletions
```

### Safety Threshold
```yaml
Rules:
  - ANY usage path → prompt user
  - Affects public API → prompt user
  - Unsure → prompt user
  - --aggressive flag → reduce prompts
  - --safe flag → maximize prompts
```

---

## Examples

### Safe Code Cleanup
```
/da:clean src/ --type code --safe
# Agents: refactoring-expert, quality-engineer
# Only removes verified dead code
# Preserves all potentially used code
```

### Import Optimization
```
/da:clean --type imports
# Removes unused imports across project
# Organizes and sorts imports
# Framework-aware via Context7
```

### Comprehensive Cleanup
```
/da:clean --type all --interactive
# Full cleanup with approval prompts
# Includes code, imports, files
# User confirms each risky change
```

### Monthly Maintenance
```
/da:clean --maintenance
# PM Agent maintenance mode
# Cleans docs, archives, memory
# Updates Last Verified dates
```

### Aggressive Cleanup
```
/da:clean src/legacy/ --aggressive
# Thorough cleanup with minimal prompts
# For legacy code with known low usage
# Still validates test passage
```

---

## Cleanup Report Template

### Standard Report
```markdown
# Cleanup Report: [Target]

## Summary
| Action | Count | Size Reduction |
|--------|-------|----------------|
| 🗑️ Deleted | X files | X KB |
| ✂️ Trimmed | X imports | - |
| 📁 Organized | X moves | - |
| ⚠️ Skipped | X items | - |

## Deleted Files
- `src/old/unused.ts` (0 refs, 2023-01-15)
- `src/utils/deprecated.ts` (0 refs, 2022-08-20)

## Cleaned Imports
- `api.ts`: 15 unused imports removed
- `utils.ts`: 8 unused imports removed

## Skipped (Needs Review)
- `src/exports.ts`: Potentially used externally
- `src/config.ts`: Configuration values

## Test Validation
✅ All tests passing
✅ Build successful
```

### Compact Report
```
# Clean: src/

🗑️ 3 files (12KB) | ✂️ 47 imports | 📁 2 moves | ⚠️ 5 skipped
Tests: ✅ | Build: ✅
```

---

## Boundaries

**Will:**
- Systematically clean code with safety validation
- Remove verified dead code and unused imports
- Maintain documentation health with monthly maintenance
- Preserve all functionality through careful analysis

**Will Not:**
- Remove code without thorough reference analysis
- Skip safety validation for speed
- Delete files without user confirmation
- Compromise functionality for cleanliness

---

## Session End
Save checkpoint and proceed to the next step.
