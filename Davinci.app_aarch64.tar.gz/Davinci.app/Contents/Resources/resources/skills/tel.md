---
name: da:tel
description: "Telegram channel integration — remote commands, workflow notifications, file transfer"
category: channel
triggers:
  - telegram
  - tel
  - notification
  - alert
agent: telegram-channel
mcp:
  - da-tel
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 유틸리티: 부작용(외부 API/배포/삭제) 전 §7 destructive/cost_gate 규칙을 확인한다.

# /da:tel - Telegram Channel Integration

## Purpose
Telegram bidirectional integration channel. A bridge skill that sends Claude Code workflow notifications to Telegram and enables remote execution of da: prefixed commands from Telegram.

## Subcommands

### `da:tel setup <BOT_TOKEN>`
Set up Telegram Bot token and establish initial connection.

```bash
# Initial setup with Bot token
da:tel setup 123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11

# Setup flow:
# 1. Validate BOT_TOKEN (getMe API)
# 2. Save TELEGRAM_BOT_TOKEN to .env
# 3. Select Webhook or Polling mode
# 4. Send connection test message
```

### `da:tel status`
Display current Telegram connection status, notification level, and allowed user list.

```bash
da:tel status

# Output example:
# ✓ Bot: @davinci_dev_bot (connected)
# ✓ Mode: polling
# ✓ Notify: error-only
# ✓ Allowed users: [123456789, 987654321]
# ✓ Last activity: 2 min ago
```

### `da:tel access pair <CODE>`
Approve a pairing code issued by the bot in Telegram DM to register the user in the allowlist.

**Execution procedure (steps Claude MUST follow):**
1. Read the `~/.claude/channels/da-tel/access.json` file.
2. Find the entry matching `<CODE>` in the `pending` object.
3. Add that entry's `senderId` to the `allowFrom` array (deduplicate).
4. Delete that code entry from `pending`.
5. Write the modified JSON to `access.json`.
6. Create the `~/.claude/channels/da-tel/approved/` directory (mkdir -p).
7. Create an empty file `~/.claude/channels/da-tel/approved/<senderId>` (touch).
   → server.ts's checkApprovals() detects this file and sends a "Paired!" confirmation message to Telegram.
8. Report to user: "Pairing complete: user <senderId> added to allowlist".

**If code is missing or expired:** Return "Invalid or expired pairing code" error.

### `da:tel access allow <user_id>`
Directly add a specific Telegram user_id to allowFrom in access.json.

**Execution procedure:**
1. Read `~/.claude/channels/da-tel/access.json`.
2. Add `<user_id>` to the `allowFrom` array (deduplicate).
3. Write the modified JSON.

### `da:tel access remove <user_id>`
Remove a specific user_id from allowFrom.

**Execution procedure:**
1. Read `~/.claude/channels/da-tel/access.json`.
2. Remove `<user_id>` from the `allowFrom` array.
3. Write the modified JSON.

## Notification Levels

```yaml
all:        # All workflow event notifications (phase start/complete, warnings, errors)
error-only: # Error and failure events only (default)
off:        # Disable notifications (remote commands only)
```

Configuration:
```bash
da:tel notify all        # All notifications
da:tel notify error-only # Errors only
da:tel notify off        # Turn off notifications
```

## Remote Commands

Send `da:` prefixed commands in Telegram chat to execute in Claude Code.

```
# Sent from Telegram:
da:status          → Return current workflow status
da:verify --fast   → Execute da:verify skill
da:git status      → Check git status
da:token           → Check token usage

# Security rules:
# - Only user_ids registered in allowlist can execute
# - Destructive commands (clean, deploy --force) blocked
# - Execution results sent back to Telegram
```

## File Transfer

File transfer using the reply tool's files parameter.

```yaml
# Claude Code → Telegram:
# Send workflow deliverables (report.md, plan.md, etc.)
# Send screenshots, log files

# Telegram → Claude Code:
# Receive image files → save to project directory
# Receive config files → apply to .env, etc.
```

## Execution Flow

```
Phase 0: Environment check
  - TELEGRAM_BOT_TOKEN existence
  - Bot API connection test
  - Allowlist file verification

Phase 1: Routing
  - setup → Phase 2a (initial setup)
  - status → Phase 2b (status display)
  - access → Phase 2c (access control)
  - notify → Phase 2d (notification settings)
  - (no args) → interactive menu

Phase 2: Execution
  - Execute subcommand-specific logic
  - Telegram API calls
  - Result formatting

Phase 3: Report
  - Execution result summary
  - Next steps guidance
```

## Safety Rules

```yaml
Safe (auto-execute): status, notify, access pair
Confirm (confirmation required): setup, access allow, access remove
Blocked: Remote destructive commands (clean, deploy --force, git reset)
```

## Error Handling

| Error | Cause | Resolution |
|-------|-------|------------|
| `401 Unauthorized` | Invalid BOT_TOKEN | Re-run `da:tel setup <new_token>` |
| `403 Forbidden` | Bot not added to chat | Invite bot to chat |
| `409 Conflict` | Multiple Polling instances | Terminate existing instance then restart |
| `User not in allowlist` | Unregistered user | `da:tel access allow <user_id>` |
