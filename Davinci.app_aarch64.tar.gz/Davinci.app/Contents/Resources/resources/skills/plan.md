---
name: plan
description: Strategic planning, requirements analysis, and high-level architecture blueprint
agent: cto-lead
agents: [senior-architect, ux-designer]
davinci-phase: plan
allowed-tools: [Write, Edit, Read, Bash, Glob, Grep, Task, AskUserQuestion]
next-skill: work
skill-type: flexible
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 생성자: 자기 검증은 사전 점검일 뿐이다. 최종 판정은 독립 verify 노드가 낸다. 미완료 시 partial + remaining.

# /da:plan

Entry point of the DAVINCI cycle. Analyze requirements, define scope, create structured plan,
and produce high-level architecture blueprint (C4 Level 1). Mandatory Documentation Gate (Step 0)
checks Confluence/Obsidian sync before any planning begins.

## Iron Law
**NO IMPLEMENTATION WITHOUT A PLAN. NO PLAN WITHOUT REQUIREMENTS.**

## FIRST ACTION — Documentation Gate (do this BEFORE anything else)

**Your very first action upon entering da:plan MUST be the Documentation Gate below.**
**Do NOT analyze requirements, do NOT write any plan content, do NOT respond to the user's request yet.**
**Complete this gate first, then proceed to planning.**

1. Check if `.davinci/doc-sync.json` exists (use Bash: `cat .davinci/doc-sync.json 2>/dev/null`)
2. **If the file does NOT exist** → You MUST call `AskUserQuestion` with these exact parameters:
   - question: "계획 문서를 어디에 저장/동기화할까요?"
   - header: "Doc Sync"
   - options: [ {label: "Obsidian", description: "Obsidian vault에 마크다운으로 저장합니다. vault 경로를 지정해주세요."}, {label: "Confluence", description: "Confluence 스페이스에 페이지로 동기화합니다. 스페이스 키를 지정해주세요."}, {label: "로컬만 저장", description: "프로젝트 내 docs/ 디렉토리에만 저장합니다. 외부 동기화 없음."} ]
   - Then save the response to `.davinci/doc-sync.json`
   - If "Obsidian" → ask vault path → save `{"target":"obsidian","obsidian_vault":"{path}","last_updated":"{ISO8601}"}`
   - If "Confluence" → ask space key → save `{"target":"confluence","confluence_space":"{key}","last_updated":"{ISO8601}"}`
   - If "로컬만 저장" → save `{"target":"local","last_updated":"{ISO8601}"}`
3. **If the file EXISTS** → Read it and briefly confirm: "이전 설정({target})을 사용합니다." (1줄 안내 후 바로 진행)
4. **Only after this gate is complete** → proceed to Step 1 below.

**If you skip this gate and start planning directly, you are violating the da:plan protocol.**

## PRD Context Awareness (Brief-Gate Integration)

사용자 메시지의 첫 부분이 `[PRD_CONTEXT]` 블록으로 시작하면, 이는 davinci-gui의 brief-gate(SendToDevButton → PrdReviewPanel)에서 사전 검증된 PRD가 context-bridge로 주입된 것이다. 이때 da:plan은 다음 규칙을 반드시 따라야 한다.

```yaml
PRD_Context_Detection:
  trigger: "사용자 메시지에 [PRD_CONTEXT] ~ [/PRD_CONTEXT] 블록이 존재"
  source: "davinci-gui SendToDevButton → PrdReviewPanel approve → context-bridge 주입"
  payload: "sub-PRD with page sections, acceptance criteria, prd_path"

PRD_Driven_Planning_Rules:
  1_Authoritative_Source:
    - PRD는 WHAT/WHY의 권위 있는 출처(authoritative source)다
    - PRD에 명시된 요구사항을 다시 묻거나 재정의하지 말 것
  2_Skip_Discovery:
    - Discovery Loop (Phase 1) 전체를 스킵
    - 요구사항은 이미 brief-gate에서 검증·승인됨 (qualified)
    - 단, .davinci/doc-sync.json 게이트는 그대로 수행
  3_Roadmap_Input:
    - sub-PRD page sections + acceptance criteria를 Implementation Roadmap의 입력으로 사용
    - 각 page section → 1개 이상의 Phase 또는 Task로 매핑
  4_AC_to_Task_Mapping:
    - 각 acceptance criteria(AC) → 최소 1개 이상의 task로 변환 (1:N 허용)
    - 모든 AC가 최소 한 번은 task로 추적되어야 함 (no orphan AC)
  5_Handoff_PRD_Reference:
    - Handoff JSON에 prd_source 필드 추가 (PRD 마크다운 경로)
    - 예: "prd_source": "docs/prd/PRD-{slug}-{timestamp}.md"
```

PRD_CONTEXT 블록이 없는 경우 기존 da:plan 흐름(Documentation Gate → Discovery → Roadmap)을 100% 그대로 유지한다. backward compatible.

## Design Handoff Awareness (CRITICAL — design 재실행 방지)

디자인 세션(da:create)에서 핸드오프가 완료된 뒤 호출된 da:plan은 **절대로 design phase를 재예약하지 않는다.** 디자인은 이미 끝났고, 사용자는 dev-only 파이프라인을 기대한다. da:plan이 임의로 신규 페이지를 발견하여 `design_needed_phases`에 추가하는 행위는 사용자 의도를 위반한다.

```yaml
Handoff_Detection (FIRST-CLASS GATE — Doc Gate 직후 실행):
  Step_1_Probe:
    - Bash: ls -A .davinci/design-context/ 2>/dev/null | head -1
    - Bash: ls -A .davinci/artifacts/ 2>/dev/null | head -1
    - 둘 중 하나라도 비어있지 않으면 → 디자인 핸드오프 완료 상태로 간주

  Step_2_Detect_DESIGN_CONTEXT_block:
    - 사용자 메시지에 `[DESIGN_CONTEXT]` ~ `[/DESIGN_CONTEXT]` 블록이 있으면 → 핸드오프 완료
    - context-bridge가 design 세션에서 dev 세션으로 주입한 토큰/컴포넌트 트리

  Step_3_Effect (handoff = true 인 경우):
    - design_needed_phases = []   # 모든 phase 강제 빈 배열
    - design_mode = "skip"        # da:create / da:design 호출 금지
    - design_pages = []           # 자동 채우기 비활성화
    - 모든 Phase 요약 출력에서 "design: No" 강제 표시
    - Phase에 신규 페이지(Contact, About 등)가 등장해도 design_needed=true 로 승격 금지
    - 신규 페이지 컴포넌트는 da:dev 가 기존 디자인 시스템 토큰만으로 직접 구현

  Rationale:
    - 사용자 멘탈 모델: handoff = "디자인 phase 100% 완료"
    - 디자인 재실행은 토큰/시간 낭비이며 디자인 시스템 일관성을 깨뜨릴 위험
    - 추가 디자인이 필요하면 사용자가 명시적으로 다시 da:create 를 호출해야 함
    - 단방향 흐름 강제: handoff 이후 design phase는 항상 closed

Bypass:
  - 사용자가 명시적으로 "새 디자인이 필요해 / da:create 다시 돌려" 라고 요청한 경우만 예외
  - 이 경우에도 즉시 design phase를 plan에 넣지 말고, 사용자에게 1회 확인 (AskUserQuestion)
```

## Step 0.5: Document Naming (Intent-Driven)

**Doc Gate 통과 후, 기획 의도를 분석하여 문서명과 구조를 결정합니다.**
`PLAN.md`로 고정하지 않습니다. 사용자의 요청 의도에 맞는 이름을 사용합니다.

```yaml
Intent_to_Document_Map:
  new_product:
    primary: "PLAN-{slug}.md"          # e.g. PLAN-saas-dashboard.md
    extras: ["REQUIREMENTS-{slug}.md", "RISKS-{slug}.md"]
    example: "SaaS 대시보드 만들어줘" → PLAN-saas-dashboard.md
  prd:
    primary: "PRD-{slug}.md"
    extras: ["REQUIREMENTS-{slug}.md"]
    example: "PRD 작성해줘" → PRD-{slug}.md
  architecture:
    primary: "ARCHITECTURE-{slug}.md"
    extras: ["ADR-001-{decision}.md"]
    example: "시스템 아키텍처 설계" → ARCHITECTURE-{slug}.md
  migration:
    primary: "MIGRATION-{slug}.md"
    extras: ["RISKS-{slug}.md", "ROLLBACK-{slug}.md"]
    example: "DB 마이그레이션 계획" → MIGRATION-{slug}.md
  refactor:
    primary: "REFACTOR-{slug}.md"
    extras: ["RISKS-{slug}.md"]
    example: "인증 모듈 리팩토링" → REFACTOR-{slug}.md
  feature:
    primary: "PLAN-{slug}.md"
    extras: ["REQUIREMENTS-{slug}.md"]
    example: "검색 기능 추가" → PLAN-search-feature.md
  generic:
    primary: "PLAN-{slug}.md"          # fallback
    extras: ["REQUIREMENTS-{slug}.md", "RISKS-{slug}.md"]

Slug_Rules:
  - 사용자 요청에서 핵심 키워드 2-3개를 kebab-case로 조합
  - 한글은 영문 번역 (e.g. "채팅 기능" → "chat-feature")
  - 최대 30자
  - 예: "실시간 알림 시스템 만들어줘" → slug: "realtime-notification"

Output_Directory:
  default: "docs/"
  doc_sync_obsidian: "{obsidian_vault}/davinci/{project}/"
  doc_sync_confluence: "docs/" (Confluence는 API로 별도 push)
```

**실행 순서**:
1. 사용자 요청에서 intent 분류 (위 매핑 참조)
2. slug 생성
3. 문서명 확정 → 이후 모든 단계에서 이 문서명을 사용
4. Handoff JSON의 `plan_file`에 확정된 경로 기록

## Step 1: Template Selection

**문서명 확정 후, 템플릿 인덱스를 기반으로 최적 템플릿을 선택합니다.**

### 1-1. 템플릿 인덱스 로딩
```bash
# davinci-framework의 template-registry.json 읽기
Read(file_path="{davinci-framework}/davinci-gui/src/data/template-registry.json")
```
- 프론트엔드 + 백엔드 총 87개 템플릿 메타데이터 로드
- 각 템플릿: id, name, description, tags, tech_stack, category, keywords, source_path 포함

### 1-2. 사용자 요구사항 vs 템플릿 매칭 (Claude 판단)
```yaml
Matching_Logic:
  0. source_type 필터 (최우선): "standalone" 템플릿을 우선 매칭. "bundled" 템플릿은 standalone 매칭이 없을 때만 fallback.
  1. 기능 매칭: features 필드와 요구사항 겹침 정도
  2. 카테고리 매칭: 동일 category 우선
  3. 스택 매칭: 보유 템플릿 스택 우선 추천
  4. 태그 매칭: tags 필드 참고 (보조)

Source_Type_Priority:
  standalone: 코드가 davinci-templates/에 존재. da:work에서 즉시 복사+수정 가능. (73개)
  bundled: Tauri 번들 리소스에만 존재 (examples/). da:work 기반 템플릿으로 부적합. (34개)
  rule: 동일 점수일 때 standalone 우선. bundled는 standalone 후보가 0개일 때만 선택.
```

### 1-3. 기술 스택 추천 (보유 템플릿 기반)
```yaml
Stack_Recommendation:
  frontend:
    default: "Next.js 15 + React 19 + shadcn/ui + Tailwind" (50개 템플릿 보유)
  backend:
    node_ts: node-hono-api (Hono + Drizzle + TypeScript + Docker)
    python: python-fastapi (FastAPI + SQLAlchemy + Alembic + Docker)
    go: go-rest-api (Go + Fiber + Docker + migrations)
  recommendation_principle:
    - 보유 템플릿 스택을 우선 추천 (빌드 검증 완료된 코드 기반)
    - 추천 근거: "이 스택의 검증된 템플릿 N개를 보유하고 있어 빠른 시작이 가능합니다"
    - 사용자가 보유하지 않은 스택을 명시적으로 요청하면 존중하되, fallback(제로베이스) 안내
```

### 1-4. 기획 문서에 Template Foundation 기록
```markdown
## Template Foundation
- **frontend_template**: {id} ({name})
- **backend_template**: {id} ({name})  <!-- 백엔드 필요 시 -->
- **strategy**: modify  <!-- 템플릿 코드를 요구사항에 맞게 수정 -->
```

### 1-5. Fallback (매칭 없음)
```yaml
Fallback_Logic:
  no_frontend_match:
    - frontend_template: none (제로베이스)
    - 기존 npx create-next-app 방식으로 진행
  no_backend_match:
    - backend_template 미기재
    - 필요 시 제로베이스로 백엔드 구성
  no_match_at_all:
    - Template Foundation 섹션 생략
    - 기존 da:plan 프로세스 100% 그대로 진행
```

### 1-6. 프론트+백엔드 조합 판단
```yaml
Combination_Rules:
  fullstack: 프론트 + 백엔드 각각 선택 (예: nextjs-saas-starter + node-hono-api)
  frontend_only: API Routes로 충분한 경우 백엔드 생략
  backend_only: CLI/API 전용 프로젝트
  neither: 기존 제로베이스 fallback
```

## Deliverables
- 기획 문서 (Step 0.5에서 결정된 문서명), 부속 문서 (REQUIREMENTS, RISKS 등), initial ADRs

## Step 2.5: Domain Context Gate

기획 문서 작성 완료 후, 도메인 용어를 추출하여 CONTEXT.md를 생성/갱신합니다.

```yaml
Step_2.5_Execution:
  1_Extract_Terms:
    - 기획 문서에서 도메인 고유 용어를 추출 (비즈니스 엔티티, 상태, 액션)
    - 일반 기술 용어(API, DB, component 등)는 제외
    - 최대 20개로 제한

  2_Check_Existing:
    - Glob("CONTEXT.md") 실행
    - 존재하면 Read → 기존 용어와 병합 (중복 제거, 신규 추가)
    - 미존재 시 신규 생성

  3_Generate_Context:
    - references/CONTEXT-FORMAT.md 포맷을 따라 CONTEXT.md 작성
    - Language 섹션: 영문 Term + 한국어 정의 + Avoid 목록
    - Relationships 섹션: 용어 간 관계 규칙
    - Flagged Ambiguities 섹션: 혼동 가능한 용어 기록

  4_Record_Handoff:
    - handoff JSON에 context_file 필드 추가
    - context_file: "CONTEXT.md" (생성/갱신한 경우)
    - context_file: null (용어 추출 대상 없는 경우, e.g. 단순 리팩토링)

  5_Escalate_To_Domain (da:domain 호출 여부 판단):
    - 아래 중 하나라도 해당하면 `da:domain`을 호출하여 DOMAIN-MODEL.md로 심화
      (Complexity Pre-Classification 결과 MODERATE 이상인 경우 포함 — 아래 섹션 완료 후 재확인)
      - 추출된 도메인 용어 20개 초과
      - 서로 다른 소유권/라이프사이클을 가진 하위 도메인 2개 이상 식별
      - 기획 문서에 "바운디드 컨텍스트/마이크로서비스/모듈 분리" 언급
      - Flagged Ambiguities 3개 이상
    - 해당 없으면 CONTEXT.md만으로 종료 (da:domain 호출 없음 — 과설계 방지)
    - handoff JSON에 domain_model_file 필드 추가 (da:domain 호출 시 "docs/domain/DOMAIN-MODEL.md", 아니면 null)

Skip_Conditions:
  - 추출된 도메인 용어가 0개 → context_file: null, 스킵
  - CLI/스크립트 전용 프로젝트 → context_file: null, 스킵
```

## Complexity Pre-Classification (MANDATORY)

기획 문서 작성 완료 후, Implementation Roadmap의 Phase/Task 구조를 분석하여 complexity_estimate를 산출합니다.

```yaml
Classification_Logic:
  1_phase_3_tasks_no_new_files: LIGHT
  1_phase_5_tasks_no_new_files: SIMPLE
  2_3_phases_or_new_files: MODERATE
  4_plus_phases_or_system_keywords: COMPLEX
  migration_large_scale_redesign: EPIC

Greenfield_Guard:
  - 1개 이상 신규 파일 생성 → 최소 MODERATE
```

## Handoff Output (MANDATORY)

기획 문서 생성 완료 후, 다음 JSON handoff를 반드시 출력합니다.
`plan_file`은 Step 0.5에서 결정된 실제 문서 경로를 사용합니다.

```json
{
  "skill": "da:plan",
  "status": "completed",
  "plan_file": "docs/{intent}-{slug}.md",
  "requirements_file": "docs/REQUIREMENTS-{slug}.md",
  "context_file": "CONTEXT.md",
  "domain_model_file": "docs/domain/DOMAIN-MODEL.md or null",
  "approval_status": "pending",
  "complexity_estimate": "MODERATE",
  "template_foundation": {
    "frontend_template": "template-id or none",
    "backend_template": "template-id or none",
    "strategy": "modify or zero-base"
  },
  "phase_count": 3,
  "total_tasks": 12,
  "design_needed_phases": [1, 3],
  "design_mode": "da:design",
  "design_pages": [{"id": "...", "title": "...", "description": "..."}],
  "auto_style": "modern/gradient",
  "auto_font": "Bebas Neue",
  "acceptance_ledger": "docs/.da-acceptance.json",
  "phase_graph": [{"id": 1, "depends_on": []}, {"id": 2, "depends_on": [1]}, {"id": 3, "depends_on": [1]}],
  "evidence": [{"kind": "file", "ref": "docs/{intent}-{slug}.md", "result": "exists, N lines", "ok": true}]
}
```

### Acceptance Ledger + Phase Graph (MANDATORY — da:protocol §3.5 / §4.1)
기획 문서 저장 직후, 구현 전에 **검증 계약**을 파일로 고정한다(Sprint Contract).
```bash
# docs/.da-acceptance.json — 요구사항 1개 = 항목 1개. 구현 단계에서 항목 삭제/재작성 금지, passes/evidence만 갱신.
[{"id": "AC-01", "phase": 1, "criterion": "로그인 실패 시 401 반환", "check": "npm test -- auth", "passes": false, "evidence": null},
 {"id": "AC-02", "phase": 2, "criterion": "대시보드 첫 로드 LCP < 2.5s", "check": null, "rubric": "Lighthouse LCP 수치 명시", "passes": false, "evidence": null}]
```
- `check`: 셸 명령(exit 0 = 통과). 명령화 불가한 정성 항목은 `rubric`에 앵커 문구를 적고 독립 evaluator가 판정한다.
- `phase_graph.depends_on`: Implementation Roadmap의 Phase 간 의존. 명시 근거가 없으면 선형(N depends_on N-1)으로 채우되, 파일 소유권이 겹치지 않는 Phase는 의존을 끊어 병렬 후보로 둔다.
- da:work Stage 0은 이 두 필드를 checkpoint `graph`로 변환하고, da:verify는 원장 항목만 대조한다.

### design_mode Selection Gate

When `design_needed_phases` contains at least one phase, the planner MUST determine the design execution mode.
This field controls which design skill is invoked during da:work Stage 2/3.

> **v2 통합 노트 (PLAN-da-create-v2-unified Phase 4):**
> `da:design` 과 `da:create` 는 **da:create v2** 로 통합되었습니다 (alias 호환).
> `design_mode` 키는 backward compat 을 위해 보존되며, 두 값 모두 동일한 da:create v2 파이프라인으로 라우팅됩니다.
> 신규 프로젝트는 `"da:create"` 사용을 권장합니다.

```yaml
Design_Mode_Values:
  "da:create":   # [PREFERRED] HTML-based design (Claude Design Engine, v2 unified)
    - High-fidelity HTML artifacts in .davinci/artifacts/
    - Interactive prototypes, presentations, dashboards, complex UI systems
    - Composite Quality Gate + Fidelity Score 자동 측정
    - Best for: 모든 디자인 작업 (default for new projects)
  "da:design":   # [ALIAS] da:create v2 로 라우팅 — backward compat
    - 기존 프로젝트 호환을 위해 보존
    - alias router 가 자동으로 da:create v2 파이프라인 실행
    - original_skill="da:design" 메타데이터는 hook 에서 그대로 인식
  "skip":        # No design phase
    - Skips design entirely (API-only, CLI, backend projects)
    - Equivalent to design_needed=false for all phases

Selection_Logic:
  - 신규 프로젝트 / 명확하지 않은 경우 → "da:create" (preferred)
  - 기존 da:design 기반 프로젝트 → "da:design" 유지 (alias 자동 변환)
  - If project is API/CLI/backend only → "skip"
```

When `design_needed_phases` contains at least one phase, `design_pages` MUST be auto-populated from the Implementation Roadmap:
```yaml
Auto_Populate_Rule:
  trigger: design_needed_phases is non-empty (regardless of design_mode value)
  logic: |
    for each phase in Implementation Roadmap where design_needed=true:
      extract page-level UI units from phase tasks
      → each distinct page/screen/view = 1 design_page entry
    Example:
      Phase 1 "Landing & Auth" (tasks: Hero section, Login page, Signup page)
      → design_pages: [
          {"id": "landing", "title": "Landing Page", "description": "Hero + features + CTA"},
          {"id": "login", "title": "Login", "description": "Email/password + social login"},
          {"id": "signup", "title": "Signup", "description": "Registration form + terms"}
        ]
      Phase 3 "Dashboard" (tasks: Analytics view, Settings)
      → design_pages += [
          {"id": "dashboard", "title": "Dashboard", "description": "Analytics charts + summary cards"},
          {"id": "settings", "title": "Settings", "description": "User preferences + account"}
        ]
  granularity: |
    - 1 page = 1 독립적인 화면/뷰 (라우트 단위)
    - 모달, 드롭다운 등 부분 UI는 별도 페이지로 분리하지 않음
    - 동일 페이지의 상태 변화 (로딩, 에러, 빈 상태)도 1 페이지로 통합
```

```json
"design_pages": [
  {"id": "landing", "title": "Landing Page", "description": "Hero + features + CTA"},
  {"id": "dashboard", "title": "Dashboard", "description": "Main analytics view"}
]
```

## Auto-Verify & Improve Gate (MANDATORY)
**CRITICAL: After Plan completion, the following auto-chaining MUST be executed. Skipping is forbidden.**

When Plan deliverables (기획 문서) generation is complete:
1. **Immediately** call `Skill("da:verify")` for plan quality verification (--tier standard --type quality)
2. match rate >= 90% → **반드시 `AskUserQuestion`으로 사용자에게 계획 요약을 보여주고 승인을 받아라**
   - 사용자가 승인하면 `Skill("da:work")` 호출
   - 사용자가 거부하면 즉시 멈춰라
   - ★ **`AskUserQuestion` 없이 `Skill("da:work")`를 직접 호출하는 것은 절대 금지**
3. verdict NOT_MET (match rate < 90%, items[] 기반) → call `Skill("da:improve", "previous_failure: {reason} / hint: {next_action_hint}")` then `Skill("da:verify")` again (max 2 iterations, 매 회 다른 접근)
4. 2회 후에도 NOT_MET → Critical/High 잔존이면 **blocked**(da:work 진입 금지), Medium/Low만이면 degraded → `AskUserQuestion`으로 blocked/degraded 항목을 보고하고 진행 여부를 확인 (da:protocol §3.4)
5. verdict BLOCKED/IMPOSSIBLE → 재시도 없이 즉시 `AskUserQuestion`으로 사유 보고

This gate can only be skipped when the `--no-verify` flag is explicitly specified.

### Auto-Chain Execution (Claude MUST follow)
```
Plan complete → Skill("da:verify", "--tier standard --type quality")
  → >=90% → AskUserQuestion(승인 요청) → 승인 시 Skill("da:work"), 거부 시 중단
  → <90% → Skill("da:improve") → Skill("da:verify") (repeat, max 2 times)
  → exceeds 2 → AskUserQuestion(상태 보고) → Skill("da:work") or abort
```
**★ 텍스트로만 "승인하시겠습니까?" 출력하는 것은 승인이 아니다. 반드시 AskUserQuestion 도구를 호출하라.**

## Transition
- **Next**: /da:verify (auto, MANDATORY) → user approval → /da:work
- **Handoff**: {plan_file} + {requirements_file} → da:work orchestrates full pipeline (system → design → dev → verify → improve)
