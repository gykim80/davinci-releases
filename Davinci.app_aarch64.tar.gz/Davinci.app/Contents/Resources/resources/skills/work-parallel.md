---
name: work-parallel
description: "da:work advanced reference (COMPLEX/EPIC) — Phase Parallel Dispatch via dependency waves, Worktree Orchestration, Verify Cache, Structured Handoff Protocol. Loaded by da:work on demand, not invoked directly."
skill-type: reference
davinci-phase: work
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 오케스트레이터: §4 그래프 ready-set 디스패치, §6 노드 단위 checkpoint, §7 interrupt 표 외 질문 금지.

### Phase Parallel Dispatch (COMPLEX and Above Only)

Execute independent Phases simultaneously in COMPLEX/EPIC tasks to reduce total time.
Analyze inter-Phase file dependencies and only parallelize when safe.

**Integration Point**: This protocol is now **auto-loaded** in da:work SKILL.md Turbo-3 for COMPLEX/EPIC.
The orchestrator calls `coordinator.py` directly — no manual Read required.

```yaml
Phase_Parallel_Protocol:

  Step_0_Foundation_Guard (before dependency analysis):
    # coordinator.py _is_foundation_phase() detects config/token files:
    # globals.css, tailwind.config.*, *.config.ts/js/mjs, tsconfig.json,
    # next.config.*, vite.config.*, postcss.config.*, theme.ts/js, tokens.css, etc.
    # Foundation phases are forced into Wave 0 ALONE — all others depend on them.

  Step_1_Dependency_Analysis (after Stage 0, before Phase loop entry):
    # Executed via coordinator.py (Python)
    Bash: uv run python -c "
      from davinci.orchestration.coordinator import analyze_spec, map_file_ownership, validate_independence
      import json
      result = analyze_spec('{plan_path}')
      tasks = map_file_ownership(result.tasks, '.')
      validated = validate_independence(tasks)
      print(json.dumps({'waves': validated.parallel_groups, 'task_count': len(validated.tasks)}))"

  Step_2_Parallel_Group_Formation:
    # Handled by coordinator.py _build_parallel_groups()

  Step_3_Parallel_Execution (Turbo-3 extension):
    for wave in parallel_groups:
      if len(wave) == 1:
        execute_existing_Turbo_3(wave[0])
      elif len(wave) >= 2:
        # Sub-agents do NOT commit — orchestrator handles commit per Phase
        Task(model="opus", prompt="Phase {A} implement+verify (NO git commit)") ← ─┐
        Task(model="opus", prompt="Phase {B} implement+verify (NO git commit)") ← ─┤ Simultaneous

        # Orchestrator commits each Phase after wave completion
        for phase in wave:
          Bash: git add -A && git diff --cached --stat
          if changes: git commit -m "feat(phase-{N}): {phase.name}"

      # Wave complete → Adaptive Compact → next Wave

  Step_4_Conflict_Verification (after parallel execution):
    if parallel execution was performed:
      Bash: git diff --check
      if conflict found:
        # merge_controller.py auto_resolve_conflicts() available
        Warning: "File conflict detected. Sequential re-execution recommended."

  Fallback_Rules:
    - Phase count <= 2: sequential (overhead > savings)
    - Ambiguous file paths: sequential
    - MODERATE or below: always sequential
    - coordinator.py cycle error: sequential
```

### Phase Parallel Checkpoint Extension

```yaml
# Fields added to existing checkpoint
checkpoint_extensions:
  parallel_groups: [[1, 2], [3]]  # Wave composition
  current_wave: 0                  # Currently executing Wave index
  parallel_status:                 # Parallel Phase status tracking
    - { phase: 1, status: "running", task_id: "..." }
    - { phase: 2, status: "running", task_id: "..." }
  conflict_history: []             # Conflict history (for fallback decisions)
```

### Phase Parallel Example

```yaml
# 3-Phase project example:
#   Phase 1: DB schema + API (files: prisma/schema.prisma, src/api/*)
#   Phase 2: UI components (files: src/components/*)
#   Phase 3: API integration + integration (files: src/api/*, src/components/*, src/hooks/*)

Dependency_Analysis:
  Phase 1 ∩ Phase 2 = {} → parallel possible ✅
  Phase 1 ∩ Phase 3 = {src/api/*} → Phase 3 blocked_by Phase 1
  Phase 2 ∩ Phase 3 = {src/components/*} → Phase 3 blocked_by Phase 2

Parallel_Groups:
  Wave 1: [Phase 1, Phase 2]  # Simultaneous execution → time = max(T1, T2)
  Wave 2: [Phase 3]            # Sequential after Phase 1,2 complete → time = T3

Total_Time: max(T1, T2) + T3  (previous: T1 + T2 + T3)
Savings_Rate: ~33% (assuming T1 ≈ T2 ≈ T3)
```

### Worktree Orchestration Mode (COMPLEX+ Only)

COMPLEX or EPIC tasks can enter multi-session orchestration mode using the
Parallel Worktree Orchestrator. The Coordinator Engine (Python) decomposes
the spec into independent tasks, each running in its own git worktree + session.

```yaml
Orchestration_Entry_Conditions:
  - complexity in ["COMPLEX", "EPIC"]
  - Phase count >= 3
  - File dependency analysis shows >= 2 independent task groups

Orchestration_Protocol:
  Step_1_Coordinator_Analysis:
    # Python: src/davinci/orchestration/coordinator.py
    decomposition = analyze_spec(plan_path)
    tasks_with_ownership = map_file_ownership(decomposition.tasks, project_path)
    validated = validate_independence(tasks_with_ownership)
    # validated.parallel_groups = waves of independent task IDs

  Step_2_User_Approval:
    # Show task decomposition in OrchestrationPanel
    # User selects parallelism level (1 = no orchestration, N = parallel)
    # "1" selection -> existing single-session mode (backward compatible)

  Step_3_Spawn_and_Execute:
    # Rust backend creates N sessions with git worktrees
    # Each session runs independently with its task scope
    # depends_on tasks wait for predecessors to complete

  Step_4_Merge_and_Cleanup:
    # Python: src/davinci/orchestration/merge_controller.py
    # Sequential merge into staging branch (merge_order)
    # Auto-resolve simple conflicts
    # Cleanup: lint + verify + worktree deletion

Fallback_to_Sequential:
  - Orchestration disabled by user (parallelism = 1)
  - All tasks have file overlap (no independent groups)
  - Task count < 3 (overhead exceeds benefit)
  - validate_independence raises cycle error
```

### Verify Cache (improve loop optimization)

Skip re-verification of unchanged files during verify→improve→verify loops.
Includes affected files via transitive dependency analysis, not just simple file hashes.

```yaml
Verify_Cache_Protocol:

  Cache_Structure (verify_cache field in checkpoint):
    verify_cache:
      "src/api/auth.ts":
        hash: "sha256:abc123..."       # File content hash
        deps_hash: "sha256:def456..."  # Combined hash of import target files
        result: "pass"                 # Last verification result
        issues: []                     # Issues found (if any)
        timestamp: "2026-03-12T..."    # Verification timestamp

  Cache_Judgment_Logic:
    on_verify(files_to_check):
      for file in files_to_check:
        current_hash = sha256(file.content)
        current_deps = get_import_targets(file)  # codegraph_callers
        current_deps_hash = sha256(concat(each dep's content))

        cached = verify_cache[file.path]
        if cached AND cached.hash == current_hash AND cached.deps_hash == current_deps_hash:
          # ✅ Cache HIT — neither file nor dependencies changed
          skip_verification(file)
          reuse_result(cached.result, cached.issues)
        else:
          # ❌ Cache MISS — re-verification needed
          result = run_verification(file)
          update_cache(file.path, current_hash, current_deps_hash, result)

  Transitive_Hash_Calculation:
    # CodeGraph-based import graph analysis
    1. Parse file's import statements → direct dependency file list
    2. Check export symbols of each direct dependency → only symbols actually used by file
    3. Calculate body hash of those symbols
    4. Combine all symbol hashes → deps_hash
    # Depth limit: direct dependencies only (1-hop). Indirect dependencies have low cost-effectiveness.

  Cache_Invalidation_Conditions:
    - File content changed → hash mismatch → re-verify
    - Import target file changed → deps_hash mismatch → re-verify
    - New file added → no cache → fresh verification
    - File deleted → remove cache
    - Config file changed (tsconfig, eslint, tailwind) → full cache invalidation
    - --force flag → full cache invalidation

  Cache_Application_Scope:
    - ✅ Re-verification within verify→improve loop (primary use case)
    - ✅ Inter-Phase verify (reuse files verified in previous Phase)
    - ❌ Initial verify (no cache)
    - ❌ E2E tests (Playwright operates at scenario level, not file level)

  Expected_Effect:
    During re-verification after improve:
      - Changed files: ~30% (files modified by improve)
      - Cache hit: ~70% (unchanged files)
      - Time savings: ~60-70% reduction in verify time
```

### Structured Handoff Protocol (Inter-Skill Context Compression)

Compress information passed between skills into structured JSON.
Deliver only key information instead of raw output to extend context window lifespan.

```yaml
Handoff_Schema:
  # Structured summary each skill must return

  da:system_handoff:
    required_fields:
      - files_created: [string]        # List of created files
      - architecture_decisions: [string] # Key decisions
      - tech_stack: {frontend, backend, db, infra}
      - patterns_used: [string]        # Patterns used (repository, MVC, etc.)
    optional_fields:
      - diagrams: [string]             # Diagram file paths
      - risks: [string]               # Identified risks

  da:design_handoff:
    required_fields:
      - components_created: [string]   # Created components
      - design_tokens: {colors, fonts, spacing}
      - pages: [string]               # Created pages
    optional_fields:
      - assets_needed: [string]       # Required assets

  da:create_handoff:
    required_fields:
      - artifacts_created: [string]    # HTML artifact file paths
      - artifact_dir: string           # .davinci/artifacts/{sessionId}/
      - pages: [string]               # Page IDs generated
    optional_fields:
      - design_tokens: {colors, fonts, spacing}
      - interactive_features: [string] # JS interactions included

  da:dev_handoff:
    required_fields:
      - files_modified: [string]      # Modified file list
      - files_created: [string]       # Newly created files
      - features_implemented: [string] # Implemented features
    optional_fields:
      - known_issues: [string]        # Known issues
      - test_files: [string]          # Created test files

  da:verify_handoff:
    required_fields:
      - match_rate: number            # 0-100
      - tier_used: string             # fast|standard|full
      - issues: [{file, line, severity, issue, fix}]
      - checks_passed: number
      - checks_total: number
    optional_fields:
      - cache_hits: number            # Cache utilization count
      - cache_misses: number

  da:improve_handoff:
    required_fields:
      - files_modified: [string]
      - issues_fixed: [{issue_id, description}]
      - issues_remaining: [{issue_id, description}]

Handoff_Application_Rules:
  - Orchestrator extracts handoff JSON from Task/Skill return values
  - Include previous handoff in ARGUMENTS when calling next skill
  - Deliver handoff only instead of raw output → 60-80% context savings
  - If required_field missing in handoff → warning + raw output fallback

Handoff_Output_Rules:
  Append to end of each skill Task prompt:
  "After completion, return a summary in the following JSON format:
   {handoff_schema_for_skill}"
```

---

