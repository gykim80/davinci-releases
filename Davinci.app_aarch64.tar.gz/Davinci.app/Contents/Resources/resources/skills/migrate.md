---
name: migrate
description: Framework migration and dependency upgrade with safe rollback
agent: infra-architect
agents: [infra-architect, bkend-expert]
davinci-phase: null
allowed-tools: [Read, Glob, Grep, Bash, Write, Edit, Task]
next-skill: null
skill-type: flexible
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 생성자: 자기 검증은 사전 점검일 뿐이다. 최종 판정은 독립 verify 노드가 낸다. 미완료 시 partial + remaining.

## Tool Parameter Rules -> See CLAUDE.md (ABSOLUTE)
# /da:migrate - Migration and Upgrade

ultrathink


## Purpose
Framework migrations, dependency upgrades, and technology transitions with safe rollback strategies.

## Usage
```
/da:migrate [source-framework] [target-framework] [--safe] [--dry-run]
```

## Behavioral Flow

### Phase 1: Assessment
```yaml
1. Current_State:
   - Detect current framework and version
   - Inventory all dependencies
   - Map breaking changes

2. Migration_Plan:
   - Identify migration path
   - List required changes
   - Estimate impact scope
```

### Phase 2: Execute
```yaml
1. Safe_Migration:
   - Create restore point (git branch)
   - Apply changes incrementally
   - Run tests after each step

2. Rollback_Strategy:
   - Automatic rollback on test failure
   - Manual checkpoint approval
   - Preserve rollback branch
```

### Phase 3: Verify
```yaml
1. Post_Migration:
   - Run full test suite
   - Check for deprecation warnings
   - Validate functionality
```

> MCP Routing: See CLAUDE.md

## Boundaries

**Will:**
- Plan safe migration paths
- Create rollback points before changes
- Verify migration success with tests

**Will Not:**
- Execute migrations without dry-run preview
- Skip test verification after migration
