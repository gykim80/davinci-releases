---
name: ready
description: "Entry-point gateway activated by [READY] tag. Routes to optimal pipeline."
agent: cto-lead
davinci-phase: null
allowed-tools: [Skill, AskUserQuestion]
next-skill: null
skill-type: flexible
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 오케스트레이터: §4 그래프 ready-set 디스패치, §6 노드 단위 checkpoint, §7 interrupt 표 외 질문 금지.

# /da:ready — Universal Entry-Point Gateway

이 스킬은 [READY] 태그가 UserPromptSubmit에서 주입되었을 때만 활성화됩니다.
사용자가 직접 /da:ready를 호출하는 것도 가능하지만, 일반적으로 자동 감지됩니다.

## 태그 파싱 및 라우팅

### [READY:guided] 수신 시
1. 태그에서 `target=` 값 추출 (예: da:game, da:dev)
2. **★ 템플릿 매칭 단계 (Phase 0)**:
   a. `template-registry.json`에서 사용자 프롬프트와 매칭되는 템플릿 검색
   b. 매칭 방법: `user_intent_examples`, `keywords`, `tags` 순으로 유사도 확인
   c. 매칭 결과가 있으면:
      - 템플릿의 `source_path`에서 프로젝트 루트로 파일 복사 (node_modules, .next, .git 제외)
      - `.template-context.json` 작성 (template_id, redesign_targets, preserve_files 포함)
      - `npm install` 실행
      - 안내: "📦 **{template_name}** 템플릿을 기반으로 시작합니다. 설계(da:plan)로 진행합니다."
   d. 매칭 결과가 없으면:
      - 안내: "📋 빈 프로젝트로 시작합니다. 설계(da:plan)부터 진행합니다."
3. `Skill("da:plan", "{사용자 원래 프롬프트}")` 호출
   - 사용자 원래 프롬프트를 args로 전달하여 da:plan이 요구사항으로 활용

#### 템플릿 매칭 세부 규칙

**경로 해석 (필수)**:
- `REPO_ROOT` = davinci-framework 저장소 루트 (이 SKILL.md 파일 기준으로 `../../../../../..`)
- `template-registry.json` 위치: `{REPO_ROOT}/davinci-gui/src/data/template-registry.json`
- **Read tool로 직접 읽기** — `find`, `ls`, `locate` 등 파일시스템 탐색 명령 사용 절대 금지
- 홈 디렉토리(`~/`, `$HOME`) 전체 탐색 절대 금지 (macOS TCC 권한 요청 유발)

```
1. Read("{REPO_ROOT}/davinci-gui/src/data/template-registry.json") — 직접 경로로 읽기
2. 사용자 프롬프트에서 키워드 추출
3. 각 템플릿의 user_intent_examples 퍼지 매칭 (50점)
4. keywords 매칭 (25점/키워드)
5. CATEGORY_SIGNALS 매칭 (30점)
6. 최고 점수 템플릿 선택 (40점 이상이면 채택)
7. source_path 기반 복사:
   - source_path가 "davinci-templates/nextjs/xxx"이면 → {REPO_ROOT}/davinci-templates/nextjs/xxx/ 에서 복사
   - source_path가 "davinci-templates/backend/xxx"이면 → {REPO_ROOT}/davinci-templates/backend/xxx/ 에서 복사
   - source_type이 "bundled"인 템플릿은 standalone 후보가 없을 때만 fallback
8. .template-context.json 작성:
   {
     "template_id": "{id}",
     "template_name": "{name}",
     "source_path": "{source_path}",
     "user_intent": "{사용자 프롬프트}",
     "redesign_targets": [...],
     "preserve_files": [...],
     "created_at": "{ISO timestamp}"
   }
```

### [READY:discovery] 수신 시
1. 태그에서 `target=` 값 추출
2. **★ 템플릿 매칭 단계 (Phase 0)**: [READY:guided]와 동일한 로직 수행
3. 사용자에게 1줄 안내: "💡 아이디어를 먼저 정리합니다. 요구사항 수집(da:idea)부터 시작합니다."
4. `Skill("da:idea", "{사용자 원래 프롬프트}")` 호출
   - da:idea가 완료되면 기존 post_skill hook에 의해 da:plan → da:work 자동 체이닝

### 태그 없이 직접 호출 시 (/da:ready)
1. 사용자 프롬프트를 분석하여 GUIDED/DISCOVERY 판단
2. 판단 기준:
   - **GUIDED 조건**: 구체적 목표가 명시됨, 기술 스택 언급, 기능 요구사항 3개 이상
   - **DISCOVERY 조건**: 아이디어 단계, "~하고 싶다" 표현, 비즈니스 모델 미정
3. 판단 후 위 로직대로 da:plan 또는 da:idea 호출

## 라우팅 판단 기준 상세

| 시그널 | GUIDED | DISCOVERY |
|--------|--------|-----------|
| 기능 개수 | 3개 이상 구체적 | 1~2개 모호 |
| 기술 스택 | 명시됨 | 미정 |
| 비즈니스 목표 | 명확 | 탐색 중 |
| 표현 방식 | "~구현해줘" | "~해보고 싶어" |
| 참고 자료 | URL/디자인 첨부 | 없음 |

## 실행 흐름 다이어그램

```
[READY:guided]   → ★템플릿 매칭+복사 → da:plan → da:plan-verify → da:work → ...
[READY:discovery] → ★템플릿 매칭+복사 → da:idea → da:plan → da:plan-verify → da:work → ...
/da:ready (직접)  → ★템플릿 매칭+복사 → 분석 → GUIDED or DISCOVERY 경로 선택
```

**핵심 변경**: 모든 경로에서 da:plan/da:idea 호출 전에 템플릿 매칭이 먼저 수행됩니다.
템플릿이 복사되면 da:work는 제로부터 시작하지 않고 **템플릿 기반 수정 모드**로 동작합니다.

## 출력 형식

라우팅 결정 후 사용자에게 보여줄 메시지:
- GUIDED: "📋 {도메인} 프로젝트를 시작합니다. 설계(da:plan)부터 진행합니다."
- DISCOVERY: "💡 아이디어를 먼저 정리합니다. 요구사항 수집(da:idea)부터 시작합니다."

## 금지 사항

- ❌ da:ready에서 직접 코드 생성 금지
- ❌ da:ready에서 직접 구현 시작 금지 (반드시 da:plan 또는 da:idea 거침)
- ❌ AskUserQuestion으로 경로 확인 금지 (자동 판단형)
- ❌ da:ready에서 파일 생성/수정 금지
- ❌ 3초 이상 분석에 시간 소모 금지 (빠른 라우팅이 핵심)
- ❌ `find`, `ls -R`, `locate` 등 파일시스템 탐색 명령 금지 (macOS TCC 권한 요청 유발)
- ❌ 홈 디렉토리(`~/`, `$HOME`) 재귀 탐색 절대 금지

## 에러 처리

- 태그 파싱 실패 시: GUIDED 기본값으로 da:plan 호출
- target 값 없을 시: 프롬프트 분석으로 폴백
- Skill 호출 실패 시: 에러 메시지 출력 후 종료 (재시도 없음)
