---
name: image
description: "멀티 프로바이더 이미지 생성 -- Settings 기본 모델로 프롬프트 -> 이미지 -> 채팅 버블 표시"
agent: asset-gen-artist
agents: [asset-gen-artist]
davinci-phase: null
allowed-tools: [Bash, AskUserQuestion]
next-skill: null
skill-type: utility
---

## Execution Protocol (da:protocol v1)
> 공통 규약: `~/.claude/commands/da/protocol.md` (§2 Node Contract · §3 Evidence · §5 Retry). 본문과 충돌 시 규약 우선.
- 완료 주장은 evidence(명령 출력/exit code/파일 경로) 동반 필수. 근거 없는 completed는 partial로 취급된다.
- 응답 마지막에 handoff JSON(`status: completed|partial|blocked|failed`, `evidence[]`, `remaining[]`) 반환.
- 같은 접근의 재시도 금지. 상한 도달 시 Critical/High 잔존이면 blocked, 아니면 degraded로 보고.
- 생성자: 자기 검증은 사전 점검일 뿐이다. 최종 판정은 독립 verify 노드가 낸다. 미완료 시 partial + remaining.

# /da:image -- 멀티 프로바이더 이미지 생성

사용자 프롬프트를 받아 Settings > Image에서 설정한 기본 모델로 이미지를 생성하고, 채팅 버블에 즉시 표시한다.
어떤 LLM(Claude, Gemini, Codex)에서든 "이미지 만들어줘" 요청 시 이 스킬이 호출된다.

## Iron Law

> 이미지 생성 결과는 반드시 `OK:/absolute/path.png (NNN bytes)` 형식으로 출력한다.
> 이 형식이 깨지면 채팅 버블에 이미지가 표시되지 않는다.
>
> **절대 금지**: .env.local 파일 참조, GEMINI_IMAGE_MODEL 참조, GEMINI_IMAGE_API_KEY 참조.
> 이 스킬은 환경변수 `IMAGE_GEN_PROVIDER` / `IMAGE_GEN_MODEL` / provider별 API key만 사용한다.
> .env.local의 Gemini 설정은 da:asset 전용이며 da:image와 무관하다.

## 워크플로우

### Step 0: 환경 검증 + 프로바이더 라우팅

```bash
PROVIDER="${IMAGE_GEN_PROVIDER:-}"
MODEL="${IMAGE_GEN_MODEL:-}"

# Provider 미설정 시 fallback 탐색
if [ -z "$PROVIDER" ]; then
  if [ -n "$GEMINI_API_KEY" ]; then PROVIDER="gemini"; MODEL="${MODEL:-gemini-2.0-flash-exp}"
  elif [ -n "$OPENAI_API_KEY" ]; then PROVIDER="openai"; MODEL="${MODEL:-gpt-image-1}"
  else
    echo "FAIL: 이미지 생성 프로바이더가 설정되지 않았습니다."
    echo "Settings > Image 탭에서 프로바이더와 API 키를 설정하세요."
    exit 1
  fi
fi
echo "Provider: $PROVIDER / Model: $MODEL"
```

### Step 1: 이미지 생성 (프로바이더별 분기)

출력 디렉토리: `$(pwd)/.da-image/`

사용자의 프롬프트를 python3 `json.dumps()`로 안전하게 직렬화한 뒤 프로바이더별 API를 호출한다:

#### Gemini (기본)

```bash
MODEL="${IMAGE_GEN_MODEL:-gemini-2.0-flash-exp}"
OUTDIR="$(pwd)/.da-image"
FNAME="image-$(date +%Y%m%d-%H%M%S).png"
mkdir -p "$OUTDIR"

SAFE_PROMPT=$(python3 -c "import json,sys; print(json.dumps(sys.argv[1]))" "<사용자 프롬프트>")

curl -s -X POST \
  "https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent" \
  -H "x-goog-api-key: ${GEMINI_API_KEY}" \
  -H "Content-Type: application/json" \
  -d "{
    \"contents\": [{\"parts\": [{\"text\": ${SAFE_PROMPT}}]}],
    \"generationConfig\": {\"responseModalities\": [\"IMAGE\"]}
  }" | OUTDIR="$OUTDIR" FNAME="$FNAME" python3 -c "
import json, sys, base64, os
try:
    r = json.load(sys.stdin)
except json.JSONDecodeError as e:
    print(f'FAIL: JSON 파싱 실패 - {e}'); sys.exit(1)
if 'error' in r:
    print(f'FAIL: API 오류 - {r[\"error\"].get(\"message\",\"unknown\")}'); sys.exit(1)
candidates = r.get('candidates', [])
if not candidates:
    reason = r.get('promptFeedback',{}).get('blockReason','UNKNOWN')
    print(f'FAIL: 이미지 생성 차단 - {reason}'); sys.exit(1)
for part in candidates[0].get('content',{}).get('parts',[]):
    if 'inlineData' in part:
        path = os.path.join(os.environ['OUTDIR'], os.environ['FNAME'])
        data = base64.b64decode(part['inlineData']['data'])
        with open(path,'wb') as f: f.write(data)
        print(f'OK:{os.path.abspath(path)} ({len(data)} bytes)'); sys.exit(0)
print(f'FAIL: 응답에 이미지 없음'); sys.exit(1)
"
```

#### OpenAI (gpt-image-1 / gpt-image-2)

```bash
MODEL="${IMAGE_GEN_MODEL:-gpt-image-1}"
OUTDIR="$(pwd)/.da-image"
FNAME="image-$(date +%Y%m%d-%H%M%S).png"
mkdir -p "$OUTDIR"

SAFE_PROMPT=$(python3 -c "import json,sys; print(json.dumps(sys.argv[1]))" "<사용자 프롬프트>")

curl -s -X POST "https://api.openai.com/v1/images/generations" \
  -H "Authorization: Bearer ${OPENAI_API_KEY}" \
  -H "Content-Type: application/json" \
  -d "{
    \"model\": \"${MODEL}\",
    \"prompt\": ${SAFE_PROMPT},
    \"n\": 1,
    \"size\": \"1024x1024\",
    \"output_format\": \"png\"
  }" | OUTDIR="$OUTDIR" FNAME="$FNAME" python3 -c "
import json, sys, base64, os
try:
    r = json.load(sys.stdin)
except json.JSONDecodeError as e:
    print(f'FAIL: JSON 파싱 실패 - {e}'); sys.exit(1)
if 'error' in r:
    print(f'FAIL: API 오류 - {r[\"error\"].get(\"message\",\"unknown\")}'); sys.exit(1)
data_list = r.get('data', [])
if not data_list:
    print('FAIL: 응답에 이미지 없음'); sys.exit(1)
path = os.path.join(os.environ['OUTDIR'], os.environ['FNAME'])
item = data_list[0]
b64 = item.get('b64_json') or item.get('b64') or ''
if not b64:
    print('FAIL: 응답에 b64 데이터 없음'); sys.exit(1)
data = base64.b64decode(b64)
with open(path, 'wb') as f: f.write(data)
print(f'OK:{os.path.abspath(path)} ({len(data)} bytes)')
"
```

### Step 2: 결과 확인

- `OK:` 출력이 나오면 성공 -- 이미지가 채팅 버블에 자동 표시된다.
- `FAIL:` 출력이 나오면 에러 메시지를 사용자에게 전달한다.
- 파일 크기 < 1KB 이면 생성 실패로 간주하고 재시도를 제안한다.

## 프로바이더 라우팅 규칙

| IMAGE_GEN_PROVIDER | API Key 환경변수 | 지원 모델 |
|---|---|---|
| gemini | GEMINI_API_KEY | gemini-3-pro-image-preview, gemini-3.1-flash-image-preview, gemini-2.5-flash-image |
| openai | OPENAI_API_KEY | gpt-image-1, gpt-image-2, dall-e-3 |
| openrouter | OPENROUTER_API_KEY | google/gemini-3.1-flash-image-preview |
| fal.ai | FAL_KEY | fal-ai/seedream-v4.0, fal-ai/seedream-v5.0-lite |
| byteplus | ARK_API_KEY | seedream-5.0, seedream-4.5 |

## 출력 규약 (CRITICAL)

생성된 이미지 경로는 반드시 아래 형식으로 Bash stdout에 출력해야 한다:

```
OK:/absolute/path/to/.da-image/image-YYYYMMDD-HHmmss.png (NNN bytes)
```

이 형식이 `useStreamProcessor.ts`의 이미지 감지 정규식과 매칭되어
채팅 버블의 `ImageGallery` 컴포넌트에 자동 렌더링된다.

## 에러 처리

| 상황 | 대응 |
|------|------|
| Provider/API Key 미설정 | AskUserQuestion으로 Settings > Image 안내 |
| API 401/403 | "API 키가 유효하지 않습니다" 안내 |
| 콘텐츠 필터 차단 | blockReason 표시 + 프롬프트 수정 제안 |
| 응답에 이미지 없음 | finishReason 표시 + 상세 프롬프트 제안 |
| 네트워크 오류 | curl 실패 메시지 전달 |

## 제한사항

- 단일 이미지만 생성 (배치 불가)
- 프로젝트 에셋 통합이 필요하면 `da:asset` 사용
- 생성된 이미지는 `.da-image/`에 저장 (gitignore 권장)
