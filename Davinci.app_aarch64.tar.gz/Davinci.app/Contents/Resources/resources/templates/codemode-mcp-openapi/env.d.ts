interface Env {
  LOADER: WorkerLoader;
}
